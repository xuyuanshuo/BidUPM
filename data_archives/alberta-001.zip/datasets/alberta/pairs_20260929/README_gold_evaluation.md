# Alberta 2024 UPA: evaluate after adjudication

The workbook `阿尔伯塔人工金标模板.xlsx` contains 135 bid-form queries and the fixed 237-entry 2024 UPA catalog. It has no gold labels yet. For each bid item, two independent annotators each record all compatible UPA codes in columns H and I, then disagreements are resolved in **裁决金标代码** (column J). Separate multiple codes with English semicolons, or write `NONE` after checking the entire catalog. Enter `YES` in **全目录已核查** (column K). Do not leave a label blank to mean `NONE`. All four columns must be complete before metrics are released; only the adjudicated J column is scored. The report also counts reviewer disagreements. Do not look at the model predictions while adjudicating.

Run with the bundled Python environment after saving the filled workbook:

```bash
$SOURCE_ROOT/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  output/alberta_bge_20260929/evaluate_after_gold.py \
  --gold '/absolute/path/to/filled_gold.xlsx' \
  --output output/alberta_bge_20260929/alberta_gold_evaluation.json
```

Until all 135 rows have both valid independent labels, a valid adjudicated label, and `YES`, the script exits with status 2, prints only annotation progress, and does **not** create the JSON report or calculate metrics. It rejects unknown or repeated codes, duplicate/missing query rows, changed source item fields, altered candidate catalog, and mismatched frozen-input or score hashes. It never modifies the workbook, model scores, or thresholds. Keep the filled gold file separately from the original blank template.

The comparison uses all 31,995 query–candidate pairs. The rule accepts normalized description **and** pay-unit exact matches. The three hard-refined BGE checkpoints use the previously saved `strict_clean` scores and their original NCDOT validation thresholds, without fitting to Alberta labels. Reported metrics include pair precision/recall/F1, Hit@1/3 among gold-positive queries, `NONE` rejection, and query decision accuracy. The JSON also gives the three-seed mean, sample standard deviation, and mean difference from the exact rule. Hit@k ranks all 237 BGE candidates regardless of threshold; for the exact rule it ranks only exact candidates. Scores tied at top rank are broken by ascending pair ID and the number of tied queries is reported. Pair F1 scores every accepted candidate, while query decision accuracy requires an accepted correct top candidate or zero accepted candidates for `NONE`.

The report also isolates gold-positive queries with no *correct* exact-rule match to show whether the model recovers genuinely rule-uncovered references. The 135 bid rows contain 110 distinct normalized-description-and-unit keys. A separate 110-key sensitivity analysis is included only if gold labels and model scores agree across repeated query keys; otherwise the conflict groups are listed and no deduplicated metric is reported. The primary result remains the 135-row evaluation.

The `strict_clean` variant repeats the cleaned description in both `Description` and `Normalized` model fields. Its result is a preprocessing sensitivity estimate; avoid presenting it as a new model or a threshold tuned to this external set. Before describing Alberta as a temporally held-out test in the paper, independently confirm the bid form's tender date and the 2024 UPA report's data cutoff.
