# BidUPM-vFinal dataset audit

- Checks: 46
- Errors: 0
- Warnings: 0
- Core rows: 12000
- Added hard-positive rows: 92
- Combined rows: 12092
- Canonical training rows: 4138
- Canonical training hard positives: 111 rows, 101 directional semantic pairs
- Excluded leaking training rows: 454
- Safe Top-30 no-reference queries: 57

All defined dataset checks passed.

## Check results

- PASS: corrected core rows (observed: 12000; expected: 12000)
- PASS: hard-positive supplement rows (observed: 92; expected: 92)
- PASS: combined rows (observed: 12092; expected: 12092)
- PASS: combined pair IDs unique (observed: 0; expected: 0)
- PASS: all final labels complete (observed: 0; expected: 0)
- PASS: all final relevance complete (observed: 0; expected: 0)
- PASS: label and relevance agree (observed: 0; expected: 0)
- PASS: positive rows use conflict none (observed: 0; expected: 0)
- PASS: no directional label conflicts (observed: 0; expected: 0)
- PASS: no symmetric label conflicts (observed: 0; expected: 0)
- PASS: all dates parse (observed: 0; expected: 0)
- PASS: candidate date is strictly earlier than query date (observed: 0; expected: 0)
- PASS: same-contract candidates excluded (observed: 0; expected: 0)
- PASS: same-source-group candidates excluded (observed: 0; expected: 0)
- PASS: canonical training has no symmetric evaluation-pair leakage (observed: 0; expected: 0)
- PASS: canonical training has no evaluation query IDs (observed: 0; expected: 0)
- PASS: canonical training has no evaluation query contracts (observed: 0; expected: 0)
- PASS: canonical training has no evaluation query source groups (observed: 0; expected: 0)
- PASS: symmetric leakage keys identified (observed: 192; expected: 192)
- PASS: leaking training rows excluded (observed: 454; expected: 454)
- PASS: excluded rows cannot enter training (observed: 0; expected: 0)
- PASS: core correction rows (observed: 3; expected: 3)
- PASS: core corrections resolve to acceptable positives (observed: 0; expected: 0)
- PASS: supplement is all non-exact hard positive (observed: 0; expected: 0)
- PASS: supplement review paths complete (observed: {'two_pass_agreement': 64, 'two_pass_disagreement_adjudicated': 28}; expected: {'two_pass_agreement': 64, 'two_pass_disagreement_adjudicated': 28})
- PASS: supplement final review complete (observed: 0; expected: 0)
- PASS: supplement has no evaluation semantic-pair overlap (observed: 0; expected: 0)
- PASS: training hard-positive rows reach 100 (observed: 111; expected: >=100)
- PASS: training hard-positive directional semantic pairs reach 100 (observed: 101; expected: >=100)
- PASS: safe no-reference Top30 rows (observed: 1710; expected: 1710)
- PASS: safe no-reference query count (observed: 57; expected: 57)
- PASS: safe no-reference Top30 has no positive (observed: 0; expected: 0)
- PASS: safe no-reference has exactly 30 reviewed candidates per query (observed: {30: 57}; expected: {30: 57})
- PASS: no-reference ranks 31-100 have no known positive semantic pair (observed: 0; expected: 0)
- PASS: no-reference ranks 31-100 have no exact-description/unit anchor (observed: 0; expected: 0)
- PASS: locked rows unchanged (observed: 3000; expected: 3000)
- PASS: validation rows unchanged (observed: 900; expected: 900)
- PASS: external rows unchanged (observed: 2400; expected: 2400)
- PASS: every locked query has a positive (observed: 100; expected: 100)
- PASS: every validation query has a positive (observed: 30; expected: 30)
- PASS: review units complete (observed: 6441; expected: 6441)
- PASS: review unit IDs unique (observed: 0; expected: 0)
- PASS: review members cover every pair (observed: 12092; expected: 12092)
- PASS: every pair has A/B labels (observed: 0; expected: 0)
- PASS: final adjudication units recorded (observed: 964; expected: 964)
- PASS: six source annotation workbooks archived (observed: 6; expected: 6)
