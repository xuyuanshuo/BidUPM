# BidUPM-vFinal dataset package

This directory is the canonical input for the next experiment cycle. It contains
the corrected 12,000-row benchmark core and a training-only hard-positive
supplement. The original submitted files remain unchanged outside this directory.

## Canonical files

- `pairs/all_pairs_vfinal_12092.csv`: full auditable dataset.
- `training/training_pairs_all_rows.csv`: leakage-safe training rows.
- `training/training_pairs_semantic_deduplicated.csv`: directional semantic-pair deduplicated training set.
- `training/reranker_train_human_labeled_plus_hard.jsonl`: reranker-ready training input.
- `evaluation/validation_pairs.csv`: validation pairs.
- `evaluation/locked_pairs.csv`: locked internal test pairs.
- `evaluation/no_reference_top30_pairs.csv`: Top-30 no-reference safety evaluation.
- `evaluation/external_mixed_pairs.csv`: frozen external mixed test.
- `review/all_review_units_vfinal.csv`: final review-unit records.
- `review/final_adjudication_964.csv`: all adjudicated review units and reasons.
- `provenance/source_submissions/`: the six submitted A/B annotation workbooks.
- `quality/dataset_audit.md`: final checks and observed values.

## Repairs completed

1. Three locked rows for the reverse 24-inch drainage/side-drain pipe pair were
   corrected to `acceptable` positives, resolving the only symmetric label conflict.
2. Training rows sharing an unordered semantic pair with any evaluation split were
   marked `train_excluded_eval_semantic_overlap` and removed from canonical training.
3. Ninety-two novel, non-exact, provenance-safe hard positives were added from
   historical NCDOT bid tabs. Sixty-four have agreement from both review passes;
   twenty-eight review disagreements have a recorded final semantic adjudication.
4. Canonical training now contains at least 100 hard-positive rows and at least 100
   directional hard-positive semantic pairs after leakage removal.
5. No-reference evaluation is fixed at Top-30: 57 safe queries and 1,710 reviewed
   pairs. Ranks 31-100 retain automated consistency checks and are not part of the
   human-reviewed safety metric.

## Data use rules

- Train only from files under `training/`.
- Tune thresholds only on `evaluation/validation_pairs.csv`.
- Do not tune on Locked, No-reference, or External files.
- Report Locked, No-reference, and External metrics separately.
- The no-reference claim is limited to the retrieved Top-30 candidate set.
