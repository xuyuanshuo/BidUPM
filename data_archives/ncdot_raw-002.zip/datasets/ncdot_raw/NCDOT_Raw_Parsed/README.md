# Parsed NCDOT Raw Bid Tabs

This package parses the downloaded public NCDOT XLS bid-tab files into row-level bid items and bidder price records.

| Item | Count |
| --- | ---: |
| Parsed files | 39 |
| Parse-ok files | 39 |
| Bid item rows | 59004 |
| Bidder price records | 144993 |
| Raw rule-exact positive pairs | 8518172 |
| Capped rule-exact positive pairs | 271938 |

The exact-positive pool requires equal normalized description and unit and different source files.
