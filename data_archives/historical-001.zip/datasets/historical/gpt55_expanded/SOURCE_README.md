# BidUPM v2 Expanded GPT-5.5 Benchmark

This package expands the clean human seed benchmark with GPT-5.5-adjudicated pending clean rows.

| Item | Rows |
| --- | ---: |
| Human-checked seed pairs | 1270 |
| Human-checked seed positives | 128 |
| GPT-5.5 adjudicated pending rows | 4432 |
| GPT-5.5 adjudicated pending positives | 152 |
| Expanded rows | 5702 |
| Expanded positives | 280 |

Use this as an expanded adjudicated benchmark or annotation queue. Do not call GPT-adjudicated rows `human_checked` until a human spot-check pass is completed.
