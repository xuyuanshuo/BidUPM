# Historical confirmed gold (May 2026)

3,000 confirmed pairs from 100 query pools; a derived hard-no-exact subset contains 2,879 pairs. Earlier Qwen annotation records and risk appendices are retained as annotation evidence. Some derived result tables are included for provenance. Three byte-identical unpacked copies have been deduplicated. This older corpus does not replace current canonical labels/splits.

Source reuse/license status: not established in the supplied evidence. Original public agency materials retain their owners' rights. No new blanket data licence is granted by this package.
