# BidUPM Gold Confirmed Revised Package

Generated: 2026-05-11

This package revises `gold(1).zip` according to the user's instruction that all 3000 pre-labeled rows have already been manually confirmed.

## Main files

- `gold_eval_queries.csv`: 100 selected val/test queries.
- `gold_candidate_pairs_raw.csv`: original 30-candidate recall pool per query.
- `gold_eval_pairs.csv`: confirmed main evaluation table. All rows are `annotation_status=human_checked` and `exclude_from_main_eval=0`.
- `gold_eval_pairs_hard_no_exact.csv`: stress-test subset excluding exact relevance rows. Use this to avoid overclaiming from obvious exact matches.
- `gold_query_summary.csv`: per-query label and hard-subset coverage summary.
- `gold_risk_review_appendix.csv`: high-risk rows retained for transparency.
- `gold_eval_qwen_annotations.jsonl`: original Qwen annotation trace.
- `gold_eval_annotation_summary.json`: counts and baseline snapshots.

## Important interpretation

The main set is now usable as a confirmed small gold set. However, main-set Top-1 is very easy because every query has at least one strong positive, often at rank 1. Report the hard subset alongside the main set.

Recommended reporting:

1. Pair-level F1/Precision/Recall on `gold_eval_pairs.csv`.
2. Ranking metrics on `gold_eval_pairs.csv`, but note it is an easy positive-existing set.
3. Stress-test metrics on `gold_eval_pairs_hard_no_exact.csv`.
4. Do not claim this is the final large benchmark; it is the 100-query gold pilot.
