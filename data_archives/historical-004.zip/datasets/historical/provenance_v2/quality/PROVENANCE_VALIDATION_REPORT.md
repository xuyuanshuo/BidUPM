# Provenance Validation Report

- all checks passed: `True`
- allowed sources: `11`
- query rows: `10358`
- candidate rows: `1719`
- confirmed rows: `2449`
- confirmed clean rows: `1270`
- pending review rows: `9565`

## Source Counts

{
  "queries_by_scope": {
    "ncdot_10_links": 10223,
    "user_original": 135
  },
  "candidates_by_scope": {
    "ncdot_10_links": 1584,
    "user_original": 135
  },
  "confirmed_same_form_flag": {
    "0": 1270,
    "1": 1179
  },
  "pending_same_form_flag": {
    "1": 5133,
    "0": 4432
  }
}

## Quality Checks

{
  "allowed_sources_11": true,
  "no_alberta_candidates_in_main": true,
  "confirmed_only_human_checked": true,
  "pending_only_needs_review": true,
  "all_confirmed_pass_source_rule": true,
  "all_pending_pass_source_rule": true,
  "clean_confirmed_has_no_same_form_candidate": true,
  "clean_pending_has_no_same_form_candidate": true,
  "all_checks_passed": true
}
