# Historical price_case_v1

Distinct earlier corpus/version retained for reproducibility. Consult SOURCE_README.md and source data cards for historical scope and annotation status. These files do not replace the 12,092-pair canonical benchmark. GPT-adjudicated or pending review rows must not be described as human gold. Duplicate source hashes are represented by aliases in datasets/manifest.json.

Source reuse/license status: not established in the supplied evidence. Original public agency materials retain their owners' rights. No new blanket data licence is granted by this package.
