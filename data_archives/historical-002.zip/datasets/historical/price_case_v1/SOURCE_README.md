# BidUPM Publication Dataset Package v1

This package is organized for paper-grade dataset development. It separates
confirmed gold labels from pending review rows and keeps source provenance next
to every processed and annotation table.

| Item | Value |
| --- | ---: |
| Query items | 10358 |
| Candidate items | 2377 |
| Price records | 7154 |
| Annotation queries | 500 |
| Annotation pairs | 15000 |
| Pending review rows | 12000 |
| All structural checks passed | True |

## Main Tables

- `data/processed/query_items.csv`
- `data/processed/candidate_items.csv`
- `data/processed/price_records.csv`
- `annotation/paper_gold_pairs_for_review_enriched.csv`
- `annotation/paper_gold_review_queue_enriched.csv`
- `annotation/paper_gold_confirmed_seed_pairs_enriched.csv`
- `metadata/data_sources.csv`
- `metadata/source_manifest.csv`

## Important Rule

Only rows with `paper_gold_status = confirmed_seed_gold` are confirmed labels
right now. Rows marked `pending_review` are structured annotation candidates and
must be reviewed before final benchmark reporting.
