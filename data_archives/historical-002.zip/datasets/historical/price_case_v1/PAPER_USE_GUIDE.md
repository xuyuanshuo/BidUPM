# Paper Use Guide

Recommended paper tracks:

- `primary_confirmed_gold`: confirmed labels whose candidates come from primary
  Alberta price/catalog sources.
- `confirmed_external_stress`: confirmed labels involving external bid-tab
  candidates; useful for stress analysis, but disclose provenance caveats.
- `primary_after_human_review`: rows that can enter the final main benchmark
  after human review.
- `external_stress_after_provenance_or_review`: rows for external stress tests
  after review or candidate-provenance repair.

Do not report final metrics on `pending_review` rows. Report the number of
queries with positives and no positives separately for ranking metrics.

The safest paper claim remains: cheap retrieval provides candidate pools, and
semantic verification/routing improves hard conflict judgment. Do not claim that
legacy prelabels are expert gold labels.
