# Data Card

## Task

BidUPM evaluates bid-item to historical unit-price reference matching. Given a
query bid item, the system retrieves candidate historical items and judges
whether each candidate is a valid unit-price reference.

## Sources

- Alberta Unit Prices and Cost Adjustments: https://www.alberta.ca/unit-prices-and-cost-adjustments
- Alberta Bid Item List workbook URL recorded in `metadata/data_sources.csv`.
- NCDOT Central Letting bid tabs URLs recorded in `metadata/data_sources.csv`.
- One client-provided bid-form workbook has no public URL in the handoff.

## Label Status

The package intentionally distinguishes confirmed labels from review candidates.
The legacy delivery pair table is preserved under `data/legacy/` but is not
treated as final gold because prior audits found stale-label risks. The 500-query
annotation table is the correct path for maturing the benchmark.

## Leakage Caveat

`NCDOT_BID_TAB` candidate rows do not preserve row-level source bid-form IDs.
Rows involving external bid-tab candidates are explicitly flagged with
`source_leakage_risk`. Use primary Alberta sources for the cleanest main paper
track, and keep NCDOT candidate rows as external stress/distractor rows until
candidate provenance is repaired.
