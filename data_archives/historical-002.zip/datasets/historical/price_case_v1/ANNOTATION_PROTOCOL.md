# Annotation Protocol

Use `annotation/paper_gold_review_queue_enriched.csv` as the master queue.

Valid final labels:

- `exact`: same item, compatible unit and specs, label 1.
- `acceptable`: wording differs but it is a safe unit-price reference, label 1.
- `related`: same broad family but unsafe direct reference, label 0.
- `wrong`: different item/category, label 0.

Default to negative when there is a real unit, spec, material, action, scope, or
generic-specific conflict. Do not force every query to have a positive candidate.
After reviewing candidates for a query, update query-level positive/no-positive
status using `annotation/query_positive_status_review.csv`.

Review priority:

1. high-similarity traps and hard unit/spec/action conflicts;
2. prelabel rows and easy exact candidates;
3. low-score likely negatives and standard rows.
