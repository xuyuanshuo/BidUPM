# Controlled diagnostic challenge (600 pairs)

600 constructed pairs clustered into 300 real-source anchors; 300 provisional positives and 300 single-attribute negatives. Construction labels are provisional; independent human annotation is incomplete. Source contracts are excluded from canonical benchmark contracts. Version v3 (observed dimension values) is frozen; obsolete v1/v2 snapshots are omitted. Model input files omit labels and transformation rationale. Do not treat this as a naturally occurring 600-project corpus or human gold. Prospective natural candidate mining evidence is separate under natural_candidate_mining/.

Source reuse/license status: not established in the supplied evidence. Original public agency materials retain their owners' rights. No new blanket data licence is granted by this package.
