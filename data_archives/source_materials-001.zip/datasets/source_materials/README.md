# Source item corpus and original forms

Original available NCDOT central-let bid-tab workbooks and the historical user-supplied bid form. The all_bid_items_raw_normalized table retains parsed NCDOT/WSDOT/Caltrans records and price fields. Frozen Top-100 retrieval tables/query selections are historical candidate-generation artifacts with provisional labels, not current gold. Eight WSDOT source workbook names appear in canonical provenance but the original Excel bytes were not found locally; their public URLs and parsed rows are retained. SHA aliases refer to identical original files already stored under ncdot_raw. User-supplied form publication rights are not established.

Source reuse/license status: not established in the supplied evidence. Original public agency materials retain their owners' rights. No new blanket data licence is granted by this package.
