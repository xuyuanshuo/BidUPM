# Historical Alberta UPA code anchors and price case data

2019–2026 UPA entries and code-anchored cross-year pairs preserved from an earlier experiment, plus held-out 2026 price-case outputs and provenance. Code anchors are deterministic identities and are not independently human-reviewed semantic-match labels. Price-case predictions are derived results; they must not be confused with the current 135-query bid-form evaluation.

Source reuse/license status: not established in the supplied evidence. Original public agency materials retain their owners' rights. No new blanket data licence is granted by this package.
