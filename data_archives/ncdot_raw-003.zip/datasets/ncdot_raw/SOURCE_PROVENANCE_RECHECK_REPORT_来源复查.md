# BidUPM 原始文件与来源链接复查

复查时间：`2026-05-13T21:50:38`。

## 复查结果

- NCDOT 原始下载清单行数：`49`。
- 下载清单标记成功行数：`49`。
- 项目内原始文件存在数：`49`。
- 英文交付文件夹内原始文件存在数：`49`。
- 中文交付文件夹内原始文件存在数：`49`。
- 原始表解析成功数：`49`。
- 论文主数据集允许来源行数：`11`。

## 已包含的原始层

- 原始 XLS 文件：`06_原始超大全量数据_Raw_Large_Data/NCDOT_Raw_Downloads/raw/`。
- 原始下载 URL 清单：`06_原始超大全量数据_Raw_Large_Data/NCDOT_Raw_Downloads/download_manifest.csv`。
- 原始解析后的 bid items 和 price records：`06_原始超大全量数据_Raw_Large_Data/NCDOT_Raw_Parsed/`。
- 逐文件复查表：`06_原始超大全量数据_Raw_Large_Data/raw_file_source_recheck.csv`。

## 主数据集来源链接

- `BF001` Client-provided Bid Form workbook: `local:archive/投标表Bid form.xlsx`
- `BF002` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/03-24-2026%20Central%20Letting/L260324%20XLS%20Bid%20Tabs.xls`
- `BF003` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/03-17-2026%20Central%20Letting/L260317%20XLS%20Bid%20Tabs.xls`
- `BF004` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/02-17-2026%20Central%20Letting/L260217%20XLS%20Bid%20Tabs.xls`
- `BF005` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/01-22-2026%20Central%20Letting/L260122%20XLS%20Bid%20Tabs.xls`
- `BF006` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/01-20-2026%20Central%20Letting/L260120%20XLS%20Bid%20Tabs.xls`
- `BF007` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/12-16-2025%20Central%20Letting/L251216%20XLS%20Bid%20Tabs.xls`
- `BF008` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/11-18-2025%20Central%20Letting/L251118%20XLS%20Bid%20Tabs.xls`
- `BF009` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/10-21-2025%20Central%20Letting/L251021%20XLS%20Bid%20Tabs.xls`
- `BF010` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/09-16-2025%20Central%20Letting/L250916%20XLS%20Bid%20Tabs.xls`
- `BF011` NCDOT Central Let Bid Tabs: `https://connect.ncdot.gov/letting/Central%20Letting/08-19-2025%20Central%20Letting/Bid%20Tabs%20xls.xls`

`BF001` 是用户本地提供的原始工作簿；公开 NCDOT 来源都保留在 metadata 和 raw download manifest 的 URL 字段里。
