# Raw NCDOT large corpus

59,004 raw bid-item rows and 144,993 raw price records from 39 parsed public bid-tab workbooks. Deterministic exact-rule mined pairs are separate: capped 271,938 rows and full 8,518,172 rows. These rule-exact positives are not human-reviewed semantic gold. The full 4.94GB source CSV is losslessly represented as ordered gzip shards with its original header repeated. Use full_pairs/manifest.json to reconstruct the original bytes and verify the full-source hash. Raw HTML listing, source recheck and download/parse manifests are retained. Source reuse/license status is unknown.

Source reuse/license status: not established in the supplied evidence. Original public agency materials retain their owners' rights. No new blanket data licence is granted by this package.
