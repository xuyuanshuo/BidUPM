# BidUPM Pain-Point Gold Validation Dataset Check

Dataset: `bidupm_painpoint_gold_validation_500q_20260512`

## Status

All structural checks passed: `True`

## Size

| Item | Value |
| --- | ---: |
| Queries | 500 |
| Pairs | 15000 |
| Candidates per query min | 30 |
| Candidates per query max | 30 |
| Confirmed seed pairs | 3000 |
| Pending review pairs | 12000 |
| Queries with confirmed positive | 100 |
| Queries with provisional positive | 213 |
| Queries needing positive/no-positive decision | 287 |

## Splits

| Split | Queries | Pairs |
| --- | ---: | ---: |
| val | 200 | 6000 |
| test | 300 | 9000 |

## Pain-Point Buckets

| review_bucket | test | val | total |
| --- | --- | --- | --- |
| standard_review | 2613 | 1492 | 4105 |
| hard_unit_conflict | 2287 | 1270 | 3557 |
| high_similarity_trap_check | 1937 | 1320 | 3257 |
| confirmed_seed | 1500 | 1500 | 3000 |
| easy_exact_candidate_check | 252 | 154 | 406 |
| hard_spec_conflict | 251 | 133 | 384 |
| likely_negative_low_score | 114 | 106 | 220 |
| prelabeled_review | 39 | 19 | 58 |
| hard_action_conflict | 7 | 6 | 13 |

## Structural Checks

- `query_rows_500`: `True`
- `pair_rows_15000`: `True`
- `raw_pair_rows_match`: `True`
- `candidate_count_exact_30_for_each_query`: `True`
- `no_duplicate_query_candidate_pairs`: `True`
- `query_splits_only_val_test`: `True`
- `pair_splits_only_val_test`: `True`
- `required_query_columns_present`: `True`
- `required_pair_columns_present`: `True`
- `confirmed_seed_only_human_checked`: `True`
- `review_queue_only_needs_human_review`: `True`
- `confirmed_seed_pair_count_3000`: `True`
- `pending_review_pair_count_12000`: `True`
- `initial_rank_range_1_to_30`: `True`

## Review Order

1. Start with `painpoint_review_queue_top500.csv`.
2. Then review `painpoint_hard_unit_conflict.csv`, `painpoint_hard_spec_conflict.csv`, `painpoint_hard_action_conflict.csv`, and `painpoint_high_similarity_trap_check.csv`.
3. Use `query_positive_status_review.csv` to decide query-level positive/no-positive status after candidate review.
4. Treat only `annotation_status = human_checked` rows as final gold labels.
5. Do not compute final benchmark metrics on the expanded rows until pending rows are confirmed.

## Validation Files

- `structure_validation_summary.json`
- `STRUCTURE_VALIDATION_REPORT.md`
- `painpoint_review_bucket_summary.csv`
- `query_positive_status_review.csv`
- `painpoint_review_queue_top500.csv`
- `painpoint_hard_unit_conflict.csv`
- `painpoint_hard_spec_conflict.csv`
- `painpoint_hard_action_conflict.csv`
- `painpoint_high_similarity_trap_check.csv`
- `painpoint_easy_exact_candidate_check.csv`
- `painpoint_prelabeled_review.csv`
- `painpoint_likely_negative_low_score.csv`
- `painpoint_standard_review.csv`
