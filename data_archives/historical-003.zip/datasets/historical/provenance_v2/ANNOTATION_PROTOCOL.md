# Annotation Protocol

Labels:

- `exact`: same item, same key specification, compatible unit
- `acceptable`: usable historical reference despite minor wording/spec variance
- `related`: same family but not reliable enough for direct reference
- `wrong`: not a valid reference

Binary mapping:

- `exact` and `acceptable` -> `label=1`
- `related` and `wrong` -> `label=0`

Every reviewed row must preserve the query text, candidate text, source IDs,
source URLs, decision, difficulty, match type, and reason.
