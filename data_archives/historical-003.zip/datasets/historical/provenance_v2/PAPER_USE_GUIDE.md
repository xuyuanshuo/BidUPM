# Paper Use Guide

Recommended benchmark file:

`annotation/confirmed_gold_pairs_clean_no_same_form.csv`

Recommended metrics:

- pair-level classification: Accuracy, Precision, Recall, F1
- query-level ranking: Top-1, Recall@3, Recall@5, MRR, nDCG@5

Do not report final metrics on:

- `annotation/review_queue_allowed.csv`
- `annotation/review_queue_clean_no_same_form.csv`

Those files still need human review.
