# Data Card

## Task

BidUPM evaluates bid-item matching: given a query bid item, rank candidate
historical or external bid items and decide whether each candidate is a valid
reference match.

## Source Rule

The main dataset only uses rows traceable to the user-provided original bid form
or the ten NCDOT links. Alberta price/catalog rows are intentionally excluded
from this package's main experiment tables.

## Known Limitation

Original NCDOT candidate rows were deduplicated without row-level bid-form
provenance. This package repairs provenance by matching candidate
description+unit back to BF002-BF011 query rows and flags candidates that may
come from the same bid form as the query.
