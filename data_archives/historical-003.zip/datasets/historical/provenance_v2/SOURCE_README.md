# BidUPM Provenance Dataset v2

This package is the provenance-restricted main experiment dataset.

Allowed main sources:

- `BF001`: user-provided original bid form.
- `BF002`-`BF011`: the ten NCDOT bid-tab links recorded in `metadata/allowed_sources.csv`.

Excluded from the main matching dataset:

- `AT_UPA`
- `AB_BID_ITEM_LIST`
- any row without a valid allowed source URL or user-original source record

## Size

| Item | Rows |
| --- | ---: |
| Query items | 10358 |
| Candidate items | 1719 |
| Confirmed gold pairs | 2449 |
| Confirmed clean no-same-form pairs | 1270 |
| Pending review pairs | 9565 |

## Main Rule

Use `annotation/confirmed_gold_pairs_clean_no_same_form.csv` for the cleanest
paper benchmark. Use `annotation/confirmed_gold_pairs_allowed.csv` only when you
want the broader NCDOT-only confirmed set with leakage flags retained.

Pending rows are not final labels. They are structured review candidates.
