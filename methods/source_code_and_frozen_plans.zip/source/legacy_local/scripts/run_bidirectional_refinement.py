#!/usr/bin/env python3
"""Test a validation-frozen bidirectional cross-encoder hard-case refinement."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import SEED, conflict_gate, evaluate_scores, load_data, write_json  # noqa: E402
from run_cross_encoder_local import predict  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--experiment-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--bootstrap", type=int, default=5000)
    return parser.parse_args()


def swap_roles(frame: pd.DataFrame) -> pd.DataFrame:
    swapped = frame.copy()
    suffixes = [
        "description",
        "normalized_description",
        "normalized_unit",
        "category",
        "spec_tokens",
    ]
    for suffix in suffixes:
        query = f"query_{suffix}"
        candidate = f"candidate_{suffix}"
        swapped[query] = frame[candidate].to_numpy()
        swapped[candidate] = frame[query].to_numpy()
    return swapped


def main() -> None:
    args = parse_args()
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    _, _, evaluation, hashes = load_data(args.data_dir)
    reversed_evaluation = swap_roles(evaluation)
    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    configurations = [
        {
            "label": "minilm_l6_zero_shot",
            "model": "cross-encoder/ms-marco-MiniLM-L-6-v2",
            "forward_file": args.experiment_root / "minilm_l6" / "pair_scores.csv",
            "forward_column": "score_minilm_l6_zero_shot",
            "batch_size": 32,
        },
        {
            "label": "minilm_l6_standard",
            "model": args.experiment_root / "minilm_l6" / "checkpoint_standard",
            "forward_file": args.experiment_root / "minilm_l6" / "pair_scores.csv",
            "forward_column": "score_minilm_l6_standard",
            "batch_size": 32,
        },
        {
            "label": "minilm_l12_standard",
            "model": args.experiment_root / "minilm_l12" / "checkpoint_standard",
            "forward_file": args.experiment_root / "minilm_l12" / "pair_scores.csv",
            "forward_column": "score_minilm_l12_standard",
            "batch_size": 24,
        },
    ]
    score_columns: dict[str, str] = {}
    timing: dict[str, float] = {}
    for config in configurations:
        saved = pd.read_csv(config["forward_file"])
        forward_lookup = saved.set_index("pair_id")[config["forward_column"]]
        forward = evaluation["pair_id"].map(forward_lookup).to_numpy(dtype=float)
        model_source = str(config["model"])
        tokenizer = AutoTokenizer.from_pretrained(model_source)
        model = AutoModelForSequenceClassification.from_pretrained(model_source).to(device)
        reverse, seconds = predict(
            model,
            tokenizer,
            reversed_evaluation,
            device,
            int(config["batch_size"]),
            256,
        )
        label = str(config["label"])
        combinations = {
            f"{label}_forward": forward,
            f"{label}_bidirectional_mean": (forward + reverse) / 2.0,
            f"{label}_bidirectional_max": np.maximum(forward, reverse),
            f"{label}_bidirectional_min": np.minimum(forward, reverse),
        }
        for name, values in combinations.items():
            column = f"score_{name}"
            evaluation[column] = values
            score_columns[name] = column
            if "bidirectional" in name:
                gated_name = f"{name}_conflict_refined"
                gated_column = f"score_{gated_name}"
                evaluation[gated_column] = conflict_gate(evaluation, values, strength=1.0)
                score_columns[gated_name] = gated_column
        evaluation[f"score_{label}_reverse"] = reverse
        timing[f"{label}_reverse_seconds"] = seconds
        del model
        if device.type == "mps":
            torch.mps.empty_cache()

    _, metrics, _, _ = evaluate_scores(
        evaluation,
        score_columns,
        args.output_dir,
        bootstrap_samples=args.bootstrap,
        seed=SEED,
    )
    score_output_columns = [
        "pair_id",
        "evaluation_split",
        "query_id",
        "candidate_id",
        "final_label",
        "final_relevance",
        "difficulty",
        "final_conflict_type",
        *[column for column in evaluation if column.startswith("score_")],
    ]
    evaluation[score_output_columns].to_csv(args.output_dir / "pair_scores.csv", index=False)
    manifest = {
        "status": "complete",
        "paper_eligible": True,
        "method": (
            "Score each pair in query-candidate and candidate-query order; combine by mean, "
            "max, or min; select all thresholds on validation only."
        ),
        "reason": (
            "MS MARCO cross-encoders are direction-sensitive, while bid-item compatibility "
            "is intended to be symmetric."
        ),
        "models": [str(config["label"]) for config in configurations],
        "device": str(device),
        "input_hashes": hashes,
        "timing": timing,
        "bootstrap_samples": args.bootstrap,
        "seed": SEED,
    }
    write_json(args.output_dir / "manifest.json", manifest)
    locked = metrics[(metrics["split"].eq("locked")) & (metrics["policy"].eq("f1_opt"))]
    locked = locked.sort_values(["hard_pair_f1", "pair_f1"], ascending=False)
    print(json.dumps(manifest, indent=2))
    print(
        locked[
            ["model", "top1", "recall_at_5", "pair_f1", "hard_pair_f1", "tp", "fp", "fn"]
        ].head(20).to_string(index=False)
    )


if __name__ == "__main__":
    main()
