#!/usr/bin/env python3
"""Run fast, non-neural BidUPM-vFinal experiments on the canonical dataset."""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import cohen_kappa_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import (  # noqa: E402
    CONFLICT_FLAG_COLUMNS,
    EVALUATION_SPLITS,
    SEED,
    evaluate_scores,
    load_data,
    normalize_text,
    per_query_ranking,
    select_threshold,
    sha256,
    write_json,
)


TOKEN_RE = re.compile(r"[a-z0-9]+")
BASE_FEATURES = [
    "score_tfidf",
    "score_bm25",
    "sequence_ratio",
    "token_jaccard",
    "token_containment",
    "exact_description",
]
STRUCTURED_FEATURES = ["unit_match", "category_match", "item_code_match"]
ALL_FEATURES = BASE_FEATURES + STRUCTURED_FEATURES + CONFLICT_FLAG_COLUMNS


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=SEED)
    return parser.parse_args()


def tokenize(text: object) -> list[str]:
    return TOKEN_RE.findall(normalize_text(text))


class BM25Scorer:
    def __init__(self, documents: list[str], k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b
        tokenized = [tokenize(document) for document in documents]
        self.avgdl = float(np.mean([len(tokens) for tokens in tokenized]))
        self.n = len(tokenized)
        document_frequency: Counter[str] = Counter()
        for tokens in tokenized:
            document_frequency.update(set(tokens))
        self.idf = {
            token: math.log(1.0 + (self.n - count + 0.5) / (count + 0.5))
            for token, count in document_frequency.items()
        }

    def score(self, query: object, document: object) -> float:
        query_tokens = set(tokenize(query))
        document_tokens = tokenize(document)
        frequency = Counter(document_tokens)
        length_norm = self.k1 * (
            1.0 - self.b + self.b * len(document_tokens) / max(self.avgdl, 1e-12)
        )
        return float(
            sum(
                self.idf.get(token, 0.0)
                * frequency[token]
                * (self.k1 + 1.0)
                / (frequency[token] + length_norm)
                for token in query_tokens
                if frequency[token]
            )
        )


def add_lexical_scores(all_frame: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, float]]:
    frame = all_frame.copy()
    query_text = frame["query_normalized_description"].map(normalize_text)
    candidate_text = frame["candidate_normalized_description"].map(normalize_text)
    candidate_corpus = list(dict.fromkeys(candidate_text.tolist()))
    timings: dict[str, float] = {}

    start = time.perf_counter()
    vectorizer = TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),
        min_df=1,
        sublinear_tf=True,
        norm="l2",
        token_pattern=r"(?u)\b[a-z0-9][a-z0-9.-]*\b",
    )
    vectorizer.fit(candidate_corpus)
    query_matrix = vectorizer.transform(query_text)
    candidate_matrix = vectorizer.transform(candidate_text)
    frame["score_tfidf"] = np.asarray(query_matrix.multiply(candidate_matrix).sum(axis=1)).ravel()
    timings["tfidf_total_seconds"] = time.perf_counter() - start

    start = time.perf_counter()
    bm25 = BM25Scorer(candidate_corpus)
    frame["score_bm25_raw"] = [
        bm25.score(query, candidate) for query, candidate in zip(query_text, candidate_text)
    ]
    scale = float(np.quantile(frame["score_bm25_raw"], 0.99))
    frame["score_bm25"] = (frame["score_bm25_raw"] / max(scale, 1e-12)).clip(0, 1)
    timings["bm25_total_seconds"] = time.perf_counter() - start

    frame["score_exact_description"] = frame["exact_description"].astype(float)
    frame["score_token_jaccard"] = frame["token_jaccard"].astype(float)
    frame["score_rapidfuzz"] = frame["sequence_ratio"].astype(float)
    frame["score_retrieval_generator"] = frame["retrieval_score"].astype(float)
    frame["score_hybrid_fixed"] = (
        0.26 * frame["score_tfidf"]
        + 0.23 * frame["score_bm25"]
        + 0.20 * frame["sequence_ratio"]
        + 0.12 * frame["token_containment"]
        + 0.08 * frame["token_jaccard"]
        + 0.07 * frame["unit_match"]
        + 0.04 * frame["category_match"]
    )
    any_conflict = frame[CONFLICT_FLAG_COLUMNS].max(axis=1).astype(float)
    frame["score_hybrid_conflict_refined"] = (
        frame["score_hybrid_fixed"]
        - 0.20 * (1.0 - frame["unit_match"].astype(float))
        - 0.15 * any_conflict
    )
    timings["rows_scored"] = len(frame)
    timings["tfidf_rows_per_second"] = len(frame) / max(timings["tfidf_total_seconds"], 1e-12)
    timings["bm25_rows_per_second"] = len(frame) / max(timings["bm25_total_seconds"], 1e-12)
    return frame, timings


def fit_feature_model(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    features: list[str],
    seed: int,
) -> tuple[Pipeline, float, float, float]:
    best = None
    for c_value in [0.01, 0.1, 1.0, 10.0]:
        model = Pipeline(
            [
                ("scale", StandardScaler()),
                (
                    "logistic",
                    LogisticRegression(
                        C=c_value,
                        class_weight="balanced",
                        max_iter=5000,
                        random_state=seed,
                    ),
                ),
            ]
        )
        model.fit(train[features], train["final_label"].astype(int))
        score = model.predict_proba(validation[features])[:, 1]
        threshold, metrics = select_threshold(
            validation["final_label"].to_numpy(int), score, "f1_opt"
        )
        key = (float(metrics["pair_f1"]), float(metrics["pair_precision"]), -c_value)
        if best is None or key > best[0]:
            best = (key, model, c_value, threshold)
    assert best is not None
    return best[1], float(best[2]), float(best[3]), float(best[0][0])


def add_feature_models(
    train: pd.DataFrame,
    frame: pd.DataFrame,
    seed: int,
) -> tuple[pd.DataFrame, list[dict[str, object]], dict[str, float]]:
    output = frame.copy()
    validation = output[output["evaluation_split"].eq("validation")]
    definitions = {
        "feature_full": ALL_FEATURES,
        "feature_description_only": BASE_FEATURES,
        "feature_no_unit": [column for column in ALL_FEATURES if column != "unit_match"],
        "feature_no_category_specs": [
            column
            for column in ALL_FEATURES
            if column not in {"category_match", "item_code_match", "class_conflict", "type_conflict", "spec_conflict"}
        ],
        "feature_no_conflicts": BASE_FEATURES + STRUCTURED_FEATURES,
    }
    records = []
    timings = {}
    for name, features in definitions.items():
        start = time.perf_counter()
        model, c_value, threshold, val_f1 = fit_feature_model(train, validation, features, seed)
        output[f"score_{name}"] = model.predict_proba(output[features])[:, 1]
        elapsed = time.perf_counter() - start
        timings[f"{name}_fit_and_score_seconds"] = elapsed
        logistic = model.named_steps["logistic"]
        records.append(
            {
                "model": name,
                "features": features,
                "selected_c": c_value,
                "validation_threshold_during_selection": threshold,
                "validation_f1_during_selection": val_f1,
                "intercept": logistic.intercept_.tolist(),
                "coefficients": logistic.coef_.tolist(),
            }
        )
    return output, records, timings


def annotation_statistics(data_dir: Path) -> dict[str, object]:
    units = pd.read_csv(
        data_dir / "review" / "all_review_units_vfinal.csv", dtype=str, keep_default_na=False
    )
    canonical_path = data_dir / "quality" / "annotation_summary.json"
    canonical = json.loads(canonical_path.read_text(encoding="utf-8"))
    binary_a = units["annotator_a_label"].astype(int)
    binary_b = units["annotator_b_label"].astype(int)
    relevance_order = ["wrong", "related", "acceptable", "exact"]
    rel_a = pd.Categorical(units["annotator_a_relevance"], categories=relevance_order, ordered=True).codes
    rel_b = pd.Categorical(units["annotator_b_relevance"], categories=relevance_order, ordered=True).codes
    conflict_a = units["annotator_a_conflict_type"].astype(str)
    conflict_b = units["annotator_b_conflict_type"].astype(str)
    return {
        "reporting_note": (
            "Paper-facing agreement uses the canonical core pair-weighted statistics. "
            "The 92 hard-positive supplement units followed a separate two-pass review "
            "and are not pooled into the core Kappa estimates."
        ),
        "canonical": {
            "review_units": int(canonical["review_units"]),
            "underlying_pairs": int(canonical["underlying_pairs"]),
            "final_adjudication_units": int(canonical["final_adjudication_units"]),
            "core_review_units": int(canonical["core_review_units"]),
            "core_raw_binary_agreement": float(canonical["core_raw_binary_agreement"]),
            "core_cohen_kappa_binary": float(canonical["core_cohen_kappa_binary"]),
            "core_raw_relevance_agreement": float(canonical["core_raw_relevance_agreement"]),
            "core_weighted_kappa_relevance_quadratic": float(
                canonical["core_weighted_kappa_relevance_quadratic"]
            ),
            "supplement_review_units": int(canonical["supplement_review_units"]),
            "supplement_two_pass_agreement": int(canonical["supplement_two_pass_agreement"]),
            "supplement_two_pass_disagreement_adjudicated": int(
                canonical["supplement_two_pass_disagreement_adjudicated"]
            ),
        },
        "all_review_units_unweighted_diagnostic": {
            "review_units": len(units),
            "binary_raw_agreement": float((binary_a == binary_b).mean()),
            "binary_cohen_kappa": float(cohen_kappa_score(binary_a, binary_b)),
            "binary_disagreements": int((binary_a != binary_b).sum()),
            "relevance_raw_agreement": float((rel_a == rel_b).mean()),
            "relevance_cohen_kappa_unweighted": float(cohen_kappa_score(rel_a, rel_b)),
            "relevance_cohen_kappa_quadratic": float(
                cohen_kappa_score(rel_a, rel_b, weights="quadratic")
            ),
            "relevance_disagreements": int((rel_a != rel_b).sum()),
            "conflict_raw_agreement": float((conflict_a == conflict_b).mean()),
            "conflict_cohen_kappa": float(cohen_kappa_score(conflict_a, conflict_b)),
            "conflict_disagreements": int((conflict_a != conflict_b).sum()),
            "units_with_adjudicator_field": int(
                units["adjudicator_label"].astype(str).str.strip().ne("").sum()
            ),
        },
        "canonical_summary_sha256": sha256(canonical_path),
    }


def split_statistics(data_dir: Path) -> pd.DataFrame:
    all_pairs = pd.read_csv(
        data_dir / "pairs" / "all_pairs_vfinal_12092.csv", dtype=str, keep_default_na=False
    )
    all_pairs["final_label"] = all_pairs["final_label"].astype(int)
    rows = []
    for split, group in all_pairs.groupby("split_final", sort=False):
        rows.append(
            {
                "split": split,
                "pairs": len(group),
                "queries": group["query_id"].nunique(),
                "positive": int(group["final_label"].sum()),
                "negative": int(len(group) - group["final_label"].sum()),
                "hard_rows": int(group["difficulty"].eq("hard").sum()),
                "hard_positive": int(
                    (group["difficulty"].eq("hard") & group["final_label"].eq(1)).sum()
                ),
                "exact": int(group["final_relevance"].eq("exact").sum()),
                "acceptable": int(group["final_relevance"].eq("acceptable").sum()),
                "related": int(group["final_relevance"].eq("related").sum()),
                "wrong": int(group["final_relevance"].eq("wrong").sum()),
            }
        )
    return pd.DataFrame(rows)


def conflict_metrics(frame: pd.DataFrame, score_columns: dict[str, str], thresholds: pd.DataFrame) -> pd.DataFrame:
    from local_experiment_utils import f1_counts

    rows = []
    locked = frame[frame["evaluation_split"].eq("locked")]
    threshold_map = thresholds[thresholds["policy"].eq("f1_opt")].set_index("model")["threshold"]
    for model, score_column in score_columns.items():
        threshold = float(threshold_map[model])
        for conflict, group in locked.groupby("final_conflict_type", sort=True):
            metrics = f1_counts(
                group["final_label"].to_numpy(int), group[score_column].to_numpy(float), threshold
            )
            rows.append({"model": model, "conflict_type": conflict, **metrics})
    return pd.DataFrame(rows)


def threshold_sensitivity(frame: pd.DataFrame, score_columns: dict[str, str]) -> pd.DataFrame:
    from local_experiment_utils import f1_counts

    validation = frame[frame["evaluation_split"].eq("validation")]
    rows = []
    for model, column in score_columns.items():
        scores = validation[column].to_numpy(float)
        for threshold in np.unique(np.quantile(scores, np.linspace(0, 1, 101))):
            metrics = f1_counts(validation["final_label"].to_numpy(int), scores, float(threshold))
            rows.append({"model": model, "threshold": float(threshold), **metrics})
    return pd.DataFrame(rows)


def paired_bootstrap(frame: pd.DataFrame, score_columns: dict[str, str], samples: int, seed: int) -> pd.DataFrame:
    locked = frame[frame["evaluation_split"].eq("locked")]
    per_model = {
        model: per_query_ranking(locked, column).set_index("query_id")
        for model, column in score_columns.items()
    }
    reference = "feature_full" if "feature_full" in per_model else "hybrid_conflict_refined"
    rng = np.random.default_rng(seed)
    rows = []
    for model, values in per_model.items():
        if model == reference:
            continue
        common = per_model[reference].index.intersection(values.index)
        for metric in ["top1", "recall_at_5", "mrr", "ndcg_at_5_graded"]:
            difference = (
                per_model[reference].loc[common, metric].to_numpy(float)
                - values.loc[common, metric].to_numpy(float)
            )
            draws = rng.choice(difference, size=(samples, len(difference)), replace=True).mean(axis=1)
            p_two_sided = float(2 * min((draws <= 0).mean(), (draws >= 0).mean()))
            rows.append(
                {
                    "reference_model": reference,
                    "comparison_model": model,
                    "metric": metric,
                    "queries": len(common),
                    "mean_difference": float(difference.mean()),
                    "ci_low": float(np.quantile(draws, 0.025)),
                    "ci_high": float(np.quantile(draws, 0.975)),
                    "bootstrap_p_two_sided": min(p_two_sided, 1.0),
                    "samples": samples,
                }
            )
    return pd.DataFrame(rows)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    train_all, train_dedup, evaluation, hashes = load_data(args.data_dir)
    combined = pd.concat([train_dedup.assign(evaluation_split="train"), evaluation], ignore_index=True)
    combined, lexical_timing = add_lexical_scores(combined)
    train_scored = combined[combined["evaluation_split"].eq("train")].copy()
    eval_scored = combined[~combined["evaluation_split"].eq("train")].copy()
    eval_scored, feature_models, feature_timing = add_feature_models(
        train_scored, eval_scored, args.seed
    )

    score_columns = {
        "exact_description": "score_exact_description",
        "token_jaccard": "score_token_jaccard",
        "rapidfuzz": "score_rapidfuzz",
        "tfidf": "score_tfidf",
        "bm25": "score_bm25_raw",
        "retrieval_generator": "score_retrieval_generator",
        "hybrid_fixed": "score_hybrid_fixed",
        "hybrid_conflict_refined": "score_hybrid_conflict_refined",
        "feature_full": "score_feature_full",
        "feature_description_only": "score_feature_description_only",
        "feature_no_unit": "score_feature_no_unit",
        "feature_no_category_specs": "score_feature_no_category_specs",
        "feature_no_conflicts": "score_feature_no_conflicts",
    }
    thresholds, metrics, safety, per_query = evaluate_scores(
        eval_scored,
        score_columns,
        args.output_dir,
        bootstrap_samples=args.bootstrap,
        seed=args.seed,
    )
    split_stats = split_statistics(args.data_dir)
    split_stats.to_csv(args.output_dir / "dataset_split_statistics.csv", index=False)
    annotation = annotation_statistics(args.data_dir)
    write_json(args.output_dir / "annotation_agreement.json", annotation)
    write_json(args.output_dir / "feature_models.json", feature_models)
    write_json(args.output_dir / "runtime.json", {**lexical_timing, **feature_timing})
    conflicts = conflict_metrics(eval_scored, score_columns, thresholds)
    conflicts.to_csv(args.output_dir / "locked_conflict_metrics.csv", index=False)
    sensitivity = threshold_sensitivity(eval_scored, score_columns)
    sensitivity.to_csv(args.output_dir / "validation_threshold_sensitivity.csv", index=False)
    significance = paired_bootstrap(eval_scored, score_columns, args.bootstrap, args.seed)
    significance.to_csv(args.output_dir / "locked_paired_bootstrap.csv", index=False)
    keep = [
        "pair_id",
        "evaluation_split",
        "query_id",
        "candidate_id",
        "final_label",
        "final_relevance",
        "difficulty",
        "final_conflict_type",
        *score_columns.values(),
    ]
    eval_scored[keep].to_csv(args.output_dir / "pair_scores.csv", index=False)
    manifest = {
        "status": "complete",
        "paper_eligible": True,
        "data_dir": str(args.data_dir.resolve()),
        "input_hashes": hashes,
        "training_rows_all": len(train_all),
        "training_rows_semantic_deduplicated": len(train_dedup),
        "feature_model_training_rows": len(train_scored),
        "evaluation_rows": evaluation["evaluation_split"].value_counts().to_dict(),
        "models": list(score_columns),
        "threshold_selection": "validation only",
        "bootstrap_samples": args.bootstrap,
        "seed": args.seed,
        "no_reference_primary_scope": "38 internal queries; external no-reference cases remain inside external mixed test",
        "generated_at_utc": pd.Timestamp.utcnow().isoformat(),
    }
    write_json(args.output_dir / "manifest.json", manifest)
    print(json.dumps({"manifest": manifest, "annotation": annotation}, indent=2))


if __name__ == "__main__":
    main()
