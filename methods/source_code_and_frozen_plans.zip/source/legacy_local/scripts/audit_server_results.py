#!/usr/bin/env python3
"""Audit the completeness and provenance of downloaded GPU experiment results."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import pandas as pd


EXPECTED_RUNS = [
    "bge_v2_m3_sym_seed_20260904",
    "bge_v2_m3_sym_seed_20260905",
    "bge_v2_m3_sym_seed_20260906",
    "bge_v2_m3_sym_hard_seed_20260904",
    "bge_v2_m3_ablation_description_only_seed_20260904",
    "bge_v2_m3_ablation_no_unit_seed_20260904",
    "bge_v2_m3_ablation_no_category_specs_seed_20260904",
    "qwen3_reranker_06b_sym_seed_20260904",
    "qwen3_reranker_06b_sym_seed_20260905",
    "qwen3_reranker_06b_sym_seed_20260906",
    "qwen3_reranker_06b_sym_hard_seed_20260904",
    "qwen3_reranker_4b_zero_shot",
    "qwen3_reranker_4b_sym_seed_20260904",
    "qwen3_4b_instruct_prompt_verifier",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    checks = []
    canonical_hashes = None

    def check(run: str, name: str, passed: bool, detail: object) -> None:
        checks.append({"run": run, "check": name, "passed": bool(passed), "detail": detail})

    for run in EXPECTED_RUNS:
        root = args.results_dir / run
        manifest_path = root / "manifest.json"
        scores_path = root / "pair_scores.csv"
        thresholds_path = root / "validation_thresholds.csv"
        check(run, "run directory exists", root.is_dir(), str(root))
        if not root.is_dir():
            continue
        check(run, "manifest exists", manifest_path.is_file(), str(manifest_path))
        check(run, "pair scores exist", scores_path.is_file(), str(scores_path))
        check(run, "validation thresholds exist", thresholds_path.is_file(), str(thresholds_path))
        if not (manifest_path.is_file() and scores_path.is_file() and thresholds_path.is_file()):
            continue

        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        check(run, "manifest complete", manifest.get("status") == "complete", manifest.get("status"))
        check(run, "paper eligible", manifest.get("paper_eligible") is True, manifest.get("paper_eligible"))
        check(
            run,
            "validation-only threshold selection",
            manifest.get("threshold_selection") == "validation only",
            manifest.get("threshold_selection"),
        )
        hashes = manifest.get("input_hashes")
        if canonical_hashes is None:
            canonical_hashes = hashes
        check(run, "canonical input hashes match", hashes == canonical_hashes, hashes)

        scores = pd.read_csv(scores_path)
        check(run, "7,500 pair scores", len(scores) == 7500, len(scores))
        check(run, "pair IDs unique", not scores["pair_id"].duplicated().any(), int(scores["pair_id"].duplicated().sum()))
        expected_splits = {
            "validation": 900,
            "locked": 3000,
            "external": 2400,
            "no_reference": 1140,
            "no_reference_reclassified": 60,
        }
        observed_splits = scores["evaluation_split"].value_counts().to_dict()
        check(run, "split row counts", observed_splits == expected_splits, observed_splits)
        score_columns = [column for column in scores if column.startswith("score_")]
        finite = all(
            scores[column].map(lambda value: math.isfinite(float(value))).all()
            for column in score_columns
        )
        check(run, "all scores finite", finite, score_columns)
        thresholds = pd.read_csv(thresholds_path)
        check(run, "threshold records nonempty", len(thresholds) > 0, len(thresholds))

    failed = [row for row in checks if not row["passed"]]
    report = {
        "status": "passed" if not failed else "failed",
        "expected_runs": len(EXPECTED_RUNS),
        "checks": len(checks),
        "failures": len(failed),
        "canonical_input_hashes": canonical_hashes,
        "result_tree_sha256": {
            str(path.relative_to(args.results_dir)): sha256(path)
            for path in sorted(args.results_dir.glob("*/manifest.json"))
        },
        "check_rows": checks,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({key: report[key] for key in ["status", "expected_runs", "checks", "failures"]}, indent=2))
    if failed:
        for row in failed:
            print(f"FAIL {row['run']}: {row['check']} -> {row['detail']}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
