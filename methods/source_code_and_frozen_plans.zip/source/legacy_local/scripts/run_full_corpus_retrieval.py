#!/usr/bin/env python3
"""Evaluate independent full-corpus candidate generation under temporal filters."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
import torch
from huggingface_hub import model_info
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import TfidfVectorizer

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import load_data, normalize_text, sha256, write_json  # noqa: E402


K_VALUES = [1, 5, 10, 30, 100]
QUERY_INSTRUCTION = "Represent this sentence for searching relevant passages: "


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--corpus", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--model", default="BAAI/bge-small-en-v1.5")
    parser.add_argument("--batch-size", type=int, default=128)
    return parser.parse_args()


def text_from_columns(frame: pd.DataFrame, prefix: str = "") -> list[str]:
    def column(name: str) -> pd.Series:
        return frame[f"{prefix}{name}"].map(normalize_text)

    return [
        f"Description: {d}. Normalized: {n}. Pay unit: {u}. Category: {c}. Specs: {s}."
        for d, n, u, c, s in zip(
            column("description"),
            column("normalized_description"),
            column("normalized_unit"),
            column("category"),
            column("spec_tokens"),
        )
    ]


def minmax(values: np.ndarray) -> np.ndarray:
    low = float(values.min())
    high = float(values.max())
    if high <= low:
        return np.zeros_like(values, dtype=float)
    return (values - low) / (high - low)


def tfidf_scores(query_text: str, candidate_texts: list[str]) -> np.ndarray:
    vectorizer = TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),
        sublinear_tf=True,
        norm="l2",
        token_pattern=r"(?u)\b[\w.-]+\b",
    )
    matrix = vectorizer.fit_transform([query_text, *candidate_texts])
    scores = matrix[1:] @ matrix[0].T
    if sp.issparse(scores):
        return scores.toarray().reshape(-1)
    return np.asarray(scores).reshape(-1)


def ranking_indices(scores: np.ndarray, ids: np.ndarray, limit: int = 100) -> np.ndarray:
    order = np.lexsort((ids, -scores))
    return order[:limit]


def summarize(detail: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (split, method), group in detail.groupby(["split", "method"], sort=True):
        positive = group[group["known_positive_count"].gt(0)]
        row: dict[str, object] = {
            "split": split,
            "method": method,
            "queries": len(group),
            "positive_queries": len(positive),
            "known_positive_references": int(positive["known_positive_count"].sum()),
            "mean_eligible_corpus": float(group["eligible_corpus"].mean()),
        }
        for k in K_VALUES:
            row[f"candidate_hit_rate_at_{k}"] = (
                float(positive[f"hit_at_{k}"].mean()) if len(positive) else np.nan
            )
            denominator = int(positive["known_positive_count"].sum())
            row[f"micro_known_reference_recall_at_{k}"] = (
                float(positive[f"known_positive_hits_at_{k}"].sum() / denominator)
                if denominator
                else np.nan
            )
        rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    _, _, evaluation, input_hashes = load_data(args.data_dir)
    corpus = pd.read_csv(args.corpus, dtype=str, keep_default_na=False)
    corpus["_date"] = pd.to_datetime(corpus["letting_date"], errors="raise")
    corpus_text = text_from_columns(corpus)

    query_columns = [column for column in evaluation.columns if column.startswith("query_")]
    queries = evaluation[["evaluation_split", *query_columns]].drop_duplicates("query_id")
    queries = queries.rename(columns={"evaluation_split": "split"}).reset_index(drop=True)
    query_text = text_from_columns(queries, "query_")

    device = "mps" if torch.backends.mps.is_available() else "cpu"
    model = SentenceTransformer(args.model, device=device)
    started = time.perf_counter()
    candidate_embeddings = model.encode(
        corpus_text,
        batch_size=args.batch_size,
        normalize_embeddings=True,
        show_progress_bar=True,
        convert_to_numpy=True,
    )
    query_embeddings = model.encode(
        [QUERY_INSTRUCTION + text for text in query_text],
        batch_size=args.batch_size,
        normalize_embeddings=True,
        show_progress_bar=False,
        convert_to_numpy=True,
    )
    embedding_seconds = time.perf_counter() - started

    known_positive = {
        query_id: set(group.loc[group["final_label"].eq(1), "candidate_id"])
        for query_id, group in evaluation.groupby("query_id", sort=False)
    }
    details = []
    rankings = []
    ranking_started = time.perf_counter()
    item_ids_all = corpus["item_id"].to_numpy(str)
    for query_index, query in queries.iterrows():
        query_date = pd.Timestamp(query["query_letting_date"])
        eligible_mask = (
            corpus["agency"].eq(query["query_agency"])
            & corpus["_date"].lt(query_date)
            & ~corpus["contract_id"].eq(query["query_contract_id"])
            & ~corpus["source_group_id"].eq(query["query_source_group_id"])
        ).to_numpy()
        eligible_indices = np.flatnonzero(eligible_mask)
        if len(eligible_indices) < 100:
            raise RuntimeError(f"{query['query_id']} has only {len(eligible_indices)} eligible items")
        ids = item_ids_all[eligible_indices]
        dense = candidate_embeddings[eligible_indices] @ query_embeddings[query_index]
        lexical = tfidf_scores(
            query_text[query_index], [corpus_text[index] for index in eligible_indices]
        )
        hybrid = 0.55 * minmax(dense) + 0.45 * minmax(lexical)
        positives = known_positive[str(query["query_id"])]
        for method, scores in [
            ("tfidf_full_corpus", lexical),
            ("bge_small_full_corpus", dense),
            ("tfidf_bge_hybrid_full_corpus", hybrid),
        ]:
            top = ranking_indices(scores, ids, 100)
            ranked_ids = ids[top]
            row: dict[str, object] = {
                "split": query["split"],
                "method": method,
                "query_id": query["query_id"],
                "query_date": query["query_letting_date"],
                "query_agency": query["query_agency"],
                "eligible_corpus": len(eligible_indices),
                "known_positive_count": len(positives),
            }
            for k in K_VALUES:
                hits = sum(candidate_id in positives for candidate_id in ranked_ids[:k])
                row[f"known_positive_hits_at_{k}"] = hits
                row[f"hit_at_{k}"] = int(hits > 0)
            details.append(row)
            rankings.extend(
                {
                    "split": query["split"],
                    "method": method,
                    "query_id": query["query_id"],
                    "rank": rank,
                    "candidate_id": ids[position],
                    "score": float(scores[position]),
                    "is_known_positive": int(ids[position] in positives),
                }
                for rank, position in enumerate(top, start=1)
            )

    detail = pd.DataFrame(details)
    summary = summarize(detail)
    detail.to_csv(args.output_dir / "candidate_recall_per_query.csv", index=False)
    summary.to_csv(args.output_dir / "candidate_recall_summary.csv", index=False)
    pd.DataFrame(rankings).to_csv(args.output_dir / "top100_rankings.csv", index=False)
    try:
        revision = model_info(args.model).sha
    except Exception as exc:
        revision = f"unavailable: {type(exc).__name__}"
    manifest = {
        "status": "complete",
        "paper_eligible": True,
        "definition": (
            "Independent retrieval from all eligible same-agency historical items. "
            "Candidates must predate the query and come from a different contract and source group."
        ),
        "claim_boundary": (
            "Candidate hit rates use human-labeled positive candidate IDs available in BidUPM-vFinal. "
            "They are a conservative lower bound because unlabeled full-corpus items are not assumed positive."
        ),
        "corpus_path": str(args.corpus.resolve()),
        "corpus_sha256": sha256(args.corpus),
        "corpus_rows": len(corpus),
        "queries": len(queries),
        "input_hashes": input_hashes,
        "embedding_model": args.model,
        "embedding_model_revision": revision,
        "query_instruction": QUERY_INSTRUCTION,
        "device": device,
        "embedding_seconds": embedding_seconds,
        "ranking_seconds": time.perf_counter() - ranking_started,
        "reported_k": K_VALUES,
        "threshold_or_model_selection_on_test": False,
    }
    write_json(args.output_dir / "manifest.json", manifest)
    print(json.dumps(manifest, indent=2))
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
