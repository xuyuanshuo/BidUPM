#!/usr/bin/env python3
"""Consolidate local BidUPM-vFinal experiments and prepare API-ready inputs."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import (  # noqa: E402
    CONFLICT_FLAG_COLUMNS,
    SEED,
    conflict_gate,
    evaluate_scores,
    f1_counts,
    load_data,
    per_query_ranking,
    select_threshold,
    write_json,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--experiment-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--bootstrap", type=int, default=10000)
    return parser.parse_args()


def attach_score(
    frame: pd.DataFrame,
    path: Path,
    source_column: str,
    target_name: str,
) -> None:
    saved = pd.read_csv(path, usecols=["pair_id", source_column])
    if saved["pair_id"].duplicated().any():
        raise RuntimeError(f"Duplicate pair IDs in {path}")
    lookup = saved.set_index("pair_id")[source_column]
    frame[f"score_{target_name}"] = frame["pair_id"].map(lookup)
    if frame[f"score_{target_name}"].isna().any():
        raise RuntimeError(f"Missing {target_name} scores after joining {path}")


def add_saved_models(frame: pd.DataFrame, root: Path) -> dict[str, str]:
    sources = [
        ("classical/pair_scores.csv", "score_bm25_raw", "bm25"),
        ("classical/pair_scores.csv", "score_tfidf", "tfidf"),
        ("classical/pair_scores.csv", "score_hybrid_conflict_refined", "hybrid_conflict_refined"),
        ("classical/pair_scores.csv", "score_feature_full", "feature_full"),
        ("bge_embedding/pair_scores.csv", "score_bge_small_full", "bge_small_full"),
        (
            "bge_embedding/pair_scores.csv",
            "score_bge_small_full_conflict_refined",
            "bge_small_full_conflict_refined",
        ),
        ("minilm_l6/pair_scores.csv", "score_minilm_l6_zero_shot", "minilm_l6_zero_shot"),
        (
            "minilm_l6/pair_scores.csv",
            "score_minilm_l6_zero_shot_conflict_refined",
            "minilm_l6_zero_shot_conflict_refined",
        ),
        ("minilm_l6/pair_scores.csv", "score_minilm_l6_standard", "minilm_l6_seed_20260904"),
        (
            "minilm_l6/pair_scores.csv",
            "score_minilm_l6_standard_conflict_refined",
            "minilm_l6_seed_20260904_conflict_refined",
        ),
        (
            "minilm_l6_seed_20260905/pair_scores.csv",
            "score_minilm_l6_seed_20260905_standard",
            "minilm_l6_seed_20260905",
        ),
        (
            "minilm_l6_seed_20260905/pair_scores.csv",
            "score_minilm_l6_seed_20260905_standard_conflict_refined",
            "minilm_l6_seed_20260905_conflict_refined",
        ),
        (
            "minilm_l6_seed_20260906/pair_scores.csv",
            "score_minilm_l6_seed_20260906_standard",
            "minilm_l6_seed_20260906",
        ),
        (
            "minilm_l6_seed_20260906/pair_scores.csv",
            "score_minilm_l6_seed_20260906_standard_conflict_refined",
            "minilm_l6_seed_20260906_conflict_refined",
        ),
        ("minilm_l12/pair_scores.csv", "score_minilm_l12_standard", "minilm_l12_standard"),
        (
            "minilm_l12/pair_scores.csv",
            "score_minilm_l12_standard_conflict_refined",
            "minilm_l12_standard_conflict_refined",
        ),
        (
            "ablation_description_only/pair_scores.csv",
            "score_minilm_l6_description_only_standard",
            "ablation_description_only",
        ),
        (
            "ablation_description_only/pair_scores.csv",
            "score_minilm_l6_description_only_standard_conflict_refined",
            "ablation_description_only_conflict_refined",
        ),
        (
            "ablation_no_unit/pair_scores.csv",
            "score_minilm_l6_no_unit_standard",
            "ablation_no_unit",
        ),
        (
            "ablation_no_unit/pair_scores.csv",
            "score_minilm_l6_no_unit_standard_conflict_refined",
            "ablation_no_unit_conflict_refined",
        ),
        (
            "ablation_no_category_specs/pair_scores.csv",
            "score_minilm_l6_no_category_specs_standard",
            "ablation_no_category_specs",
        ),
        (
            "ablation_no_category_specs/pair_scores.csv",
            "score_minilm_l6_no_category_specs_standard_conflict_refined",
            "ablation_no_category_specs_conflict_refined",
        ),
        (
            "minilm_l6_symmetric/pair_scores.csv",
            "score_minilm_l6_symmetric_standard",
            "minilm_l6_symmetric_seed_20260904",
        ),
        (
            "minilm_l6_symmetric/pair_scores.csv",
            "score_minilm_l6_symmetric_standard_conflict_refined",
            "minilm_l6_symmetric_seed_20260904_conflict_refined",
        ),
        (
            "minilm_l6_symmetric_seed_20260905/pair_scores.csv",
            "score_minilm_l6_symmetric_seed_20260905_standard",
            "minilm_l6_symmetric_seed_20260905",
        ),
        (
            "minilm_l6_symmetric_seed_20260905/pair_scores.csv",
            "score_minilm_l6_symmetric_seed_20260905_standard_conflict_refined",
            "minilm_l6_symmetric_seed_20260905_conflict_refined",
        ),
        (
            "minilm_l6_symmetric_seed_20260906/pair_scores.csv",
            "score_minilm_l6_symmetric_seed_20260906_standard",
            "minilm_l6_symmetric_seed_20260906",
        ),
        (
            "minilm_l6_symmetric_seed_20260906/pair_scores.csv",
            "score_minilm_l6_symmetric_seed_20260906_standard_conflict_refined",
            "minilm_l6_symmetric_seed_20260906_conflict_refined",
        ),
        (
            "minilm_l6_symmetric_hard/pair_scores.csv",
            "score_minilm_l6_symmetric_hard_hard_refined",
            "minilm_l6_symmetric_hard_refined",
        ),
        (
            "minilm_l6_symmetric_hard/pair_scores.csv",
            "score_minilm_l6_symmetric_hard_hard_refined_conflict_refined",
            "minilm_l6_symmetric_hard_refined_conflict_refined",
        ),
    ]
    for relative, source, name in sources:
        attach_score(frame, root / relative, source, name)

    seeds = frame[
        [
            "score_minilm_l6_seed_20260904",
            "score_minilm_l6_seed_20260905",
            "score_minilm_l6_seed_20260906",
        ]
    ]
    for aggregation in ["mean", "median", "max", "min"]:
        values = getattr(seeds, aggregation)(axis=1).to_numpy(float)
        name = f"minilm_l6_ensemble_{aggregation}"
        frame[f"score_{name}"] = values
        frame[f"score_{name}_conflict_refined"] = conflict_gate(frame, values, strength=1.0)

    symmetric_seeds = frame[
        [
            "score_minilm_l6_symmetric_seed_20260904",
            "score_minilm_l6_symmetric_seed_20260905",
            "score_minilm_l6_symmetric_seed_20260906",
        ]
    ]
    for aggregation in ["mean", "median", "max", "min"]:
        values = getattr(symmetric_seeds, aggregation)(axis=1).to_numpy(float)
        name = f"minilm_l6_symmetric_ensemble_{aggregation}"
        frame[f"score_{name}"] = values
        frame[f"score_{name}_conflict_refined"] = conflict_gate(frame, values, strength=1.0)

    return {
        column.removeprefix("score_"): column
        for column in frame.columns
        if column.startswith("score_")
    }


def multi_seed_summary(metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    families = {
        "minilm_l6_three_seed": "minilm_l6_seed_",
        "minilm_l6_symmetric_three_seed": "minilm_l6_symmetric_seed_",
    }
    for family, prefix in families.items():
        for refined in [False, True]:
            suffix = "_conflict_refined" if refined else ""
            names = [f"{prefix}{seed}{suffix}" for seed in [20260904, 20260905, 20260906]]
            selected = metrics[
                metrics["policy"].eq("f1_opt") & metrics["model"].isin(names)
            ]
            for split, group in selected.groupby("split", sort=False):
                for metric in [
                    "pair_precision",
                    "pair_recall",
                    "pair_f1",
                    "hard_pair_f1",
                    "top1",
                    "recall_at_5",
                    "mrr",
                    "ndcg_at_5_graded",
                ]:
                    values = group[metric].dropna().to_numpy(float)
                    rows.append(
                        {
                            "model": f"{family}{'_conflict_refined' if refined else ''}",
                            "split": split,
                            "metric": metric,
                            "seeds": len(values),
                            "mean": float(values.mean()) if len(values) else math.nan,
                            "sample_std": float(values.std(ddof=1)) if len(values) > 1 else math.nan,
                            "minimum": float(values.min()) if len(values) else math.nan,
                            "maximum": float(values.max()) if len(values) else math.nan,
                        }
                    )
    return pd.DataFrame(rows)


def query_cluster_bootstrap(
    frame: pd.DataFrame,
    thresholds: pd.DataFrame,
    comparisons: list[str],
    reference: str,
    samples: int,
    seed: int,
) -> pd.DataFrame:
    locked = frame[frame["evaluation_split"].eq("locked")].copy()
    query_ids = np.array(sorted(locked["query_id"].unique()))
    threshold_map = thresholds[thresholds["policy"].eq("f1_opt")].set_index("model")["threshold"]
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, len(query_ids), size=(samples, len(query_ids)))

    predictions: dict[str, np.ndarray] = {}
    count_arrays: dict[str, np.ndarray] = {}
    ranking_arrays: dict[str, pd.DataFrame] = {}
    y = locked["final_label"].to_numpy(dtype=int)
    for model in [reference, *comparisons]:
        score_column = f"score_{model}"
        pred = locked[score_column].to_numpy(float) >= float(threshold_map[model])
        predictions[model] = pred
        per_query_counts = []
        for query_id in query_ids:
            mask = locked["query_id"].eq(query_id).to_numpy()
            per_query_counts.append(
                [
                    int((pred[mask] & (y[mask] == 1)).sum()),
                    int((pred[mask] & (y[mask] == 0)).sum()),
                    int((~pred[mask] & (y[mask] == 1)).sum()),
                ]
            )
        count_arrays[model] = np.asarray(per_query_counts, dtype=float)
        ranking_arrays[model] = per_query_ranking(locked, score_column).set_index("query_id").loc[query_ids]

    rows = []
    for comparison in comparisons:
        for metric in ["pair_f1", "top1", "recall_at_5", "mrr", "ndcg_at_5_graded"]:
            if metric == "pair_f1":
                values = {}
                for model in [reference, comparison]:
                    sampled_counts = count_arrays[model][draws].sum(axis=1)
                    tp, fp, fn = sampled_counts[:, 0], sampled_counts[:, 1], sampled_counts[:, 2]
                    values[model] = 2 * tp / np.maximum(2 * tp + fp + fn, 1)
                observed = (
                    2 * count_arrays[reference][:, 0].sum()
                    / max(
                        2 * count_arrays[reference][:, 0].sum()
                        + count_arrays[reference][:, 1].sum()
                        + count_arrays[reference][:, 2].sum(),
                        1,
                    )
                    - 2 * count_arrays[comparison][:, 0].sum()
                    / max(
                        2 * count_arrays[comparison][:, 0].sum()
                        + count_arrays[comparison][:, 1].sum()
                        + count_arrays[comparison][:, 2].sum(),
                        1,
                    )
                )
            else:
                values = {
                    model: ranking_arrays[model][metric].to_numpy(float)[draws].mean(axis=1)
                    for model in [reference, comparison]
                }
                observed = float(
                    ranking_arrays[reference][metric].mean()
                    - ranking_arrays[comparison][metric].mean()
                )
            difference = values[reference] - values[comparison]
            p = 2 * min(float((difference <= 0).mean()), float((difference >= 0).mean()))
            rows.append(
                {
                    "reference": reference,
                    "comparison": comparison,
                    "metric": metric,
                    "queries": len(query_ids),
                    "observed_difference": observed,
                    "bootstrap_mean_difference": float(difference.mean()),
                    "ci_low": float(np.quantile(difference, 0.025)),
                    "ci_high": float(np.quantile(difference, 0.975)),
                    "p_two_sided": min(p, 1.0),
                    "bootstrap_samples": samples,
                }
            )
    return pd.DataFrame(rows)


def error_analysis(
    frame: pd.DataFrame,
    thresholds: pd.DataFrame,
    model: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    score_column = f"score_{model}"
    threshold = float(
        thresholds[(thresholds["model"].eq(model)) & (thresholds["policy"].eq("f1_opt"))][
            "threshold"
        ].iloc[0]
    )
    detail = frame.copy()
    detail["prediction"] = (detail[score_column] >= threshold).astype(int)
    detail["error_type"] = np.select(
        [
            detail["final_label"].eq(1) & detail["prediction"].eq(1),
            detail["final_label"].eq(0) & detail["prediction"].eq(0),
            detail["final_label"].eq(0) & detail["prediction"].eq(1),
        ],
        ["TP", "TN", "FP"],
        default="FN",
    )
    summary = (
        detail.groupby(
            ["evaluation_split", "difficulty", "final_conflict_type", "error_type"],
            dropna=False,
        )
        .size()
        .rename("rows")
        .reset_index()
    )
    return detail, summary


def routing_and_api_inputs(
    frame: pd.DataFrame,
    thresholds: pd.DataFrame,
    data_dir: Path,
    output_dir: Path,
    model: str,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, object]]:
    score_column = f"score_{model}"
    threshold = float(
        thresholds[(thresholds["model"].eq(model)) & (thresholds["policy"].eq("f1_opt"))][
            "threshold"
        ].iloc[0]
    )
    validation = frame[frame["evaluation_split"].eq("validation")]
    validation_margin = (validation[score_column] - threshold).abs()
    operating_budget = 0.20
    uncertainty_delta = float(np.quantile(validation_margin, operating_budget, method="higher"))

    routed = frame.copy()
    routed["local_score"] = routed[score_column]
    routed["local_threshold"] = threshold
    routed["absolute_margin"] = (routed[score_column] - threshold).abs()
    routed["local_prediction"] = (routed[score_column] >= threshold).astype(int)
    routed["observable_conflict"] = (
        routed[CONFLICT_FLAG_COLUMNS].max(axis=1).astype(int)
        | (1 - routed["unit_match"].astype(int))
    )
    routed["route_uncertain"] = routed["absolute_margin"].le(uncertainty_delta)
    routed["route_positive_conflict"] = routed["local_prediction"].eq(1) & routed[
        "observable_conflict"
    ].eq(1)
    routed["route_to_llm"] = routed["route_uncertain"] | routed["route_positive_conflict"]
    routed["is_error"] = routed["local_prediction"].ne(routed["final_label"].astype(int))
    routed["route_reason"] = np.select(
        [routed["route_uncertain"], routed["route_positive_conflict"]],
        ["low_margin", "predicted_positive_with_conflict"],
        default="local_accept_or_reject",
    )

    budget_rows = []
    for budget in [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50]:
        delta = float(np.quantile(validation_margin, budget, method="higher"))
        route = routed["absolute_margin"].le(delta) | routed["route_positive_conflict"]
        for split, group in routed.groupby("evaluation_split", sort=False):
            mask = routed.index.isin(group.index)
            split_route = route[mask]
            split_error = routed.loc[mask, "is_error"]
            errors = int(split_error.sum())
            routed_errors = int((split_route & split_error).sum())
            budget_rows.append(
                {
                    "validation_budget": budget,
                    "validation_frozen_margin_delta": delta,
                    "split": split,
                    "rows": len(group),
                    "routed_rows": int(split_route.sum()),
                    "routed_fraction": float(split_route.mean()),
                    "call_reduction_fraction": float(1.0 - split_route.mean()),
                    "local_errors": errors,
                    "routed_errors": routed_errors,
                    "error_capture_recall": routed_errors / max(errors, 1),
                }
            )
    budget_curve = pd.DataFrame(budget_rows)

    summary_rows = []
    for split, group in routed.groupby("evaluation_split", sort=False):
        routed_rows = int(group["route_to_llm"].sum())
        errors = int(group["is_error"].sum())
        routed_errors = int((group["route_to_llm"] & group["is_error"]).sum())
        summary_rows.append(
            {
                "split": split,
                "rows": len(group),
                "routed_rows": routed_rows,
                "routed_fraction": routed_rows / len(group),
                "call_reduction_fraction": 1.0 - routed_rows / len(group),
                "local_errors": errors,
                "routed_errors": routed_errors,
                "error_capture_recall": routed_errors / max(errors, 1),
            }
        )
    summary = pd.DataFrame(summary_rows)

    api_root = output_dir / "api_ready"
    full_root = api_root / "full"
    selective_root = api_root / "selective"
    full_root.mkdir(parents=True, exist_ok=True)
    selective_root.mkdir(parents=True, exist_ok=True)
    all_pairs = pd.read_csv(
        data_dir / "pairs" / "all_pairs_vfinal_12092.csv", dtype=str, keep_default_na=False
    )
    descriptive = all_pairs.set_index("pair_id")
    fields = [
        "pair_id",
        "query_description",
        "query_unit",
        "query_category",
        "query_spec_tokens",
        "candidate_description",
        "candidate_unit",
        "candidate_category",
        "candidate_spec_tokens",
    ]
    for split, group in routed.groupby("evaluation_split", sort=False):
        records = descriptive.loc[group["pair_id"], fields[1:]].reset_index()
        operational = group.set_index("pair_id")[
            ["local_score", "local_threshold", "absolute_margin", "route_to_llm", "route_reason"]
        ]
        records = records.join(operational, on="pair_id")
        full_path = full_root / f"{split}.jsonl"
        selective_path = selective_root / f"{split}.jsonl"
        with full_path.open("w", encoding="utf-8") as handle:
            for record in records.to_dict("records"):
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        with selective_path.open("w", encoding="utf-8") as handle:
            for record in records[records["route_to_llm"]].to_dict("records"):
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    response_schema = {
        "pair_id": "string",
        "label": "0 or 1",
        "relevance": "exact, acceptable, related, or wrong",
        "confidence": "number from 0 to 1",
        "conflict_type": "none, unit, action, material, dimension, class, type, spec, scope, generic-specific, or other",
        "review_flag": "boolean",
        "reason": "short evidence-based explanation",
    }
    write_json(api_root / "response_schema.json", response_schema)
    manifest = {
        "status": "inputs_ready_no_api_calls_made",
        "local_model": model,
        "threshold_selected_on_validation": threshold,
        "operating_budget_on_validation": operating_budget,
        "uncertainty_delta_selected_as_validation_margin_quantile": uncertainty_delta,
        "route_definition": (
            "At the pre-specified 20% validation budget, route a pair when its local-score margin "
            "is within the validation-frozen uncertainty "
            "band or when it is predicted positive despite an observable unit/conflict flag."
        ),
        "budget_sweep_reported": [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50],
        "labels_in_api_inputs": False,
        "full_and_selective_inputs_written": True,
    }
    write_json(api_root / "manifest.json", manifest)
    return summary, budget_curve, manifest


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    _, _, evaluation, hashes = load_data(args.data_dir)
    score_columns = add_saved_models(evaluation, args.experiment_root)
    thresholds, metrics, safety, per_query = evaluate_scores(
        evaluation,
        score_columns,
        args.output_dir,
        bootstrap_samples=args.bootstrap,
        seed=SEED,
    )

    seed_summary = multi_seed_summary(metrics)
    seed_summary.to_csv(args.output_dir / "three_seed_summary.csv", index=False)

    ablation_models = [
        "minilm_l6_seed_20260904",
        "ablation_description_only",
        "ablation_description_only_conflict_refined",
        "ablation_no_unit",
        "ablation_no_unit_conflict_refined",
        "ablation_no_category_specs",
        "ablation_no_category_specs_conflict_refined",
    ]
    metrics[
        metrics["model"].isin(ablation_models)
        & metrics["split"].eq("locked")
        & metrics["policy"].eq("f1_opt")
    ].to_csv(args.output_dir / "input_ablation_locked.csv", index=False)

    hard_models = [
        "minilm_l6_zero_shot",
        "minilm_l6_zero_shot_conflict_refined",
        "minilm_l6_seed_20260904",
        "minilm_l6_seed_20260904_conflict_refined",
        "minilm_l12_standard",
        "minilm_l12_standard_conflict_refined",
        "minilm_l6_ensemble_min",
        "minilm_l6_ensemble_min_conflict_refined",
        "minilm_l6_symmetric_seed_20260904",
        "minilm_l6_symmetric_seed_20260904_conflict_refined",
        "minilm_l6_symmetric_hard_refined",
        "minilm_l6_symmetric_hard_refined_conflict_refined",
        "minilm_l6_symmetric_ensemble_min",
        "minilm_l6_symmetric_ensemble_min_conflict_refined",
    ]
    metrics[
        metrics["model"].isin(hard_models)
        & metrics["split"].isin(["validation", "locked", "external"])
        & metrics["policy"].eq("f1_opt")
    ].to_csv(args.output_dir / "hard_case_refinement.csv", index=False)

    comparisons = [
        "bm25",
        "tfidf",
        "hybrid_conflict_refined",
        "feature_full",
        "bge_small_full",
        "minilm_l6_zero_shot",
        "minilm_l12_standard_conflict_refined",
    ]
    significance = query_cluster_bootstrap(
        evaluation,
        thresholds,
        comparisons,
        "minilm_l6_symmetric_seed_20260904",
        args.bootstrap,
        SEED,
    )
    significance.to_csv(args.output_dir / "locked_query_cluster_bootstrap.csv", index=False)

    error_detail, error_summary = error_analysis(
        evaluation, thresholds, "minilm_l6_symmetric_seed_20260904"
    )
    error_summary.to_csv(args.output_dir / "primary_error_summary.csv", index=False)
    error_ids = error_detail[error_detail["error_type"].isin(["FP", "FN"])][
        [
            "pair_id",
            "evaluation_split",
            "query_id",
            "candidate_id",
            "final_label",
            "final_relevance",
            "difficulty",
            "final_conflict_type",
            "score_minilm_l6_symmetric_seed_20260904",
            "prediction",
            "error_type",
        ]
    ]
    descriptive = pd.read_csv(
        args.data_dir / "pairs" / "all_pairs_vfinal_12092.csv",
        dtype=str,
        keep_default_na=False,
        usecols=["pair_id", "query_description", "query_unit", "candidate_description", "candidate_unit"],
    )
    error_ids.merge(descriptive, on="pair_id", how="left").to_csv(
        args.output_dir / "primary_error_rows.csv", index=False
    )

    routing_summary, routing_budget_curve, routing_manifest = routing_and_api_inputs(
        evaluation,
        thresholds,
        args.data_dir,
        args.output_dir,
        "minilm_l6_symmetric_seed_20260904",
    )
    routing_summary.to_csv(args.output_dir / "routing_coverage.csv", index=False)
    routing_budget_curve.to_csv(args.output_dir / "routing_budget_curve.csv", index=False)

    manifest = {
        "status": "all_fast_local_experiments_complete",
        "paper_eligible": True,
        "data_dir": str(args.data_dir.resolve()),
        "input_hashes": hashes,
        "models_consolidated": len(score_columns),
        "evaluation_rows": len(evaluation),
        "threshold_selection": "validation only for every model",
        "bootstrap_samples": args.bootstrap,
        "primary_single_seed_model_for_error_analysis": "minilm_l6_symmetric_seed_20260904",
        "primary_paper_result": "three-seed mean of symmetric MiniLM-L6",
        "hard_case_refinement_result": "symmetric hard-weighted MiniLM-L6 plus observable conflict gate",
        "three_seed_reporting_available": True,
        "routing": routing_manifest,
        "remote_or_api_experiments_not_run": [
            "BGE-reranker-v2-m3 zero-shot",
            "BGE-reranker-v2-m3 fine-tuning",
            "LLM verifier API calls",
            "actual routed-LLM correction performance and token cost",
        ],
        "figures_created": False,
        "seed": SEED,
    }
    write_json(args.output_dir / "manifest.json", manifest)
    print(json.dumps(manifest, indent=2))
    locked = metrics[
        metrics["split"].eq("locked") & metrics["policy"].eq("f1_opt")
    ].sort_values(["pair_f1", "hard_pair_f1"], ascending=False)
    print(
        locked[
            ["model", "top1", "recall_at_5", "mrr", "ndcg_at_5_graded", "pair_f1", "hard_pair_f1"]
        ].head(15).to_string(index=False)
    )
    print("\nRouting coverage:\n" + routing_summary.to_string(index=False))


if __name__ == "__main__":
    main()
