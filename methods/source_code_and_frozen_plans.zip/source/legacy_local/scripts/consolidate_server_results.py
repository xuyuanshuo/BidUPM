#!/usr/bin/env python3
"""Consolidate GPU experiments, routing, and model disagreement for the paper.

All model/threshold/route choices are made on validation only. Locked,
no-reference, reclassified no-reference, and external splits are read once for
frozen evaluation and are never used to select a checkpoint or threshold.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import (  # noqa: E402
    CONFLICT_FLAG_COLUMNS,
    EVALUATION_SPLITS,
    SEED,
    evaluate_scores,
    f1_counts,
    load_data,
    per_query_ranking,
    select_threshold,
    write_json,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--local-root", required=True, type=Path)
    parser.add_argument("--server-results", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=SEED)
    return parser.parse_args()


def attach_score(
    frame: pd.DataFrame,
    path: Path,
    source_column: str,
    target_column: str,
) -> None:
    if not path.exists():
        raise FileNotFoundError(path)
    saved = pd.read_csv(path, usecols=["pair_id", source_column])
    if saved["pair_id"].duplicated().any():
        raise RuntimeError(f"Duplicate pair_id in {path}")
    lookup = saved.set_index("pair_id")[source_column]
    frame[target_column] = frame["pair_id"].map(lookup)
    if frame[target_column].isna().any():
        missing = int(frame[target_column].isna().sum())
        raise RuntimeError(f"{missing} missing scores after joining {path}")


def add_all_scores(frame: pd.DataFrame, local: Path, server: Path) -> dict[str, str]:
    attach_score(
        frame,
        local / "classical" / "pair_scores.csv",
        "score_tfidf",
        "score_tfidf",
    )
    attach_score(
        frame,
        local / "bge_embedding" / "pair_scores.csv",
        "score_bge_small_full_conflict_refined",
        "score_bge_small_embedding",
    )

    bge_seed_columns = []
    qwen06_seed_columns = []
    for seed in [20260904, 20260905, 20260906]:
        bge_target = f"score_bge_v2_m3_seed_{seed}"
        attach_score(
            frame,
            server / f"bge_v2_m3_sym_seed_{seed}" / "pair_scores.csv",
            "score_bge_v2_m3_standard",
            bge_target,
        )
        bge_seed_columns.append(bge_target)

        qwen_target = f"score_qwen06_seed_{seed}"
        attach_score(
            frame,
            server / f"qwen3_reranker_06b_sym_seed_{seed}" / "pair_scores.csv",
            "score_qwen3_reranker_06b_standard",
            qwen_target,
        )
        qwen06_seed_columns.append(qwen_target)

    frame["score_bge_v2_m3_three_seed_mean"] = frame[bge_seed_columns].mean(axis=1)
    frame["score_qwen06_three_seed_mean"] = frame[qwen06_seed_columns].mean(axis=1)
    attach_score(
        frame,
        server / "bge_v2_m3_sym_seed_20260904" / "pair_scores.csv",
        "score_bge_v2_m3_zero_shot",
        "score_bge_v2_m3_zero_shot",
    )
    attach_score(
        frame,
        server / "bge_v2_m3_sym_hard_seed_20260904" / "pair_scores.csv",
        "score_bge_v2_m3_hard_hard_refined",
        "score_bge_v2_m3_hard_refined",
    )
    attach_score(
        frame,
        server / "qwen3_reranker_06b_sym_seed_20260904" / "pair_scores.csv",
        "score_qwen3_reranker_06b_zero_shot",
        "score_qwen06_zero_shot",
    )
    attach_score(
        frame,
        server / "qwen3_reranker_06b_sym_hard_seed_20260904" / "pair_scores.csv",
        "score_qwen3_reranker_06b_hard_hard_refined",
        "score_qwen06_hard_refined",
    )
    attach_score(
        frame,
        server / "qwen3_reranker_4b_zero_shot" / "pair_scores.csv",
        "score_qwen3_reranker_4b_zero_shot",
        "score_qwen4_zero_shot",
    )
    attach_score(
        frame,
        server / "qwen3_reranker_4b_sym_seed_20260904" / "pair_scores.csv",
        "score_qwen3_reranker_4b_standard",
        "score_qwen4_fine_tuned",
    )
    attach_score(
        frame,
        server / "qwen3_4b_instruct_prompt_verifier" / "pair_scores.csv",
        "score_qwen3_4b_instruct_verifier",
        "score_open_llm_verifier",
    )

    for variant in ["description_only", "no_unit", "no_category_specs"]:
        attach_score(
            frame,
            server / f"bge_v2_m3_ablation_{variant}_seed_20260904" / "pair_scores.csv",
            f"score_bge_v2_m3_{variant}_standard",
            f"score_bge_ablation_{variant}",
        )

    names = [
        "tfidf",
        "bge_small_embedding",
        "bge_v2_m3_zero_shot",
        "bge_v2_m3_seed_20260904",
        "bge_v2_m3_seed_20260905",
        "bge_v2_m3_seed_20260906",
        "bge_v2_m3_three_seed_mean",
        "bge_v2_m3_hard_refined",
        "qwen06_zero_shot",
        "qwen06_seed_20260904",
        "qwen06_seed_20260905",
        "qwen06_seed_20260906",
        "qwen06_three_seed_mean",
        "qwen06_hard_refined",
        "qwen4_zero_shot",
        "qwen4_fine_tuned",
        "open_llm_verifier",
        "bge_ablation_description_only",
        "bge_ablation_no_unit",
        "bge_ablation_no_category_specs",
    ]
    return {name: f"score_{name}" for name in names}


def multi_seed_summary(metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    families = {
        "BGE-reranker-v2-m3": "bge_v2_m3_seed_",
        "Qwen3-Reranker-0.6B": "qwen06_seed_",
    }
    selected = metrics[metrics["policy"].eq("f1_opt")]
    for family, prefix in families.items():
        models = [f"{prefix}{seed}" for seed in [20260904, 20260905, 20260906]]
        subset = selected[selected["model"].isin(models)]
        for split, group in subset.groupby("split", sort=False):
            for metric in [
                "pair_precision",
                "pair_recall",
                "pair_f1",
                "hard_pair_f1",
                "top1",
                "recall_at_5",
                "mrr",
                "ndcg_at_5_graded",
            ]:
                values = group[metric].dropna().to_numpy(float)
                rows.append(
                    {
                        "model_family": family,
                        "split": split,
                        "metric": metric,
                        "seeds": len(values),
                        "mean": float(values.mean()) if len(values) else math.nan,
                        "sample_std": (
                            float(values.std(ddof=1)) if len(values) > 1 else math.nan
                        ),
                        "minimum": float(values.min()) if len(values) else math.nan,
                        "maximum": float(values.max()) if len(values) else math.nan,
                    }
                )
    return pd.DataFrame(rows)


def robust_probability(scores: np.ndarray, threshold: float, validation_scores: np.ndarray) -> np.ndarray:
    margins = np.asarray(validation_scores, dtype=float) - threshold
    scale = float(np.median(np.abs(margins)))
    if not np.isfinite(scale) or scale < 1e-8:
        scale = float(np.std(margins))
    scale = max(scale, 1e-6)
    z = np.clip((np.asarray(scores, dtype=float) - threshold) / scale, -30.0, 30.0)
    return 1.0 / (1.0 + np.exp(-z))


def route_priority(
    frame: pd.DataFrame,
    local_scores: np.ndarray,
    local_threshold: float,
    validation_mask: np.ndarray,
) -> np.ndarray:
    validation_margin = local_scores[validation_mask] - local_threshold
    scale = max(float(np.median(np.abs(validation_margin))), 1e-6)
    uncertainty = -np.abs((local_scores - local_threshold) / scale)
    conflict = frame[CONFLICT_FLAG_COLUMNS].max(axis=1).to_numpy(float)
    unit_mismatch = 1.0 - frame["unit_match"].to_numpy(float)
    return uncertainty + 0.35 * conflict + 0.35 * unit_mismatch


def routing_analysis(
    frame: pd.DataFrame,
    output_dir: Path,
    bootstrap: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    y = frame["final_label"].to_numpy(int)
    validation_mask = frame["evaluation_split"].eq("validation").to_numpy()
    local_scores = frame["score_bge_v2_m3_seed_20260904"].to_numpy(float)
    expert_scores = frame["score_open_llm_verifier"].to_numpy(float)
    local_threshold, _ = select_threshold(y[validation_mask], local_scores[validation_mask])
    expert_threshold, _ = select_threshold(y[validation_mask], expert_scores[validation_mask])
    local_prob = robust_probability(local_scores, local_threshold, local_scores[validation_mask])
    expert_prob = robust_probability(expert_scores, expert_threshold, expert_scores[validation_mask])
    priority = route_priority(frame, local_scores, local_threshold, validation_mask)

    budgets = [0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50, 1.00]
    strategy_functions = {
        "replace": lambda local, expert: expert,
        "mean_fusion": lambda local, expert: 0.5 * (local + expert),
        "conservative_veto": lambda local, expert: np.minimum(local, expert),
        "positive_rescue": lambda local, expert: np.maximum(local, expert),
    }
    route_rows = []
    selected_score_columns: dict[str, str] = {
        "routing_local_only": "score_routing_local_only",
        "routing_full_open_llm": "score_routing_full_open_llm",
    }
    frame["score_routing_local_only"] = local_prob
    frame["score_routing_full_open_llm"] = expert_prob
    selected_twenty: dict[str, object] | None = None

    for budget in budgets:
        if budget <= 0:
            cutoff = math.inf
        elif budget >= 1:
            cutoff = -math.inf
        else:
            cutoff = float(
                np.quantile(priority[validation_mask], 1.0 - budget, method="higher")
            )
        routed = priority >= cutoff
        if budget <= 0:
            routed[:] = False
        if budget >= 1:
            routed[:] = True

        candidates = []
        for strategy, combine in strategy_functions.items():
            score = local_prob.copy()
            score[routed] = combine(local_prob[routed], expert_prob[routed])
            threshold, val = select_threshold(y[validation_mask], score[validation_mask])
            hard_val = validation_mask & frame["difficulty"].eq("hard").to_numpy()
            hard_metrics = f1_counts(y[hard_val], score[hard_val], threshold)
            candidates.append(
                (
                    float(val["pair_f1"]),
                    float(hard_metrics["pair_f1"]),
                    float(val["pair_precision"]),
                    strategy,
                    score,
                    threshold,
                )
            )
        best = max(candidates, key=lambda row: (row[0], row[1], row[2], row[3]))
        _, _, _, strategy, score, threshold = best
        model_name = f"routing_budget_{int(round(100 * budget)):02d}_{strategy}"
        frame[f"score_{model_name}"] = score
        selected_score_columns[model_name] = f"score_{model_name}"
        if math.isclose(budget, 0.20):
            selected_twenty = {
                "budget": budget,
                "cutoff": cutoff,
                "strategy": strategy,
                "score": score.copy(),
                "threshold": threshold,
                "routed": routed.copy(),
            }

        for split in EVALUATION_SPLITS:
            split_mask = frame["evaluation_split"].eq(split).to_numpy()
            metrics = f1_counts(y[split_mask], score[split_mask], threshold)
            local_pred = local_prob[split_mask] >= 0.5
            local_error = local_pred != y[split_mask]
            routed_split = routed[split_mask]
            route_rows.append(
                {
                    "validation_budget": budget,
                    "validation_priority_cutoff": cutoff,
                    "validation_selected_strategy": strategy,
                    "validation_selected_threshold": threshold,
                    "split": split,
                    "rows": int(split_mask.sum()),
                    "routed_rows": int(routed_split.sum()),
                    "routed_fraction": float(routed_split.mean()),
                    "call_reduction_fraction": float(1.0 - routed_split.mean()),
                    "local_errors": int(local_error.sum()),
                    "routed_local_errors": int((routed_split & local_error).sum()),
                    "error_capture_recall": float(
                        (routed_split & local_error).sum() / max(local_error.sum(), 1)
                    ),
                    **metrics,
                }
            )

    if selected_twenty is None:
        raise RuntimeError("20% routing policy was not generated")
    frame["score_routing_fixed_20pct"] = selected_twenty["score"]
    selected_score_columns["routing_fixed_20pct"] = "score_routing_fixed_20pct"
    thresholds, metrics, safety, _ = evaluate_scores(
        frame,
        selected_score_columns,
        output_dir / "routing_metrics",
        bootstrap_samples=bootstrap,
        seed=seed,
    )
    pd.DataFrame(route_rows).to_csv(output_dir / "routing_budget_curve.csv", index=False)
    write_json(
        output_dir / "routing_policy.json",
        {
            "status": "complete",
            "selection_data": "validation only",
            "primary_local_model": "BGE-reranker-v2-m3 fine-tuned seed 20260904",
            "expert_model": "Qwen3-4B-Instruct-2507 prompt-only verifier",
            "route_features": [
                "absolute local score margin",
                "precomputed domain conflict flags",
                "pay-unit mismatch",
            ],
            "reported_fixed_validation_budget": 0.20,
            "fixed_policy": {
                "priority_cutoff": selected_twenty["cutoff"],
                "fusion_strategy": selected_twenty["strategy"],
                "validation_threshold": selected_twenty["threshold"],
            },
            "test_labels_used_for_selection": False,
        },
    )
    return metrics, safety, thresholds


def disagreement_analysis(frame: pd.DataFrame, output_dir: Path) -> None:
    models = {
        "bge_v2_m3": "score_bge_v2_m3_three_seed_mean",
        "qwen06": "score_qwen06_three_seed_mean",
        "open_llm": "score_open_llm_verifier",
    }
    validation = frame[frame["evaluation_split"].eq("validation")]
    thresholds = {
        model: select_threshold(
            validation["final_label"].to_numpy(int),
            validation[column].to_numpy(float),
        )[0]
        for model, column in models.items()
    }
    predictions = np.column_stack(
        [frame[column].to_numpy(float) >= thresholds[model] for model, column in models.items()]
    )
    vote_count = predictions.sum(axis=1)
    majority = vote_count >= 2
    truth = frame["final_label"].to_numpy(int).astype(bool)
    detail = frame[
        [
            "pair_id",
            "evaluation_split",
            "query_id",
            "candidate_id",
            "final_label",
            "final_relevance",
            "difficulty",
            "final_conflict_type",
        ]
    ].copy()
    for index, model in enumerate(models):
        detail[f"prediction_{model}"] = predictions[:, index].astype(int)
    detail["positive_vote_count"] = vote_count
    detail["agreement_pattern"] = np.where(
        np.isin(vote_count, [0, 3]), "three_model_agreement", "two_to_one_disagreement"
    )
    detail["majority_prediction"] = majority.astype(int)
    detail["majority_correct"] = (majority == truth).astype(int)
    detail.to_csv(output_dir / "three_model_disagreement_rows.csv", index=False)

    summary_rows = []
    for split, group in detail.groupby("evaluation_split", sort=False):
        for pattern, part in group.groupby("agreement_pattern", sort=False):
            summary_rows.append(
                {
                    "split": split,
                    "agreement_pattern": pattern,
                    "rows": len(part),
                    "fraction": len(part) / len(group),
                    "positive_rows": int(part["final_label"].sum()),
                    "majority_errors": int((1 - part["majority_correct"]).sum()),
                    "majority_error_rate": float((1 - part["majority_correct"]).mean()),
                }
            )
    pd.DataFrame(summary_rows).to_csv(
        output_dir / "three_model_disagreement_summary.csv", index=False
    )

    conflict_rows = []
    disputed = detail[detail["agreement_pattern"].eq("two_to_one_disagreement")]
    for (split, conflict), group in disputed.groupby(
        ["evaluation_split", "final_conflict_type"], sort=False
    ):
        conflict_rows.append(
            {
                "split": split,
                "conflict_type": conflict,
                "disagreement_rows": len(group),
                "positive_rows": int(group["final_label"].sum()),
                "majority_errors": int((1 - group["majority_correct"]).sum()),
            }
        )
    pd.DataFrame(conflict_rows).to_csv(
        output_dir / "three_model_disagreement_by_conflict.csv", index=False
    )
    write_json(
        output_dir / "three_model_disagreement_manifest.json",
        {
            "status": "complete",
            "models": list(models),
            "thresholds_selected_on_validation": thresholds,
            "label_space": "binary valid-reference decision",
            "patterns": ["three_model_agreement", "two_to_one_disagreement"],
            "all_different_applicability": (
                "Not applicable: with three models and binary outputs, three mutually "
                "different predictions are mathematically impossible."
            ),
        },
    )


def runtime_summary(server: Path) -> pd.DataFrame:
    rows = []
    for path in sorted(server.glob("*/manifest.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        timing = data.get("timing", {})
        if "inference_seconds" in data:
            timing = {"prompt_only_evaluation_seconds": data["inference_seconds"]}
        for name, seconds in timing.items():
            if not name.endswith("evaluation_seconds"):
                continue
            rows.append(
                {
                    "run": path.parent.name,
                    "model": name.removesuffix("_evaluation_seconds"),
                    "evaluation_rows": data.get("evaluation_rows", 7500),
                    "evaluation_seconds": seconds,
                    "pairs_per_second": data.get("evaluation_rows", 7500) / max(seconds, 1e-12),
                    "gpu": data.get("gpu_name"),
                    "dtype": data.get("dtype"),
                }
            )
    return pd.DataFrame(rows)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    _, _, evaluation, hashes = load_data(args.data_dir)
    score_columns = add_all_scores(evaluation, args.local_root, args.server_results)
    _, metrics, safety, _ = evaluate_scores(
        evaluation,
        score_columns,
        args.output_dir / "all_models",
        bootstrap_samples=args.bootstrap,
        seed=args.seed,
    )
    multi_seed_summary(metrics).to_csv(
        args.output_dir / "three_seed_summary.csv", index=False
    )
    routing_analysis(evaluation, args.output_dir, args.bootstrap, args.seed)
    disagreement_analysis(evaluation, args.output_dir)
    runtime_summary(args.server_results).to_csv(
        args.output_dir / "server_runtime_summary.csv", index=False
    )

    evaluation[
        [
            "pair_id",
            "evaluation_split",
            "query_id",
            "candidate_id",
            "final_label",
            "final_relevance",
            "difficulty",
            "final_conflict_type",
            *score_columns.values(),
            "score_routing_fixed_20pct",
        ]
    ].to_csv(args.output_dir / "all_model_pair_scores.csv", index=False)
    write_json(
        args.output_dir / "manifest.json",
        {
            "status": "complete",
            "paper_eligible": True,
            "input_hashes": hashes,
            "model_threshold_selection": "validation only",
            "route_selection": "validation only; 20% validation budget frozen",
            "locked_or_external_labels_used_for_selection": False,
            "evaluation_rows": len(evaluation),
            "models": list(score_columns),
            "bootstrap_samples": args.bootstrap,
            "seed": args.seed,
        },
    )


if __name__ == "__main__":
    main()
