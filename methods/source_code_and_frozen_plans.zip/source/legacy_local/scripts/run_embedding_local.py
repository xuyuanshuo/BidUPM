#!/usr/bin/env python3
"""Run reproducible open bi-encoder baselines on BidUPM-vFinal."""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from huggingface_hub import model_info
from sentence_transformers import SentenceTransformer

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import (  # noqa: E402
    SEED,
    conflict_gate,
    evaluate_scores,
    item_text,
    load_data,
    write_json,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--model", default="BAAI/bge-small-en-v1.5")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--bootstrap", type=int, default=5000)
    return parser.parse_args()


def encode_unique(
    model: SentenceTransformer,
    texts: list[str],
    batch_size: int,
    prompt: str = "",
) -> np.ndarray:
    unique = list(dict.fromkeys(texts))
    embedded = model.encode(
        [prompt + text for text in unique],
        batch_size=batch_size,
        convert_to_numpy=True,
        normalize_embeddings=True,
        show_progress_bar=True,
    )
    lookup = {text: embedded[index] for index, text in enumerate(unique)}
    return np.stack([lookup[text] for text in texts])


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    _, _, evaluation, hashes = load_data(args.data_dir)
    device = "mps" if torch.backends.mps.is_available() else "cpu"
    started = time.perf_counter()
    model = SentenceTransformer(args.model, device=device)
    score_columns: dict[str, str] = {}
    variant_timings: dict[str, float] = {}
    query_prompt = "Represent this sentence for searching relevant passages: "

    for variant in ["description_only", "full"]:
        variant_start = time.perf_counter()
        queries = item_text(evaluation, "query", variant)
        candidates = item_text(evaluation, "candidate", variant)
        query_embeddings = encode_unique(model, queries, args.batch_size, query_prompt)
        candidate_embeddings = encode_unique(model, candidates, args.batch_size)
        scores = np.einsum("ij,ij->i", query_embeddings, candidate_embeddings)
        name = f"bge_small_{variant}"
        column = f"score_{name}"
        evaluation[column] = scores
        score_columns[name] = column
        if variant == "full":
            gated_name = "bge_small_full_conflict_refined"
            gated_column = f"score_{gated_name}"
            evaluation[gated_column] = conflict_gate(evaluation, scores, strength=0.20)
            score_columns[gated_name] = gated_column
        variant_timings[variant] = time.perf_counter() - variant_start

    thresholds, metrics, safety, per_query = evaluate_scores(
        evaluation,
        score_columns,
        args.output_dir,
        bootstrap_samples=args.bootstrap,
        seed=SEED,
    )
    keep = [
        "pair_id",
        "evaluation_split",
        "query_id",
        "candidate_id",
        "final_label",
        "final_relevance",
        "difficulty",
        "final_conflict_type",
        *score_columns.values(),
    ]
    evaluation[keep].to_csv(args.output_dir / "pair_scores.csv", index=False)
    try:
        revision = model_info(args.model).sha
    except Exception as exc:  # Network metadata is useful but not required for scoring.
        revision = f"unavailable: {type(exc).__name__}"
    manifest = {
        "status": "complete",
        "paper_eligible": True,
        "model": args.model,
        "model_revision": revision,
        "device": device,
        "input_hashes": hashes,
        "rows": len(evaluation),
        "models": list(score_columns),
        "query_instruction": query_prompt,
        "threshold_selection": "validation only",
        "bootstrap_samples": args.bootstrap,
        "batch_size": args.batch_size,
        "runtime_seconds": time.perf_counter() - started,
        "variant_runtime_seconds": variant_timings,
        "packages": {
            name: importlib.metadata.version(name)
            for name in ["torch", "transformers", "sentence-transformers"]
        },
        "seed": SEED,
    }
    write_json(args.output_dir / "manifest.json", manifest)
    print(json.dumps(manifest, indent=2))
    print(
        metrics[(metrics["split"].eq("locked")) & (metrics["policy"].eq("f1_opt"))][
            ["model", "top1", "recall_at_5", "mrr", "ndcg_at_5_graded", "pair_f1", "hard_pair_f1"]
        ].to_string(index=False)
    )


if __name__ == "__main__":
    main()
