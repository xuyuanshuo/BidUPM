#!/usr/bin/env python3
"""Shared data loading and evaluation utilities for BidUPM-vFinal experiments."""

from __future__ import annotations

import hashlib
import json
import math
import time
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score


SEED = 20260904
EVALUATION_SPLITS = [
    "validation",
    "locked",
    "no_reference",
    "no_reference_reclassified",
    "external",
]
RELEVANCE_GAIN = {"exact": 3.0, "acceptable": 2.0, "related": 1.0, "wrong": 0.0}
CONFLICT_FLAG_COLUMNS = [
    "action_conflict",
    "material_conflict",
    "dimension_conflict",
    "class_conflict",
    "type_conflict",
    "spec_conflict",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def _read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def load_data(data_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, str]]:
    """Load canonical training and disjoint evaluation inputs.

    The combined Top-30 no-reference export also contains the external no-positive
    queries. Primary no-reference metrics instead use only split_final=no_reference,
    while the external file retains its own mixed positive/no-positive composition.
    """

    data_dir = data_dir.resolve()
    all_path = data_dir / "pairs" / "all_pairs_vfinal_12092.csv"
    train_all_path = data_dir / "training" / "training_pairs_all_rows.csv"
    train_dedup_path = data_dir / "training" / "training_pairs_semantic_deduplicated.csv"
    validation_path = data_dir / "evaluation" / "validation_pairs.csv"
    locked_path = data_dir / "evaluation" / "locked_pairs.csv"
    external_path = data_dir / "evaluation" / "external_mixed_pairs.csv"

    all_pairs = _read(all_path)
    train_all = _read(train_all_path)
    train_dedup = _read(train_dedup_path)
    pieces = []
    for name, path in [
        ("validation", validation_path),
        ("locked", locked_path),
        ("external", external_path),
    ]:
        frame = _read(path)
        frame["evaluation_split"] = name
        pieces.append(frame)

    no_reference = all_pairs[all_pairs["split_final"].eq("no_reference")].copy()
    no_reference["evaluation_split"] = "no_reference"
    pieces.append(no_reference)
    reclassified = all_pairs[
        all_pairs["split_final"].eq("no_reference_reclassified_positive")
    ].copy()
    reclassified["evaluation_split"] = "no_reference_reclassified"
    pieces.append(reclassified)
    evaluation = pd.concat(pieces, ignore_index=True)

    expected = {
        "all": 12092,
        "train_all": 4138,
        "train_dedup": 2278,
        "validation": 900,
        "locked": 3000,
        "no_reference": 1140,
        "no_reference_reclassified": 60,
        "external": 2400,
    }
    observed = {
        "all": len(all_pairs),
        "train_all": len(train_all),
        "train_dedup": len(train_dedup),
        **evaluation["evaluation_split"].value_counts().to_dict(),
    }
    for key, value in expected.items():
        if observed.get(key) != value:
            raise RuntimeError(f"Unexpected {key} rows: {observed.get(key)} != {value}")
    if evaluation["pair_id"].duplicated().any():
        raise RuntimeError("Evaluation pair IDs overlap across primary splits")
    if not train_all["training_eligibility"].eq("1").all():
        raise RuntimeError("Canonical training includes ineligible rows")
    if set(train_all["unordered_pair_key"]) & set(evaluation["unordered_pair_key"]):
        raise RuntimeError("Symmetric semantic leakage remains between train and evaluation")
    if set(train_all["query_id"]) & set(evaluation["query_id"]):
        raise RuntimeError("Query ID leakage remains between train and evaluation")
    if not evaluation["final_label"].isin(["0", "1"]).all():
        raise RuntimeError("Evaluation labels are incomplete")

    numeric_columns = [
        "final_label",
        "retrieval_score",
        "unit_match",
        "category_match",
        "item_code_match",
        "exact_description",
        "token_jaccard",
        "token_containment",
        "sequence_ratio",
        *CONFLICT_FLAG_COLUMNS,
    ]
    for frame in [all_pairs, train_all, train_dedup, evaluation]:
        for column in numeric_columns:
            frame[column] = pd.to_numeric(frame[column], errors="raise")

    hashes = {
        str(path.relative_to(data_dir)): sha256(path)
        for path in [
            all_path,
            train_all_path,
            train_dedup_path,
            validation_path,
            locked_path,
            external_path,
        ]
    }
    return train_all, train_dedup, evaluation, hashes


def normalize_text(value: object) -> str:
    return " ".join(str(value).strip().lower().split())


def item_text(frame: pd.DataFrame, side: str, variant: str = "full") -> list[str]:
    if side not in {"query", "candidate"}:
        raise ValueError(side)
    description = frame[f"{side}_description"].map(normalize_text)
    normalized = frame[f"{side}_normalized_description"].map(normalize_text)
    unit = frame[f"{side}_normalized_unit"].map(normalize_text)
    category = frame[f"{side}_category"].map(normalize_text)
    specs = frame[f"{side}_spec_tokens"].map(normalize_text)
    if variant == "description_only":
        return description.tolist()
    if variant == "no_unit":
        return [
            f"Description: {d}. Normalized: {n}. Category: {c}. Specs: {s}."
            for d, n, c, s in zip(description, normalized, category, specs)
        ]
    if variant == "no_category_specs":
        return [
            f"Description: {d}. Normalized: {n}. Pay unit: {u}."
            for d, n, u in zip(description, normalized, unit)
        ]
    if variant != "full":
        raise ValueError(variant)
    return [
        f"Description: {d}. Normalized: {n}. Pay unit: {u}. Category: {c}. Specs: {s}."
        for d, n, u, c, s in zip(description, normalized, unit, category, specs)
    ]


def f1_counts(y: np.ndarray, scores: np.ndarray, threshold: float) -> dict[str, float | int]:
    y = np.asarray(y, dtype=int)
    scores = np.asarray(scores, dtype=float)
    pred = scores >= threshold
    tp = int(((pred == 1) & (y == 1)).sum())
    tn = int(((pred == 0) & (y == 0)).sum())
    fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum())
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-12)
    try:
        roc_auc = float(roc_auc_score(y, scores)) if len(np.unique(y)) == 2 else math.nan
        pr_auc = float(average_precision_score(y, scores)) if y.sum() else math.nan
    except ValueError:
        roc_auc = math.nan
        pr_auc = math.nan
    return {
        "rows": len(y),
        "positive": int(y.sum()),
        "negative": int(len(y) - y.sum()),
        "pair_precision": precision,
        "pair_recall": recall,
        "pair_f1": f1,
        "pair_accuracy": (tp + tn) / max(len(y), 1),
        "roc_auc": roc_auc,
        "pr_auc": pr_auc,
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
    }


def threshold_candidates(scores: np.ndarray, maximum: int = 1200) -> np.ndarray:
    unique = np.unique(np.asarray(scores, dtype=float))
    if len(unique) <= maximum:
        return np.r_[unique[0] - 1e-8, unique, unique[-1] + 1e-8]
    quantiles = np.linspace(0, 1, maximum)
    return np.unique(np.quantile(unique, quantiles))


def select_threshold(
    y: np.ndarray,
    scores: np.ndarray,
    policy: str = "f1_opt",
) -> tuple[float, dict[str, float | int]]:
    candidates = threshold_candidates(scores)
    best: tuple[tuple[float, ...], float, dict[str, float | int]] | None = None
    for threshold in candidates:
        metrics = f1_counts(y, scores, float(threshold))
        if policy == "f1_opt":
            key = (
                float(metrics["pair_f1"]),
                float(metrics["pair_precision"]),
                float(metrics["pair_recall"]),
                float(threshold),
            )
        elif policy == "precision_r80":
            recall_ok = float(metrics["pair_recall"]) >= 0.80
            key = (
                float(recall_ok),
                float(metrics["pair_precision"]) if recall_ok else float(metrics["pair_recall"]),
                float(metrics["pair_f1"]),
                float(threshold),
            )
        else:
            raise ValueError(policy)
        if best is None or key > best[0]:
            best = (key, float(threshold), metrics)
    assert best is not None
    return best[1], best[2]


def _dcg(gains: np.ndarray, k: int) -> float:
    values = gains[:k]
    if not len(values):
        return 0.0
    return float((values / np.log2(np.arange(2, len(values) + 2))).sum())


def per_query_ranking(frame: pd.DataFrame, score_column: str) -> pd.DataFrame:
    rows = []
    for query_id, group in frame.groupby("query_id", sort=True):
        ranked = group.sort_values(
            [score_column, "candidate_id"], ascending=[False, True], kind="stable"
        )
        labels = ranked["final_label"].to_numpy(dtype=int)
        positives = int(labels.sum())
        if positives == 0:
            continue
        ranks = np.flatnonzero(labels == 1) + 1
        relevance = ranked["final_relevance"].map(RELEVANCE_GAIN).fillna(0.0).to_numpy(float)
        ideal_relevance = np.sort(relevance)[::-1]
        binary = labels.astype(float)
        ideal_binary = np.sort(binary)[::-1]
        rows.append(
            {
                "query_id": query_id,
                "positives": positives,
                "top1": float(labels[0] == 1),
                "hit_at_3": float(labels[:3].sum() > 0),
                "hit_at_5": float(labels[:5].sum() > 0),
                "recall_at_3": float(labels[:3].sum() / positives),
                "recall_at_5": float(labels[:5].sum() / positives),
                "mrr": float(1.0 / ranks[0]),
                "ndcg_at_5_graded": _dcg(relevance, 5) / max(_dcg(ideal_relevance, 5), 1e-12),
                "ndcg_at_5_binary": _dcg(binary, 5) / max(_dcg(ideal_binary, 5), 1e-12),
            }
        )
    return pd.DataFrame(rows)


def bootstrap_mean_ci(
    values: np.ndarray,
    rng: np.random.Generator,
    samples: int = 5000,
) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    if len(values) == 0:
        return math.nan, math.nan
    draws = rng.choice(values, size=(samples, len(values)), replace=True).mean(axis=1)
    return float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))


def ranking_summary(
    frame: pd.DataFrame,
    score_column: str,
    rng: np.random.Generator,
    bootstrap_samples: int,
) -> tuple[dict[str, float | int], pd.DataFrame]:
    per_query = per_query_ranking(frame, score_column)
    summary: dict[str, float | int] = {"positive_queries": len(per_query)}
    metrics = [
        "top1",
        "hit_at_3",
        "hit_at_5",
        "recall_at_3",
        "recall_at_5",
        "mrr",
        "ndcg_at_5_graded",
        "ndcg_at_5_binary",
    ]
    for metric in metrics:
        values = per_query[metric].to_numpy(float) if len(per_query) else np.array([])
        low, high = bootstrap_mean_ci(values, rng, bootstrap_samples)
        summary[metric] = float(values.mean()) if len(values) else math.nan
        summary[f"{metric}_ci_low"] = low
        summary[f"{metric}_ci_high"] = high
    return summary, per_query


def safety_summary(frame: pd.DataFrame, score_column: str, threshold: float) -> dict[str, float | int]:
    records = []
    for query_id, group in frame.groupby("query_id", sort=True):
        actual_has_reference = bool(group["final_label"].astype(int).any())
        top_score = float(group[score_column].max())
        abstained = top_score < threshold
        records.append((query_id, actual_has_reference, abstained))
    if not records:
        return {"queries": 0}
    actual_no_ref = np.array([not row[1] for row in records], dtype=bool)
    abstained = np.array([row[2] for row in records], dtype=bool)
    unsafe = actual_no_ref & ~abstained
    return {
        "queries": len(records),
        "actual_no_reference_queries": int(actual_no_ref.sum()),
        "abstention_accuracy": float((abstained == actual_no_ref).mean()),
        "unsafe_top1_count": int(unsafe.sum()),
        "unsafe_top1_rate_on_no_reference": float(unsafe.sum() / max(actual_no_ref.sum(), 1)),
        "abstention_precision": float((actual_no_ref & abstained).sum() / max(abstained.sum(), 1)),
        "review_flag_recall": float((actual_no_ref & abstained).sum() / max(actual_no_ref.sum(), 1)),
    }


def conflict_gate(frame: pd.DataFrame, scores: np.ndarray, strength: float = 1.0) -> np.ndarray:
    scores = np.asarray(scores, dtype=float)
    any_conflict = frame[CONFLICT_FLAG_COLUMNS].max(axis=1).to_numpy(dtype=float)
    unit_mismatch = 1.0 - frame["unit_match"].to_numpy(dtype=float)
    return scores - strength * (1.25 * unit_mismatch + 0.75 * any_conflict)


def evaluate_scores(
    frame: pd.DataFrame,
    score_columns: dict[str, str],
    output_dir: Path,
    bootstrap_samples: int = 5000,
    seed: int = SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    output_dir.mkdir(parents=True, exist_ok=True)
    validation = frame[frame["evaluation_split"].eq("validation")]
    rng = np.random.default_rng(seed)
    threshold_rows = []
    metric_rows = []
    safety_rows = []
    per_query_rows = []
    for model, score_column in score_columns.items():
        for policy in ["f1_opt", "precision_r80"]:
            threshold, val_metrics = select_threshold(
                validation["final_label"].to_numpy(int),
                validation[score_column].to_numpy(float),
                policy,
            )
            threshold_rows.append(
                {"model": model, "policy": policy, "threshold": threshold, **val_metrics}
            )
            for split in EVALUATION_SPLITS:
                subset = frame[frame["evaluation_split"].eq(split)]
                classification = f1_counts(
                    subset["final_label"].to_numpy(int),
                    subset[score_column].to_numpy(float),
                    threshold,
                )
                ranking, per_query = ranking_summary(
                    subset, score_column, rng, bootstrap_samples
                )
                hard = subset[subset["difficulty"].eq("hard")]
                hard_metrics = f1_counts(
                    hard["final_label"].to_numpy(int),
                    hard[score_column].to_numpy(float),
                    threshold,
                )
                metric_rows.append(
                    {
                        "split": split,
                        "model": model,
                        "policy": policy,
                        "threshold_selected_on_validation": threshold,
                        **classification,
                        **ranking,
                        "hard_rows": len(hard),
                        "hard_positive": int(hard["final_label"].sum()),
                        "hard_pair_precision": hard_metrics["pair_precision"],
                        "hard_pair_recall": hard_metrics["pair_recall"],
                        "hard_pair_f1": hard_metrics["pair_f1"],
                    }
                )
                if len(per_query):
                    per_query.insert(0, "policy", policy)
                    per_query.insert(0, "model", model)
                    per_query.insert(0, "split", split)
                    per_query_rows.append(per_query)
                if split in {"no_reference", "external", "no_reference_reclassified"}:
                    safety_rows.append(
                        {
                            "split": split,
                            "model": model,
                            "policy": policy,
                            "threshold_selected_on_validation": threshold,
                            **safety_summary(subset, score_column, threshold),
                        }
                    )
    thresholds = pd.DataFrame(threshold_rows)
    metrics = pd.DataFrame(metric_rows)
    safety = pd.DataFrame(safety_rows)
    per_query = pd.concat(per_query_rows, ignore_index=True) if per_query_rows else pd.DataFrame()
    thresholds.to_csv(output_dir / "validation_thresholds.csv", index=False)
    metrics.to_csv(output_dir / "metrics.csv", index=False)
    safety.to_csv(output_dir / "safety_metrics.csv", index=False)
    per_query.to_csv(output_dir / "per_query_ranking.csv", index=False)
    return thresholds, metrics, safety, per_query


def time_call(function, *args, **kwargs):
    start = time.perf_counter()
    value = function(*args, **kwargs)
    return value, time.perf_counter() - start

