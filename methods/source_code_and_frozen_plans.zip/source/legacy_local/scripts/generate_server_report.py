#!/usr/bin/env python3
"""Generate a concise completion report from consolidated server experiments."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


REPORT_MODELS = [
    "tfidf",
    "bge_small_embedding",
    "bge_v2_m3_zero_shot",
    "bge_v2_m3_three_seed_mean",
    "bge_v2_m3_hard_refined",
    "qwen06_three_seed_mean",
    "qwen4_zero_shot",
    "qwen4_fine_tuned",
    "open_llm_verifier",
]


def markdown_table(frame: pd.DataFrame, digits: int) -> str:
    def format_value(value: object) -> str:
        if pd.isna(value):
            return ""
        if isinstance(value, float):
            return f"{value:.{digits}f}"
        return str(value)

    header = "| " + " | ".join(frame.columns) + " |"
    rule = "| " + " | ".join(["---"] * len(frame.columns)) + " |"
    rows = [
        "| " + " | ".join(format_value(value) for value in row) + " |"
        for row in frame.itertuples(index=False, name=None)
    ]
    return "\n".join([header, rule, *rows])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-dir", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    root = args.package_dir / "consolidated_final"
    metrics = pd.read_csv(root / "all_models" / "metrics.csv")
    seeds = pd.read_csv(root / "three_seed_summary.csv")
    routing = pd.read_csv(root / "routing_budget_curve.csv")
    significance = pd.read_csv(root / "locked_query_cluster_bootstrap.csv")
    audit = json.loads(
        (args.package_dir / "audits" / "server_results_audit.json").read_text(
            encoding="utf-8"
        )
    )

    columns = [
        "model",
        "pair_precision",
        "pair_recall",
        "pair_f1",
        "hard_pair_f1",
        "top1",
        "recall_at_5",
        "mrr",
        "ndcg_at_5_graded",
    ]

    def metric_table(split: str) -> str:
        selected = metrics[
            metrics["split"].eq(split)
            & metrics["policy"].eq("f1_opt")
            & metrics["model"].isin(REPORT_MODELS)
        ][columns]
        return markdown_table(selected.sort_values("pair_f1", ascending=False), 4)

    seed_table = seeds[
        seeds["split"].eq("locked")
        & seeds["metric"].isin(
            ["pair_f1", "hard_pair_f1", "recall_at_5", "ndcg_at_5_graded"]
        )
    ][
        [
            "model_family",
            "metric",
            "seeds",
            "mean",
            "sample_std",
            "minimum",
            "maximum",
        ]
    ]
    route_table = routing[routing["validation_budget"].eq(0.2)][
        [
            "split",
            "rows",
            "routed_rows",
            "routed_fraction",
            "call_reduction_fraction",
            "error_capture_recall",
            "pair_precision",
            "pair_recall",
            "pair_f1",
        ]
    ]
    significance_table = significance[significance["metric"].eq("pair_f1")][
        [
            "reference",
            "comparison",
            "observed_difference",
            "ci_low",
            "ci_high",
            "p_two_sided",
        ]
    ]

    report = f"""# BidUPM-vFinal GPU Experiment Completion Report

Generated: 2026-09-05

## Completion and provenance

- GPU experiment runs: **{audit['expected_runs']} / {audit['expected_runs']}**
- Automated audit checks: **{audit['checks']} passed, {audit['failures']} failed**
- Evaluation predictions per run: **7,500 unique pairs**
- Threshold/model selection: **validation only**
- Locked/external labels used for selection: **no**
- Canonical dataset: **BidUPM-vFinal, 12,092 pairs**

## Locked internal test

{metric_table('locked')}

## External mixed test

{metric_table('external')}

## Three-seed stability

{markdown_table(seed_table, 6)}

## Fixed 20% validation-budget routing

{markdown_table(route_table, 4)}

The open verifier is Qwen3-4B-Instruct-2507. The routing strategy, priority cutoff,
fusion rule, and final threshold were selected on validation and then frozen.

## Paired query-cluster bootstrap on Locked pair F1

{markdown_table(significance_table, 6)}

## Interpretation boundaries

- The strongest stable standard result is BGE-reranker-v2-m3 over three seeds.
- The hard-focused BGE run gives the strongest Locked pair F1 and improves hard-case
  F1, but it is reported separately from the standard three-seed result.
- Top-1 is saturated for several neural methods on the 100 positive-containing Locked
  queries. Pair F1, Recall@5, nDCG@5, hard F1, no-reference safety, and external
  transfer are therefore all reported.
- External hard F1 is not a stable headline statistic because the external split
  contains only three hard-positive pairs.
- Selective routing reduces calls, but the open verifier does not improve the primary
  reranker automatically. It is best interpreted as a review and audit route.
"""
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(report, encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
