#!/usr/bin/env python3
"""Independent, offline evaluation of completed selective GPT agent judgments.

This is a post-hoc diagnostic on an already studied formal test. Reconstruct
every policy from frozen inputs/outputs before reading authoritative labels.
Never rejudge labels, call a model, retune a threshold, or estimate API costs.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE.parent / "rule_first_system_20261004/results/server"
PRIVATE = BASE / "results/selective_gpt6_sol"
OUT = PRIVATE / "evaluation"
SEEDS = (20260904, 20260905, 20260906)
FIELDS = ("description", "normalized_description", "normalized_unit", "category", "spec_tokens")
QKEYS = ["evaluation_split", "query_id"]
GROUPS = {
    "locked": ["locked"], "no_reference": ["no_reference"],
    "no_reference_reclassified": ["no_reference_reclassified"], "external": ["external"],
    "internal_combined": ["locked", "no_reference", "no_reference_reclassified"],
    "all_formal": ["locked", "no_reference", "no_reference_reclassified", "external"],
}
META = ["source", "policy", "seed", "batch_size"]


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def read_json(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=strict_object)


def read_jsonl(path):
    return [json.loads(line, object_pairs_hook=strict_object)
            for line in Path(path).read_text().splitlines() if line.strip()]


def safe(value):
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe(v) for v in value]
    if isinstance(value, (np.integer, np.bool_)):
        return value.item()
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(value) else None
    return value


def dump(path, value):
    Path(path).write_text(json.dumps(safe(value), ensure_ascii=False, indent=2) + "\n")


def rate(num, den):
    return 100 * num / den if den else np.nan


def exact_series(inputs):
    def canonical(text):
        return " ".join(re.sub(r"[^a-z0-9]+", " ", text.lower().replace("&", " and ")).split())
    def unit(text):
        return " ".join(text.lower().strip().split())
    qd, cd = (inputs[f"{r}_normalized_description"].map(canonical) for r in ["query", "candidate"])
    qu, cu = (inputs[f"{r}_normalized_unit"].map(unit) for r in ["query", "candidate"])
    return qd.ne("") & qu.ne("") & qd.eq(cd) & qu.eq(cu)


def rank_pandas(frame, accepted):
    """Exact priority, ID order; nonexact BGE score desc / candidate ID tie."""
    rank = pd.Series(0, index=frame.index, dtype=int)
    for _, part in frame.groupby(QKEYS, sort=False):
        rules = part[part.exact_match.eq(1)].sort_values("candidate_id", kind="stable")
        model = part[part.exact_match.eq(0) & accepted.loc[part.index]]
        require(np.isfinite(model.score.to_numpy(float)).all(), "Accepted nonexact score missing")
        model = model.sort_values(["score", "candidate_id"], ascending=[False, True], kind="stable")
        chosen = pd.concat([rules, model]).head(3)
        rank.loc[chosen.index] = range(1, len(chosen) + 1)
    return rank


def rank_python(records, accepted_ids):
    """Independent list/dictionary reconstruction; does not use pandas rank."""
    groups, ranks = defaultdict(list), {r["pair_id"]: 0 for r in records}
    for row in records:
        groups[(row["evaluation_split"], row["query_id"])].append(row)
    for pool in groups.values():
        rules = sorted((r for r in pool if int(r["exact_match"]) == 1), key=lambda r: r["candidate_id"])
        model = sorted((r for r in pool if int(r["exact_match"]) == 0 and r["pair_id"] in accepted_ids),
                       key=lambda r: (-float(r["score"]), r["candidate_id"]))
        for order, row in enumerate((rules + model)[:3], 1):
            ranks[row["pair_id"]] = order
    return ranks


def validate_blind_and_inputs(qa):
    manifest = read_json(PRIVATE / "frozen_manifest.json")
    require(manifest["status"] == "frozen_before_selective_judgment", "Selective input was not frozen")
    require(manifest["labels_read"] is False and manifest["previous_gpt_predictions_read"] is False,
            "Freeze does not declare label/prior-answer isolation")
    require(manifest["api_latency_and_cost_measured"] is False, "Unexpected API cost claim")
    require(sha(BASE / "scripts/prepare_selective_gpt_verification.py") == manifest["created_by_sha256"],
            "Executed preparation script hash changed")
    for relative, expected in manifest["source_sha256"].items():
        require(sha(BASE / relative) == expected, f"Frozen source hash differs: {relative}")
    input_path = BASE / "blind_selective_gpt6_sol/inputs/query_pools.jsonl"
    output_path = BASE / "blind_selective_gpt6_sol/outputs/predictions.jsonl"
    notes_path = output_path.parent / "decision_notes.json"
    require(sha(input_path) == manifest["input_sha256"], "Selective input hash mismatch")
    pools, predictions, notes = read_jsonl(input_path), read_jsonl(output_path), read_json(notes_path)
    require(len(pools) == len(predictions) == manifest["query_n"] == 9, "Selective pool count differs")
    pindex, oindex, offered, accepted_keys, flat = {}, {}, set(), set(), []
    for pool in pools:
        q = pool["query_key"]
        require(q not in pindex and isinstance(q, str), "Repeated/invalid selective query key")
        require(set(pool) == {"query_key", "query", "candidates"}, "Unapproved selective pool fields")
        require(set(pool["query"]) == set(FIELDS), "Query contains gold, score, or metadata fields")
        require(all(isinstance(pool["query"][f], str) for f in FIELDS), "Invalid query field type")
        require(isinstance(pool["candidates"], list) and bool(pool["candidates"]), "Empty candidate pool")
        pindex[q] = pool
        for c in pool["candidates"]:
            require(set(c) == {"candidate_key", *FIELDS}, "Candidate contains gold, score, or metadata fields")
            require(all(isinstance(c[f], str) for f in FIELDS), "Invalid candidate field type")
            k = (q, c["candidate_key"])
            require(k not in offered and isinstance(k[1], str), "Duplicate/invalid candidate key")
            offered.add(k)
            flat.append({"query_key": q, "candidate_key": k[1],
                         **{f"query_{f}": pool["query"][f] for f in FIELDS},
                         **{f"candidate_{f}": c[f] for f in FIELDS}})
    for row in predictions:
        require(set(row) == {"query_key", "accepted"}, "Unapproved prediction fields")
        q, accepted = row["query_key"], row["accepted"]
        require(q not in oindex and q in pindex, "Repeated/unknown output query")
        require(isinstance(accepted, list) and all(isinstance(c, str) for c in accepted), "Malformed accepted keys")
        require(len(accepted) == len(set(accepted)), "Repeated accepted key")
        require(all((q, c) in offered for c in accepted), "Accepted key was not offered")
        accepted_keys.update((q, c) for c in accepted)
        oindex[q] = row
    require(set(pindex) == set(oindex) == set(notes), "Input/output/decision-note coverage differs")
    require(len(offered) == manifest["unique_candidate_pairs"] == 25, "Selective pair count differs")
    decisions = []
    for q, pool in pindex.items():
        require(set(notes[q]) == {c["candidate_key"] for c in pool["candidates"]}, "Offered candidate missing a judgment")
        for c, note in notes[q].items():
            require(set(note) == {"decision", "reason"} and isinstance(note["reason"], str) and bool(note["reason"]),
                    "Malformed decision note")
            require(note["decision"] in {"accept", "reject_conflict", "reject_uncertain"}, "Unknown judgment")
            require((note["decision"] == "accept") == ((q, c) in accepted_keys), "Prediction/decision-note disagreement")
            decisions.append({"query_key": q, "candidate_key": c, "verifier_accept": int((q,c) in accepted_keys), **note})
    mapping = pd.read_csv(PRIVATE / "private_mapping.csv", dtype=str, keep_default_na=False)
    full_mapping = pd.read_csv(BASE / "results/gpt6_sol_blind/private_mapping.csv", dtype=str, keep_default_na=False)
    require(list(mapping.columns) == ["query_key", "candidate_key", "pair_id"], "Selective mapping schema differs")
    require(len(mapping) == 25 and not mapping.pair_id.duplicated().any() and
            not mapping.duplicated(["query_key", "candidate_key"]).any(), "Selective mapping is not bijective")
    require(set(map(tuple, mapping[["query_key", "candidate_key"]].to_numpy())) == offered, "Mapping/payload key mismatch")
    matched_mapping = mapping.merge(full_mapping, on=["query_key", "candidate_key"], validate="one_to_one", suffixes=("", "_full"))
    require(len(matched_mapping) == 25 and matched_mapping.pair_id.eq(matched_mapping.pair_id_full).all(), "Original mapping changed")
    orig_pools = {p["query_key"]: p for p in read_jsonl(BASE / "blind_gpt6_sol/inputs/query_pools.jsonl")}
    for q, pool in pindex.items():
        require(pool["query"] == orig_pools[q]["query"], "Selective query text changed")
        original_candidates = {c["candidate_key"]: c for c in orig_pools[q]["candidates"]}
        require(all(c == original_candidates[c["candidate_key"]] for c in pool["candidates"]), "Selective candidate text changed")
    source_manifest = read_json(SOURCE / "source_manifest.json")
    require(sha(SOURCE / "inputs.csv") == source_manifest["inputs_sha256"], "Authoritative input hash mismatch")
    inputs = pd.read_csv(SOURCE / "inputs.csv", dtype=str, keep_default_na=False)
    require(list(inputs.columns) == source_manifest["inference_input_contract"], "Authoritative input schema differs")
    inputs = inputs[inputs.evaluation_split.isin(GROUPS["all_formal"])].copy()
    require(len(inputs) == 6600 and inputs.pair_id.nunique() == 6600, "Formal input count/key mismatch")
    require(inputs.groupby(QKEYS).size().eq(30).all() and len(inputs.groupby(QKEYS)) == 220, "Formal pool scope mismatch")
    inputs["exact_match"] = exact_series(inputs).astype(int)
    decoded = pd.DataFrame(flat).merge(mapping, on=["query_key", "candidate_key"], validate="one_to_one")
    decoded = decoded.merge(inputs, on="pair_id", validate="one_to_one", suffixes=("_blind", ""))
    require(len(decoded) == 25, "Selective payload not fully joined to source")
    for r in ["query", "candidate"]:
        for f in FIELDS:
            require(decoded[f"{r}_{f}"].eq(decoded[f"{r}_{f}_blind"]).all(), f"Authoritative content mismatch: {r}_{f}")
    decoded = decoded.merge(pd.DataFrame(decisions), on=["query_key", "candidate_key"], validate="one_to_one")
    require(decoded.exact_match.eq(0).all(), "An exact candidate entered the verifier")
    accepted_ids = set(decoded.loc[decoded.verifier_accept.eq(1), "pair_id"])
    qa["blind_integrity"] = {"status": "passed", "query_n": 9, "offered_pair_n": 25,
        "judged_pair_n": len(decisions), "accepted_pair_n": len(accepted_ids),
        "all_offered_candidates_have_explicit_notes": True, "accepted_keys_unique_and_offered": True,
        "payload_exact_field_allowlist": True, "gold_score_seed_prior_answer_fields_absent": True,
        "source_text_and_private_mapping_equal_frozen_original": True,
        "input_sha256": sha(input_path), "output_sha256": sha(output_path),
        "notes_sha256": sha(notes_path), "private_mapping_sha256": sha(PRIVATE / "private_mapping.csv"),
        "freeze_manifest_sha256": sha(PRIVATE / "frozen_manifest.json"),
        "source_sha256_verified": manifest["source_sha256"],
        "input_source_hashes_verified_before_gold_join": True,
        "judge_identity_basis": "Frozen declared gpt-6-sol/medium agent task; no API provider usage metadata",
        "predictions_and_all_notes_complete_before_evaluator_gold_read": True}
    return inputs, decoded, accepted_ids, manifest, source_manifest


def validate_runtime_part(raw, inputs, seed, threshold, policy):
    part = raw[(raw.policy == policy) & (raw.batch_size == 64)].copy()
    require(len(part) == 6600 and part.pair_id.nunique() == 6600 and set(part.pair_id) == set(inputs.pair_id), "Runtime scope/key mismatch")
    require(part.seed.eq(seed).all() and part.threshold.eq(threshold).all(), "Frozen runtime seed/threshold changed")
    part = part.merge(inputs.drop(columns=QKEYS), on="pair_id", validate="one_to_one", suffixes=("_recorded", ""))
    require(part.exact_match_recorded.eq(part.exact_match).all(), "Runtime exact rule differs")
    for col in ["prediction", "returned_rank", "model_called", "rule_accept", "exact_match"]:
        require(part[col].notna().all(), f"Runtime {col} is missing")
    exact_count = part.groupby(QKEYS).exact_match.transform("sum")
    called = part.exact_match.eq(0) & exact_count.lt(3) if policy == "system_top3" else pd.Series(False, index=part.index)
    expected = part.exact_match.copy()
    expected.loc[called] = part.loc[called, "score"].ge(threshold).astype(int)
    if policy == "system_top3":
        expected.loc[part.exact_match.eq(0) & exact_count.ge(3)] = -1
    require(part.model_called.eq(called.astype(int)).all() and part.rule_accept.eq(part.exact_match).all(), "Runtime gate differs")
    require(part.prediction.eq(expected).all(), "Runtime frozen decisions differ")
    require(part.loc[~called, "score"].isna().all() and np.isfinite(part.loc[called, "score"].to_numpy(float)).all(), "Runtime score visibility differs")
    accepted = part.model_called.eq(1) & part.prediction.eq(1) & part.exact_match.eq(0)
    reconstructed = rank_pandas(part, accepted)
    require(reconstructed.eq(part.returned_rank).all(), "Runtime recorded Top3 does not reconstruct")
    pure = rank_python(part.to_dict("records"), set(part.loc[accepted, "pair_id"]))
    require(part.pair_id.map(pure).eq(part.returned_rank).all(), "Independent Python runtime Top3 differs")
    return part.drop(columns=["exact_match_recorded"])


def reconstruct(inputs, selective, accepted_ids, manifest, qa):
    runtime_manifest = read_json(BASE / "results/runtime/execution_manifest.json")
    require(runtime_manifest["status"] == "complete" and runtime_manifest["labels_accessed"] is False
            and runtime_manifest["thresholds_retuned"] is False, "Runtime source is incomplete or retuned")
    runs = {int(r["seed"]): r for r in runtime_manifest["completed_runs"]}
    require(set(runs) == set(SEEDS), "Unexpected runtime seeds")
    original_manifest = read_json(SOURCE / "execution_manifest.json")
    require(original_manifest["status"] == "complete" and original_manifest["labels_accessed_by_runner"] is False
            and original_manifest["gate_label_access"] is False, "Original formal execution not complete/blind")
    original_runs = {int(r["seed"]): r for r in original_manifest["runs"]}
    require(set(original_runs) == set(SEEDS), "Original formal seed set changed")
    previous = read_jsonl(BASE / "blind_gpt6_sol/outputs/predictions.jsonl")
    require(len(previous) == 220 and len({p["query_key"] for p in previous}) == 220, "Previous full-pool GPT incomplete")
    fmap = pd.read_csv(BASE / "results/gpt6_sol_blind/private_mapping.csv", dtype=str, keep_default_na=False)
    full_accepted_keys = set()
    for p in previous:
        require(p["adjudication_complete"] is True and len(set(p["accepted_candidates"])) == len(p["accepted_candidates"]), "Previous GPT judgment incomplete/duplicate")
        full_accepted_keys.update((p["query_key"], c) for c in p["accepted_candidates"])
    full_accept_ids = {r.pair_id for r in fmap.itertuples() if (r.query_key, r.candidate_key) in full_accepted_keys}
    selective = selective.copy()
    selective["prior_fullpool_gpt_accept"] = selective.pair_id.isin(full_accept_ids).astype(int)
    rows, changes, checks = [], [], []
    for seed in SEEDS:
        path = BASE / f"results/runtime/predictions_seed_{seed}.csv"
        require(sha(path) == runs[seed]["prediction_sha256"], "Runtime completed hash differs")
        raw = pd.read_csv(path, float_precision="round_trip")
        rule = validate_runtime_part(raw, inputs, seed, runs[seed]["threshold"], "rule_only")
        old = validate_runtime_part(raw, inputs, seed, runs[seed]["threshold"], "system_top3")
        original_path = SOURCE / f"predictions_seed_{seed}.csv"
        require(sha(original_path) == original_runs[seed]["prediction_sha256"], "Original formal prediction SHA differs")
        original = pd.read_csv(original_path, float_precision="round_trip")
        original_scope = original[original.pair_id.isin(inputs.pair_id)]
        formal_checks = []
        for actual, original_policy in [(rule, "rule_only"), (old, "stop_3")]:
            formal_part = original_scope[original_scope.policy.eq(original_policy)]
            require(len(formal_part) == 6600 and formal_part.pair_id.nunique() == 6600, "Original formal baseline scope differs")
            check = actual[["pair_id", "prediction", "returned_rank"]].merge(
                formal_part[["pair_id", "prediction", "returned_rank"]], on="pair_id", validate="one_to_one", suffixes=("_runtime", "_formal"))
            pdiff = int(check.prediction_runtime.ne(check.prediction_formal).sum())
            rdiff = int(check.returned_rank_runtime.ne(check.returned_rank_formal).sum())
            require(pdiff == rdiff == 0, "Runtime and original formal baseline differ; must report separately")
            formal_checks.append({"original_policy": original_policy, "candidate_n": 6600,
                                  "prediction_disagreement_n": pdiff, "rank_disagreement_n": rdiff})
        eligible = old.model_called.eq(1) & old.prediction.eq(1) & old.exact_match.eq(0)
        eligible_ids = set(old.loc[eligible, "pair_id"])
        require(eligible_ids == set(manifest["seed_eligible_pair_ids"][str(seed)]), "Frozen selective candidate selection changed")
        require(eligible_ids.issubset(set(selective.pair_id)), "An eligible pair was never offered to new verifier")
        for frame, name in [(rule, "rule_only_top3"), (old, "old_system_top3")]:
            frame["source"], frame["policy"] = "runtime_frozen_batch64", name
            rows.append(frame)
        for mask_ids, name in [(accepted_ids, "selective_gpt_top3"), (full_accept_ids, "same_runtime_fullpool_gpt_and_top3")]:
            frame = old.copy()
            retained = eligible & frame.pair_id.isin(mask_ids)
            frame["eligible_nonexact"] = eligible.astype(int)
            frame["verifier_accept"] = frame.pair_id.isin(mask_ids).astype(int)
            frame.loc[eligible & ~retained, "prediction"] = 0
            frame["returned_rank"] = rank_pandas(frame, retained)
            py_ranks = rank_python(old.to_dict("records"), set(frame.loc[retained, "pair_id"]))
            require(frame.pair_id.map(py_ranks).eq(frame.returned_rank).all(), "Independent selective Top3 differs")
            require(frame.loc[frame.exact_match.eq(1), "prediction"].eq(1).all(), "Exact acceptance altered")
            frame["source"], frame["policy"] = "posthoc_selective_agent_diagnostic", name
            rows.append(frame)
        new = rows[-2]
        matched = old[["pair_id", "prediction", "returned_rank"]].merge(new[["pair_id", "prediction", "returned_rank"]],
            on="pair_id", validate="one_to_one", suffixes=("_old", "_new"))
        matched["seed"] = seed
        changes.append(matched)
        checks.append({"seed": seed, "eligible_nonexact_n": len(eligible_ids),
                       "new_retained_nonexact_n": len(eligible_ids & accepted_ids),
                       "ranking_matches_two_independent_implementations": True,
                       "runtime_baseline_recorded_ranks_reproduced": True,
                       "original_formal_prediction_sha256": sha(original_path),
                       "original_formal_baseline_crosscheck": formal_checks})
    union = set().union(*(set(v) for v in manifest["seed_eligible_pair_ids"].values()))
    require(union == set(selective.pair_id), "Offered set not equal to frozen three-seed eligibility union")
    # Bring in the *previous* frozen full-score AND policy, whose BGE scores may
    # differ from subset-scored runtime; comparison must preserve this distinction.
    family_root = BASE / "results/gpt6_sol_blind/posthoc_complementarity"
    family = read_json(family_root / "family_freeze.json")
    require(sha(BASE / "blind_gpt6_sol/outputs/predictions.jsonl") == family["frozen_input_hashes"]["gpt_output"]["sha256"],
            "Previous completed full-pool judgment hash changed")
    require(sha(family_root / "frozen_counterfactual_predictions.csv") == family["counterfactual_prediction_sha256"], "Previous posthoc prediction hash changed")
    historical = pd.read_csv(family_root / "frozen_counterfactual_predictions.csv")
    historical = historical[historical.policy.eq("exact_bge_and_gpt_fallback")].copy()
    require(len(historical) == 19800 and set(historical.seed) == set(SEEDS), "Previous posthoc AND scope mismatch")
    historical = historical.merge(inputs.drop(columns=QKEYS + ["candidate_id", "exact_match"]), on="pair_id", validate="many_to_one")
    historical["source"], historical["policy"] = "previous_full_bge_score_counterfactual", "prior_posthoc_fullscore_and_top3"
    rows.append(historical)
    predictions = pd.concat(rows, ignore_index=True)
    require(not predictions.duplicated(META + ["pair_id"]).any(), "Duplicate reconstructed prediction")
    require(predictions.groupby(META + QKEYS).returned_rank.apply(lambda x: sorted(x[x.gt(0)].tolist()) == list(range(1, int(x.gt(0).sum()) + 1))).all(), "Nonconsecutive/over-cap rank")
    require(predictions.groupby(META + QKEYS).returned_rank.apply(lambda x: x.gt(0).sum()).le(3).all(), "Top3 cap exceeded")
    cols = META + ["pair_id", *QKEYS, "candidate_id", "exact_match", "prediction", "returned_rank"]
    predictions[cols].to_csv(OUT / "reconstructed_predictions_before_gold.csv", index=False)
    qa["reconstruction"] = {"status": "passed", "seeds": list(SEEDS), "batch_size": 64,
        "thresholds_retuned": False, "new_rule_or_conflict_filter": False, "original_scores_preserved": True,
        "candidate_order": "exact first by candidate ID, nonexact original BGE score descending then candidate ID; max3",
        "gold_used_in_selection_acceptance_gate_or_order": False, "per_seed_checks": checks,
        "prediction_only_csv_sha256": sha(OUT / "reconstructed_predictions_before_gold.csv"),
        "prior_fullpool_gpt_sha256": sha(BASE / "blind_gpt6_sol/outputs/predictions.jsonl"),
        "prior_posthoc_predictions_sha256": family["counterfactual_prediction_sha256"]}
    return predictions, selective, pd.concat(changes, ignore_index=True)


def query_frame(predictions):
    rows = []
    for key, part in predictions.groupby(META + QKEYS):
        returned, gold, exact = part.returned_rank.gt(0), part.final_label.eq(1), part.exact_match.eq(1)
        positive, tp, fp = int(gold.sum()), int((gold & returned).sum()), int((~gold & returned).sum())
        rows.append({**dict(zip(META + QKEYS, key)), "candidate_n": len(part),
            "positive_n": positive, "exact_positive_n": int((gold & exact).sum()),
            "nonexact_positive_n": int((gold & ~exact).sum()), "returned_n": tp+fp,
            "returned_tp_n": tp, "returned_fp_n": fp, "returned_fn_n": positive-tp,
            "returned_nonexact_tp_n": int((returned & gold & ~exact).sum()),
            "returned_nonexact_fp_n": int((returned & ~gold & ~exact).sum()),
            "recall_at3": tp/positive if positive else np.nan,
            "hit": int(tp>0), "wrong_reference": int(fp>0), "pool_rejected": int(tp+fp==0),
            "returned_pairs": json.dumps(part[returned].sort_values("returned_rank").pair_id.tolist()),
            "missing_positive_pairs": json.dumps(part[gold & ~returned].pair_id.tolist())})
    return pd.DataFrame(rows)


def summary_frame(predictions, queries):
    rows = []
    for group, splits in GROUPS.items():
        selected = predictions[predictions.evaluation_split.isin(splits)]
        for key, part in queries[queries.evaluation_split.isin(splits)].groupby(META):
            identity = dict(zip(META, key))
            pairs = selected.copy()
            for k, v in identity.items():
                pairs = pairs[pairs[k].eq(v)]
            positive, noref = part.positive_n.gt(0), part.positive_n.eq(0)
            tp, fp, gold = int(part.returned_tp_n.sum()), int(part.returned_fp_n.sum()), int(part.positive_n.sum())
            returned = pairs.returned_rank.gt(0)
            accepted, exact, pos = pairs.prediction.eq(1), pairs.exact_match.eq(1), pairs.final_label.eq(1)
            loss = {"gate_skipped_positive_n": int((pairs.prediction.eq(-1) & pos).sum()),
                    "rejected_positive_n": int((pairs.prediction.eq(0) & pos).sum()),
                    "accepted_positive_not_returned_n": int((accepted & pos & ~returned).sum())}
            require(sum(loss.values())+tp == gold, "Positive loss accounting does not close")
            rows.append({**identity, "evaluation_group": group, "query_n": len(part),
                "positive_query_n": int(positive.sum()), "no_reference_query_n": int(noref.sum()),
                "candidate_pair_n": len(pairs), "gold_positive_n": gold, "returned_n": tp+fp,
                "returned_tp_n": tp, "returned_fp_n": fp, "returned_fn_n": gold-tp,
                "returned_precision_pct": rate(tp,tp+fp), "micro_recall_at3_pct": rate(tp,gold),
                "macro_recall_at3_pct": 100*part.loc[positive, "recall_at3"].mean(),
                "hit_query_n": int(part.loc[positive, "hit"].sum()),
                "hit_at3_pct": rate(part.loc[positive, "hit"].sum(),positive.sum()),
                "wrong_reference_query_n": int(part.wrong_reference.sum()),
                "wrong_reference_query_rate_pct": rate(part.wrong_reference.sum(),len(part)),
                "no_reference_rejected_query_n": int(part.loc[noref, "pool_rejected"].sum()),
                "no_reference_pool_rejection_pct": rate(part.loc[noref, "pool_rejected"].sum(),noref.sum()),
                "nonexact_positive_n": int(part.nonexact_positive_n.sum()),
                "returned_nonexact_tp_n": int(part.returned_nonexact_tp_n.sum()),
                "returned_nonexact_fp_n": int(part.returned_nonexact_fp_n.sum()),
                "nonexact_micro_recall_at3_pct": rate(part.returned_nonexact_tp_n.sum(),part.nonexact_positive_n.sum()),
                "accepted_n": int(accepted.sum()), "accepted_nonexact_tp_n": int((accepted & ~exact & pos).sum()),
                "accepted_nonexact_fp_n": int((accepted & ~exact & ~pos).sum()),
                "unobserved_pair_n": int(pairs.prediction.eq(-1).sum()), **loss})
    return pd.DataFrame(rows)


def independent_count_crosscheck(predictions, summary):
    """Direct raw-record loops and query lists independently reconcile metrics."""
    grouped = defaultdict(list)
    for r in predictions.to_dict("records"):
        grouped[tuple(r[k] for k in META)].append(r)
    comparisons = []
    for sm in summary.to_dict("records"):
        identity = tuple(sm[k] for k in META)
        records = [r for r in grouped[identity] if r["evaluation_split"] in GROUPS[sm["evaluation_group"]]]
        pools = defaultdict(list)
        for r in records:
            pools[(r["evaluation_split"],r["query_id"])].append(r)
        tp = sum(int(r["final_label"])==1 and int(r["returned_rank"])>0 for r in records)
        fp = sum(int(r["final_label"])==0 and int(r["returned_rank"])>0 for r in records)
        gold = sum(int(r["final_label"]) for r in records)
        recalls, hits, noref_reject, noref_n = [], [], 0, 0
        for pool in pools.values():
            positives = sum(int(r["final_label"]) for r in pool)
            found = sum(int(r["final_label"])==1 and int(r["returned_rank"])>0 for r in pool)
            if positives:
                recalls.append(found/positives)
                hits.append(int(found>0))
            else:
                noref_n += 1
                noref_reject += int(all(int(r["returned_rank"])==0 for r in pool))
        nonexact_gold = sum(int(r["final_label"])==1 and int(r["exact_match"])==0 for r in records)
        nonexact_tp = sum(int(r["final_label"])==1 and int(r["exact_match"])==0 and int(r["returned_rank"])>0 for r in records)
        expected = {"query_n":len(pools),"gold_positive_n":gold,"returned_tp_n":tp,"returned_fp_n":fp,
                    "returned_fn_n":gold-tp,"returned_precision_pct":rate(tp,tp+fp),
                    "macro_recall_at3_pct":100*sum(recalls)/len(recalls) if recalls else np.nan,
                    "hit_at3_pct":rate(sum(hits),len(hits)),"nonexact_positive_n":nonexact_gold,
                    "returned_nonexact_tp_n":nonexact_tp,"nonexact_micro_recall_at3_pct":rate(nonexact_tp,nonexact_gold),
                    "no_reference_query_n":noref_n,"no_reference_rejected_query_n":noref_reject,
                    "no_reference_pool_rejection_pct":rate(noref_reject,noref_n)}
        for metric, value in expected.items():
            actual = sm[metric]
            passed = (pd.isna(actual) and pd.isna(value)) or math.isclose(float(actual),float(value),rel_tol=0,abs_tol=1e-10)
            require(passed, f"Independent metric disagreement: {sm['policy']} {sm['seed']} {metric}")
            comparisons.append({**{k:sm[k] for k in META+["evaluation_group"]},"metric":metric,"primary_value":actual,"independent_value":value,"passed":passed})
    return pd.DataFrame(comparisons)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    qa = {"study_type":"POST-HOC selective-agent diagnostic on old formal test", "prospective_gold_test":False,
          "previous_formal_and_gpt_metrics_already_known":True, "new_model_calls_by_evaluator":0,
          "api_money_or_latency_measured":False, "gold_rejudged_or_overwritten":False,
          "evaluator_sha256":sha(Path(__file__)), "created_utc":datetime.now(timezone.utc).isoformat()}
    inputs, selective, accepted_ids, manifest, source_manifest = validate_blind_and_inputs(qa)
    predictions, selective, changes = reconstruct(inputs, selective, accepted_ids, manifest, qa)
    qa["prediction_reconstruction_completed_utc"] = datetime.now(timezone.utc).isoformat()
    # This is the first authoritative-label access by the evaluator. Predictions
    # and policy composition are already fully constructed and written above.
    labels_path = SOURCE / "labels.csv"
    require(sha(labels_path)==source_manifest["labels_sha256"], "Authoritative gold hash changed")
    labels = pd.read_csv(labels_path, keep_default_na=False)
    qa["first_gold_read_utc"] = datetime.now(timezone.utc).isoformat()
    require(list(labels.columns)==source_manifest["label_contract"] and labels.pair_id.nunique()==len(labels), "Gold contract/key mismatch")
    require(labels.final_label.isin([0,1]).all(), "Invalid gold label")
    predictions = predictions.merge(labels, on="pair_id", validate="many_to_one")
    qa["first_gold_join_utc"] = datetime.now(timezone.utc).isoformat()
    require(len(predictions)==len(SEEDS)*len(inputs)*5, "A reconstructed prediction was lost at gold join")
    selective = selective.merge(labels,on="pair_id",validate="one_to_one")
    changes = changes.merge(inputs[["pair_id",*QKEYS,"candidate_id","exact_match","query_description","candidate_description"]],on="pair_id",validate="many_to_one")
    changes = changes.merge(labels,on="pair_id",validate="many_to_one")
    changes["returned_tp_lost"] = changes.returned_rank_old.gt(0) & changes.returned_rank_new.eq(0) & changes.final_label.eq(1)
    changes["returned_fp_removed"] = changes.returned_rank_old.gt(0) & changes.returned_rank_new.eq(0) & changes.final_label.eq(0)
    changes["returned_tp_gained"] = changes.returned_rank_old.eq(0) & changes.returned_rank_new.gt(0) & changes.final_label.eq(1)
    changes["accepted_tp_rejected"] = changes.prediction_old.eq(1) & changes.prediction_new.eq(0) & changes.final_label.eq(1)
    queries = query_frame(predictions)
    summary = summary_frame(predictions,queries)
    crosscheck = independent_count_crosscheck(predictions,summary)
    identifiers = ["source","policy","batch_size","evaluation_group"]
    metrics = [c for c in summary if c not in identifiers+["seed"]]
    aggregate_rows=[]
    for key,part in summary.groupby(identifiers):
        for metric in metrics:
            values=part[metric].dropna().to_numpy(float)
            aggregate_rows.append({**dict(zip(identifiers,key)),"metric":metric,"run_n":len(part),"finite_run_n":len(values),
                "mean":values.mean() if len(values) else np.nan,"sample_sd":values.std(ddof=1) if len(values)>1 else np.nan,
                "sd_basis":"Three frozen BGE seeds sharing one completed selective judgment; not three GPT repetitions"})
    aggregate=pd.DataFrame(aggregate_rows)
    delta_metrics=["returned_tp_n","returned_fp_n","returned_fn_n","returned_precision_pct","macro_recall_at3_pct","hit_at3_pct",
                   "returned_nonexact_tp_n","nonexact_micro_recall_at3_pct","no_reference_rejected_query_n","no_reference_pool_rejection_pct"]
    deltas=[]
    for (seed,group),part in summary.groupby(["seed","evaluation_group"]):
        new=part[part.policy.eq("selective_gpt_top3")].iloc[0]
        for baseline in ["rule_only_top3","old_system_top3","same_runtime_fullpool_gpt_and_top3","prior_posthoc_fullscore_and_top3"]:
            old=part[part.policy.eq(baseline)].iloc[0]
            deltas.append({"seed":seed,"evaluation_group":group,"new_policy":"selective_gpt_top3","baseline_policy":baseline,
                           **{f"delta_{m}":new[m]-old[m] for m in delta_metrics}})
    # Previously published runtime metric reconciliation uses all raw splits.
    published=pd.read_csv(BASE / "results/runtime_analysis/runtime_quality_per_seed.csv")
    baseline_checks=[]
    names={"rule_only_top3":"rule_only","old_system_top3":"system_top3"}
    pmetrics={"query_n":"queries","positive_query_n":"positive_queries","candidate_pair_n":"candidate_pairs",
              "returned_tp_n":"returned_tp","returned_fp_n":"returned_fp","returned_precision_pct":"returned_precision_pct",
              "macro_recall_at3_pct":"macro_recall_at3_pct","hit_at3_pct":"hit_at3_pct",
              "wrong_reference_query_rate_pct":"wrong_reference_query_pct","no_reference_pool_rejection_pct":"no_reference_rejection_pct"}
    for row in summary[summary.policy.isin(names)].to_dict("records"):
        chosen=published[(published.seed==row["seed"]) & (published.policy==names[row["policy"]]) & (published.batch_size==64) & (published.evaluation_group==row["evaluation_group"])]
        if len(chosen)==0:
            continue
        require(len(chosen)==1,"Ambiguous published baseline")
        for ours,theirs in pmetrics.items():
            a,b=row[ours],chosen.iloc[0][theirs]
            passed=(pd.isna(a) and pd.isna(b)) or math.isclose(float(a),float(b),rel_tol=0,abs_tol=1e-10)
            require(passed,f"Published baseline mismatch: {row['policy']} {row['seed']} {ours}")
            baseline_checks.append({"policy":row["policy"],"seed":row["seed"],"evaluation_group":row["evaluation_group"],"metric":ours,"new_value":a,"published_value":b,"passed":passed})
    require(len(baseline_checks)>0,"No published baseline crosschecks executed")
    # Full-pool comparisons explicitly compare acceptance and returned lists.
    compare_rows=[]
    for seed in SEEDS:
        chosen=predictions[predictions.seed.eq(seed)]
        new=chosen[chosen.policy.eq("selective_gpt_top3")].set_index("pair_id")
        for baseline in ["same_runtime_fullpool_gpt_and_top3","prior_posthoc_fullscore_and_top3"]:
            old=chosen[chosen.policy.eq(baseline)].set_index("pair_id").reindex(new.index)
            compare_rows.append({"seed":seed,"baseline_policy":baseline,"pair_n":len(new),
                "prediction_disagreement_n":int(new.prediction.ne(old.prediction).sum()),
                "returned_membership_disagreement_n":int(new.returned_rank.gt(0).ne(old.returned_rank.gt(0)).sum()),
                "returned_rank_disagreement_n":int(new.returned_rank.ne(old.returned_rank).sum()),
                "exact_prediction_disagreement_n":int((new.prediction.ne(old.prediction)&new.exact_match.eq(1)).sum())})
    outputs={"per_query.csv":queries,"summary_per_seed.csv":summary,"summary_aggregate.csv":aggregate,
             "differences_per_seed.csv":pd.DataFrame(deltas),"independent_count_crosscheck.csv":crosscheck,
             "baseline_summary_crosscheck.csv":pd.DataFrame(baseline_checks),"verifier_pair_decisions.csv":selective,
             "changed_candidate_outcomes.csv":changes[(changes.prediction_old.ne(changes.prediction_new)) | changes.returned_rank_old.ne(changes.returned_rank_new)],
             "prior_fullpool_and_comparison.csv":pd.DataFrame(compare_rows)}
    disagreement_rows = selective[selective.verifier_accept.ne(selective.prior_fullpool_gpt_accept)]
    outputs["prior_fullpool_judgment_disagreements.csv"] = disagreement_rows
    for name,frame in outputs.items():
        frame.to_csv(OUT / name,index=False)
    main_rows=summary[summary.evaluation_group.eq("all_formal")]
    compact=main_rows[["policy","seed","returned_tp_n","returned_fp_n","returned_precision_pct","macro_recall_at3_pct","hit_at3_pct",
                       "returned_nonexact_tp_n","nonexact_positive_n","nonexact_micro_recall_at3_pct","no_reference_rejected_query_n","no_reference_query_n"]]
    compact.to_csv(OUT / "all_formal_display.csv",index=False)
    disag=selective.verifier_accept.ne(selective.prior_fullpool_gpt_accept)
    qa.update({"status":"passed","labels_sha256":sha(labels_path),
               "formal_query_n":220,"formal_pair_n":6600,"formal_gold_positive_n":int(inputs.merge(labels,on="pair_id").final_label.sum()),
               "independent_count_checks_n":len(crosscheck),"independent_count_checks_all_passed":bool(crosscheck.passed.all()),
               "published_baseline_checks_n":len(baseline_checks),"published_baseline_checks_all_passed":True,
               "new_vs_prior_fullpool_selective_judgment_disagreement_n":int(disag.sum()),
               "new_verifier_rejected_gold_positive_n":int((selective.verifier_accept.eq(0)&selective.final_label.eq(1)).sum()),
               "new_verifier_rejected_gold_positive_pair_ids":selective.loc[selective.verifier_accept.eq(0)&selective.final_label.eq(1),"pair_id"].tolist(),
               "returned_tp_lost_by_seed":changes.groupby("seed").returned_tp_lost.sum().to_dict(),
               "accepted_tp_rejected_by_seed":changes.groupby("seed").accepted_tp_rejected.sum().to_dict(),
               "new_verifier_accept_gold_positive_n":int((selective.verifier_accept.eq(1)&selective.final_label.eq(1)).sum()),
               "new_verifier_accept_gold_negative_n":int((selective.verifier_accept.eq(1)&selective.final_label.eq(0)).sum())})
    # Plain Chinese report with exact denominator definitions and scope limits.
    lines=["# 新 selective GPT 窄上下文盲判：事后诊断", "",
      "本报告评估已完成的 gpt-6-sol/medium 代理盲判。它是对旧正式测试的事后机制诊断，既往正式结果与全池 GPT 结果已知，不是新数据上的前瞻性金标准测试，也没有测量 API 费用或调用延迟。评估器没有模型调用，没有修改或重新裁定标签。", "",
      "输入在判定前冻结：三个 BGE 种子（20260904/05/06）的 system_top3、batch_size=64 中，model_called=1、prediction=1、exact_match=0 的候选并集。共有 9 个查询、25 个候选，全部逐一给出理由；接受 2 个。每个查询只展示该并集内候选，因此与先前 30 候选全池判定的上下文不同。", "",
      "评估前检查通过：冻结输入与原始来源哈希一致；只允许五个条目字段与匿名键，未出现 gold、模型分数、种子或先前 GPT 结论；映射与权威 inputs.csv 一致；所有候选都有决定；接受键唯一且均已提供。完整重建结果并保存后才读取权威 labels.csv。", "",
      "固定组合：exact 候选始终接受并按 candidate_id 排序；仅保留本种子 BGE 已调用且判为阳性的 nonexact 候选，并要求新验证器接受；保留原始 BGE 分数降序和 candidate_id 平分排序，最多 3 个，不强制补满。不调阈值，不增加规则。", "",
      "指标定义：返回 TP/FP 是实际 Top3 列表；宏 Recall@3 在有正例查询上对 TP/正例数取均值；Hit@3 分母同样为有正例查询；非 exact 正例召回分母是全部既定非 exact 金标准正例；no-reference 是该查询金标准正例为 0，而非只根据 split 名称认定。所有比例用百分数。", "",
      "| 方法 | 种子 | 返回 TP | 返回 FP | P (%) | 宏 R@3 (%) | Hit@3 (%) | 非 exact TP/正例 | 非 exact R@3 (%) | 无参考拒绝 |",
      "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in compact[compact.policy.isin(["rule_only_top3","old_system_top3","selective_gpt_top3"])].to_dict("records"):
        lines.append(f"| {r['policy']} | {r['seed']} | {r['returned_tp_n']} | {r['returned_fp_n']} | {r['returned_precision_pct']:.6f} | {r['macro_recall_at3_pct']:.6f} | {r['hit_at3_pct']:.6f} | {r['returned_nonexact_tp_n']}/{r['nonexact_positive_n']} | {r['nonexact_micro_recall_at3_pct']:.6f} | {r['no_reference_rejected_query_n']}/{r['no_reference_query_n']} |")
    new_main = main_rows[main_rows.policy.eq("selective_gpt_top3")]
    lines += ["", f"新方法三种子均值：返回 TP {new_main.returned_tp_n.mean():.6f}±{new_main.returned_tp_n.std(ddof=1):.6f}，FP 0，P 100%；宏 R@3 {new_main.macro_recall_at3_pct.mean():.6f}±{new_main.macro_recall_at3_pct.std(ddof=1):.6f}%，Hit@3 {new_main.hit_at3_pct.mean():.6f}±{new_main.hit_at3_pct.std(ddof=1):.6f}%，非 exact 正例 R@3 {new_main.nonexact_micro_recall_at3_pct.mean():.6f}±{new_main.nonexact_micro_recall_at3_pct.std(ddof=1):.6f}%。非 exact 正例分母只有 29；这轮每个种子仅恢复 1 或 2 个，仍未覆盖其余非 exact 正例。", "",
      "相对旧 system_top3 的差值如下；比例差为百分点：", "",
      "| 种子 | ΔTP | ΔFP | Δ宏 R@3 | ΔHit@3 | Δ非 exact R@3 | Δ无参考拒绝数 |",
      "|---|---:|---:|---:|---:|---:|---:|"]
    for r in pd.DataFrame(deltas).query("evaluation_group == 'all_formal' and baseline_policy == 'old_system_top3'").to_dict("records"):
        lines.append(f"| {r['seed']} | {r['delta_returned_tp_n']:+.0f} | {r['delta_returned_fp_n']:+.0f} | {r['delta_macro_recall_at3_pct']:+.6f} | {r['delta_hit_at3_pct']:+.6f} | {r['delta_nonexact_micro_recall_at3_pct']:+.6f} | {r['delta_no_reference_rejected_query_n']:+.0f} |")
    lines += ["", "三个种子共享同一份新 GPT 判定。聚合 CSV 的标准差为 BGE 检查点之间的样本标准差（ddof=1），不能解释为三次独立 GPT 运行的稳定性。", "",
              f"新窄上下文与先前全池 GPT 在 25 个已提供候选上的接受决定差异为 {int(disag.sum())}/25。下表将基于相同 runtime 候选和分数的全池 GPT AND，与先前基于 full-BGE 分数的事后 AND 分开比较：", "",
              "| 种子 | 比较对象 | 候选判断差异 | 返回成员差异 | 排名差异 |",
              "|---|---|---:|---:|---:|"]
    for r in compare_rows:
        lines.append(f"| {r['seed']} | {r['baseline_policy']} | {r['prediction_disagreement_n']} | {r['returned_membership_disagreement_n']} | {r['returned_rank_disagreement_n']} |")
    lines += ["", "三处判断差异均来自 Q104 的 C05/C16/C24，即 NOR000692/693/694。旧全池 GPT 接受这三个 Class IV subgrade stabilization 候选，新窄上下文判定它们未明确查询中的 aggregate 材料而拒绝；权威旧标签均为 0。新验证器仍接受 NOR000691 的 Class IV aggregate stabilization。20260905 原始排序把三个错误 subgrade 候选放在该正例之前，因此移除三个错误候选后，该正例进入 Top3。", "",
              "20260904/06 与旧全池 GPT AND 的逐候选决定和完整返回顺序一致；20260905 有 3 个候选决定差异，Top3 成员差异为 4 个（移除 3 个 FP、加入 1 个 TP）。相同 runtime 分数版本与先前 full-BGE 分数版本在本比较上的输出一致，但仍作为不同来源保存。"]
    rejected_tp=selective[selective.verifier_accept.eq(0)&selective.final_label.eq(1)]
    lines += ["", f"新验证器拒绝了 {len(rejected_tp)} 个金标准正例：" + ("、".join(rejected_tp.pair_id) if len(rejected_tp) else "无") + "。",
              "验证器可能拒绝有用候选，因此不能仅从 FP 下降推断优越性。以下统计明确检查相对旧系统的返回 TP 损失和已接受 TP 被拒绝：", "",
              "| 种子 | 旧系统已返回 TP 被移除 | 旧系统已接受 TP 被拒绝 | 旧系统返回 FP 被移除 | 新增返回 TP |",
              "|---|---:|---:|---:|---:|"]
    for seed,p in changes.groupby("seed"):
        lines.append(f"| {seed} | {int(p.returned_tp_lost.sum())} | {int(p.accepted_tp_rejected.sum())} | {int(p.returned_fp_removed.sum())} | {int(p.returned_tp_gained.sum())} |")
    lines += ["", "逐候选原始理由、既定标签及全池 GPT 接受标记见 verifier_pair_decisions.csv；差异与缺失正例见 changed_candidate_outcomes.csv、per_query.csv。报告解释沿用原有金标准，不把 GPT 理由当作改标签的证据。", "",
              f"所有新组合与 runtime 基线 Top3 排名均由 pandas 与独立 Python 列表实现交叉核对；{len(crosscheck)} 个计数/比例检查全部一致，{len(baseline_checks)} 个既有 runtime 基线指标检查全部一致。rule_only 与旧 system_top3 的已记录返回顺序被逐项重建，三个种子的全部 6,600 候选决定/返回排名也与原始 server 中 rule_only/stop_3 输出完全一致。", "",
              "本实验只能说明这 25 个已筛选候选上的新代理判定如何改变既有输出。它不能估计新数据泛化、API 模型随机性、线上时延、价格、费用节省或经济优势。候选并集数量是诊断样本量，不是实际线上调用负载。"]
    (OUT / "REPORT_zh.md").write_text("\n".join(lines)+"\n")
    qa["output_hashes"]={p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="qa.json"}
    dump(OUT / "qa.json",qa)
    print(json.dumps(safe({"status":"passed","out":str(OUT),"all_formal":compact.to_dict("records"),
                          "judgment_disagreements":int(disag.sum()),"rejected_gold_positive_pairs":qa["new_verifier_rejected_gold_positive_pair_ids"],
                          "returned_tp_lost_by_seed":qa["returned_tp_lost_by_seed"]}),ensure_ascii=False))


if __name__=="__main__":
    main()
