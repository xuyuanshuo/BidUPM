"""Read-only validation of the two artifact-tool-authored annotation workbooks."""
import hashlib
import json
from pathlib import Path

from openpyxl import load_workbook

ROOT = Path('research_workspace/output/rule_first_system_validation_20261005')
raw = json.loads((ROOT / 'results/raw_alberta_import/raw_items.json').read_text())
manifest_path = ROOT / 'annotation/qa/annotation_manifest.json'
manifest = json.loads(manifest_path.read_text())
queries = raw['queries']
sources = [item for year in ('2024', '2026') for item in raw['sources'][year]]
expected_queries = [[f"Q{item['item_number_metadata_only']:03d}", item['item_number_metadata_only'], item['description'], item['unit'], item['quantity'], item['source_sheet'], item['source_row']] for item in queries]
expected_sources = [[f"{item['year']}_R{item['source_row']:03d}", item['year'], item['source_sheet'], item['source_row'], item['code_metadata_only'], item['description'], item['unit'], Path(item['source_file']).name] for item in sources]
checks = []
saved_query_rows = []
saved_source_rows = []
for export in manifest['exports']:
    file_path = Path(export['path'])
    digest = hashlib.sha256(file_path.read_bytes()).hexdigest()
    assert digest == export['sha256']
    workbook = load_workbook(file_path, read_only=False, data_only=False)
    assert workbook.sheetnames == ['查询标注', '完整目录']
    query_sheet, source_sheet = workbook.worksheets
    query_rows = [list(row) for row in query_sheet.iter_rows(min_row=10, max_row=144, min_col=1, max_col=7, values_only=True)]
    source_rows = [list(row) for row in source_sheet.iter_rows(min_row=7, max_row=507, min_col=1, max_col=8, values_only=True)]
    labels = [value for row in query_sheet.iter_rows(min_row=10, max_row=144, min_col=8, max_col=12, values_only=True) for value in row]
    assert query_rows == expected_queries
    assert source_rows == expected_sources
    assert len(query_rows) == 135 and len(source_rows) == 501
    assert all(value is None for value in labels)
    assert len(set(row[0] for row in query_rows)) == 135
    assert len(set(row[0] for row in source_rows)) == 501
    assert [table.ref for table in query_sheet.tables.values()] == ['A9:L144']
    assert [table.ref for table in source_sheet.tables.values()] == ['A6:H507']
    validation_ranges = sorted(str(validation.sqref) for validation in query_sheet.data_validations.dataValidation)
    assert validation_ranges == ['I10:I144', 'K10:K144']
    assert query_sheet.freeze_panes == 'D10'
    assert source_sheet.freeze_panes == 'B7'
    formula_count = sum(cell.data_type == 'f' for sheet in workbook.worksheets for row in sheet.iter_rows() for cell in row)
    assert formula_count == 0
    saved_query_rows.append(query_rows)
    saved_source_rows.append(source_rows)
    checks.append({'reviewer': export['reviewer'], 'path': str(file_path), 'sha256': digest,
                   'query_rows': 135, 'catalogue_rows': 501, 'raw_values_equal_source_import': True,
                   'all_675_annotation_cells_blank': True, 'stable_ids_unique': True, 'formula_count': formula_count,
                   'status_dropdown_ranges': validation_ranges, 'table_filters_available': True,
                   'query_freeze_panes': query_sheet.freeze_panes, 'catalogue_freeze_panes': source_sheet.freeze_panes})
    workbook.close()
assert saved_query_rows[0] == saved_query_rows[1]
assert saved_source_rows[0] == saved_source_rows[1]
for source in manifest['sources']:
    assert hashlib.sha256(Path(source['path']).read_bytes()).hexdigest() == source['sha256']
validation = {'passed': True, 'reviewer_data_identical': True, 'original_workbook_hashes_unchanged': True,
              'human_confirmed_labels_exist': False, 'predictions_or_suggested_labels_displayed': False,
              'visual_review': {'reviewed_each_reviewer_and_each_tab': True,
                                'ranges': {'查询标注': ['A1:L16', 'A133:L144'], '完整目录': ['A1:H15', 'A498:H507']},
                                'long_original_descriptions_wrap_without_clipping': True},
              'workbooks': checks}
(ROOT / 'annotation/qa/annotation_export_validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(validation, ensure_ascii=False, indent=2))
