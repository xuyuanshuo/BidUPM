"""Input-only rule-first Top-3 reference screening; no model or label access.

The model checkpoint and acceptance threshold are supplied by the caller. Rules
accept nonempty canonical descriptions with equal nonempty normalized units.
With at least three exact candidates, no candidate in that query is modeled.
Otherwise all nonexact candidates require BGE scoring to fill remaining slots.
Unscored nonexact candidates remain unknown (-1), rather than incompatibilities.
"""
from __future__ import annotations

from collections.abc import Mapping
import re

import numpy as np
import pandas as pd


MAX_REFERENCES = 3
TEXT_FIELDS = ("description", "normalized_description", "normalized_unit", "category", "spec_tokens")
GATE_FIELDS = ("query_normalized_description", "candidate_normalized_description",
               "query_normalized_unit", "candidate_normalized_unit")


def _text(value: object) -> str:
    """Treat scalar None/NA/NaN as missing; preserve other source notation."""
    if value is None or pd.isna(value):
        return ""
    return str(value)


def normalize_text(value: object) -> str:
    return " ".join(_text(value).strip().lower().split())


def canonical_description(value: object) -> str:
    # The original server rule's punctuation and ampersand normalization.
    text = _text(value).lower().replace("&", " and ")
    return " ".join(re.sub(r"[^a-z0-9]+", " ", text).split())


def normalize_unit(value: object) -> str:
    # Inputs already supply normalized units. Do not invent conversions here.
    return normalize_text(value)


def _require_fields(frame: pd.DataFrame, fields) -> None:
    missing = set(fields) - set(frame.columns)
    if missing:
        raise ValueError(f"Missing input fields: {sorted(missing)}")


def _query_keys(frame: pd.DataFrame) -> list[str]:
    _require_fields(frame, ["query_id"])
    keys = ["evaluation_split", "query_id"] if "evaluation_split" in frame.columns else ["query_id"]
    for key in keys:
        if frame[key].map(normalize_text).eq("").any():
            raise ValueError(f"Missing query metadata: {key}")
    return keys


def exact_mask(frame: pd.DataFrame) -> np.ndarray:
    """Return exact-match input features; no labels/difficulty/conflicts used."""
    _require_fields(frame, GATE_FIELDS)
    qd = frame["query_normalized_description"].map(canonical_description).to_numpy()
    cd = frame["candidate_normalized_description"].map(canonical_description).to_numpy()
    qu = frame["query_normalized_unit"].map(normalize_unit).to_numpy()
    cu = frame["candidate_normalized_unit"].map(normalize_unit).to_numpy()
    return (qd != "") & (qu != "") & (qd == cd) & (qu == cu)


def route(frame: pd.DataFrame) -> dict[str, np.ndarray]:
    """Compute rule acceptances and actual scoring requirements, positionally.

    Output dictionaries use masks aligned to frame row positions, not its index
    labels. Only explicit item fields and query metadata are read.
    """
    keys = _query_keys(frame)
    exact = exact_mask(frame)
    called = ~exact
    unscored = np.zeros(len(frame), dtype=bool)
    for _, indices in frame[keys].groupby(keys, sort=False).indices.items():
        if int(exact[indices].sum()) >= MAX_REFERENCES:
            called[indices] = False
            unscored[indices] = ~exact[indices]
    return {"exact_match": exact, "rule_accept": exact.copy(), "model_called": called,
            "unscored": unscored, "called_indices": np.flatnonzero(called)}


def serialize(frame: pd.DataFrame, side: str) -> list[str]:
    """Reproduce frozen five-field BGE input serialization exactly."""
    if side not in {"query", "candidate"}:
        raise ValueError(f"Unknown item side: {side}")
    fields = [f"{side}_{suffix}" for suffix in TEXT_FIELDS]
    _require_fields(frame, fields)
    values = [frame[field].map(normalize_text).tolist() for field in fields]
    return [f"Description: {d}. Normalized: {n}. Pay unit: {u}. Category: {c}. Specs: {s}."
            for d, n, u, c, s in zip(*values)]


def rank_returned(frame: pd.DataFrame, rule_accept: np.ndarray, scores: np.ndarray,
                  threshold: float) -> np.ndarray:
    """Exact references first by ID, then accepted BGE references by logit/ID."""
    keys = _query_keys(frame)
    _require_fields(frame, ["candidate_id"])
    if frame["candidate_id"].map(normalize_text).eq("").any():
        raise ValueError("Missing candidate identifier")
    if frame[[*keys, "candidate_id"]].duplicated().any():
        raise ValueError("Duplicate candidate within query pool")
    rank = np.zeros(len(frame), dtype=np.int8)
    candidate_ids = frame["candidate_id"].to_numpy(str)
    for _, indices in frame[keys].groupby(keys, sort=False).indices.items():
        rules = indices[rule_accept[indices]]
        if len(rules):
            rules = rules[np.argsort(candidate_ids[rules], kind="stable")]
        model = indices[~rule_accept[indices] & np.isfinite(scores[indices]) & (scores[indices] >= threshold)]
        if len(model):
            ordering = np.lexsort((candidate_ids[model], -scores[model]))
            model = model[ordering]
        returned = np.r_[rules, model][:MAX_REFERENCES]
        rank[returned] = np.arange(1, len(returned) + 1)
    return rank


def compose(frame: pd.DataFrame, routing: Mapping[str, np.ndarray], scores,
            threshold: float) -> dict[str, np.ndarray]:
    """Merge rules and supplied frozen-checkpoint scores, without inference.

    scores may contain one value per input row or only values for called_indices.
    Scores on noncalled rows are ignored and removed from output. A missing or
    nonfinite score on a called row is an error, never an implicit rejection.
    """
    threshold = float(threshold)
    if not np.isfinite(threshold):
        raise ValueError("Acceptance threshold must be finite")
    masks = {name: np.asarray(routing[name], dtype=bool) for name in
             ["exact_match", "rule_accept", "model_called", "unscored"]}
    if any(mask.shape != (len(frame),) for mask in masks.values()):
        raise ValueError("Routing mask does not align to input rows")
    exact, accepted, called, unscored = (masks[name] for name in
                                        ["exact_match", "rule_accept", "model_called", "unscored"])
    if not np.array_equal(exact, accepted) or np.any(accepted & called) or np.any(unscored & (accepted | called)):
        raise ValueError("Overlapping or inconsistent routing states")
    if not np.all(accepted | called | unscored):
        raise ValueError("A candidate has no declared routing state")
    indices = np.flatnonzero(called)
    if not np.array_equal(indices, np.asarray(routing["called_indices"])):
        raise ValueError("called_indices disagrees with model_called mask")
    supplied = np.asarray(scores, dtype=float).reshape(-1)
    full_scores = np.full(len(frame), np.nan)
    if len(supplied) == len(frame):
        full_scores[called] = supplied[called]
    elif len(supplied) == len(indices):
        full_scores[called] = supplied
    else:
        raise ValueError("Score count must match all input rows or called candidates")
    if not np.isfinite(full_scores[called]).all():
        raise ValueError("A model-called candidate has a missing or nonfinite score")
    prediction = accepted.astype(np.int8)
    prediction[called] = (full_scores[called] >= threshold).astype(np.int8)
    prediction[unscored] = -1
    rank = rank_returned(frame, accepted, full_scores, threshold)
    return {**masks, "called_indices": indices, "score": full_scores,
            "prediction": prediction, "returned_rank": rank}


def apply_policy(frame: pd.DataFrame, scores, threshold: float) -> dict[str, np.ndarray]:
    return compose(frame, route(frame), scores, threshold)
