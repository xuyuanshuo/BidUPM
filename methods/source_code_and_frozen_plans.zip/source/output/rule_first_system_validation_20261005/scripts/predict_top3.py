#!/usr/bin/env python3
"""Run the validated, input-only Top3 screening system on a 30-candidate CSV."""
import argparse,json,time
from pathlib import Path
import numpy as np
import pandas as pd
from system_policy import route,compose

ANNOTATION_FIELDS={'final_label','final_relevance','difficulty','final_conflict_type'}

def export_references(frame,routing,result):
    output=[]
    for qid,indices in frame.groupby('query_id',sort=True).indices.items():
        called=routing['model_called'][indices]
        exact=routing['rule_accept'][indices]
        ranked=indices[result['returned_rank'][indices]>0]
        ranked=ranked[np.argsort(result['returned_rank'][ranked])]
        refs=[]
        for i in ranked:
            score=result['score'][i]
            refs.append({'rank':int(result['returned_rank'][i]),'candidate_id':str(frame.iloc[i].candidate_id),
                'description':str(frame.iloc[i].candidate_description),'unit':str(frame.iloc[i].candidate_normalized_unit),
                'accepted_by':'exact_rule' if routing['rule_accept'][i] else 'fine_tuned_bge',
                'model_logit':float(score) if np.isfinite(score) else None})
        assert len(refs)<=3
        output.append({'query_id':str(qid),'query_description':str(frame.iloc[indices[0]].query_description),
            'candidate_count':len(indices),'exact_reference_count':int(exact.sum()),
            'model_scored_candidates':int(called.sum()),'early_stopped':bool(exact.sum()>=3),
            'references':refs,
            'unscored_candidate_ids':[str(frame.iloc[i].candidate_id) for i in indices if routing['unscored'][i]]})
    return output

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--manifest',type=Path,required=True)
    ap.add_argument('--seed',type=int,choices=[20260904,20260905,20260906],required=True)
    ap.add_argument('--input',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--batch-size',type=int,default=64)
    a=ap.parse_args();assert a.batch_size>0
    started=time.perf_counter()
    source=json.loads(a.manifest.read_text())
    run=next(r for r in source['runs'] if int(r['seed'])==a.seed)
    raw=pd.read_csv(a.input,dtype=str,keep_default_na=False)
    if ANNOTATION_FIELDS.intersection(raw.columns):raise ValueError('Inference input must not contain annotation fields')
    fields=source['inference_input_contract']
    if not set(fields).issubset(raw.columns):raise ValueError('Input CSV does not satisfy the frozen field contract')
    frame=raw[fields].reset_index(drop=True)
    assert not frame.pair_id.duplicated().any()
    assert frame.groupby('query_id').size().eq(30).all(),'Each query requires exactly 30 fixed candidates'
    assert not frame.duplicated(['query_id','candidate_id']).any()
    routing=route(frame)
    if routing['model_called'].any():
        import torch
        from transformers import AutoModelForSequenceClassification,AutoTokenizer
        from run_runtime_validation import execute,sha
        cp=Path(run['checkpoint'])
        for name,expected in run['checkpoint_files'].items():assert sha(cp/name)==expected,(name,'Checkpoint changed')
        if not torch.cuda.is_available():raise RuntimeError('CUDA is required for unresolved candidate scoring')
        torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False
        torch.manual_seed(a.seed)
        tokenizer=AutoTokenizer.from_pretrained(cp,local_files_only=True)
        model=AutoModelForSequenceClassification.from_pretrained(cp,local_files_only=True).to('cuda').eval()
        result,timing=execute(frame,'system_top3',model,tokenizer,float(run['threshold']),a.batch_size)
    else:
        result=compose(frame,routing,[],float(run['threshold']))
        timing={'seconds':None,'model_pairs':0,'model_batches':0}
    output={'schema':'bidupm-top3-screening-v1','seed':a.seed,'threshold':float(run['threshold']),
        'checkpoint':run['checkpoint'],'candidate_pool':30,'maximum_references':3,
        'labels_accessed':False,'query_count':frame.query_id.nunique(),
        'model_scored_pairs':int(routing['model_called'].sum()),
        'processing_seconds_including_loading_and_integrity_checks':time.perf_counter()-started,
        'screening_seconds_resident_model':timing['seconds'],
        'references_are_recommendations_for_human_review':True,
        'queries':export_references(frame,routing,result)}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(output,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'output':str(a.output),'queries':output['query_count'],'model_scored_pairs':output['model_scored_pairs'],'labels_accessed':False}))

if __name__=='__main__':main()
