#!/usr/bin/env python3
"""Read-only schema-specific Excel import and deterministic candidate-coverage audit.

This script never saves a workbook, calls a model, or treats an item code as a
matching/acceptance criterion. It produces JSON/CSV/text audit evidence only.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import re
import statistics
import sys
import time
import unicodedata
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import openpyxl
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "results" / "raw_alberta_import"
UPA_PATH = Path("user_inputs/trans-unit-price-averages.xlsx")
BID_PATH = Path("user_inputs/Price Form or Bid Form.xlsx")
EARLIER_CACHE = ROOT.parent / "early_form_matching_20260929" / "matching_data.json"
STAGES = (
    "literal_description_raw_unit",
    "case_space_punctuation",
    "unit_aliases",
    "specification_reference_removal",
    "class_abbreviation_expansion",
)

# These narrowly scoped patterns are copied from the former parser as documented
# preprocessing rules. Semantic parentheses (layers, dimensions, material type,
# etc.) are retained. No generic parenthesis removal or fuzzy matching occurs.
SPEC_PATTERNS = (
    ("HCS_BCS_GCS_reference", re.compile(r"\(\s*(?:HCS|BCS|GCS)\s+[^)]*\)", re.I)),
    ("special_provisions_reference", re.compile(r"\(\s*Special\s+Provisions?\s*\)", re.I)),
    ("bridge_file_reference", re.compile(r"\(\s*B\.?\s*F\.?\s*[- ]*\d+[A-Za-z0-9\s-]*\)", re.I)),
)
CLASS_PATTERN = re.compile(r"\bCl\.(?=\s*\d)", re.I)
UNIT_GROUPS = {
    "tonne": ["t", "tonnes", "tonne"],
    "metre": ["m", "meter", "meters", "metres", "metre"],
    "kilometre": ["km", "kilometer", "kilometers", "kilometre"],
    "square metre": ["m2", "m²", "square meters", "square meter", "square metres", "square metre"],
    "cubic metre": ["m3", "m³", "cubic meters", "cubic meter", "cubic metres", "cubic metre"],
    "kilogram": ["kg", "kilograms", "kilogram"],
    "hectare": ["ha", "hectares", "hectare"],
    "lump sum": ["ls", "l.s.", "lump sum"],
    "unit": ["ea", "each", "unit"],
    "sign": ["signs", "sign"],
    "day": ["day", "days"],
}


def present(value):
    return value is not None and bool(str(value).strip())


def raw_text(value):
    return "" if value is None else str(value)


def unicode_text(value):
    return unicodedata.normalize("NFKC", raw_text(value)).replace("\u2013", "-").replace("\u2014", "-")


def formatting(value):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", unicode_text(value).casefold())).strip()


UNIT_ALIASES = {formatting(alias): canonical for canonical, aliases in UNIT_GROUPS.items() for alias in aliases}


def strip_references(value):
    text = unicode_text(value)
    for _, pattern in SPEC_PATTERNS:
        text = pattern.sub(" ", text)
    return text


def normal_key(item, stage_index):
    desc, unit = item["description"], item["unit"]
    if stage_index == 0:
        return raw_text(desc), raw_text(unit)
    if stage_index >= 3:
        desc = strip_references(desc)
    if stage_index >= 4:
        desc = CLASS_PATTERN.sub("Class", unicode_text(desc))
    desc_key, unit_key = formatting(desc), formatting(unit)
    if stage_index >= 2:
        unit_key = UNIT_ALIASES.get(unit_key, unit_key)
    return desc_key, unit_key


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def header_token(value):
    return re.sub(r"\s+", " ", raw_text(value)).strip().casefold()


def inventory(path):
    wb = load_workbook(path, read_only=True, data_only=False)
    result = [{"sheet": ws.title, "max_row": ws.max_row, "max_column": ws.max_column} for ws in wb.worksheets]
    wb.close()
    return result


def find_header(rows, expected):
    found = [
        number for number, values in enumerate(rows[:20], 1)
        if all(index < len(values) and header_token(values[index]) == header_token(label) for index, label in expected.items())
    ]
    if len(found) != 1:
        raise ValueError(f"Expected one schema header; found {found}")
    return found[0]


def cell_ref(sheet, row, column):
    return "'" + sheet.replace("'", "''") + "'!" + get_column_letter(column) + str(row)


def provenance(path, sheet, row, description_col, unit_col):
    return {
        "source_file": str(path),
        "source_sheet": sheet,
        "source_row": row,
        "description_cell": cell_ref(sheet, row, description_col),
        "unit_cell": cell_ref(sheet, row, unit_col),
    }


def parse_upa(path, year):
    start = time.perf_counter()
    wb = load_workbook(path, read_only=True, data_only=False)
    matches = [ws for ws in wb.worksheets if ws.title.strip() == f"{year} UPA"]
    if len(matches) != 1:
        raise ValueError(f"Expected one {year} UPA sheet; found {len(matches)}")
    ws = matches[0]
    rows = list(ws.iter_rows(values_only=True))
    expected = {1: "Item", 2: "Description", 3: "Unit", 4: "No. of\nContracts", 5: "Amount", 6: "Quantity", 7: "Avg. 3 low bids"}
    header_row = find_header(rows, expected)
    items, excluded = [], []
    for row_number, values in enumerate(rows, 1):
        if row_number <= header_row:
            continue
        # Description-bearing rows are imported independently of code contents.
        if not present(values[2]):
            excluded.append({"source_row": row_number, "reason": "blank_description", "values": list(values[:8])})
            continue
        record = provenance(path, ws.title, row_number, 3, 4)
        record.update({
            "source_id": f"upa_{year}_row_{row_number}", "year": year,
            "code_metadata_only": values[1], "description": values[2], "unit": values[3],
            "province_contracts": values[4], "province_amount": values[5],
            "province_quantity": values[6], "province_average_3_low_bids": values[7],
            "raw_row_values": list(values),
        })
        items.append(record)
    schema = {
        "sheet": ws.title, "header_row": header_row, "header_values": list(rows[header_row - 1]),
        "row_count_scanned": len(rows), "data_rows_imported": len(items),
        "description_column": "C", "unit_column": "D", "province_fields": "B:H",
        "first_imported_row": items[0]["source_row"] if items else None,
        "last_imported_row": items[-1]["source_row"] if items else None,
        "excluded_after_header": excluded,
        "code_pattern_diagnostic_only": dict(Counter("standard_letter_3_digits" if re.fullmatch(r"[A-Z]\d{3}", raw_text(x["code_metadata_only"])) else "other" for x in items)),
    }
    wb.close()
    return items, schema, time.perf_counter() - start


def parse_bid(path):
    start = time.perf_counter()
    wb = load_workbook(path, read_only=True, data_only=False)
    if len(wb.worksheets) != 1 or wb.worksheets[0].title != "Owner Bid Form":
        raise ValueError("This adapter expects the observed single Owner Bid Form sheet")
    ws = wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    expected = {0: "Item No.", 1: "Description", 2: "Estimated Quantity", 3: "UoM", 4: "Unit Price", 5: "Total Bid"}
    header_row = find_header(rows, expected)
    items, excluded = [], []
    for row_number, values in enumerate(rows, 1):
        if row_number <= header_row:
            continue
        # Numeric item numbers identify line items within this known form schema;
        # they never determine candidate equality or matching acceptance.
        if not isinstance(values[0], int) or isinstance(values[0], bool):
            excluded.append({"source_row": row_number, "reason": "section_or_total_row", "values": list(values)})
            continue
        record = provenance(path, ws.title, row_number, 2, 4)
        record.update({
            "query_id": f"bid_row_{row_number}", "item_number_metadata_only": values[0],
            "description": values[1], "quantity": values[2], "unit": values[3],
            "bid_unit_price": values[4], "bid_total_raw": values[5], "raw_row_values": list(values),
        })
        items.append(record)
    schema = {
        "sheet": ws.title, "header_row": header_row, "header_values": list(rows[header_row - 1]),
        "row_count_scanned": len(rows), "data_rows_imported": len(items),
        "description_column": "B", "unit_column": "D", "fields": "A:F",
        "first_imported_row": items[0]["source_row"] if items else None,
        "last_imported_row": items[-1]["source_row"] if items else None,
        "excluded_after_header": excluded,
    }
    wb.close()
    return items, schema, time.perf_counter() - start


def candidate_ref(item):
    return {key: item[key] for key in (
        "source_id", "source_file", "source_sheet", "source_row", "description_cell", "unit_cell",
        "code_metadata_only", "description", "unit", "province_average_3_low_bids",
    )}


def stage_run(sources, queries, stage_index):
    start = time.perf_counter()
    source_keys = [normal_key(item, stage_index) for item in sources]
    query_keys = [normal_key(item, stage_index) for item in queries]
    normalize_seconds = time.perf_counter() - start
    start = time.perf_counter()
    index, desc_index = defaultdict(list), defaultdict(list)
    for idx, key in enumerate(source_keys):
        if key[0] and key[1]:
            index[key].append(idx)
            desc_index[key[0]].append(idx)
    index_seconds = time.perf_counter() - start
    start = time.perf_counter()
    matches = []
    for query, key in zip(queries, query_keys):
        candidates = index.get(key, []) if key[0] and key[1] else []
        same_desc_other_unit = [i for i in desc_index.get(key[0], []) if source_keys[i][1] != key[1]] if not candidates else []
        matches.append({
            "query_id": query["query_id"], "query_sheet": query["source_sheet"],
            "query_source_row": query["source_row"], "query_item_number_metadata_only": query["item_number_metadata_only"],
            "query_description": query["description"], "query_unit": query["unit"],
            "stage": STAGES[stage_index], "normalized_description_key": key[0], "normalized_unit_key": key[1],
            "candidate_count": len(candidates),
            "status": "ambiguous_candidates" if len(candidates) > 1 else "single_candidate" if candidates else "no_candidate",
            "ineligible_reason": "missing_description" if not key[0] else "missing_unit" if not key[1] else "",
            "candidate_indices": list(candidates), "description_only_different_unit_indices": same_desc_other_unit,
        })
    search_seconds = time.perf_counter() - start
    eligible = sum(bool(key[0] and key[1]) for key in query_keys)
    matched = sum(x["candidate_count"] > 0 for x in matches)
    counts = {
        "stage": STAGES[stage_index], "source_rows": len(sources), "query_rows": len(queries),
        "eligible_query_rows": eligible, "missing_description_or_unit_query_rows": len(queries) - eligible,
        "matched_query_rows": matched, "single_candidate_query_rows": sum(x["candidate_count"] == 1 for x in matches),
        "ambiguous_query_rows": sum(x["candidate_count"] > 1 for x in matches),
        "unmatched_query_rows": len(queries) - matched,
        "candidate_coverage_all_queries": matched / len(queries) if queries else None,
        "candidate_coverage_eligible_queries": matched / eligible if eligible else None,
        "distinct_query_keys": len(set(query_keys)),
        "distinct_eligible_query_keys": len({key for key in query_keys if key[0] and key[1]}),
        "matched_distinct_query_keys": len({query_keys[i] for i, item in enumerate(matches) if item["candidate_count"] > 0}),
        "same_description_different_unit_only_query_rows": sum(bool(x["normalized_unit_key"] and x["description_only_different_unit_indices"]) for x in matches),
        "missing_unit_same_description_candidate_query_rows": sum(bool(not x["normalized_unit_key"] and x["description_only_different_unit_indices"]) for x in matches),
        "distinct_index_keys": len(index), "duplicate_source_key_count": sum(len(v) > 1 for v in index.values()),
        "source_rows_in_duplicate_keys": sum(len(v) for v in index.values() if len(v) > 1),
    }
    duplicates = [{"description_key": key[0], "unit_key": key[1], "source_rows": [sources[i]["source_row"] for i in indices],
                   "raw_description_unit_variant_count": len({(sources[i]["description"], sources[i]["unit"]) for i in indices})}
                  for key, indices in index.items() if len(indices) > 1]
    return matches, counts, duplicates, {
        "normalize_seconds": normalize_seconds, "index_seconds": index_seconds, "search_seconds": search_seconds,
    }


def add_preprocessing_trace(item):
    item["stage_keys"] = {stage: {"description": normal_key(item, idx)[0], "unit": normal_key(item, idx)[1]} for idx, stage in enumerate(STAGES)}
    item["removed_reference_spans"] = [{"rule": name, "text": match.group(0)} for name, pattern in SPEC_PATTERNS for match in pattern.finditer(unicode_text(item["description"]))]
    item["class_abbreviation_spans"] = [match.group(0) for match in CLASS_PATTERN.finditer(unicode_text(item["description"]))]
    item["retained_parenthetical_spans_after_reference_removal"] = re.findall(r"\([^)]*\)", strip_references(item["description"]))


def ablations(sources, queries):
    """Counterfactual key equalities for attribution, never extra acceptance."""
    def key(item, setting):
        desc = unicode_text(item["description"])
        if setting != "without_specification_reference_removal":
            desc = strip_references(desc)
        if setting != "without_class_abbreviation_expansion":
            desc = CLASS_PATTERN.sub("Class", desc)
        desc_key = formatting(desc)
        unit_key = formatting(item["unit"])
        if setting != "without_unit_aliases":
            unit_key = UNIT_ALIASES.get(unit_key, unit_key)
        return desc_key, unit_key
    result = {}
    for setting in ("full_final_rules", "without_unit_aliases", "without_specification_reference_removal", "without_class_abbreviation_expansion"):
        index = defaultdict(list)
        for item in sources:
            desc_key, unit_key = key(item, setting)
            if desc_key and unit_key:
                index[(desc_key, unit_key)].append(item["source_row"])
        matched = []
        ambiguous = []
        for item in queries:
            desc_key, unit_key = key(item, setting)
            candidates = index.get((desc_key, unit_key), []) if desc_key and unit_key else []
            if candidates:
                matched.append(item["query_id"])
            if len(candidates) > 1:
                ambiguous.append(item["query_id"])
        result[setting] = {"matched_query_rows": len(matched), "matched_query_ids": matched, "ambiguous_query_rows": len(ambiguous)}
    return result


def query_integrity(queries, schema):
    numbers = [item["item_number_metadata_only"] for item in queries]
    counts = Counter(numbers)
    grouped = defaultdict(list)
    for item in queries:
        desc_key, unit_key = normal_key(item, 4)
        if desc_key and unit_key:
            grouped[(desc_key, unit_key)].append(item)
    return {
        "all_item_numbers": numbers, "numeric_item_count": len(numbers), "unique_item_number_count": len(counts),
        "duplicate_item_numbers": [number for number, count in counts.items() if count > 1],
        "distinct_raw_descriptions": len({item["description"] for item in queries}),
        "distinct_raw_description_unit_pairs": len({(item["description"], item["unit"]) for item in queries}),
        "distinct_final_descriptions": len({normal_key(item, 4)[0] for item in queries}),
        "distinct_final_description_unit_pairs": len({normal_key(item, 4) for item in queries}),
        "missing_item_numbers_between_min_and_max": sorted(set(range(min(numbers), max(numbers) + 1)) - set(numbers)),
        "all_query_source_rows": [item["source_row"] for item in queries],
        "non_line_item_rows_excluded": schema["excluded_after_header"],
        "missing_quantity_queries": [{key: item[key] for key in ("query_id", "source_row", "item_number_metadata_only", "description", "unit")} for item in queries if item["quantity"] is None],
        "missing_unit_queries": [{key: item[key] for key in ("query_id", "source_row", "item_number_metadata_only", "description", "quantity")} for item in queries if not present(item["unit"])],
        "queries_with_removed_reference_spans": sum(bool(item["removed_reference_spans"]) for item in queries),
        "removed_reference_span_rule_counts": dict(Counter(span["rule"] for item in queries for span in item["removed_reference_spans"])),
        "duplicate_final_query_keys": [{"description_key": key[0], "unit_key": key[1], "query_rows": [item["source_row"] for item in group],
                                        "raw_descriptions": [item["description"] for item in group]}
                                       for key, group in grouped.items() if len(group) > 1],
    }


def compare_earlier_cache(queries, source_by_year):
    if not EARLIER_CACHE.exists():
        return {"available": False, "path": str(EARLIER_CACHE), "prior_claimed_106_query_count_verified": False}
    old = json.loads(EARLIER_CACHE.read_text(encoding="utf-8"))
    old_queries = {item["source_row"]: item for item in old["bids"]}
    new_queries = {item["source_row"]: item for item in queries}
    changed = [row for row in sorted(set(old_queries) & set(new_queries))
               if any(old_queries[row].get(key) != new_queries[row].get(key) for key in ("description", "unit", "quantity"))
               or old_queries[row].get("item") != new_queries[row]["item_number_metadata_only"]]
    source_changes = {}
    for year, new_sources in source_by_year.items():
        old_sources = {item["source_row"]: item for item in old["sources"][year]}
        new_sources = {item["source_row"]: item for item in new_sources}
        pairs = (("description", "description"), ("unit", "unit"), ("code", "code_metadata_only"),
                 ("contracts", "province_contracts"), ("amount", "province_amount"),
                 ("quantity", "province_quantity"), ("price", "province_average_3_low_bids"))
        source_changes[year] = {
            "old_count": len(old_sources), "new_count": len(new_sources),
            "added_rows": sorted(set(new_sources) - set(old_sources)), "removed_rows": sorted(set(old_sources) - set(new_sources)),
            "changed_common_raw_fields_rows": [row for row in sorted(set(old_sources) & set(new_sources))
                                                if any(old_sources[row].get(a) != new_sources[row].get(b) for a, b in pairs)],
        }
    return {
        "available": True, "path": str(EARLIER_CACHE), "cache_sha256": sha256_file(EARLIER_CACHE),
        "old_query_count": len(old_queries), "new_query_count": len(new_queries),
        "new_only_query_rows": sorted(set(new_queries) - set(old_queries)),
        "old_only_query_rows": sorted(set(old_queries) - set(new_queries)), "changed_common_query_raw_fields_rows": changed,
        "source_comparison": source_changes,
        "prior_claimed_106_query_count_verified": False,
        "reconciliation": "The saved September 29 import contains 135 queries, identical to this raw import. There are zero extra query rows relative to that artifact. No saved 106-query subset was found in this referenced experiment, so the claim of 29 extra items is unsupported. This comparison checks stored raw fields, not an unavailable historic workbook hash.",
    }


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def write_csv(path, records):
    if not records:
        path.write_text("", encoding="utf-8")
        return
    fields = list(dict.fromkeys(key for row in records for key in row))
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for record in records:
            writer.writerow({key: json.dumps(value, ensure_ascii=False, default=str) if isinstance(value, (dict, list, tuple)) else value for key, value in record.items()})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()
    if args.repeats != 5:
        raise ValueError("This audit specification requires exactly 5 timed repeats")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    source_hash_before = {str(path): sha256_file(path) for path in (UPA_PATH, BID_PATH)}
    file_manifest = [{"path": str(path), "file_name": path.name, "size_bytes": path.stat().st_size,
                      "sha256": source_hash_before[str(path)], "sheets": inventory(path)} for path in (UPA_PATH, BID_PATH)]
    year_results, all_matches, all_coverage, all_timings, raw_sources = {}, [], [], [], {}
    raw_queries = None
    for year in (2024, 2026):
        repeat_runs, final = [], None
        for repeat in range(1, 6):
            sources, source_schema, source_parse_seconds = parse_upa(UPA_PATH, year)
            queries, query_schema, query_parse_seconds = parse_bid(BID_PATH)
            timings = {"year": year, "repeat": repeat, "source_parse_seconds": source_parse_seconds,
                       "query_parse_seconds": query_parse_seconds, "parse_seconds": source_parse_seconds + query_parse_seconds,
                       "stages": {}}
            stages, duplicates, matches_per_stage = [], {}, []
            for stage_index, stage in enumerate(STAGES):
                matches, coverage, collisions, stage_timing = stage_run(sources, queries, stage_index)
                timings["stages"][stage] = stage_timing
                stages.append(coverage)
                duplicates[stage] = collisions
                matches_per_stage.append(matches)
            final_timing = timings["stages"][STAGES[-1]]
            timings["final_pipeline_seconds"] = timings["parse_seconds"] + sum(final_timing.values())
            signatures = [[(x["query_id"], x["candidate_indices"], x["ineligible_reason"]) for x in matches] for matches in matches_per_stage]
            if final is not None and signatures != final["signatures"]:
                raise AssertionError("Non-deterministic candidate lists across repeats")
            final = {"sources": sources, "queries": queries, "source_schema": source_schema, "query_schema": query_schema,
                     "stages": stages, "duplicates": duplicates, "matches": matches_per_stage, "signatures": signatures}
            repeat_runs.append(timings)
        median_parse = {key: statistics.median(run[key] for run in repeat_runs) for key in ("source_parse_seconds", "query_parse_seconds", "parse_seconds", "final_pipeline_seconds")}
        median_stages = {stage: {key: statistics.median(run["stages"][stage][key] for run in repeat_runs)
                                 for key in ("normalize_seconds", "index_seconds", "search_seconds")} for stage in STAGES}
        previous_matched = set()
        for stage, coverage, matches in zip(STAGES, final["stages"], final["matches"]):
            now_matched = {item["query_id"] for item in matches if item["candidate_count"] > 0}
            coverage["newly_matched_query_ids"] = sorted(now_matched - previous_matched)
            coverage["newly_matched_query_rows"] = len(now_matched - previous_matched)
            coverage["lost_candidate_query_ids"] = sorted(previous_matched - now_matched)
            coverage.update({"year": year, "timing_median_5_repeats": median_stages[stage]})
            previous_matched = now_matched
            all_coverage.append(coverage)
            for match in matches:
                match.update({"year": year, "candidates": [candidate_ref(final["sources"][i]) for i in match.pop("candidate_indices")],
                              "description_only_different_unit_candidates": [candidate_ref(final["sources"][i]) for i in match.pop("description_only_different_unit_indices")]})
                all_matches.append(match)
        for record in final["sources"] + final["queries"]:
            add_preprocessing_trace(record)
        raw_sources[str(year)] = final["sources"]
        if raw_queries is not None and raw_queries != final["queries"]:
            raise AssertionError("Bid import differed between target-year audits")
        raw_queries = final["queries"]
        all_timings.extend(repeat_runs)
        year_results[str(year)] = {
            "source_schema_adapter": final["source_schema"], "query_schema_adapter": final["query_schema"],
            "coverage_by_stage": final["stages"], "source_duplicate_keys_by_stage": final["duplicates"],
            "rule_ablation_candidate_coverage": ablations(final["sources"], final["queries"]),
            "timing_median_5_repeats": {**median_parse, "stages": median_stages},
        }
    source_hash_after = {str(path): sha256_file(path) for path in (UPA_PATH, BID_PATH)}
    if source_hash_before != source_hash_after:
        raise AssertionError("A source workbook changed during the read-only audit")
    summary = {
        "audit_type": "raw_excel_import_and_exact_candidate_coverage",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "metric_definition": "Candidate coverage is the proportion of imported bid line items with at least one source row having equal description and unit keys at the stated stage. It is not accuracy, precision, recall, or verified semantic correctness.",
        "matching_criteria": ["description key equality", "unit key equality", "nonempty description and unit"],
        "item_codes_used_for_matching": False, "llm_used": False, "remote_access_used": False, "gold_labels_available": False,
        "ambiguous_handling": "All source rows are retained. Multiple candidates are reported as ambiguous; no first-match acceptance.",
        "semantic_limitation": "Equal normalized text and unit keys do not verify pay scope, location, specification version, or BOQ identity. Removing bridge-file/specification references can collapse project-specific query distinctions; repeated final query keys are reported. Source duplicate keys remain ambiguous.",
        "schema_scope": "Validated adapters for these two observed workbook schemas only. Known headers, target sheet names, row types, and provenance are validated once per import; arbitrary Excel files are not universally parsed.",
        "normalization_scope": "Casefold, NFKC, whitespace and punctuation normalization; explicit same-dimension unit aliases; only listed specification/file-reference parentheses removed; numeric Cl. expands to Class in the final separate stage. Semantic parentheses are retained.",
        "stage_order": list(STAGES), "unit_alias_groups": UNIT_GROUPS,
        "reference_removal_patterns": [{"name": name, "pattern": pattern.pattern} for name, pattern in SPEC_PATTERNS],
        "sources": file_manifest, "source_workbooks_unchanged_sha256": source_hash_before == source_hash_after,
        "years": year_results,
        "query_import_integrity": query_integrity(raw_queries, year_results["2024"]["query_schema_adapter"]),
        "earlier_cached_import_comparison": compare_earlier_cache(raw_queries, raw_sources),
        "timing_scope": "Five local repeated imports per year (source workbook load plus target sheet scan, bid workbook load plus sheet scan), key normalization, dictionary indexing (including description-only diagnostic index), and all-query exact candidate lookup. Reporting/export/hashing excluded. Source/item key caches are rebuilt in every repeat. Filesystem cache is uncontrolled; these are local measured times, not cross-hardware claims.",
        "environment": {"python": sys.version, "executable": sys.executable, "openpyxl": openpyxl.__version__, "platform": platform.platform()},
    }
    write_json(output / "audit_summary.json", summary)
    write_json(output / "raw_items.json", {"sources": raw_sources, "queries": raw_queries})
    write_json(output / "per_query_matches.json", all_matches)
    write_json(output / "timing_repeats.json", all_timings)
    validation = {
        "source_workbooks_unchanged_sha256": summary["source_workbooks_unchanged_sha256"],
        "query_count": len(raw_queries), "all_item_numbers_1_to_135_once": sorted(item["item_number_metadata_only"] for item in raw_queries) == list(range(1, 136)),
        "source_counts": {year: len(rows) for year, rows in raw_sources.items()},
        "per_query_stage_records": len(all_matches), "expected_per_query_stage_records": 2 * len(STAGES) * len(raw_queries),
        "all_coverage_counts_reconciled": all(row["single_candidate_query_rows"] + row["ambiguous_query_rows"] + row["unmatched_query_rows"] == row["query_rows"] for row in all_coverage),
        "candidate_lists_deterministic_across_5_repeats": True,
        "source_and_query_raw_field_parity_with_previous_saved_import": not summary["earlier_cached_import_comparison"]["changed_common_query_raw_fields_rows"] and all(not row["changed_common_raw_fields_rows"] and not row["added_rows"] and not row["removed_rows"] for row in summary["earlier_cached_import_comparison"]["source_comparison"].values()),
    }
    assert validation["query_count"] == 135 and validation["all_item_numbers_1_to_135_once"]
    assert validation["per_query_stage_records"] == validation["expected_per_query_stage_records"] == 1350
    assert validation["all_coverage_counts_reconciled"] and validation["source_workbooks_unchanged_sha256"]
    write_json(output / "audit_validation.json", validation)
    write_csv(output / "coverage_by_stage.csv", all_coverage)
    write_csv(output / "per_query_matches.csv", all_matches)
    write_csv(output / "raw_bid_items.csv", raw_queries)
    for year, rows in raw_sources.items():
        write_csv(output / f"raw_upa_{year}_items.csv", rows)
    flattened_timings = []
    for run in all_timings:
        for stage, measures in run["stages"].items():
            flattened_timings.append({"year": run["year"], "repeat": run["repeat"], "stage": stage,
                                      "source_parse_seconds": run["source_parse_seconds"], "query_parse_seconds": run["query_parse_seconds"],
                                      "parse_seconds": run["parse_seconds"], **measures})
    write_csv(output / "timing_repeats.csv", flattened_timings)
    lines = ["Read-only raw Alberta Excel import audit", "", summary["metric_definition"], "", summary["schema_scope"], ""]
    lines.extend([summary["semantic_limitation"], "", summary["earlier_cached_import_comparison"].get("reconciliation", "Earlier cache unavailable."), ""])
    integrity = summary["query_import_integrity"]
    lines.append(f"Bid integrity: {integrity['numeric_item_count']} line items; all integers 1 through 135 occur once; section rows 3, 68, 87, 114 and total row 141 excluded. Missing quantities: bid rows {[x['source_row'] for x in integrity['missing_quantity_queries']]}; missing units: bid rows {[x['source_row'] for x in integrity['missing_unit_queries']]}. Missing quantity is not a line-item exclusion or matching criterion.")
    lines.append(f"All {integrity['queries_with_removed_reference_spans']} bid queries contain one or more reference spans. Stage order is a cumulative pipeline; the jump at reference removal cannot attribute all benefit to that rule alone. Separate rule ablations are in audit_summary.json.")
    lines.append("")
    for year, result in year_results.items():
        lines.append(f"{year} UPA: {result['source_schema_adapter']['data_rows_imported']} source rows; {result['query_schema_adapter']['data_rows_imported']} bid query rows.")
        for row in result["coverage_by_stage"]:
            lines.append(f"  {row['stage']}: {row['matched_query_rows']}/{row['query_rows']} with candidates ({row['candidate_coverage_all_queries']:.2%}); single={row['single_candidate_query_rows']}; ambiguous={row['ambiguous_query_rows']}; unmatched={row['unmatched_query_rows']}; newly covered={row['newly_matched_query_rows']}")
        times = result["timing_median_5_repeats"]
        lines.append(f"  Median import time over 5 repeats: source {times['source_parse_seconds'] * 1000:.3f} ms; bid {times['query_parse_seconds'] * 1000:.3f} ms; combined {times['parse_seconds'] * 1000:.3f} ms.")
        for stage, measures in times["stages"].items():
            lines.append(f"  {stage} median timing: normalize {measures['normalize_seconds'] * 1000:.3f} ms; index {measures['index_seconds'] * 1000:.3f} ms; search {measures['search_seconds'] * 1000:.3f} ms.")
        lines.append(f"  Median final-rule pipeline including raw source/bid import: {times['final_pipeline_seconds'] * 1000:.3f} ms.")
        lines.append("  Candidate coverage ablations: " + "; ".join(f"{setting}={values['matched_query_rows']}/135" for setting, values in result["rule_ablation_candidate_coverage"].items()))
        lines.append("")
    lines.append("Original workbook hashes unchanged. No workbook export, LLM, remote access, gold-label evaluation, fuzzy matching, price-based matching, or item-code matching.")
    (output / "audit_report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "stages": list(STAGES),
                      "matched_query_counts": {year: [row["matched_query_rows"] for row in result["coverage_by_stage"]] for year, result in year_results.items()},
                      "parse_median_seconds": {year: result["timing_median_5_repeats"]["parse_seconds"] for year, result in year_results.items()},
                      "validation": validation}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
