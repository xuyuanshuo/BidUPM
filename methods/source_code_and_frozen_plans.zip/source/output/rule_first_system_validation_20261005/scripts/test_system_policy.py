#!/usr/bin/env python3
"""Boundary/metamorphic acceptance and historical GPU-output reproduction.

This script never opens labels.csv. Historical verification uses each policy's
own actual stop_3 GPU scores, not all-BGE scores or newly generated predictions.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

import system_policy as policy


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not bool(condition):
        raise AssertionError(message)


def frame_for(exact_n: int = 0, count: int = 30) -> pd.DataFrame:
    records = []
    for number in range(count):
        records.append({"pair_id": f"pair_{number}", "evaluation_split": "fixture", "query_id": "query",
                        "candidate_id": f"candidate_{number:02}", "query_description": " Concrete  Curb ",
                        "candidate_description": "CONCRETE CURB" if number < exact_n else f"Other work {number}",
                        "query_normalized_description": "Concrete curb", "candidate_normalized_description":
                        "CONCRETE-CURB" if number < exact_n else f"other work {number}",
                        "query_normalized_unit": "LF", "candidate_normalized_unit": "lf",
                        "query_category": "Concrete", "candidate_category": "Concrete",
                        "query_spec_tokens": "S-10", "candidate_spec_tokens": "S-10"})
    return pd.DataFrame(records)


class LabelAccessGuard(pd.DataFrame):
    """Fail on selected annotation fields to detect accidental value access."""
    forbidden = {"final_label", "final_relevance", "difficulty", "final_conflict_type", "human_conflict"}

    @property
    def _constructor(self):
        return LabelAccessGuard

    def __getitem__(self, key):
        if isinstance(key, str) and key in self.forbidden:
            raise AssertionError(f"Forbidden annotation access: {key}")
        if isinstance(key, (list, tuple)) and any(value in self.forbidden for value in key):
            raise AssertionError(f"Forbidden annotation selection: {key}")
        return super().__getitem__(key)


def check_boundaries() -> list[dict]:
    checks = []
    def passed(name: str, detail: str):
        checks.append({"test": name, "status": "passed", "detail": detail})

    missing = [None, np.nan, pd.NA, "", "  ", "!!!"]
    for value in missing:
        frame = frame_for(1, 1)
        frame["query_normalized_description"] = value
        frame["candidate_normalized_description"] = value
        require(not policy.exact_mask(frame).any(), "Missing/effectively-empty descriptions accepted")
        require(policy.route(frame)["model_called"].all(), "Missing description was implicitly rejected")
    for value in [None, np.nan, pd.NA, "", "  "]:
        frame = frame_for(1, 1)
        frame["query_normalized_unit"] = value
        frame["candidate_normalized_unit"] = value
        require(not policy.exact_mask(frame).any(), "Missing normalized units accepted")
        require(policy.route(frame)["model_called"].all(), "Missing unit was implicitly rejected")
    passed("missing_values_not_accepted", "Equal None/NA/NaN/blank fields never produce exact acceptance; unresolved pairs require scoring.")

    frame = frame_for(1, 1)
    frame.loc[0, "query_normalized_description"] = " Curb & Gutter! "
    frame.loc[0, "candidate_normalized_description"] = "curb-and-gutter"
    frame.loc[0, "query_normalized_unit"] = "  Linear_Foot  "
    frame.loc[0, "candidate_normalized_unit"] = "linear_foot"
    require(policy.exact_mask(frame).all(), "Canonical punctuation/ampersand/whitespace equivalence failed")
    passed("canonical_text_equivalence", "Server-compatible lowercasing, punctuation, ampersand, and whitespace normalization.")

    for field, value in [("candidate_normalized_description", "repair concrete curb"),
                         ("candidate_normalized_unit", "sf")]:
        frame = frame_for(1, 1)
        frame.loc[0, field] = value
        route = policy.route(frame)
        require(not route["rule_accept"].any() and route["model_called"].all() and not route["unscored"].any(),
                "A nonexact candidate was rejected without a score")
    passed("nonexact_is_uncertain", "Description/unit differences never become an automatic negative rule.")

    frame = frame_for(4)
    rng = np.random.default_rng(20261005)
    a = policy.apply_policy(frame, rng.normal(size=len(frame)), .5)
    b = policy.apply_policy(frame, np.full(len(frame), np.inf), .5)
    require(not a["model_called"].any() and np.array_equal(a["returned_rank"], b["returned_rank"]),
            "Already-full exact list depended on nonexact scores")
    require(a["prediction"][:4].tolist() == [1, 1, 1, 1] and a["prediction"][4:].tolist() == [-1] * 26,
            "Skipped candidates lost their unknown state")
    require(np.flatnonzero(a["returned_rank"]).tolist() == [0, 1, 2], "Exact candidate-ID priority failed")
    require(np.isnan(a["score"]).all(), "Uncalled scores retained")
    passed("full_exact_list_score_invariance", "With >=3 exact references, arbitrary nonexact scores cannot alter calls, unknown states, or Top3.")

    frame = frame_for(1)
    scores = np.full(len(frame), -.5)
    scores[[1, 2]] = 2.0
    scores[3] = .5
    result = policy.apply_policy(frame, scores, .5)
    require(result["returned_rank"][[0, 1, 2]].tolist() == [1, 2, 3], "Rule priority or model score/ID ties failed")
    require(result["prediction"][3] == 1 and result["returned_rank"][3] == 0, "Acceptance/return cap were conflated")
    require(result["model_called"].sum() == 29, "Residual candidate routing failed")
    scores[2:] = -.5
    partial = policy.apply_policy(frame, scores, .5)
    require((partial["returned_rank"] > 0).sum() == 2, "List was forcibly filled below threshold")
    none = policy.apply_policy(frame_for(0), np.full(30, -.5), .5)
    require(not none["returned_rank"].any(), "Empty accepted set did not produce an empty list")
    passed("partial_thresholded_list", "Rules take priority; score/ID ties are deterministic; threshold is inclusive; fewer than three and empty outputs are allowed.")

    original = frame_for(2)
    guarded = LabelAccessGuard(original.copy())
    for annotation in guarded.forbidden:
        guarded[annotation] = [f"poison_{annotation}_{i}" for i in range(len(guarded))]
    reference = policy.apply_policy(original, scores, .5)
    isolated = policy.apply_policy(guarded, scores, .5)
    require(np.array_equal(reference["model_called"], isolated["model_called"])
            and np.array_equal(reference["returned_rank"], isolated["returned_rank"]), "Annotations influenced policy")
    require(policy.serialize(original, "query") == policy.serialize(guarded, "query"), "Annotations influenced serialization")
    passed("annotation_access_guard", "Poisoned label/difficulty/manual-conflict fields cannot be selected by routing, ranking, or serialization.")

    frame = frame_for(2)
    scores = rng.normal(size=len(frame))
    baseline = policy.apply_policy(frame, scores, .5)
    permutation = rng.permutation(len(frame))
    permuted = frame.iloc[permutation].copy()
    permuted.index = np.arange(100, 100 + len(frame))
    transformed = policy.apply_policy(permuted, scores[permutation], .5)
    for field in ["model_called", "prediction", "returned_rank"]:
        back = np.empty_like(transformed[field])
        back[permutation] = transformed[field]
        require(np.array_equal(baseline[field], back), f"Row permutation changed {field}")
    passed("row_permutation_invariance", "Candidate-ID tie order and per-query membership are independent of row ordering/index labels.")

    frame = frame_for(1)
    residual = np.flatnonzero(policy.route(frame)["model_called"])
    full = rng.normal(size=len(frame))
    a = policy.apply_policy(frame, full, .5)
    b = policy.apply_policy(frame, full[residual], .5)
    require(np.array_equal(a["returned_rank"], b["returned_rank"]), "Called-only score interface differs")
    for bad in [np.nan, np.inf]:
        invalid = full.copy()
        invalid[residual[0]] = bad
        try:
            policy.apply_policy(frame, invalid, .5)
        except ValueError:
            pass
        else:
            raise AssertionError("Missing actual model score became an implicit negative")
    passed("missing_called_score_rejected", "Full-row and called-only score arrays agree; NaN/Inf on modeled candidates raise errors.")

    serialized = policy.serialize(frame, "query")[0]
    require(serialized == "Description: concrete curb. Normalized: concrete curb. Pay unit: lf. Category: concrete. Specs: s-10.",
            "Frozen input serialization changed")
    passed("frozen_serialization", "Five fields, punctuation, order, casing, and whitespace preserve the checkpoint's original template.")
    return checks


def check_history(source: Path) -> tuple[list[dict], dict]:
    manifest_path = source / "source_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    input_path = source / "inputs.csv"
    require(sha256(input_path) == manifest["inputs_sha256"], "Historical source input hash mismatch")
    inputs = pd.read_csv(input_path, dtype=str, keep_default_na=False)
    require(not {"final_label", "final_relevance", "difficulty"}.intersection(inputs.columns), "Historical inference input contains annotation fields")
    require(not inputs.pair_id.duplicated().any(), "Duplicate historical input IDs")
    records = []
    files = {"inputs.csv": sha256(input_path), "source_manifest.json": sha256(manifest_path)}
    for mode, directory in [("batch", source), ("query", source / "query_mode")]:
        require(directory.exists(), f"Missing historical mode {mode}")
        for run in manifest["runs"]:
            seed, threshold = int(run["seed"]), float(run["threshold"])
            prediction_path = directory / f"predictions_seed_{seed}.csv"
            require(prediction_path.exists(), f"Missing historical predictions: {prediction_path}")
            original = pd.read_csv(prediction_path, dtype={"pair_id": str}, float_precision="round_trip")
            original = original[original.policy.eq("stop_3")].set_index("pair_id")
            require(not original.index.duplicated().any() and set(original.index) == set(inputs.pair_id), "Incomplete historical stop_3 outputs")
            original = original.reindex(inputs.pair_id)
            require(original.threshold.eq(threshold).all(), "Historical frozen threshold mismatch")
            result = policy.apply_policy(inputs, original.score.to_numpy(float), threshold)
            expected_called = original.model_called.to_numpy(int).astype(bool)
            differences = {name: int(np.sum(np.asarray(result[name], dtype=int) != original[name].to_numpy(int)))
                           for name in ["exact_match", "rule_accept", "model_called", "prediction", "returned_rank"]}
            require(all(count == 0 for count in differences.values()), f"Historical output differs: {mode}/{seed}/{differences}")
            require(np.array_equal(result["called_indices"], np.flatnonzero(expected_called)), "Historical called indices differ")
            for name in ["query", "candidate"]:
                fields = [inputs[f"{name}_{suffix}"].map(policy.normalize_text).tolist() for suffix in policy.TEXT_FIELDS]
                expected_text = [f"Description: {d}. Normalized: {n}. Pay unit: {u}. Category: {c}. Specs: {s}."
                                 for d, n, u, c, s in zip(*fields)]
                require(policy.serialize(inputs, name) == expected_text, "Historical checkpoint serialization differs")
            records.append({"mode": mode, "seed": seed, "threshold": threshold, "pairs": len(inputs),
                            "query_pools": int(inputs.groupby(["evaluation_split", "query_id"]).ngroups),
                            "model_called_pairs": int(expected_called.sum()),
                            "zero_model_query_pools": int(pd.Series(expected_called).groupby(
                                [inputs.evaluation_split, inputs.query_id]).sum().eq(0).sum()),
                            "called_indices_equal": True, "all_returned_lists_equal": True, **differences})
            files[f"{mode}/{prediction_path.name}"] = sha256(prediction_path)
    return records, files


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-directory", type=Path, default=Path(__file__).resolve().parents[2] / "rule_first_system_20261004" / "results" / "server")
    parser.add_argument("--output-directory", type=Path, default=Path(__file__).resolve().parents[1] / "results" / "qa")
    args = parser.parse_args()
    output = args.output_directory.resolve()
    output.mkdir(parents=True, exist_ok=True)
    report = {"status": "started", "new_inference_performed": False, "labels_read": False,
              "module_sha256": sha256(Path(policy.__file__)), "test_script_sha256": sha256(Path(__file__)),
              "output_cap": policy.MAX_REFERENCES, "historical_mode": "Each actual stop_3 policy's own GPU score array, without new scoring."}
    try:
        boundaries = check_boundaries()
        history, sources = check_history(args.source_directory.resolve())
        pd.DataFrame(boundaries).to_csv(output / "system_policy_boundary_checks.csv", index=False)
        pd.DataFrame(history).to_csv(output / "system_policy_historical_reproduction.csv", index=False)
        report.update({"status": "passed", "boundary_checks": boundaries, "historical_runs": history,
                       "historical_source_hashes": sources, "actual_run_reproduction": "Zero mask, prediction, rank, and scoring-index differences for every seed/mode/query."})
        print(json.dumps({"status": "passed", "boundary_test_n": len(boundaries), "historical_run_n": len(history),
                          "output_directory": str(output)}, ensure_ascii=False))
    except Exception as error:
        report["status"] = "failed"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "system_policy_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
