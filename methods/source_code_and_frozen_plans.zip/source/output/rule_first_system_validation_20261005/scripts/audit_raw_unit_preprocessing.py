#!/usr/bin/env python3
"""CPU-only audit using hash-verified exported original units/descriptions.

Only pair_id/query_unit/candidate_unit are read from the canonical data file.
All rule masks and lists are constructed before offline gold-label evaluation.
No GPU, model inference, retuning, Excel extraction, or retrieval is performed.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import platform
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

import audit_rule_preprocessing as description_audit
import system_policy


CANONICAL_SHA = "057326fea7a529bddfb20fe69865ca8ed7affcfca37b22b78d0a1b69c6c90ae7"
COMMON_SHA = "2523afc4b5c3474551a27f2a3a51aab55520766bc45585795139a9bbca920b7a"
RULES = ["original_description_and_unit_literal", "canonical_description_unit_whitespace",
         "canonical_description_unit_punctuation", "canonical_description_unit_aliases", "current_exported_rule"]
QKEY = ["evaluation_split", "query_id"]


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def pct(numerator, denominator):
    return 100.0 * numerator / denominator if denominator else np.nan


def load_common(path):
    require(sha(path) == COMMON_SHA, "Common utility hash differs from server-confirmed source")
    spec = importlib.util.spec_from_file_location("verified_bidupm_common", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def rule_masks(frame, common):
    result = {}
    for name in RULES:
        if name == "original_description_and_unit_literal":
            description_column, description_norm, unit_column, unit_norm = "description", str, "unit", str
        elif name == "current_exported_rule":
            description_column, description_norm, unit_column, unit_norm = "normalized_description", common.canonical_text, "normalized_unit", system_policy.normalize_unit
        else:
            description_column, description_norm, unit_column = "description", common.canonical_text, "unit"
            unit_norm = {"canonical_description_unit_whitespace": system_policy.normalize_unit,
                         "canonical_description_unit_punctuation": common.canonical_text,
                         "canonical_description_unit_aliases": common.canonical_unit}[name]
        qd = frame[f"query_{description_column}"].map(description_norm)
        cd = frame[f"candidate_{description_column}"].map(description_norm)
        qu = frame[f"query_{unit_column}"].map(unit_norm)
        cu = frame[f"candidate_{unit_column}"].map(unit_norm)
        nonempty = qd.str.strip().ne("") & cd.str.strip().ne("") & qu.str.strip().ne("") & cu.str.strip().ne("")
        result[name] = (nonempty & qd.eq(cd) & qu.eq(cu)).to_numpy(bool)
    require(np.array_equal(result["current_exported_rule"], system_policy.exact_mask(frame)), "Current rule mismatch")
    return result


def quality(frame, masks, ranks):
    rows, query_rows = [], []
    for name in RULES:
        data = frame[[*QKEY, "final_label"]].copy()
        data["accept"] = masks[name]
        data["return"] = ranks[name] > 0
        data["returned_tp"] = data["return"] & data.final_label.eq(1)
        data["returned_fp"] = data["return"] & data.final_label.eq(0)
        for (split, query_id), group in data.groupby(QKEY):
            positives = int(group.final_label.sum())
            tp, fp = int(group.returned_tp.sum()), int(group.returned_fp.sum())
            query_rows.append({"variant": name, "evaluation_split": split, "query_id": query_id,
                               "positive_n": positives, "accept_n": int(group.accept.sum()), "returned_tp": tp,
                               "returned_fp": fp, "returned_n": tp + fp, "hit": tp > 0,
                               "recall_at3": tp / positives if positives else np.nan})
    queries = pd.DataFrame(query_rows)
    for group_name, splits in description_audit.groups_for(frame).items():
        selected = frame.evaluation_split.isin(splits).to_numpy()
        gold = frame.final_label.eq(1).to_numpy()[selected]
        for name in RULES:
            accept = masks[name][selected]
            tp, fp, fn, tn = (int(x.sum()) for x in [accept & gold, accept & ~gold, ~accept & gold, ~accept & ~gold])
            q = queries[queries.variant.eq(name) & queries.evaluation_split.isin(splits)]
            positive_q, noref = q.positive_n.gt(0), q.positive_n.eq(0)
            returned_tp, returned_fp = int(q.returned_tp.sum()), int(q.returned_fp.sum())
            rows.append({"evaluation_group": group_name, "variant": name, "pairs": int(selected.sum()), "queries": len(q),
                         "positive_pairs": int(gold.sum()), "tp": tp, "fp": fp, "fn": fn, "tn": tn,
                         "pair_precision_pct": pct(tp, tp + fp), "pair_recall_pct": pct(tp, tp + fn), "pair_f1_pct": pct(2 * tp, 2 * tp + fp + fn),
                         "returned_tp": returned_tp, "returned_fp": returned_fp, "returned_precision_pct": pct(returned_tp, returned_tp + returned_fp),
                         "macro_recall_at3_pct": 100 * q.loc[positive_q, "recall_at3"].mean(), "hit_at3_pct": pct(q.loc[positive_q, "hit"].sum(), positive_q.sum()),
                         "accepted_queries": int(q.accept_n.gt(0).sum()), "at_least_three_accepted_queries": int(q.accept_n.ge(3).sum()),
                         "no_reference_rejection_pct": pct(q.loc[noref, "returned_n"].eq(0).sum(), noref.sum())})
    return pd.DataFrame(rows), queries


def main():
    workspace = Path(__file__).resolve().parents[3]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=workspace / "output/rule_first_system_20261004/results/server")
    parser.add_argument("--canonical", type=Path, default=workspace / "output/revise3_full_20260920/supplementary/data/canonical/all_pairs_vfinal_12092.csv")
    parser.add_argument("--common", type=Path, default=workspace / "output/revise3_full_20260920/supplementary/scripts/original/bidupm_vfinal_common.py")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "results/preprocessing_audit")
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    report = {"status": "started", "script_sha256": sha(__file__), "inference_performed": False,
              "labels_used_for_routing": False, "threshold_selection": False,
              "scope": "Previously extracted original fields within the same fixed 30-candidate gold pools; not untouched Excel-to-reference end-to-end processing.",
              "rules": {"original_description_and_unit_literal": "Original exported description and original exported unit strings equal, nonblank.",
                        "canonical_description_unit_whitespace": "Canonical original descriptions; raw units lowercased, stripped and whitespace collapsed.",
                        "canonical_description_unit_punctuation": "Canonical original descriptions and raw-unit punctuation/case canonicalization, no aliases.",
                        "canonical_description_unit_aliases": "Canonical original descriptions and original units mapped by hash-verified canonical_unit alias dictionary.",
                        "current_exported_rule": "Current canonical normalized-description and normalized-unit exact rule."}}
    try:
        manifest = json.loads((source / "source_manifest.json").read_text())
        require(sha(args.canonical) == CANONICAL_SHA == manifest["input_hashes"]["pairs/all_pairs_vfinal_12092.csv"], "Canonical data differs from verified server bytes")
        require(sha(source / "inputs.csv") == manifest["inputs_sha256"], "Inference input hash mismatch")
        require(sha(source / "labels.csv") == manifest["labels_sha256"], "Gold label hash mismatch")
        common = load_common(args.common)
        inputs = pd.read_csv(source / "inputs.csv", dtype=str, keep_default_na=False)
        inputs = inputs[inputs.evaluation_split.ne("validation")].reset_index(drop=True)
        raw_units = pd.read_csv(args.canonical, dtype=str, keep_default_na=False, usecols=["pair_id", "query_unit", "candidate_unit"])
        require(not raw_units.pair_id.duplicated().any(), "Duplicate canonical pair ID")
        inputs = inputs.merge(raw_units, on="pair_id", how="left", validate="one_to_one")
        require(len(inputs) == 6600 and inputs[QKEY].drop_duplicates().shape[0] == 220, "Expected 220 formal queries and 6600 pairs")
        require(inputs.query_unit.notna().all() and inputs.candidate_unit.notna().all(), "Missing original-unit join")
        require(not {"final_label", "final_relevance", "difficulty", "final_conflict_type"}.intersection(inputs.columns), "Inference data contains annotations")
        raw_path = output / "raw_inference_fields.csv"
        inputs.to_csv(raw_path, index=False)
        masks = rule_masks(inputs, common)
        ranks = {name: system_policy.rank_returned(inputs, accept, np.full(len(inputs), np.nan), 1.0) for name, accept in masks.items()}
        labels = pd.read_csv(source / "labels.csv", dtype={"pair_id": str}, keep_default_na=False)
        require(not labels.pair_id.duplicated().any() and labels.final_label.isin([0, 1]).all(), "Invalid gold labels")
        evaluated = inputs.merge(labels[["pair_id", "final_label"]], on="pair_id", how="left", validate="one_to_one")
        require(evaluated.final_label.notna().all(), "Missing gold labels")
        summary, queries = quality(evaluated, masks, ranks)
        sample_fields = ["pair_id", *QKEY, "candidate_id", "query_description", "candidate_description", "query_unit", "candidate_unit",
                         "query_normalized_description", "candidate_normalized_description", "query_normalized_unit", "candidate_normalized_unit", "final_label"]
        rescued_parts, transition_rows = [], []
        for previous, current in zip(RULES[:-1], RULES[1:]):
            gain = ~masks[previous] & masks[current]
            loss = masks[previous] & ~masks[current]
            gold = evaluated.final_label.eq(1).to_numpy()
            sample = evaluated.loc[gain & gold, sample_fields].copy()
            sample["transition"] = f"{previous} -> {current}"
            rescued_parts.append(sample)
            transition_rows.append({"from_variant": previous, "to_variant": current,
                                    "gained_positive_pairs": int((gain & gold).sum()), "gained_negative_pairs": int((gain & ~gold).sum()),
                                    "lost_positive_pairs": int((loss & gold).sum()), "lost_negative_pairs": int((loss & ~gold).sum())})
        mappings = []
        mapping_mismatches = []
        for side in ["query", "candidate"]:
            table = inputs[[f"{side}_unit", f"{side}_normalized_unit"]].copy()
            table.columns = ["raw_unit", "exported_normalized_unit"]
            table["unit_whitespace"] = table.raw_unit.map(system_policy.normalize_unit)
            table["unit_punctuation"] = table.raw_unit.map(common.canonical_text)
            table["unit_aliases"] = table.raw_unit.map(common.canonical_unit)
            table["matches_exported"] = table.unit_aliases.eq(table.exported_normalized_unit.map(system_policy.normalize_unit))
            grouped = table.groupby(list(table.columns), dropna=False).size().rename("pair_side_occurrences").reset_index()
            grouped["side"] = side
            mappings.append(grouped)
            mapping_mismatches.append({"side": side, "occurrences": len(table), "canonical_alias_output_differs_from_exported_n": int((~table.matches_exported).sum())})
        # Time just deterministic in-memory description/unit normalization and
        # exact comparison on 6000 pairs; no IO, retrieval, labels, or sorting.
        bench = inputs.head(6000)
        timings = []
        for repeat in range(10):
            start = time.perf_counter()
            qd = bench.query_description.map(common.canonical_text)
            cd = bench.candidate_description.map(common.canonical_text)
            qu = bench.query_unit.map(common.canonical_unit)
            cu = bench.candidate_unit.map(common.canonical_unit)
            accepted = qd.ne("") & cd.ne("") & qu.ne("") & cu.ne("") & qd.eq(cd) & qu.eq(cu)
            seconds = time.perf_counter() - start
            timings.append({"repeat": repeat, "pairs": len(bench), "seconds": seconds, "accepted_pairs": int(accepted.sum())})
        outputs = {"raw_unit_rule_summary.csv": summary, "raw_unit_rule_per_query.csv": queries,
                   "raw_unit_rule_transitions.csv": pd.DataFrame(transition_rows),
                   "raw_unit_preprocessing_recovered_gold_positives.csv": pd.concat(rescued_parts, ignore_index=True),
                   "raw_unit_normalization_mappings.csv": pd.concat(mappings, ignore_index=True),
                   "raw_field_cpu_normalization_timing.csv": pd.DataFrame(timings)}
        for name, frame in outputs.items():
            frame.to_csv(output / name, index=False)
        seconds = np.array([row["seconds"] for row in timings])
        report.update({"status": "passed", "source_hashes": {"canonical": sha(args.canonical), "common": sha(args.common),
                                                               "inputs": sha(source / "inputs.csv"), "labels": sha(source / "labels.csv")},
                       "canonical_columns_read": ["pair_id", "query_unit", "candidate_unit"], "raw_inference_sha256": sha(raw_path),
                       "gold_label_use": "Offline rule/list evaluation and example selection only; masks and ranks computed first.",
                       "raw_unit_mapping_checks": mapping_mismatches,
                       "deterministic_code_review": {"functions": ["canonical_text", "canonical_unit", "tokens", "pair_features", "TemporalRetriever.retrieve"],
                                                     "ai_inference_in_these_functions": False,
                                                     "normalization": "Explicit regex/text transformations and static unit aliases; no learned semantic model.",
                                                     "semantic_key": "Canonical description concatenated with canonical unit; lexical equality key, not an AI semantic embedding.",
                                                     "retrieval": "Same-agency earlier eligible records; term-IDF overlap plus engineering features. Item code receives 35 initial +20 reranking boost; exact description+unit key receives 45 initial +25 reranking boost.",
                                                     "candidate_composition": "Candidates are already ranked using exact-match-friendly features before final Top30. First pass limits each canonical description/unit key to 3 records; fallback can relax this if too few candidates.",
                                                     "boundary": "These verified helpers are deterministic; the entire upstream spreadsheet/PDF extraction workflow was not timed or fully audited here."},
                       "cpu_normalization": {"pairs": len(bench), "repeats": 10, "seconds_median": float(np.median(seconds)), "seconds_mean": float(seconds.mean()),
                                             "seconds_sample_sd": float(seconds.std(ddof=1)), "seconds_min": float(seconds.min()), "seconds_max": float(seconds.max()),
                                             "platform": platform.platform(), "machine": platform.machine(),
                                             "scope": "In-memory raw-description canonicalization + raw-unit aliases + exact comparison only; excludes extraction, IO, retrieval, ranking, and model inference."},
                       "all_formal_results": summary[summary.evaluation_group.eq("all_formal")].to_dict("records"),
                       "output_files": {name: {"rows": len(frame), "sha256": sha(output / name)} for name, frame in outputs.items()}})
        print(json.dumps(description_audit.json_clean({"status": "passed", "all_formal_results": report["all_formal_results"],
                                                       "unit_transitions": transition_rows, "cpu_normalization": report["cpu_normalization"],
                                                       "output_directory": str(output)}), ensure_ascii=False))
    except Exception as error:
        report["status"] = "failed"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "raw_unit_preprocessing_report.json").write_text(json.dumps(description_audit.json_clean(report), indent=2, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
