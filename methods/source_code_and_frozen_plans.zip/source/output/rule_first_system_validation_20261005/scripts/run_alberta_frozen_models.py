#!/usr/bin/env python3
"""Score exhaustive Alberta pools with three frozen BGE checkpoints.

This runner never reads labels or benchmark/formal-test rows. --check-inputs is
CPU-only and never imports torch/transformers, loads a model, or accesses CUDA.
Normal execution is an explicit GPU operation using offline local checkpoints.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import time

import numpy as np
import pandas as pd

import system_policy


VARIANTS = ("cleaned", "raw")
SEEDS = (20260904, 20260905, 20260906)
THRESHOLDS = {20260904: 9.1875, 20260905: -1.453125, 20260906: 8.4375}
SOURCE_N = {2024: 237, 2026: 264}
QUERY_N = 135
PAIR_N = sum(QUERY_N * n for n in SOURCE_N.values())
POOL_N = 270
KEYS = ["evaluation_split", "query_id"]
BATCH_SIZE = 64
MAX_LENGTH = 256
CONTRACT = ["pair_id", *KEYS, "candidate_id", "initial_rank", "retrieval_score",
            *[f"{side}_{suffix}" for side in ("query", "candidate") for suffix in system_policy.TEXT_FIELDS]]
FORBIDDEN = {"label", "final_label", "final_relevance", "difficulty", "final_conflict_type",
             "prediction", "score", "model_logit", "gold_label", "is_match"}


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read_inputs(args):
    frozen_path = args.source / "source_manifest.json"
    input_manifest_path = args.inputs / "input_manifest.json"
    frozen = json.loads(frozen_path.read_text(encoding="utf-8"))
    manifest = json.loads(input_manifest_path.read_text(encoding="utf-8"))
    require(manifest["status"] == "passed", "Alberta input provenance failed")
    require(manifest["labels_accessed"] is False and manifest["models_run"] is False,
            "Alberta input creation accessed labels/models")
    require(manifest["item_codes_used_for_matching"] is False, "Input creation used item-code matching")
    require(manifest["full_candidate_pools"] is True, "Alberta inputs do not cover all source rows")
    require(sha(frozen_path) == manifest["frozen_manifest_sha256"], "Frozen source manifest hash differs")
    require(frozen["inference_input_contract"] == CONTRACT == manifest["inference_input_contract"],
            "Frozen five-slot inference contract differs")
    require(sha(system_policy.__file__) == manifest["serializer_policy_sha256"], "Frozen serializer bytes differ")
    for name in ("input_schema", "input_qa"):
        require(sha(args.inputs / f"{name}.json") == manifest[f"{name}_sha256"], f"Input {name} hash differs")
    qa = json.loads((args.inputs / "input_qa.json").read_text(encoding="utf-8"))
    require(qa["status"] == "passed" and qa["pairs_per_variant"] == PAIR_N,
            "Alberta QA did not pass full-pair checks")
    require(qa["labels_read"] is False and qa["predictions_read"] is False, "Input QA used labels/predictions")
    runs = frozen["runs"]
    require([int(run["seed"]) for run in runs] == list(SEEDS), "Frozen seed list differs")
    for run in runs:
        threshold = float(run["threshold"])
        require(math.isfinite(threshold) and threshold == THRESHOLDS[int(run["seed"])],
                "Original frozen threshold differs")
        require(run["checkpoint_files"] and "model.safetensors" in run["checkpoint_files"],
                "Frozen checkpoint hashes missing")
    entries = {entry["variant"]: entry for entry in manifest["outputs"]}
    require(set(entries) == set(VARIANTS), "Unexpected Alberta input variant")
    frames = {}
    actual_inputs = []
    for variant in VARIANTS:
        path = args.inputs / f"inference_pairs_{variant}.csv"
        require(sha(path) == entries[variant]["sha256"], f"CSV hash differs: {variant}")
        with path.open(encoding="utf-8", newline="") as stream:
            columns = next(csv.reader(stream))
        require(columns == manifest["columns"], "Input schema differs")
        require(columns[:len(CONTRACT)] == CONTRACT, "Frozen contract prefix differs")
        require(not FORBIDDEN.intersection(columns), "Annotations or predictions found in input header")
        frame = pd.read_csv(path, usecols=CONTRACT + ["source_year", "input_variant"],
                            dtype=str, keep_default_na=False)
        frame = frame[CONTRACT + ["source_year", "input_variant"]]
        require(len(frame) == PAIR_N, "Expected 67,635 full pairs per variant")
        require(frame.input_variant.eq(variant).all(), "Variant metadata differs")
        require(not frame.pair_id.duplicated().any(), "Duplicate pair IDs")
        require(not frame.duplicated([*KEYS, "candidate_id"]).any(), "Duplicate candidate in yearly query pool")
        require(frame.query_id.nunique() == QUERY_N, "Expected 135 unique actual bid items")
        require(set(frame.query_id) == {f"Q{n:03d}" for n in range(1, 136)}, "Actual item number set differs")
        require(frame[KEYS].drop_duplicates().shape[0] == POOL_N, "Expected 270 year/query pools")
        require(frame.initial_rank.eq("").all() and frame.retrieval_score.eq("").all(),
                "Exhaustive pools unexpectedly contain retrieval metadata")
        for side in ("query", "candidate"):
            require(frame[f"{side}_category"].eq("").all() and frame[f"{side}_spec_tokens"].eq("").all(),
                    "Unknown category/specification slot was filled")
            require(frame.groupby(KEYS, sort=False)[[f"query_{suffix}" for suffix in system_policy.TEXT_FIELDS]].nunique().le(1).all().all(),
                    "Query features vary within a yearly candidate pool")
        for year, count in SOURCE_N.items():
            sub = frame.loc[frame.source_year.eq(str(year))]
            require(len(sub) == QUERY_N * count, "Yearly full-pair count differs")
            require(sub.evaluation_split.eq(f"raw_alberta_{year}").all(), "Yearly split differs")
            require(sub.groupby(KEYS).size().eq(count).all(), "Candidate pool incomplete")
            require(sub.candidate_id.nunique() == count, "Unexpected yearly source ID count")
            source_rows = sub.candidate_id.str.extract(rf"^{year}_R(\d{{3}})$", expand=False)
            require(source_rows.notna().all(), "Candidate worksheet-row ID malformed")
            expected_ids = "Alberta" + str(year) + "-" + sub.query_id + "-R" + source_rows
            require(sub.pair_id.eq(expected_ids).all(), "Pair ID does not map query item number and worksheet row")
        frames[variant] = frame.reset_index(drop=True)
        actual_inputs.append({"variant": variant, "name": path.name, "sha256": entries[variant]["sha256"],
                              "pairs": len(frame), "year_query_pools": POOL_N})
    identity = ["pair_id", *KEYS, "candidate_id", "source_year"]
    require(frames["cleaned"][identity].equals(frames["raw"][identity]), "Variant pair identity/order differs")
    require(frames["cleaned"][["query_description", "candidate_description"]].equals(
            frames["raw"][["query_description", "candidate_description"]]), "Variants changed raw descriptions")
    return frames, frozen, manifest, actual_inputs


def diagnostic_summary(frame, score, prediction, rank, seed, variant, threshold):
    data = frame[[*KEYS, "source_year"]].copy()
    data["score"] = score
    data["prediction"] = prediction
    data["returned"] = rank > 0
    summaries = []
    for (split, query_id), pool in data.groupby(KEYS, sort=False):
        returned_n = int(pool.returned.sum())
        accepted_n = int(pool.prediction.sum())
        require(returned_n == min(accepted_n, 3), "Top-three cap or threshold ranking differs")
        summaries.append({"seed": seed, "variant": variant, "threshold": threshold,
                          "evaluation_split": split, "source_year": pool.source_year.iloc[0],
                          "query_id": query_id, "candidate_count": len(pool),
                          "above_threshold_candidates": accepted_n, "returned_recommendations": returned_n,
                          "maximum_logit": float(pool.score.max())})
    return summaries


def run_gpu(args, frames, frozen, input_manifest, actual_inputs):
    require(not args.output.exists() or not any(args.output.iterdir()),
            "Refusing to overwrite existing run results: choose an empty output directory")
    # Model packages are imported only for explicit normal GPU execution.
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    require(torch.cuda.is_available(), "Actual execution requires CUDA")
    require(torch.cuda.is_bf16_supported(), "Actual execution requires BF16 support")
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    args.output.mkdir(parents=True, exist_ok=True)
    plan = {
        "status": "running", "created_utc": datetime.now(timezone.utc).isoformat(),
        "schema": "alberta-frozen-full-model-inference-v1", "variants": list(VARIANTS),
        "seed_list": list(SEEDS), "source_runs": frozen["runs"], "input_csvs": actual_inputs,
        "input_manifest_sha256": sha(args.inputs / "input_manifest.json"),
        "source_manifest_sha256": sha(args.source / "source_manifest.json"),
        "raw_items_sha256": input_manifest["raw_items_sha256"],
        "script_sha256": sha(__file__), "policy_sha256": sha(system_policy.__file__),
        "pairs_per_condition": PAIR_N, "unique_bid_items": QUERY_N,
        "year_query_pools_per_condition": POOL_N, "source_count_by_year": SOURCE_N,
        "batch_size": BATCH_SIZE, "max_length": MAX_LENGTH, "threads": 8,
        "precision": "CUDA BF16 autocast; TF32 false", "gpu": torch.cuda.get_device_name(0),
        "torch_version": torch.__version__, "labels_accessed": False, "labels_available": False, "benchmark_rows_read": False,
        "training_performed": False, "thresholds_retuned": False,
        "conditions": "two Alberta input variants times three original frozen checkpoints",
        "candidate_scoring": "all pairs scored by BGE; no exact-rule gate or candidate retrieval",
        "ranking": "frozen threshold per checkpoint; descending model logit, candidate ID tie-break, maximum three returned per year/query pool",
        "warmup": "first 64 pairs once per variant per loaded checkpoint, excluded from inference timing",
        "timing": "one synchronized resident full-pair pass per condition; serialization, tokenization, GPU inference, threshold classification and top-three ranking included; file I/O, model loading, integrity checks excluded",
        "model_load_timing": "tokenizer/model loading and transfer to CUDA; recorded separately",
        "evaluation_limitation": "No gold labels: outputs are scores and review recommendations, not accuracy or semantic correctness metrics.",
        "completed_conditions": [], "model_loads": [],
    }
    manifest_path = args.output / "execution_manifest.json"
    write_json(manifest_path, plan)
    timing_rows, query_rows = [], []

    @torch.inference_mode()
    def execute(frame, model, tokenizer, threshold):
        torch.cuda.synchronize()
        started = time.perf_counter()
        queries = system_policy.serialize(frame, "query")
        candidates = system_policy.serialize(frame, "candidate")
        score = np.empty(len(frame), dtype=np.float64)
        for low in range(0, len(frame), BATCH_SIZE):
            encoded = tokenizer(queries[low:low + BATCH_SIZE], candidates[low:low + BATCH_SIZE],
                                padding=True, truncation=True, max_length=MAX_LENGTH, return_tensors="pt")
            encoded = {key: value.to("cuda") for key, value in encoded.items()}
            with torch.autocast("cuda", dtype=torch.bfloat16):
                logits = model(**encoded).logits
            require(logits.numel() == min(BATCH_SIZE, len(frame) - low), "Expected one binary logit per pair")
            score[low:low + BATCH_SIZE] = logits.reshape(-1).float().cpu().numpy()
        require(np.isfinite(score).all(), "Non-finite BGE scores")
        prediction = (score >= threshold).astype(np.int8)
        rank = system_policy.rank_returned(frame, np.zeros(len(frame), dtype=bool), score, threshold)
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - started
        return score, prediction, rank, elapsed

    for run in frozen["runs"]:
        seed, threshold = int(run["seed"]), float(run["threshold"])
        checkpoint = Path(run["checkpoint"])
        print(f"CHECKPOINT_VERIFY seed={seed}", flush=True)
        for name, expected_hash in run["checkpoint_files"].items():
            require(sha(checkpoint / name) == expected_hash, f"Checkpoint hash differs: {seed}/{name}")
        torch.manual_seed(seed)
        torch.cuda.synchronize()
        load_start = time.perf_counter()
        tokenizer = AutoTokenizer.from_pretrained(checkpoint, local_files_only=True)
        model = AutoModelForSequenceClassification.from_pretrained(checkpoint, local_files_only=True).to("cuda").eval()
        torch.cuda.synchronize()
        load_seconds = time.perf_counter() - load_start
        plan["model_loads"].append({"seed": seed, "seconds": load_seconds, "checkpoint_hashes_verified": True})
        write_json(manifest_path, plan)
        for variant in VARIANTS:
            execute(frames[variant].head(BATCH_SIZE), model, tokenizer, threshold)
        # Seeded order avoids fixing one variant's position for every checkpoint.
        for variant in np.random.default_rng(seed).permutation(VARIANTS).tolist():
            frame = frames[variant]
            print(f"START seed={seed} variant={variant} pairs={PAIR_N}", flush=True)
            score, prediction, rank, seconds = execute(frame, model, tokenizer, threshold)
            output = frame[["pair_id", *KEYS, "source_year", "candidate_id"]].copy()
            output["seed"], output["variant"], output["threshold"] = seed, variant, threshold
            output["score"], output["prediction"], output["returned_rank"] = score, prediction, rank
            path = args.output / f"predictions_{variant}_seed_{seed}.csv"
            output.to_csv(path, index=False, lineterminator="\n")
            timing_rows.append({"seed": seed, "variant": variant, "threshold": threshold,
                                "batch_size": BATCH_SIZE, "repeat": 0, "pairs": PAIR_N,
                                "unique_bid_items": QUERY_N, "year_query_pools": POOL_N,
                                "seconds": seconds, "model_load_seconds": load_seconds,
                                "model_batches": math.ceil(PAIR_N / BATCH_SIZE)})
            query_rows.extend(diagnostic_summary(frame, score, prediction, rank, seed, variant, threshold))
            pd.DataFrame(timing_rows).to_csv(args.output / "timing.csv", index=False, lineterminator="\n")
            pd.DataFrame(query_rows).to_csv(args.output / "query_recommendation_summary.csv", index=False, lineterminator="\n")
            plan["completed_conditions"].append({"seed": seed, "variant": variant, "threshold": threshold,
                                                  "prediction_file": path.name, "prediction_sha256": sha(path),
                                                  "pairs": len(output), "seconds": seconds})
            write_json(manifest_path, plan)
            print(f"FINISH seed={seed} variant={variant} seconds={seconds:.3f}", flush=True)
        del model, tokenizer
        gc.collect()
        torch.cuda.empty_cache()
    require(len(timing_rows) == 6 and len(query_rows) == 6 * POOL_N, "Incomplete frozen-model conditions")
    require(Counter((entry["seed"], entry["variant"]) for entry in plan["completed_conditions"]) ==
            Counter((seed, variant) for seed in SEEDS for variant in VARIANTS), "Missing/duplicate inference condition")
    run_qa = {
        "status": "passed", "completed_conditions": 6, "pairs_per_condition": PAIR_N,
        "total_scored_pairs": 6 * PAIR_N, "unique_bid_items": QUERY_N,
        "year_query_pools_per_condition": POOL_N, "query_summary_rows": len(query_rows),
        "source_count_by_year": SOURCE_N, "full_pool_counts_verified": True,
        "input_hashes_verified": True, "all_checkpoint_hashes_verified": True,
        "serializer_hash_verified": True, "finite_scores_verified": True,
        "returned_count_equals_min_above_threshold_and_3": True,
        "labels_available": False, "labels_accessed": False,
        "gold_metrics_computed": False, "training_performed": False, "thresholds_retuned": False,
    }
    write_json(args.output / "run_qa.json", run_qa)
    plan.update(status="complete", completed_utc=datetime.now(timezone.utc).isoformat(),
                timing_sha256=sha(args.output / "timing.csv"),
                query_recommendation_summary_sha256=sha(args.output / "query_recommendation_summary.csv"),
                run_qa_sha256=sha(args.output / "run_qa.json"))
    write_json(manifest_path, plan)
    print("ALL_COMPLETE", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="Frozen GPU source directory containing source_manifest.json")
    parser.add_argument("--inputs", type=Path, required=True, help="Alberta CSVs and input_manifest/input_qa/input_schema JSON")
    parser.add_argument("--output", type=Path, help="New or empty run output directory; required for GPU execution")
    parser.add_argument("--check-inputs", action="store_true", help="CPU-only provenance and full-pair validation; never loads a model")
    args = parser.parse_args()
    frames, frozen, input_manifest, actual_inputs = read_inputs(args)
    if args.check_inputs:
        print(json.dumps({"status": "passed", "pairs_per_variant": PAIR_N, "variants": list(VARIANTS),
                          "unique_bid_items": QUERY_N, "year_query_pools_per_variant": POOL_N,
                          "input_csvs": actual_inputs, "labels_read": False, "labels_available": False, "models_loaded": False,
                          "checkpoint_files_verified": False,
                          "checkpoint_validation": "deferred to normal GPU execution on checkpoint host"}, ensure_ascii=False))
        return
    require(args.output is not None, "--output required for explicit GPU execution")
    run_gpu(args, frames, frozen, input_manifest, actual_inputs)


if __name__ == "__main__":
    main()
