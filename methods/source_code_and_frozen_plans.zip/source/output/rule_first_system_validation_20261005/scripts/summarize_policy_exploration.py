#!/usr/bin/env python3
"""Report the already-frozen replay; never chooses or modifies a policy."""
from pathlib import Path
import json

import pandas as pd

from explore_validation_policies import align_predictions, execute, selected_spec


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "policy_exploration"
SOURCE = ROOT.parent / "rule_first_system_20261004" / "results" / "server"


def main():
    frame = pd.read_csv(SOURCE / "inputs.csv", keep_default_na=False)
    gold = pd.read_csv(SOURCE / "labels.csv").set_index("pair_id").loc[frame.pair_id]
    frame["_gold_for_evaluation_only"] = gold.final_label.to_numpy(int)
    freeze = json.loads((OUT / "selected_policy_freeze.json").read_text())
    # Report already-frozen predictions without passing evaluator gold to routing.
    routing_frame = frame.drop(columns="_gold_for_evaluation_only")
    for selection in freeze["selections"]:
        seed = selection["seed"]
        scores = align_predictions(SOURCE / f"predictions_seed_{seed}.csv", routing_frame, "all_bge").score.to_numpy(float)
        spec = selected_spec(selection)
        result = execute(routing_frame, scores, spec["threshold"], mode=spec["mode"], family=spec.get("family"))
        predictions = routing_frame[["pair_id", "evaluation_split", "query_id", "candidate_id"]].copy()
        predictions["seed"] = seed
        predictions["selected_family"] = selection["selected_family"]
        for name in ("exact_match", "rule_accept", "model_called", "unscored", "score", "prediction", "returned_rank"):
            predictions[name] = result[name]
        predictions.to_csv(OUT / f"selected_policy_predictions_seed_{seed}.csv", index=False)
    ceilings = []
    for split, z in frame.groupby("evaluation_split"):
        q = z.groupby("query_id")._gold_for_evaluation_only.sum()
        total, oracle = int(q.sum()), int(q.clip(upper=3).sum())
        ceilings.append({"split": split, "query_n": len(q), "positive_query_n": int(q.gt(0).sum()),
                         "gold_positive_n": total, "oracle_top3_tp": oracle,
                         "oracle_top3_micro_recall_ceiling": oracle / total if total else None,
                         "gold_positive_query_distribution": json.dumps(q.value_counts().sort_index().to_dict())})
    pd.DataFrame(ceilings).to_csv(OUT / "top3_oracle_ceiling.csv", index=False)
    grid = pd.read_csv(OUT / "validation_grid.csv")
    grid_audit = []
    for seed, z in grid.groupby("seed"):
        positive = z.loc[z.semantic_tp.gt(0)]
        grid_audit.append({"seed": int(seed), "policy_grid_n": len(z),
                           "max_returned_nonexact_validation_tp": int(z.nonexact_returned_tp.max()),
                           "eligible_policies_with_semantic_positive_n": int((z.eligible & z.semantic_tp.gt(0)).sum()),
                           "max_eligible_recall": float(z.loc[z.eligible, "returned_micro_recall"].max()),
                           "best_semantic_precision_with_semantic_positive": float(positive.semantic_precision.max()) if len(positive) else None})
    pd.DataFrame(grid_audit).to_csv(OUT / "validation_identifiability.csv", index=False)
    formal = pd.read_csv(OUT / "formal_summary.csv")
    metrics = ["returned_precision", "returned_micro_recall", "macro_recall", "hit_returned",
               "returned_tp", "returned_fp", "nonexact_returned_tp", "nonexact_returned_recall",
               "wrong_query_rate", "model_candidate_calls"]
    comparison = formal.groupby(["evaluation_group", "policy"])[metrics].mean().reset_index()
    comparison.to_csv(OUT / "policy_comparison_mean_seeds.csv", index=False)
    compact = comparison.loc[comparison.evaluation_group.eq("formal_combined")]
    display = compact[["policy", "returned_precision", "returned_micro_recall", "nonexact_returned_recall", "model_candidate_calls"]].copy()
    for name in ("returned_precision", "returned_micro_recall", "nonexact_returned_recall"):
        display[name] = display[name].map(lambda x: f"{100*x:.3f}%")
    display.model_candidate_calls = display.model_candidate_calls.map(lambda x: f"{x:.0f}")
    conclusion = {
        "selection": "all three seeds select rule_only; no validated semantic fallback improvement",
        "selected_threshold_note": "rule_only never uses a model threshold; stored numeric sentinels are serialization only",
        "validation_design_failure": "zero no-reference query pools and zero additional true semantic returns possible under exact-first Top3",
        "validation_top3_tp_ceiling": 86, "validation_gold_positive_n": 107,
        "validation_positive_query_n": 30, "validation_exact_saturated_query_n": 27,
        "formal_rule_only": {"returned_tp": 405, "returned_fp": 0, "gold_positive_n": 434,
                             "precision": 1.0, "recall": 405/434, "nonexact_recall": 0.0, "model_candidate_calls": 0},
        "old_benchmark_limitation": "known archived test, deliberately enriched for prior exact query matches; not a new blind holdout or representative Alberta evidence",
        "supported_claim": "input-only exact routing reduces modeled candidate counts; fixed stop3 preserves exact-rescue Top3 outputs under frozen scores",
        "unsupported_claims": ["new SOTA", "beats GPT", "general semantic competence", "real latency/currency savings from replay", "99% population precision guarantee"],
        "best_next_method": "selective exact rules plus calibrated semantic fallback with abstention, independent semantic-only and no-reference validation, and an untouched Alberta human-gold test",
    }
    (OUT / "research_findings.json").write_text(json.dumps(conclusion, ensure_ascii=False, indent=2) + "\n")
    report = """Validation-only policy exploration and next research design (2026-10-05)

What was frozen
Eight input-only fallback families were defined before calibration: initial
retrieval rank cap 3/5/10/30, each with normalized-unit equality off/on. Every
family uses exact canonical description AND nonempty normalized-unit equality
first, returns at most three references, and skips semantic scoring after three
exact references. Family scores are replayed from each seed's archived full BGE
scores. Threshold grids come from each seed's validation scores, independently.
The fixed selection criterion requires at least 99% empirical returned precision
and at least 99% empirical semantic-fallback precision when the fallback returns
anything, then maximizes validation returned micro recall and minimizes candidate
calls. Rule-only is included. All thresholds, all grid metrics, and tie criteria
are logged. The selection freeze was written before this run's formal evaluation.

Result and its limit
All three seeds select rule-only. This is a negative result for developing a
semantic fallback on this validation set. There are only30 validation query pools;
all 30 contain exact positives and 27 already have three exact candidates. The
validation gold has 107 positive pairs, but the maximum possible Top3 output
contains 86 positives (80.374% pair recall). Exact rules already return all 86.
There is no returned nonexact validation positive in any candidate family at any
threshold. The validation set also contains zero all-negative pools. Consequently
it cannot identify fallback performance on semantic-only queries or set a useful
no-reference rejection threshold. A point precision threshold does not establish
a 99% population guarantee, especially with clustered and selected query pools.
Rule-only does not use any model threshold; its stored numeric sentinels have
no operational meaning. They do not represent a validated fallback threshold.

Frozen formal result
Formal pools combine locked, external, no_reference, and no_reference_reclassified:
220 queries /6,600 pairs /434 positive pairs. Rule-only returns405 true references
and0 false references:100% observed returned precision,93.318% returned pair recall,
and zero model candidate calls. It returns0/29 nonexact positives and misses both
reclassified semantic-only positive pools. Its broad apparent success is therefore
not evidence that semantic matching is solved. The formal benchmark has already
been analyzed in prior work: this validation-only selection prevents a new choice
from depending on this run's formal scores, but cannot create a fresh blind test.

Formal combined comparison (arithmetic means over three seeds)
""" + display.to_string(index=False) + """

At most3 and all accepted references answer different questions. Exact-rescue
with all accepted pairs has mean recall96.697%, whereas exact-rescue Top3 has
mean recall93.625%. Mean nonexact recall drops from50.575% to4.598% because exact
matches fill most of the three slots. All-BGE Top3 has mean precision97.660% and
recall92.780%; exact-first Top3 has mean precision98.312% and recall93.625%. These
are archived benchmark development results. The three seed results are reported
separately in formal_summary.csv, with each raw split kept separate. No full-pair
classifier F1 is reported for a policy that leaves any candidate unscored.

Operational evidence supported by saved scores
Stop-after-three exact references preserves exact-rescue's returned Top3 set
under the same frozen scores. Formal candidate calls fall from6,195 to3,063
(50.56% fewer than exact-rescue,53.59% fewer than full BGE). This is candidate-pair
workload accounting only. It is not a measured GPU latency, API-request count,
monetary cost, or end-to-end deployment result. The original18 seed/policy runs
were reproduced with their own archived scores with zero routing, classification,
or returned-rank differences; the shared system_policy module also agrees.

Why exact routing looks strong on this benchmark
The original construction code explicitly selects locked and validation queries
with has_prior_exact==1 and Top30 proposed positives. External positive queries
are selected the same way. The retriever adds45 for a semantic-key match and25
for exact description plus unit. It preferentially limits each semantic key to
three candidates before filling. In the current audited pools every exact
candidate has initial rank at most3. The original provisional judgment proposes
an exact-positive/easy label for description/unit equality, while final human
gold is a separate field. These are documented sampling and retrieval choices,
not evidence of illicit label leakage. They explain why standardized repeated
items dominate the observed positives. Exact-positive fractions are80.374%
(validation),91.873%(locked),97.973%(external); exact negatives observed are zero.
The original benchmark remains useful for this repeated-item setting and should
be preserved rather than relabeled to make a new method look stronger.

Exact source references
output/revise3_full_20260920/supplementary/scripts/original/build_vfinal.py:
100-111 prior-exact flag;643-660 no-reference selection;670-699 locked/validation
selection;744-785 external no-reference/positive selection.
output/revise3_full_20260920/supplementary/scripts/original/bidupm_vfinal_common.py:
299-307 exact-positive proposal;450-460 lexical/code/semantic score contributions;
472-479 feature score contributions;490-499 semantic-key multiplicity limit.
The package data README explicitly limits no-reference safety to reviewed Top30
and requires thresholds to be tuned on validation only. This exploration follows
that separation and keeps raw split metrics available.

Best next design
1. Define the intended product before optimizing: up to3 useful price references
per query, with a chosen maximum wrong-reference rate and an abstention path.
Report query success and precision/coverage; report full-pair recall separately.
2. Preserve exact description/unit rules as a transparent cheap branch, but
audit distinct cost-relevant specifications and original raw item descriptions
on independently sourced records. Do not promise that exact strings guarantee
economic price comparability or estimate correctness.
3. Keep the existing BGE as a semantic fallback and score only remaining eligible
candidates. Unit and explicit specification conflicts are prospective candidates
for conservative vetoes, defined from raw fields; assess them on development
gold before making deployment claims. Do not route on gold difficulty.
4. Build independent Alberta human gold from temporally eligible original bid
items with contract/source provenance. Sample natural queries without filtering
for prior exact matches. Label semantic-only positives, true no-reference pools,
near matches, specification/action/unit conflicts, and hard examples as well as
repeated exact items. Use independent reviewers plus adjudication and hide model
outputs during labeling. Do not convert GPT answers into human gold.
5. Split at source group / contract and time before modeling. Use development
data for feature definitions and a separate validation set containing sufficient
semantic-only and all-negative queries. Calibrate each seed's model threshold
against a declared precision-risk/coverage objective; track fallback precision
separately so exact matches cannot conceal its errors. Freeze all feature rules,
retrieval, prompt, checkpoint, threshold, and return cap before opening new test.
6. On an untouched Alberta test compare rule-only, full BGE, frozen rule+BGE,
and a blind GPT comparator on identical candidates/information and output cap.
Also evaluate retrieval against independently reviewed broader candidates; Top30
pair correctness alone cannot establish corpus recall. Use query/source-group
uncertainty estimates, and report failures and abstentions alongside means.
7. Run real model inference only after those choices are frozen. Measure actual
single-query and batched latency, memory, candidate scoring calls, total request
charges, and preprocessing/retrieval on the intended hardware. Existing saved
scores are appropriate for design screening, not runtime or cost claims.

This run supports a transparent inexpensive exact branch and exposes the missing
semantic validation evidence. It does not support a new SOTA claim, general GPT
outperformance, or a validated improvement in semantic reference recall.
"""
    (OUT / "RESEARCH_DESIGN.txt").write_text(report)
    print(json.dumps(conclusion, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
