#!/usr/bin/env python3
"""Frozen-checkpoint input ablation. GPU execution never reads annotations.

The --analyze branch independently checks predictions before joining labels.
All variants use extracted fields and the original five-slot text template.
They do not test unparsed Excel, retrain models, or retune thresholds.
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import json
import os
from pathlib import Path
import time

import numpy as np
import pandas as pd

import system_policy


VARIANTS = ['full_frozen', 'no_normalized_description',
            'raw_description_and_unit', 'raw_description_only']
KEYS = ['evaluation_split', 'query_id']
FORBIDDEN = {'final_label', 'final_relevance', 'difficulty', 'final_conflict_type', 'label'}
BATCH = 64
MAX_LENGTH = 256


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def variant_fields(raw, variant):
    require(variant in VARIANTS, 'Unknown variant')
    frame = raw.copy()
    if variant == 'no_normalized_description':
        for side in ['query', 'candidate']:
            frame[f'{side}_normalized_description'] = ''
    elif variant in ['raw_description_and_unit', 'raw_description_only']:
        for side in ['query', 'candidate']:
            for name in ['normalized_description', 'normalized_unit', 'category', 'spec_tokens']:
                frame[f'{side}_{name}'] = ''
            if variant == 'raw_description_and_unit':
                frame[f'{side}_normalized_unit'] = raw[f'{side}_unit']
    return frame


def read_inputs(args):
    manifest = json.loads((args.source / 'source_manifest.json').read_text())
    provenance = json.loads(args.provenance.read_text())
    require(provenance['status'] == 'passed', 'Raw-field provenance failed')
    require(sha(args.raw) == provenance['raw_inference_sha256'], 'Raw input hash differs')
    require(sha(args.source / 'inputs.csv') == manifest['inputs_sha256'] == provenance['input_sha256'], 'Frozen input hash differs')
    require(provenance['canonical_sha256'] == manifest['input_hashes']['pairs/all_pairs_vfinal_12092.csv'], 'Canonical provenance differs')
    require(provenance['annotation_columns_read'] is False, 'Raw export accessed annotations')
    raw = pd.read_csv(args.raw, dtype=str, keep_default_na=False)
    require(not FORBIDDEN.intersection(raw.columns), 'Inference input contains annotations')
    contract = manifest['inference_input_contract']
    require(raw.columns.tolist() == contract + ['query_unit', 'candidate_unit'], 'Unexpected raw-field schema')
    frozen = pd.read_csv(args.source / 'inputs.csv', dtype=str, keep_default_na=False)
    frozen = frozen[frozen.evaluation_split.ne('validation')].reset_index(drop=True)
    require(raw[contract].equals(frozen), 'Raw export changed frozen fields or row order')
    require(len(raw) == 6600 and raw[KEYS].drop_duplicates().shape[0] == 220, 'Expected 6600 pairs/220 pools')
    require(not raw.pair_id.duplicated().any(), 'Duplicate pair IDs')
    require(raw.groupby(KEYS).size().eq(30).all(), 'Pool sizes must be 30')
    require(not raw.duplicated([*KEYS, 'candidate_id']).any(), 'Duplicate candidate in pool')
    require([int(r['seed']) for r in manifest['runs']] == [20260904, 20260905, 20260906], 'Frozen seeds differ')
    return raw, manifest, provenance


def run_gpu(args):
    # Imports are deliberately lazy: local independent analysis needs no CUDA.
    os.environ.setdefault('HF_HUB_OFFLINE', '1')
    os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
    os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    raw, source, provenance = read_inputs(args)
    require(torch.cuda.is_available(), 'Actual GPU execution requires CUDA')
    require(torch.cuda.is_bf16_supported(), 'BF16 unavailable')
    args.output.mkdir(parents=True, exist_ok=True)
    require(not (args.output / 'execution_manifest.json').exists(), 'Refusing to overwrite an existing run')
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    frames = {name: variant_fields(raw, name) for name in VARIANTS}
    plan = {'status': 'running', 'variants': VARIANTS, 'batch_size': BATCH, 'max_length': MAX_LENGTH,
            'repeats': args.repeats, 'pair_n': 6600, 'query_n': 220,
            'precision': 'CUDA BF16 autocast; TF32 false', 'gpu': torch.cuda.get_device_name(0),
            'torch': torch.__version__, 'script_sha256': sha(__file__),
            'policy_sha256': sha(system_policy.__file__), 'raw_input_sha256': sha(args.raw),
            'source_manifest_sha256': sha(args.source / 'source_manifest.json'),
            'provenance_sha256': sha(args.provenance), 'source_runs': source['runs'],
            'labels_accessed': False, 'training_performed': False, 'thresholds_retuned': False,
            'scope': 'Existing checkpoints, extracted fields, fixed candidate pools; not unparsed Excel.',
            'timing': 'Resident serialization, tokenization, inference and full-model Top3 ranking; excludes variant construction, file I/O, retrieval and model loading.',
            'warmup': 'One forward pass over first 64 formal pairs for each variant; excluded from timing.',
            'serialization': 'Original five-field template with lowercase/whitespace normalization; absent slots remain empty.',
            'completed_runs': []}
    write_json(args.output / 'execution_manifest.json', plan)

    @torch.inference_mode()
    def execute(frame, model, tokenizer, threshold):
        torch.cuda.synchronize()
        start = time.perf_counter()
        queries = system_policy.serialize(frame, 'query')
        candidates = system_policy.serialize(frame, 'candidate')
        scores = np.empty(len(frame), dtype=np.float64)
        for lo in range(0, len(frame), BATCH):
            encoded = tokenizer(queries[lo:lo+BATCH], candidates[lo:lo+BATCH], padding=True,
                                truncation=True, max_length=MAX_LENGTH, return_tensors='pt')
            encoded = {key: value.to('cuda') for key, value in encoded.items()}
            with torch.autocast('cuda', dtype=torch.bfloat16):
                logits = model(**encoded).logits.reshape(-1)
            scores[lo:lo+BATCH] = logits.float().cpu().numpy()
        require(np.isfinite(scores).all(), 'Nonfinite model scores')
        prediction = (scores >= threshold).astype(np.int8)
        rank = system_policy.rank_returned(frame, np.zeros(len(frame), bool), scores, threshold)
        torch.cuda.synchronize()
        return scores, prediction, rank, time.perf_counter() - start

    timing, consistency = [], []
    for run in source['runs']:
        seed, threshold, checkpoint = int(run['seed']), float(run['threshold']), Path(run['checkpoint'])
        for name, expected in run['checkpoint_files'].items():
            require(sha(checkpoint / name) == expected, f'Checkpoint differs: {seed}/{name}')
        print(f'LOAD seed={seed}', flush=True)
        torch.manual_seed(seed)
        tokenizer = AutoTokenizer.from_pretrained(checkpoint, local_files_only=True)
        model = AutoModelForSequenceClassification.from_pretrained(checkpoint, local_files_only=True).to('cuda').eval()
        for variant in VARIANTS:
            execute(frames[variant].head(64), model, tokenizer, threshold)
        saved, pieces = {}, []
        for repeat in range(args.repeats):
            for variant in np.random.default_rng(seed + repeat).permutation(VARIANTS):
                print(f'START seed={seed} variant={variant} repeat={repeat}', flush=True)
                scores, prediction, rank, seconds = execute(frames[variant], model, tokenizer, threshold)
                timing.append({'seed': seed, 'variant': variant, 'repeat': repeat, 'batch_size': BATCH,
                               'pairs': len(raw), 'queries': 220, 'seconds': seconds})
                if repeat == 0:
                    saved[variant] = (scores.copy(), prediction.copy(), rank.copy())
                    out = raw[['pair_id', *KEYS, 'candidate_id']].copy()
                    out['seed'], out['variant'], out['threshold'] = seed, variant, threshold
                    out['score'], out['prediction'], out['returned_rank'] = scores, prediction, rank
                    pieces.append(out)
                else:
                    oldscore, oldpred, oldrank = saved[variant]
                    consistency.append({'seed': seed, 'variant': variant, 'repeat': repeat,
                                        'max_score_difference': float(np.max(np.abs(scores-oldscore))),
                                        'prediction_difference_n': int((prediction != oldpred).sum()),
                                        'rank_difference_n': int((rank != oldrank).sum())})
                print(f'FINISH seconds={seconds:.3f}', flush=True)
                pd.DataFrame(timing).to_csv(args.output / 'timing.csv', index=False)
        path = args.output / f'predictions_seed_{seed}.csv'
        pd.concat(pieces, ignore_index=True).to_csv(path, index=False)
        plan['completed_runs'].append({'seed': seed, 'threshold': threshold, 'prediction_sha256': sha(path)})
        write_json(args.output / 'execution_manifest.json', plan)
        del model, tokenizer
        gc.collect()
        torch.cuda.empty_cache()
    repeat_path = args.output / 'repeat_consistency.csv'
    pd.DataFrame(consistency, columns=['seed', 'variant', 'repeat', 'max_score_difference',
                                     'prediction_difference_n', 'rank_difference_n']).to_csv(repeat_path, index=False)
    require(len(timing) == 3 * len(VARIANTS) * args.repeats, 'Incomplete timing conditions')
    plan.update(status='complete', timing_sha256=sha(args.output/'timing.csv'),
                repeat_consistency_sha256=sha(repeat_path), completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    write_json(args.output / 'execution_manifest.json', plan)
    print('ALL_COMPLETE', flush=True)


def percentage(n, d):
    return 100.0 * n / d if d else np.nan


def metrics(frame):
    y, pred, returned = frame.final_label.eq(1), frame.prediction.eq(1), frame.returned_rank.gt(0)
    tp, fp, fn, tn = int((y & pred).sum()), int((~y & pred).sum()), int((y & ~pred).sum()), int((~y & ~pred).sum())
    query_rows = []
    for key, pool in frame.groupby(KEYS, sort=False):
        good = pool.final_label.eq(1)
        out = pool.returned_rank.gt(0)
        query_rows.append({'evaluation_split': key[0], 'query_id': key[1], 'positive_n': int(good.sum()),
                           'returned_tp': int((good & out).sum()), 'returned_fp': int((~good & out).sum()),
                           'returned_n': int(out.sum())})
    q = pd.DataFrame(query_rows)
    positive = q.positive_n.gt(0)
    no_ref = ~positive
    rtp, rfp = int((y & returned).sum()), int((~y & returned).sum())
    result = {'pair_n': len(frame), 'query_n': len(q), 'positive_n': int(y.sum()), 'tp': tp, 'fp': fp, 'fn': fn, 'tn': tn,
              'pair_precision_pct': percentage(tp, tp+fp), 'pair_recall_pct': percentage(tp, tp+fn),
              'pair_f1_pct': percentage(2*tp, 2*tp+fp+fn), 'pair_accuracy_pct': percentage(tp+tn, len(frame)),
              'returned_tp': rtp, 'returned_fp': rfp, 'returned_precision_pct': percentage(rtp, rtp+rfp),
              'macro_recall_at3_pct': 100*(q.loc[positive, 'returned_tp']/q.loc[positive, 'positive_n']).mean(),
              'hit_at3_pct': percentage(q.loc[positive, 'returned_tp'].gt(0).sum(), positive.sum()),
              'no_reference_pool_rejection_pct': percentage(q.loc[no_ref, 'returned_n'].eq(0).sum(), no_ref.sum())}
    return result, q


def analyze(args):
    raw, source, provenance = read_inputs(args)
    manifest = json.loads((args.output / 'execution_manifest.json').read_text())
    require(manifest['status'] == 'complete' and manifest['labels_accessed'] is False, 'Incomplete or non-blind execution')
    require(manifest['training_performed'] is False and manifest['thresholds_retuned'] is False, 'Training or threshold retuning occurred')
    require(manifest['variants'] == VARIANTS and manifest['source_runs'] == source['runs'], 'Frozen plan differs')
    require(manifest['script_sha256'] == sha(__file__) and manifest['policy_sha256'] == sha(system_policy.__file__), 'Executed code differs')
    require(manifest['raw_input_sha256'] == sha(args.raw), 'Executed input differs')
    require(manifest['source_manifest_sha256'] == sha(args.source/'source_manifest.json') and manifest['provenance_sha256'] == sha(args.provenance), 'Executed provenance differs')
    completed = {int(r['seed']): r for r in manifest['completed_runs']}
    require(set(completed) == {int(r['seed']) for r in source['runs']}, 'Missing checkpoints')
    baseline_manifest = None
    if args.baseline_runtime:
        baseline_manifest = json.loads((args.baseline_runtime/'execution_manifest.json').read_text())
        require(baseline_manifest['status'] == 'complete' and baseline_manifest['source_runs'] == source['runs'], 'Baseline checkpoint provenance differs')
        require(baseline_manifest['input_sha256'] == source['inputs_sha256'], 'Baseline inputs differ')
    pieces, baseline_checks = [], []
    for run in source['runs']:
        seed, threshold = int(run['seed']), float(run['threshold'])
        path = args.output / f'predictions_seed_{seed}.csv'
        require(sha(path) == completed[seed]['prediction_sha256'], 'Prediction hash differs')
        data = pd.read_csv(path, dtype={'pair_id': str, 'query_id': str, 'candidate_id': str}, float_precision='round_trip')
        require(set(data.variant) == set(VARIANTS) and len(data) == len(raw)*4, 'Missing variant rows')
        require(not data.duplicated(['variant', 'pair_id']).any(), 'Duplicate prediction IDs')
        require(data.seed.eq(seed).all() and data.threshold.eq(threshold).all(), 'Seed or threshold differs')
        require(data.prediction.isin([0, 1]).all() and data.returned_rank.isin([0, 1, 2, 3]).all(), 'Invalid prediction/rank')
        require(np.isfinite(data.score).all(), 'Missing scores in full-scoring ablation')
        for variant in VARIANTS:
            condition = data[data.variant.eq(variant)].set_index('pair_id').reindex(raw.pair_id).reset_index()
            require(condition[KEYS+['candidate_id']].equals(raw[KEYS+['candidate_id']]), 'Prediction metadata differs')
            require(np.array_equal(condition.prediction, condition.score.ge(threshold)), 'Acceptance violates original threshold')
            rank = system_policy.rank_returned(raw, np.zeros(len(raw), bool), condition.score.to_numpy(), threshold)
            require(np.array_equal(condition.returned_rank, rank), 'Ranking violates full-model Top3')
            pieces.append(condition)
            if variant == 'full_frozen' and args.baseline_runtime:
                baseline_path = args.baseline_runtime/f'predictions_seed_{seed}.csv'
                baseline_run = next(r for r in baseline_manifest['completed_runs'] if int(r['seed']) == seed)
                require(sha(baseline_path) == baseline_run['prediction_sha256'], 'Actual baseline predictions changed')
                old = pd.read_csv(baseline_path, dtype={'pair_id': str}, float_precision='round_trip')
                old = old[old.policy.eq('all_bge') & old.batch_size.eq(BATCH)].set_index('pair_id').reindex(raw.pair_id)
                require(len(old) == len(raw) and old.score.notna().all(), 'Baseline IDs incomplete')
                delta = np.abs(condition.score.to_numpy()-old.score.to_numpy())
                flips = int((condition.prediction.to_numpy()!=old.prediction.to_numpy()).sum())
                ranks = int((condition.returned_rank.to_numpy()!=old.returned_rank.to_numpy()).sum())
                baseline_checks.append({'seed': seed, 'max_score_difference': float(delta.max()),
                                        'mean_score_difference': float(delta.mean()), 'prediction_difference_n': flips,
                                        'rank_difference_n': ranks})
                require(flips == 0 and ranks == 0, 'Full-frozen control differs in acceptance/returned ranks')
    predictions = pd.concat(pieces, ignore_index=True)
    # Gold is first accessed here, after all input-only ranking/provenance checks.
    label_path = args.source / 'labels.csv'
    require(sha(label_path) == source['labels_sha256'], 'Evaluation labels differ from frozen source')
    labels = pd.read_csv(label_path, dtype={'pair_id': str}, keep_default_na=False)
    require(not labels.pair_id.duplicated().any() and labels.final_label.isin([0, 1]).all(), 'Invalid labels')
    require(labels.difficulty.isin(['easy', 'hard']).all(), 'Invalid difficulty flag')
    predictions = predictions.merge(labels, on='pair_id', how='left', validate='many_to_one')
    require(predictions.final_label.notna().all(), 'Unmatched evaluation labels')
    groups = {'all_formal': lambda x: np.ones(len(x), bool),
              'locked': lambda x: x.evaluation_split.eq('locked'),
              'external': lambda x: x.evaluation_split.eq('external'),
              'no_reference': lambda x: x.evaluation_split.eq('no_reference'),
              'no_reference_reclassified': lambda x: x.evaluation_split.eq('no_reference_reclassified'),
              'internal_combined': lambda x: x.evaluation_split.ne('external'),
              'hard_all_formal': lambda x: x.difficulty.eq('hard'),
              'hard_locked': lambda x: x.evaluation_split.eq('locked') & x.difficulty.eq('hard'),
              'hard_external': lambda x: x.evaluation_split.eq('external') & x.difficulty.eq('hard')}
    summary, query_frames = [], []
    for (seed, variant), frame in predictions.groupby(['seed', 'variant']):
        for group, mask in groups.items():
            subset = frame[mask(frame)]
            if len(subset):
                row, query = metrics(subset)
                if group.startswith('hard_'):
                    # Absence of a hard positive does not imply that the full
                    # pool lacks an easy compatible reference.
                    row['no_reference_pool_rejection_pct'] = np.nan
                row.update(seed=seed, variant=variant, evaluation_group=group)
                summary.append(row)
                query = query.assign(seed=seed, variant=variant, evaluation_group=group)
                query_frames.append(query)
    summary = pd.DataFrame(summary)
    numeric = [c for c in summary if c not in ['seed', 'variant', 'evaluation_group']]
    aggregate = summary.groupby(['evaluation_group', 'variant'])[numeric].agg(['mean', 'std', 'count'])
    aggregate.columns = [f'{metric}_{stat}' for metric, stat in aggregate.columns]
    analysis = args.output / 'analysis'
    analysis.mkdir(exist_ok=True)
    summary.to_csv(analysis/'summary_per_seed.csv', index=False)
    aggregate.reset_index().to_csv(analysis/'summary_aggregate.csv', index=False)
    pd.concat(query_frames, ignore_index=True).to_csv(analysis/'per_query.csv', index=False)
    pd.DataFrame(baseline_checks).to_csv(analysis/'full_frozen_baseline_check.csv', index=False)
    timing_path = args.output / 'timing.csv'
    require(sha(timing_path) == manifest['timing_sha256'], 'Timing hash differs')
    timing = pd.read_csv(timing_path)
    repeats = int(manifest['repeats'])
    require(len(timing) == 12*repeats and not timing.duplicated(['seed','variant','repeat']).any(), 'Missing/duplicate actual timing runs')
    require(timing.groupby(['seed','variant']).size().eq(repeats).all(), 'Unequal repeats')
    require(timing.pairs.eq(6600).all() and timing.queries.eq(220).all() and timing.batch_size.eq(64).all() and timing.seconds.gt(0).all(), 'Timing work differs')
    median = timing.groupby(['seed','variant']).seconds.median().rename('seconds_median').reset_index()
    median.to_csv(analysis/'timing_per_seed.csv', index=False)
    median.groupby('variant').seconds_median.agg(['mean','std','count']).reset_index().to_csv(analysis/'timing_aggregate.csv', index=False)
    repeat_path = args.output/'repeat_consistency.csv'
    require(sha(repeat_path) == manifest['repeat_consistency_sha256'], 'Repeat-consistency export differs')
    consistency = pd.read_csv(repeat_path)
    require(len(consistency) == 12*(repeats-1), 'Missing repeat-consistency rows')
    repeat_decision_differences = int(consistency.prediction_difference_n.sum())
    repeat_rank_differences = int(consistency.rank_difference_n.sum())
    qa = {'status': 'passed' if not (repeat_decision_differences or repeat_rank_differences) else 'passed_with_repeat_warning', 'labels_joined_only_after_prediction_qa': True,
          'raw_input_sha256': sha(args.raw), 'labels_sha256': sha(label_path),
          'actual_measurements': len(timing), 'repeats': repeats,
          'variants': VARIANTS, 'full_frozen_baseline_checked': bool(args.baseline_runtime),
          'full_frozen_checks': baseline_checks, 'no_threshold_retuning': True, 'training_performed': False,
          'repeat_decision_difference_n': repeat_decision_differences,
          'repeat_rank_difference_n': repeat_rank_differences,
          'quality_prediction_repeat': 'First actual measured repetition; any nonzero repeat differences are reported as a warning, not silently discarded.',
          'hard_shortlist_scope': 'Original full-pool Top3 ranks retained, then restricted to hard rows; never reranked or refilled.',
          'hard_no_reference_rejection': 'Not reported: no hard positive is not equivalent to no reference in the full pool.',
          'interpretation': 'Extracted-field input ablation with fixed schema/template/checkpoints/thresholds; not raw Excel without parsing. Some variants remove engineering information as well as normalization. Better test scores cannot select a production pipeline without validation selection and retesting.',
          'undefined_metrics': 'Precision, recall, F1 or Hit are NaN when their denominator is zero; aggregation uses finite seed counts.'}
    write_json(analysis/'qa.json', qa)
    print(json.dumps({'analysis': str(analysis), 'qa': qa['status'], 'rows': len(summary)}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path, help='Frozen source_manifest.json and inputs.csv; labels only accessed with --analyze')
    parser.add_argument('--raw', required=True, type=Path)
    parser.add_argument('--provenance', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--analyze', action='store_true')
    parser.add_argument('--baseline-runtime', type=Path, help='Actual full-BGE batch64 baseline, independent analysis only')
    args = parser.parse_args()
    require(args.repeats in [1, 3], 'Use one or three actual repetitions')
    if args.analyze:
        analyze(args)
    else:
        require(args.baseline_runtime is None, 'GPU runner does not read baseline prediction files')
        run_gpu(args)


if __name__ == '__main__':
    main()
