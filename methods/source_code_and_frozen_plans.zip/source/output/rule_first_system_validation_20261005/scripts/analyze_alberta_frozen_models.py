#!/usr/bin/env python3
"""Independently audit completed Alberta inference; no labels/models/network.

The reports describe threshold acceptances and review recommendations only.
They are not estimates of semantic correctness. Original inputs are read only.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
from itertools import combinations
import json
import math
from pathlib import Path
import re
import sys

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SEEDS = (20260904, 20260905, 20260906)
VARIANTS = ("cleaned", "raw")
THRESHOLDS = {20260904: 9.1875, 20260905: -1.453125, 20260906: 8.4375}
YEAR_N = {2024: 237, 2026: 264}
PAIR_N = 67635
POOL_N = 270
QUERY_N = 135
IDENTITY = ["pair_id", "evaluation_split", "query_id", "source_year", "candidate_id"]
TEXT_FIELDS = ("description", "normalized_description", "normalized_unit", "category", "spec_tokens")
CONTRACT = ["pair_id", "evaluation_split", "query_id", "candidate_id", "initial_rank", "retrieval_score",
            *[f"{side}_{suffix}" for side in ("query", "candidate") for suffix in TEXT_FIELDS]]
FORBIDDEN = {"label", "final_label", "final_relevance", "difficulty", "final_conflict_type",
             "prediction", "score", "model_logit", "gold_label", "is_match"}
FINAL_STAGE = "class_abbreviation_expansion"


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def dump_csv(path, rows):
    frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
    frame.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n")
    return len(frame)


def text(value):
    return "" if value is None else str(value)


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def canonical(value):
    return " ".join(re.sub(r"[^a-z0-9]+", " ", text(value).lower().replace("&", " and ")).split())


def unit(value):
    return " ".join(text(value).strip().lower().split())


def qid(item):
    return f"Q{int(item['item_number_metadata_only']):03d}"


def cid(item):
    return f"{item['year']}_R{int(item['source_row']):03d}"


def jaccard(left, right):
    both = left | right
    return len(left & right) / len(both) if both else 1.0


def table(frame, columns):
    return frame[columns].to_string(index=False)


def analyze(args):
    args.output.mkdir(parents=True, exist_ok=True)
    manifest_path = args.runs / "execution_manifest.json"
    input_manifest_path = args.inputs / "input_manifest.json"
    manifest = load_json(manifest_path)
    input_manifest = load_json(input_manifest_path)
    source = load_json(args.source)
    raw = load_json(args.raw)
    audit = load_json(args.audit)
    remote_qa = load_json(args.runs / "run_qa.json")
    checks, integrity, original_hashes = [], [], {}

    def check(name, condition, details=""):
        require(condition, name)
        checks.append({"check": name, "status": "passed", "details": details})

    def verify_hash(path, expected=None, description=""):
        path = Path(path).resolve()
        value = sha(path)
        if expected is not None:
            check(f"SHA-256 {path.name}", value == expected, description)
        original_hashes[str(path)] = value
        integrity.append({"path": str(path), "actual_sha256": value,
                          "expected_sha256": expected or "", "matches_expected": expected is None or value == expected,
                          "role": description, "read_only": True})
        return value

    verify_hash(manifest_path, description="completed GPU execution manifest")
    verify_hash(input_manifest_path, manifest["input_manifest_sha256"], "Alberta input creation manifest")
    verify_hash(args.source, manifest["source_manifest_sha256"], "original frozen source manifest")
    check("frozen source manifest linked to input creation", sha(args.source) == input_manifest["frozen_manifest_sha256"])
    verify_hash(args.raw, manifest["raw_items_sha256"], "audited original item values and catalogue price context")
    check("raw items linked to input creation", sha(args.raw) == input_manifest["raw_items_sha256"])
    verify_hash(args.audit, input_manifest["audit_summary_sha256"], "raw import rule coverage and source provenance")
    verify_hash(ROOT / "scripts/run_alberta_frozen_models.py", manifest["script_sha256"], "unaltered inference runner")
    verify_hash(ROOT / "scripts/system_policy.py", manifest["policy_sha256"], "unaltered frozen serializer/policy module")
    check("policy linked to input creation", manifest["policy_sha256"] == input_manifest["serializer_policy_sha256"])
    verify_hash(ROOT / "scripts/build_raw_alberta_model_inputs.py", input_manifest["builder_sha256"], "unaltered Alberta input builder")
    for name in ("input_schema", "input_qa"):
        verify_hash(args.inputs / f"{name}.json", input_manifest[f"{name}_sha256"], "input schema/QA")
    for name, key in (("timing.csv", "timing_sha256"),
                      ("query_recommendation_summary.csv", "query_recommendation_summary_sha256"),
                      ("run_qa.json", "run_qa_sha256")):
        verify_hash(args.runs / name, manifest[key], "completed inference artifact")
    for workbook in input_manifest["source_workbooks"]:
        verify_hash(workbook["path"], workbook["audit_sha256"], "original source workbook bytes; no workbook parsing or writing")
    check("completed status and exact six conditions", manifest["status"] == "complete" and
          len(manifest["completed_conditions"]) == 6 and
          {(int(c["seed"]), c["variant"]) for c in manifest["completed_conditions"]} ==
          {(s, v) for s in SEEDS for v in VARIANTS})
    check("frozen run plans exactly preserved", manifest["source_runs"] == source["runs"])
    check("frozen seeds and thresholds exactly preserved", tuple(manifest["seed_list"]) == SEEDS and
          {int(r["seed"]): float(r["threshold"]) for r in source["runs"]} == THRESHOLDS)
    check("frozen serialization input contract", source["inference_input_contract"] == CONTRACT ==
          input_manifest["inference_input_contract"])
    for key in ("labels_accessed", "labels_available", "benchmark_rows_read", "training_performed", "thresholds_retuned"):
        check(f"execution flag {key} is false", manifest[key] is False)
    for key in ("labels_accessed", "labels_available", "gold_metrics_computed", "training_performed", "thresholds_retuned"):
        check(f"remote QA flag {key} is false", remote_qa[key] is False)
    check("input creation labels/models/item-code matching absent", input_manifest["labels_accessed"] is False and
          input_manifest["models_run"] is False and input_manifest["item_codes_used_for_matching"] is False)
    check("raw import has no gold labels", audit["gold_labels_available"] is False)
    check("full pool run counts", manifest["pairs_per_condition"] == PAIR_N and
          manifest["year_query_pools_per_condition"] == POOL_N and manifest["unique_bid_items"] == QUERY_N and
          {int(k): int(v) for k, v in manifest["source_count_by_year"].items()} == YEAR_N)
    check("three remotely verified frozen checkpoint loads", len(manifest["model_loads"]) == 3 and
          {int(r["seed"]) for r in manifest["model_loads"]} == set(SEEDS) and
          all(r["checkpoint_hashes_verified"] is True for r in manifest["model_loads"]))

    queries = {qid(q): q for q in raw["queries"]}
    candidates = {cid(c): c for y in YEAR_N for c in raw["sources"][str(y)]}
    check("annotation-compatible query/catalogue ID uniqueness", len(queries) == 135 and len(candidates) == 501,
          "Qnnn = original item number; yyyy_Rrrr = original worksheet row; same formulas as blank annotation exports")
    annotation_manifest_path = ROOT / "annotation/qa/annotation_manifest.json"
    annotation_qa_path = ROOT / "annotation/qa/annotation_export_validation.json"
    annotation_manifest = load_json(annotation_manifest_path)
    annotation_qa = load_json(annotation_qa_path)
    verify_hash(annotation_manifest_path, description="blank annotation export ID contract and provenance; not annotations")
    verify_hash(annotation_qa_path, description="existing blank annotation export QA record; not annotations")
    check("annotation ID contract linked to identical raw sources", annotation_manifest["inputRawItemsSha256"] == sha(args.raw) and
          annotation_manifest["queryIdSchema"] == "Q### from original Item No." and
          annotation_manifest["sourceIdSchema"] == "YYYY_R### from original UPA sheet row" and
          annotation_manifest["queryRowsPerWorkbook"] == 135 and annotation_manifest["catalogueRowsPerWorkbook"] == 501)
    check("blank annotation export QA verifies source values and keys", annotation_qa["passed"] is True and
          annotation_qa["human_confirmed_labels_exist"] is False and
          all(w["stable_ids_unique"] is True and w["raw_values_equal_source_import"] is True and
              w["all_675_annotation_cells_blank"] is True for w in annotation_qa["workbooks"]))
    for export in annotation_manifest["exports"]:
        # Hash-only check of previously validated blank workbook; never read cell values.
        verify_hash(export["path"], export["sha256"], "blank annotation workbook bytes: stable ID/source export remains identical")
    inputs, variant_exact = {}, {}
    input_entries = {e["variant"]: e for e in input_manifest["outputs"]}
    execution_inputs = {e["variant"]: e for e in manifest["input_csvs"]}
    for variant in VARIANTS:
        path = args.inputs / f"inference_pairs_{variant}.csv"
        verify_hash(path, input_entries[variant]["sha256"], "full-pair inference input")
        check(f"execution input hash {variant}", execution_inputs[variant]["sha256"] == sha(path))
        frame = pd.read_csv(path, dtype=str, keep_default_na=False)
        check(f"input schema and annotation absence {variant}", list(frame.columns) == input_manifest["columns"] and
              list(frame.columns[:len(CONTRACT)]) == CONTRACT and not FORBIDDEN.intersection(frame.columns))
        check(f"input row identity uniqueness {variant}", len(frame) == PAIR_N and
              not frame.pair_id.duplicated().any() and not frame.duplicated(["source_year", "query_id", "candidate_id"]).any())
        check(f"input query and candidate pools {variant}", set(frame.query_id) == set(queries) and
              frame[["source_year", "query_id"]].drop_duplicates().shape[0] == POOL_N)
        check(f"exhaustive input metadata {variant}", frame.input_variant.eq(variant).all() and
              frame.initial_rank.eq("").all() and frame.retrieval_score.eq("").all())
        for side in ("query", "candidate"):
            check(f"unknown feature slots empty {variant}/{side}", frame[f"{side}_category"].eq("").all() and
                  frame[f"{side}_spec_tokens"].eq("").all())
        stage = FINAL_STAGE if variant == "cleaned" else "case_space_punctuation"
        for side, idfield, items in (("query", "query_id", queries), ("candidate", "candidate_id", candidates)):
            unique = frame.drop_duplicates(idfield).set_index(idfield)
            for name, field in (("description", "description"), ("unit", "unit"),
                                ("source_file", "source_file"), ("source_sheet", "source_sheet"),
                                ("source_row", "source_row"), ("description_cell", "description_cell"), ("unit_cell", "unit_cell")):
                expected = unique.index.map(lambda i: text(items[i][field]))
                check(f"original {side} {name} preserved {variant}", np.array_equal(unique[f"{side}_{name}"].to_numpy(), expected))
            expected_d = unique.index.map(lambda i: items[i]["stage_keys"][stage]["description"])
            expected_u = unique.index.map(lambda i: items[i]["stage_keys"][stage]["unit"] if variant == "cleaned" else text(items[i]["unit"]))
            check(f"normalized {side} input features match audit {variant}",
                  np.array_equal(unique[f"{side}_normalized_description"].to_numpy(), expected_d) and
                  np.array_equal(unique[f"{side}_normalized_unit"].to_numpy(), expected_u))
            side_fields = [c for c in frame if c.startswith(side + "_")]
            check(f"same ID has consistent {side} fields {variant}", frame.groupby(idfield)[side_fields].nunique().le(1).all().all())
        for year, count in YEAR_N.items():
            yearly = frame.loc[frame.source_year.eq(str(year))]
            check(f"complete pools {variant}/{year}", len(yearly) == count * QUERY_N and
                  yearly.groupby("query_id").size().eq(count).all() and
                  set(yearly.candidate_id) == {i for i in candidates if i.startswith(str(year) + "_")} and
                  yearly.evaluation_split.eq(f"raw_alberta_{year}").all())
        expected_pid = "Alberta" + frame.source_year + "-" + frame.query_id + "-" + frame.candidate_id.str.split("_").str[-1]
        check(f"stable pair ID formula {variant}", frame.pair_id.eq(expected_pid).all())
        check(f"item number/candidate ID metadata {variant}", frame.query_item_number.eq(frame.query_id.str[1:].astype(int).astype(str)).all() and
              frame.candidate_source_id.eq(frame.candidate_id).all())
        qd = frame.query_normalized_description.map(canonical)
        cd = frame.candidate_normalized_description.map(canonical)
        qu, cu = frame.query_normalized_unit.map(unit), frame.candidate_normalized_unit.map(unit)
        variant_exact[variant] = (qd.ne("") & qu.ne("") & qd.eq(cd) & qu.eq(cu)).to_numpy()
        inputs[variant] = frame
    check("variants preserve exact pair identity/order", inputs["cleaned"][IDENTITY].equals(inputs["raw"][IDENTITY]))
    check("variants preserve all original descriptions and units", inputs["cleaned"][["query_description", "query_unit", "candidate_description", "candidate_unit"]].equals(
          inputs["raw"][["query_description", "query_unit", "candidate_description", "candidate_unit"]]))

    clean = inputs["cleaned"]
    pool_indices = clean.groupby(["source_year", "query_id"], sort=False).indices
    fixed_exact = {key: set(clean.iloc[idx[variant_exact["cleaned"][idx]]].candidate_id) for key, idx in pool_indices.items()}
    audit_rows_path = args.audit.parent / "per_query_matches.json"
    verify_hash(audit_rows_path, description="read-only final rule-stage candidate records")
    audit_rows = [r for r in load_json(audit_rows_path) if r["stage"] == FINAL_STAGE]
    audit_exact = {(str(r["year"]), f"Q{int(r['query_item_number_metadata_only']):03d}"):
                   {f"{r['year']}_R{int(c['source_row']):03d}" for c in r["candidates"]} for r in audit_rows}
    check("independent frozen exact candidates replicate raw import", fixed_exact == audit_exact)
    for year in YEAR_N:
        check(f"fixed rule coverage {year}: 45/135, uncovered 90", sum(bool(v) for k, v in fixed_exact.items() if int(k[0]) == year) == 45)

    summary = pd.read_csv(args.runs / "query_recommendation_summary.csv", keep_default_na=False, float_precision="round_trip")
    check("query summary unique complete condition/pools", len(summary) == 1620 and
          not summary.duplicated(["seed", "variant", "source_year", "query_id"]).any())
    timing = pd.read_csv(args.runs / "timing.csv", keep_default_na=False, float_precision="round_trip")
    check("one actual full timing observation per condition", len(timing) == 6 and
          not timing.duplicated(["seed", "variant"]).any() and timing.repeat.eq(0).all() and
          set(zip(timing.seed.astype(int), timing.variant)) == {(s, v) for s in SEEDS for v in VARIANTS} and
          timing.pairs.eq(PAIR_N).all() and timing.year_query_pools.eq(POOL_N).all() and
          timing.unique_bid_items.eq(QUERY_N).all() and timing.batch_size.eq(64).all() and timing.model_batches.eq(math.ceil(PAIR_N / 64)).all() and
          np.isfinite(timing.seconds).all() and timing.seconds.gt(0).all())

    prediction_frames, per_query, long_rows, condition_summary, score_diagnostics = {}, [], [], [], []
    structures = {}
    completed = {(int(c["seed"]), c["variant"]): c for c in manifest["completed_conditions"]}
    for variant in VARIANTS:
        frame = inputs[variant]
        for seed in SEEDS:
            condition = completed[(seed, variant)]
            path = args.runs / condition["prediction_file"]
            verify_hash(path, condition["prediction_sha256"], "full-pair model prediction bytes")
            pred = pd.read_csv(path, dtype={c: str for c in IDENTITY}, keep_default_na=False, float_precision="round_trip")
            check(f"prediction-input row bijection {variant}/{seed}", len(pred) == PAIR_N and
                  not pred.pair_id.duplicated().any() and pred[IDENTITY].equals(frame[IDENTITY]))
            check(f"prediction frozen condition metadata {variant}/{seed}", pred.seed.eq(seed).all() and
                  pred.variant.eq(variant).all() and pred.threshold.eq(THRESHOLDS[seed]).all() and
                  float(condition["threshold"]) == THRESHOLDS[seed])
            scores = pred.score.to_numpy(float)
            accepted = scores >= THRESHOLDS[seed]
            check(f"finite scores and exact threshold decisions {variant}/{seed}", np.isfinite(scores).all() and
                  np.array_equal(pred.prediction.to_numpy(), accepted.astype(int)))
            ranks = np.zeros(PAIR_N, dtype=int)
            for (year, query_id), idx in pool_indices.items():
                # Independent implementation; do not call system_policy.rank_returned.
                pool = pred.iloc[idx]
                chosen = pool.loc[pool.prediction.eq(1)].sort_values(["score", "candidate_id"], ascending=[False, True], kind="stable").head(3)
                ranks[chosen.index] = np.arange(1, len(chosen) + 1)
            check(f"independent descending-logit/ID Top-3 reconstruction {variant}/{seed}",
                  np.array_equal(ranks, pred.returned_rank.to_numpy()) and pred.returned_rank.isin([0, 1, 2, 3]).all())
            observed_time = timing.loc[timing.seed.eq(seed) & timing.variant.eq(variant)].iloc[0]
            check(f"timing linked to completed condition {variant}/{seed}", float(observed_time.seconds) == float(condition["seconds"]) and
                  float(observed_time.threshold) == THRESHOLDS[seed])
            load = next(r for r in manifest["model_loads"] if int(r["seed"]) == seed)
            check(f"separate model loading time {variant}/{seed}", float(observed_time.model_load_seconds) == float(load["seconds"]))
            rows = []
            for (year, query_id), idx in pool_indices.items():
                pool = pred.iloc[idx]
                selected = pool.loc[pool.returned_rank.gt(0)].sort_values("returned_rank")
                accepted_ids = set(pool.loc[pool.prediction.eq(1)].candidate_id)
                ids = selected.candidate_id.tolist()
                exact_ids = fixed_exact[(year, query_id)]
                item = queries[query_id]
                features = frame.iloc[idx[0]]
                n = len(accepted_ids)
                rec = {"seed": seed, "variant": variant, "source_year": int(year), "query_id": query_id,
                       "query_item_number": item["item_number_metadata_only"], "query_original_audit_id": item["query_id"],
                       "query_source_file": item["source_file"], "query_source_sheet": item["source_sheet"],
                       "query_source_row": item["source_row"], "query_description_cell": item["description_cell"],
                       "query_unit_cell": item["unit_cell"], "query_raw_description": item["description"],
                       "query_raw_unit": text(item["unit"]), "query_original_quantity": item["quantity"],
                       "query_normalized_description_input": features.query_normalized_description,
                       "query_normalized_unit_input": features.query_normalized_unit,
                       "query_unit_missing": not bool(unit(item["unit"])),
                       "query_removed_reference_spans_json": compact(item["removed_reference_spans"]),
                       "query_reference_context_json": features.query_reference_context_json,
                       "candidate_pool_size": len(pool), "frozen_threshold": THRESHOLDS[seed],
                       "maximum_logit": float(pool.score.max()), "maximum_logit_minus_threshold": float(pool.score.max()) - THRESHOLDS[seed],
                       "above_threshold_candidates": n, "returned_recommendations": len(ids),
                       "returned_candidate_ids_json": compact(ids), "fixed_cleaned_rule_candidate_count": len(exact_ids),
                       "fixed_cleaned_rule_candidate_ids_json": compact(sorted(exact_ids)),
                       "fixed_cleaned_rule_query_covered": bool(exact_ids),
                       "this_variant_rule_candidate_count": int(variant_exact[variant][idx].sum()),
                       "model_above_threshold_fixed_rule_candidates": len(exact_ids & accepted_ids),
                       "model_returned_fixed_rule_candidates": len(exact_ids & set(ids)),
                       "catalogue_price_context": "Original province average of 3 low bids; historical catalogue value, not model price estimate"}
                expected_summary = summary.loc[summary.seed.eq(seed) & summary.variant.eq(variant) &
                                               summary.source_year.eq(int(year)) & summary.query_id.eq(query_id)]
                require(len(expected_summary) == 1, "Missing unique summary row")
                expected_summary = expected_summary.iloc[0]
                require(int(expected_summary.candidate_count) == len(pool) and int(expected_summary.above_threshold_candidates) == n and
                        int(expected_summary.returned_recommendations) == len(ids) and
                        float(expected_summary.maximum_logit) == float(pool.score.max()) and
                        float(expected_summary.threshold) == THRESHOLDS[seed] and
                        expected_summary.evaluation_split == f"raw_alberta_{year}", "Per-query inference summary not replicated")
                for rank in range(1, 4):
                    prefix = f"recommendation_{rank}_"
                    fields = {"candidate_id": "", "model_logit": "", "raw_description": "", "raw_unit": "",
                              "original_catalogue_code_metadata_only": "", "source_file": "", "source_sheet": "",
                              "source_row": "", "description_cell": "", "unit_cell": "",
                              "original_province_average_3_low_bids": "", "original_province_contracts": "",
                              "original_province_amount": "", "original_province_quantity": "", "fixed_cleaned_exact_candidate": ""}
                    if rank <= len(selected):
                        chosen = selected.iloc[rank - 1]
                        candidate = candidates[chosen.candidate_id]
                        fields = {"candidate_id": chosen.candidate_id, "model_logit": float(chosen.score),
                                  "raw_description": candidate["description"], "raw_unit": text(candidate["unit"]),
                                  "original_catalogue_code_metadata_only": candidate["code_metadata_only"],
                                  "source_file": candidate["source_file"], "source_sheet": candidate["source_sheet"],
                                  "source_row": candidate["source_row"], "description_cell": candidate["description_cell"],
                                  "unit_cell": candidate["unit_cell"],
                                  "original_province_average_3_low_bids": candidate["province_average_3_low_bids"],
                                  "original_province_contracts": candidate["province_contracts"],
                                  "original_province_amount": candidate["province_amount"],
                                  "original_province_quantity": candidate["province_quantity"],
                                  "fixed_cleaned_exact_candidate": chosen.candidate_id in exact_ids}
                        long_rows.append({**{k: rec[k] for k in ("seed", "variant", "source_year", "query_id", "query_raw_description",
                                         "query_raw_unit", "query_source_row", "query_description_cell", "query_unit_cell", "frozen_threshold")},
                                          "returned_rank": rank, **fields})
                    rec.update({prefix + k: v for k, v in fields.items()})
                rows.append(rec)
                structures[(variant, seed, year, query_id)] = {"returned": tuple(ids), "accepted": accepted_ids, "count": n}
            check(f"all 270 inference query summaries independently replicated {variant}/{seed}", len(rows) == POOL_N)
            per_query.extend(rows)
            dump_csv(args.output / f"model_recommendations_{variant}_seed_{seed}.csv", rows)
            for year in YEAR_N:
                subset = [r for r in rows if r["source_year"] == year]
                covered = [r for r in subset if r["fixed_cleaned_rule_query_covered"]]
                uncovered = [r for r in subset if not r["fixed_cleaned_rule_query_covered"]]
                yearly_scores = pred.loc[pred.source_year.eq(str(year)), "score"].to_numpy(float)
                yearly_returned = pred.loc[pred.source_year.eq(str(year)) & pred.returned_rank.gt(0)]
                score_diagnostics.append({"seed": seed, "variant": variant, "source_year": year,
                    "frozen_threshold": THRESHOLDS[seed], "scored_pairs": len(yearly_scores),
                    "minimum_logit": float(np.min(yearly_scores)), "median_logit": float(np.median(yearly_scores)),
                    "maximum_logit": float(np.max(yearly_scores)), "mean_logit": float(np.mean(yearly_scores)),
                    "pairs_exactly_equal_threshold": int(np.sum(yearly_scores == THRESHOLDS[seed])),
                    "pairs_exactly_equal_threshold_accepted": int(np.sum(yearly_scores == THRESHOLDS[seed])),
                    "maximum_above_threshold_candidates_in_a_query": max(r["above_threshold_candidates"] for r in subset),
                    "query_pools_with_more_than_three_above_threshold_candidates": sum(r["above_threshold_candidates"] > 3 for r in subset),
                    "query_pools_with_tied_returned_logits": sum(g.score.duplicated().any() for _, g in yearly_returned.groupby("query_id")),
                    "interpretation": "Within-checkpoint score/threshold diagnostics only; logit scales differ across checkpoints"})
                condition_summary.append({"seed": seed, "variant": variant, "source_year": year,
                    "frozen_threshold": THRESHOLDS[seed], "queries": len(subset), "candidate_pairs_scored": YEAR_N[year] * QUERY_N,
                    "queries_with_model_recommendations": sum(r["returned_recommendations"] > 0 for r in subset),
                    "queries_without_model_recommendations": sum(r["returned_recommendations"] == 0 for r in subset),
                    "above_threshold_candidates": sum(r["above_threshold_candidates"] for r in subset),
                    "returned_recommendations": sum(r["returned_recommendations"] for r in subset),
                    "fixed_rule_covered_queries": 45, "fixed_rule_uncovered_queries": 90,
                    "rule_covered_model_nonempty_queries": sum(r["returned_recommendations"] > 0 for r in covered),
                    "rule_covered_model_empty_queries": sum(r["returned_recommendations"] == 0 for r in covered),
                    "rule_covered_queries_with_exact_candidate_above_threshold": sum(r["model_above_threshold_fixed_rule_candidates"] > 0 for r in covered),
                    "rule_covered_queries_with_exact_candidate_returned": sum(r["model_returned_fixed_rule_candidates"] > 0 for r in covered),
                    "fixed_rule_candidates_above_threshold": sum(r["model_above_threshold_fixed_rule_candidates"] for r in covered),
                    "fixed_rule_candidates_returned": sum(r["model_returned_fixed_rule_candidates"] for r in covered),
                    "rule_uncovered_model_nonempty_queries": sum(r["returned_recommendations"] > 0 for r in uncovered),
                    "rule_uncovered_model_empty_queries": sum(r["returned_recommendations"] == 0 for r in uncovered),
                    "rule_or_model_nonempty_union_queries": 45 + sum(r["returned_recommendations"] > 0 for r in uncovered),
                    **{f"queries_returning_{n}": sum(r["returned_recommendations"] == n for r in subset) for n in range(4)}})
            prediction_frames[(variant, seed)] = pred

    stats = pd.DataFrame(condition_summary)
    query_frame = pd.DataFrame(per_query)
    dump_csv(args.output / "output_summary_by_seed_variant_year.csv", stats)
    dump_csv(args.output / "per_query_output_diagnostics.csv", query_frame)
    dump_csv(args.output / "returned_recommendations_all.csv", long_rows)
    dump_csv(args.output / "score_and_boundary_diagnostics.csv", score_diagnostics)
    aggregates = []
    metrics = [c for c in stats if c not in ("seed", "variant", "source_year", "frozen_threshold")]
    for (variant, year), group in stats.groupby(["variant", "source_year"], sort=False):
        for metric in metrics:
            aggregates.append({"variant": variant, "source_year": int(year), "metric": metric, "frozen_models": 3,
                               "mean_across_three_frozen_models": float(group[metric].mean()),
                               "minimum_across_three_frozen_models": int(group[metric].min()),
                               "maximum_across_three_frozen_models": int(group[metric].max()),
                               "interpretation": "Descriptive variation across models; no confidence interval or quality estimate"})
    dump_csv(args.output / "output_descriptive_three_model_summary.csv", aggregates)

    agreement_rows, pairwise_rows = [], []
    for variant in VARIANTS:
        for (year, query_id), _ in pool_indices.items():
            structures_pool = [structures[(variant, s, year, query_id)] for s in SEEDS]
            returned = [p["returned"] for p in structures_pool]
            accepted = [p["accepted"] for p in structures_pool]
            sets = [set(p) for p in returned]
            nonempty = [bool(p) for p in returned]
            rec = {"variant": variant, "source_year": int(year), "query_id": query_id,
                   "fixed_rule_covered": bool(fixed_exact[(year, query_id)]),
                   "query_raw_description": queries[query_id]["description"], "query_raw_unit": text(queries[query_id]["unit"]),
                   "models_with_recommendations": sum(nonempty), "all_models_empty": not any(nonempty),
                   "all_models_nonempty": all(nonempty), "mixed_nonempty_status": len(set(nonempty)) > 1,
                   "ordered_lists_all_identical": len(set(returned)) == 1,
                   "returned_candidate_sets_all_identical": sets[0] == sets[1] == sets[2],
                   "above_threshold_candidate_sets_all_identical": accepted[0] == accepted[1] == accepted[2],
                   "top1_same_all_three_nonempty": all(nonempty) and len({p[0] for p in returned}) == 1,
                   "returned_intersection_all_three_count": len(set.intersection(*sets)),
                   "returned_union_three_count": len(set.union(*sets)),
                   "above_threshold_intersection_all_three_count": len(set.intersection(*accepted)),
                   "above_threshold_union_three_count": len(set.union(*accepted)),
                   "minimum_accepted_candidates": min(len(p) for p in accepted),
                   "maximum_accepted_candidates": max(len(p) for p in accepted),
                   "mean_pairwise_returned_set_jaccard": float(np.mean([jaccard(sets[i], sets[j]) for i, j in combinations(range(3), 2)])),
                   "mean_pairwise_above_threshold_set_jaccard": float(np.mean([jaccard(accepted[i], accepted[j]) for i, j in combinations(range(3), 2)]))}
            for seed, st in zip(SEEDS, structures_pool):
                rec[f"seed_{seed}_returned_ids_json"] = compact(st["returned"])
                rec[f"seed_{seed}_above_threshold_count"] = st["count"]
            agreement_rows.append(rec)
            for i, j in combinations(range(3), 2):
                pairwise_rows.append({"variant": variant, "source_year": int(year), "query_id": query_id,
                                      "seed_a": SEEDS[i], "seed_b": SEEDS[j], "ordered_list_equal": returned[i] == returned[j],
                                      "nonempty_status_equal": nonempty[i] == nonempty[j],
                                      "returned_set_jaccard": jaccard(sets[i], sets[j]),
                                      "above_threshold_set_jaccard": jaccard(accepted[i], accepted[j]),
                                      "returned_set_intersection": len(sets[i] & sets[j]), "returned_set_union": len(sets[i] | sets[j]),
                                      "above_threshold_pair_intersection": len(accepted[i] & accepted[j]),
                                      "above_threshold_pair_union": len(accepted[i] | accepted[j])})
    agreement = pd.DataFrame(agreement_rows)
    agreement_summary = []
    for (variant, year), group in agreement.groupby(["variant", "source_year"], sort=False):
        nonempty_group = group.loc[~group.all_models_empty]
        agreement_summary.append({"variant": variant, "source_year": int(year), "query_pools": len(group),
            "all_models_empty_queries": int(group.all_models_empty.sum()),
            "all_models_nonempty_queries": int(group.all_models_nonempty.sum()),
            "mixed_nonempty_status_queries": int(group.mixed_nonempty_status.sum()),
            "ordered_lists_identical_queries": int(group.ordered_lists_all_identical.sum()),
            "ordered_lists_identical_among_any_model_nonempty": int(nonempty_group.ordered_lists_all_identical.sum()),
            "any_model_nonempty_queries": len(nonempty_group),
            "returned_sets_identical_queries": int(group.returned_candidate_sets_all_identical.sum()),
            "above_threshold_sets_identical_queries": int(group.above_threshold_candidate_sets_all_identical.sum()),
            "top1_same_all_three_nonempty_queries": int(group.top1_same_all_three_nonempty.sum()),
            "mean_pairwise_returned_set_jaccard_all_queries": float(group.mean_pairwise_returned_set_jaccard.mean()),
            "mean_pairwise_returned_set_jaccard_any_model_nonempty": float(nonempty_group.mean_pairwise_returned_set_jaccard.mean()) if len(nonempty_group) else None,
            "mean_pairwise_above_threshold_set_jaccard_all_queries": float(group.mean_pairwise_above_threshold_set_jaccard.mean()),
            "rule_uncovered_any_model_nonempty_queries": int((~group.fixed_rule_covered & ~group.all_models_empty).sum()),
            "rule_uncovered_all_models_empty_queries": int((~group.fixed_rule_covered & group.all_models_empty).sum())})
    agreement_stats = pd.DataFrame(agreement_summary)
    dump_csv(args.output / "three_seed_agreement_per_query.csv", agreement)
    dump_csv(args.output / "three_seed_agreement_summary.csv", agreement_stats)
    dump_csv(args.output / "three_seed_pairwise_per_query.csv", pairwise_rows)

    variant_rows = []
    for seed in SEEDS:
        for (year, query_id), _ in pool_indices.items():
            cleaned = structures[("cleaned", seed, year, query_id)]
            raw_st = structures[("raw", seed, year, query_id)]
            variant_rows.append({"seed": seed, "source_year": int(year), "query_id": query_id,
                                 "fixed_rule_covered": bool(fixed_exact[(year, query_id)]),
                                 "raw_nonempty": bool(raw_st["returned"]), "cleaned_nonempty": bool(cleaned["returned"]),
                                 "cleaned_gains_nonempty_output": bool(cleaned["returned"]) and not bool(raw_st["returned"]),
                                 "cleaned_loses_nonempty_output": bool(raw_st["returned"]) and not bool(cleaned["returned"]),
                                 "ordered_lists_identical": raw_st["returned"] == cleaned["returned"],
                                 "returned_set_jaccard": jaccard(set(raw_st["returned"]), set(cleaned["returned"])),
                                 "above_threshold_set_jaccard": jaccard(raw_st["accepted"], cleaned["accepted"]),
                                 "raw_above_threshold_count": raw_st["count"], "cleaned_above_threshold_count": cleaned["count"],
                                 "raw_returned_ids_json": compact(raw_st["returned"]),
                                 "cleaned_returned_ids_json": compact(cleaned["returned"])})
    variation = pd.DataFrame(variant_rows)
    variation_summary = []
    for (seed, year), group in variation.groupby(["seed", "source_year"], sort=False):
        variation_summary.append({"seed": int(seed), "source_year": int(year), "query_pools": len(group),
                                  "raw_nonempty_queries": int(group.raw_nonempty.sum()),
                                  "cleaned_nonempty_queries": int(group.cleaned_nonempty.sum()),
                                  "cleaned_gains_nonempty_queries": int(group.cleaned_gains_nonempty_output.sum()),
                                  "cleaned_loses_nonempty_queries": int(group.cleaned_loses_nonempty_output.sum()),
                                  "ordered_lists_identical_queries": int(group.ordered_lists_identical.sum()),
                                  "mean_returned_set_jaccard": float(group.returned_set_jaccard.mean()),
                                  "mean_above_threshold_set_jaccard": float(group.above_threshold_set_jaccard.mean())})
    dump_csv(args.output / "raw_cleaned_variability_per_query.csv", variation)
    dump_csv(args.output / "raw_cleaned_variability_summary.csv", variation_summary)

    timing_rows = []
    for variant, group in timing.groupby("variant", sort=False):
        timing_rows.append({"variant": variant, "actual_observations": len(group), "passes_per_model_condition": 1,
                            "distinct_frozen_models": 3, "pairs_per_full_pass": PAIR_N,
                            "mean_full_pass_seconds": float(group.seconds.mean()),
                            "minimum_full_pass_seconds": float(group.seconds.min()),
                            "maximum_full_pass_seconds": float(group.seconds.max()),
                            "interpretation": "Descriptive mean across three model-specific single passes, not repeated-run uncertainty",
                            "includes": "serialization; tokenization; synchronized GPU inference; threshold decisions; Top-3 ranking",
                            "excludes": "warmup; model loading; file I/O; integrity checks",
                            "confidence_intervals_computed": False, "monetary_cost_computed": False})
    dump_csv(args.output / "actual_full_pass_timing.csv", timing)
    dump_csv(args.output / "timing_descriptive_three_model_summary.csv", timing_rows)
    dump_csv(args.output / "actual_model_loading_timing.csv", manifest["model_loads"])

    example_tags = {}
    def add_example(key, tag):
        example_tags.setdefault(key, []).append(tag)
    for year in YEAR_N:
        for query_id, q in queries.items():
            if not unit(q["unit"]):
                add_example((year, query_id), "missing_query_unit")
        for row in agreement.loc[agreement.source_year.eq(year) & agreement.variant.eq("cleaned") &
                                 ~agreement.fixed_rule_covered & ~agreement.all_models_empty].head(4).to_dict("records"):
            add_example((year, row["query_id"]), "fixed_rule_uncovered_with_model_output")
        for row in agreement.loc[agreement.source_year.eq(year) & agreement.variant.eq("cleaned") &
                                 agreement.fixed_rule_covered & ~agreement.all_models_nonempty].head(2).to_dict("records"):
            add_example((year, row["query_id"]), "fixed_rule_covered_but_at_least_one_model_empty")
        for row in agreement.loc[agreement.source_year.eq(year) & agreement.variant.eq("cleaned") &
                                 ~agreement.ordered_lists_all_identical & ~agreement.all_models_empty].head(3).to_dict("records"):
            add_example((year, row["query_id"]), "three_seed_recommendation_list_variation")
        for row in variation.loc[variation.source_year.eq(year) &
                                 (variation.cleaned_gains_nonempty_output | variation.cleaned_loses_nonempty_output)].head(3).to_dict("records"):
            add_example((year, row["query_id"]), "input_variant_changes_output_presence")
    examples = query_frame.loc[[(int(y), q) in example_tags for y, q in zip(query_frame.source_year, query_frame.query_id)]].copy()
    examples.insert(0, "example_reason", [";".join(sorted(set(example_tags[(int(y), q)]))) for y, q in zip(examples.source_year, examples.query_id)])
    dump_csv(args.output / "examples_for_human_review.csv", examples)
    check("recommendation export cardinalities", len(query_frame) == 1620 and len(long_rows) == int(query_frame.returned_recommendations.sum()))
    check("source workbook and all original artifact bytes unchanged after analysis", all(sha(p) == h for p, h in original_hashes.items()),
          f"{len(original_hashes)} read-only files rehashed after computations/exports")

    report_lines = [
        "Alberta 冻结 BGE 模型：输出分析与独立核验", "",
        "六个真实 GPU 推理条件已经完成。每个条件对 67,635 个真实候选对评分，包含 135 条投标项分别对 2024 年 237 条、2026 年 264 条目录记录的完整候选池。",
        "输入 raw 与 cleaned 均保留原始描述。raw 的规范化描述仅处理大小写/空白/标点，单位槽保留原单位；cleaned 另外使用审计中冻结的单位别名、规范/桥号参考删除及 Cl. 展开。两者类别与规格槽均为空。", "",
        "当前没有确认的 Alberta 金标准。没有读取人工判定，也没有计算 accuracy、precision、recall、F1、语义正确率或检索质量指标。下文‘有输出’仅表示至少一个候选分数达到冻结阈值，不表示候选正确。",
        "阈值沿用原模型验证集：20260904=9.1875，20260905=-1.453125，20260906=8.4375。没有在 Alberta 数据上重新训练或调阈值；完整目录、真实原文、缺失特征与原验证条件不同，阈值迁移可能受到分布变化影响。三个种子的分数尺度不同，不直接比较分数大小。", "",
        "独立核验全部通过：输入/预测/计时/摘要/原始来源/脚本/序列化模块 SHA-256，原冻结来源中的模型计划、阈值和检查点文件哈希条目，输入逐行身份一一对应，完整年度候选池，有限分数，prediction=(score>=threshold)，按分数降序、候选 ID 升序解并列、最多三条的推荐重建，以及 1,620 条运行摘要逐条重算。",
        "本地没有远端检查点文件，故本分析核验的是执行清单与原冻结来源的检查点哈希完全一致，并保留远端运行器已逐字节核验检查点的记录；本分析没有重新读取/运行远端模型。所有读取的原始文件在输出后再次哈希确认未变。", "",
        "各条件与年度的输出数量（每行 135 条查询；不是正确性）：",
        table(stats, ["seed", "variant", "source_year", "queries_with_model_recommendations", "queries_without_model_recommendations", "above_threshold_candidates", "returned_recommendations"]), "",
        "以 cleaned 冻结 exact 规则的 45/135 条覆盖查询作为固定比较基准（每年度 43 条单候选、2 条多候选，合计 47 条 exact 候选）。其余 90 条是规则未覆盖查询。以下仅计数模型是否给出审阅建议，不将规则或模型输出当标签：",
        table(stats, ["seed", "variant", "source_year", "rule_covered_model_nonempty_queries", "rule_covered_model_empty_queries", "rule_uncovered_model_nonempty_queries", "rule_uncovered_model_empty_queries", "rule_or_model_nonempty_union_queries"]), "",
        "规则候选与模型候选重叠数量保存在 output_summary_by_seed_variant_year.csv：分别记录规则覆盖查询中 exact 候选是否超过阈值、是否进入 Top-3，以及 exact 候选条数。rule_or_model_nonempty_union_queries 是规则或模型任一有候选的覆盖并集，不是混合系统的实际推理或质量评价。",
        "三种子稳定性（每年 135 个池；空列表一致会计入总体一致，因此同时展示至少一个模型有输出的分母）：",
        table(agreement_stats, ["variant", "source_year", "all_models_empty_queries", "all_models_nonempty_queries", "mixed_nonempty_status_queries", "ordered_lists_identical_queries", "ordered_lists_identical_among_any_model_nonempty", "any_model_nonempty_queries"]), "",
        "集合 Jaccard 定义为交集/并集，双方均空定义为 1。逐查询报告同时列出 Top-3 有序列表、Top-3 集合、全部超过阈值候选集合、三模型交并集与成对 Jaccard，不把稳定性作为正确性证据。",
        "raw/cleaned 的逐查询差异另存 raw_cleaned_variability_per_query.csv 与年度汇总。任何输出增减都只是输入处理后冻结模型的行为差异，没有 Alberta 标签支持‘改进’判断。", "",
        "实际时间：每个条件只有一次同步完整评分运行（repeat=0），不是多次计时重复。包括序列化、分词、GPU 推理、阈值判断和 Top-3 排序；不包括预热、模型加载、文件 I/O 或校验。运行硬件为 RTX 4090，BF16 autocast，TF32=false，batch=64，max_length=256。模型加载时间单列。",
        table(timing, ["seed", "variant", "seconds", "model_load_seconds", "pairs", "repeat"]), "",
        "三冻结模型的描述性完整运行均值：",
        table(pd.DataFrame(timing_rows), ["variant", "actual_observations", "mean_full_pass_seconds", "minimum_full_pass_seconds", "maximum_full_pass_seconds"]),
        "未计算时间置信区间、货币成本、硬件间速度比较或逐查询独立延迟。三模型均值/最小/最大描述本次观测，不估计重复运行不确定性。", "",
        "本次实际数据的全部超过阈值候选均进入返回列表，没有任何池出现超过三条阈值接受候选；因此实际数据没有触发超过三条时的截断分支。score_and_boundary_diagnostics.csv 记录阈值相等的接受边界、返回分数并列和逐条件分数分布。",
        "人工复核示例见 examples_for_human_review.csv：包含规则未覆盖却有模型输出、原单位缺失、规则覆盖但模型为空、三种子列表变化与输入变化。按查询 ID 顺序选取符合这些条件的示例，属于事后输出诊断，未作语义正确/错误判定。",
        "缺失单位原始项包括 Q006：Speed Monitor Displays (Special Provisions)，及 Q111：Excavation - Structural (BF75337-S) (BCS 1.6.1)。单位继续保留空值，不作补全。",
        "每条件 model_recommendations_<variant>_seed_<seed>.csv 有 270 行，含零输出的查询、原文/原单位/原表行号/规范上下文和三个建议的目录 ID、分数、原始目录描述、单位与原表定位。returned_recommendations_all.csv 是所有实际返回条目的长表。",
        "候选 ID 与空白独立标注表中的完整目录 ID 一致（年度_R原行号），查询 ID 与项目号一致。已核验标注导出的 ID 契约、相同 raw_items 来源与现有源值/稳定 ID 校验记录，并通过文件哈希确认两份空白导出保持原样；没有读取标注表单元格或人工填写内容。",
        "价格字段仅从原始 UPA 目录抄录 province_average_3_low_bids / contracts / amount / quantity，以 historical catalogue context 呈现；不是 BGE 价格预测，不对候选对应关系或价格适用性作确认。", "",
        "复现：使用本地 Python 运行 scripts/analyze_alberta_frozen_models.py；脚本只读已完成结果，不导入 torch/transformers、不连接远端、不访问 GPU、不读取金标准。",
    ]
    report_path = args.output / "Alberta_模型输出分析与核验报告.txt"
    report_path.write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    dump_csv(args.output / "file_integrity_verified.csv", integrity)
    dump_csv(args.output / "validation_checks.csv", checks)
    outputs = [{"name": p.name, "sha256": sha(p), "bytes": p.stat().st_size}
               for p in sorted(args.output.iterdir()) if p.is_file() and p.name != "analysis_validation_qa.json"]
    qa = {"status": "passed", "schema": "alberta-output-only-independent-analysis-v1",
          "created_utc": datetime.now(timezone.utc).isoformat(), "analysis_script_sha256": sha(__file__),
          "analysis_python": sys.executable, "conditions": 6, "pairs_per_condition": PAIR_N,
          "total_scored_pairs": PAIR_N * 6, "year_query_pools_per_condition": POOL_N,
          "per_query_rows": len(query_frame), "returned_recommendation_rows": len(long_rows),
          "candidate_counts_by_year": YEAR_N, "fixed_exact_covered_queries_by_year": {y: 45 for y in YEAR_N},
          "fixed_exact_uncovered_queries_by_year": {y: 90 for y in YEAR_N},
          "all_checks_passed": len(checks), "read_only_files_rehashed": len(original_hashes),
          "labels_available": False, "labels_accessed": False, "human_annotation_values_read": False,
          "gold_metrics_computed": False, "semantic_quality_computed": False,
          "models_executed_by_analysis": False, "remote_access_used": False, "training_performed": False,
          "thresholds_retuned": False, "original_files_changed": False,
          "input_scores_predictions_rank_summary_independently_verified": True,
          "checkpoint_provenance": {"frozen_run_entries_match_exactly": True,
                                    "remote_runner_checkpoint_byte_verification_recorded": True,
                                    "local_checkpoint_bytes_available": False,
                                    "checkpoint_bytes_independently_rehashed_locally": False},
          "actual_full_timing_passes_per_condition": 1, "timing_confidence_intervals_computed": False,
          "monetary_cost_computed": False, "outputs": outputs,
          "limitations": ["No adjudicated Alberta gold labels; recommendations are unverified review outputs.",
                          "Original validation thresholds transferred unchanged; Alberta deployment may be out of distribution.",
                          "Only one actual full scoring pass per condition; three-model means are descriptive.",
                          "Catalogue prices are copied historical source context, not model estimates."]}
    write_json(args.output / "analysis_validation_qa.json", qa)
    print(compact({"status": qa["status"], "checks": len(checks), "per_query_rows": len(query_frame),
                   "returned_recommendations": len(long_rows), "report": str(report_path)}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, default=ROOT / "results/raw_alberta_models")
    parser.add_argument("--inputs", type=Path, default=ROOT / "results/raw_alberta_model")
    parser.add_argument("--source", type=Path, default=ROOT.parent / "rule_first_system_20261004/results/server/source_manifest.json")
    parser.add_argument("--raw", type=Path, default=ROOT / "results/raw_alberta_import/raw_items.json")
    parser.add_argument("--audit", type=Path, default=ROOT / "results/raw_alberta_import/audit_summary.json")
    parser.add_argument("--output", type=Path, default=ROOT / "results/raw_alberta_models/analysis")
    args = parser.parse_args()
    analyze(args)


if __name__ == "__main__":
    main()
