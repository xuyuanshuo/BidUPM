#!/usr/bin/env python3
"""Build exhaustive, annotation-free Alberta CSVs from the audited raw JSON.

No workbook is parsed or saved, no model is loaded, and no retrieval, labels,
item-code matching, network access, or GPU execution occurs. Original workbook
bytes are read only to verify the audit's hashes before and after this export.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import unicodedata


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RAW = ROOT / "results/raw_alberta_import/raw_items.json"
DEFAULT_AUDIT = ROOT / "results/raw_alberta_import/audit_summary.json"
DEFAULT_SOURCE = ROOT.parent / "rule_first_system_20261004/results/server/source_manifest.json"
DEFAULT_OUTPUT = ROOT / "results/raw_alberta_model"
TEXT_FIELDS = ("description", "normalized_description", "normalized_unit", "category", "spec_tokens")
CONTRACT = ["pair_id", "evaluation_split", "query_id", "candidate_id", "initial_rank", "retrieval_score",
            *[f"{side}_{name}" for side in ("query", "candidate") for name in TEXT_FIELDS]]
META_SUFFIXES = (
    "unit", "original_audit_id", "source_file", "source_sha256", "source_sheet", "source_row",
    "description_cell", "unit_cell", "removed_reference_spans_json", "reference_context_json",
    "class_abbreviation_spans_json", "retained_parenthetical_spans_json",
    "category_status", "spec_tokens_status", "description_missing", "unit_missing",
)
COLUMNS = CONTRACT + ["source_year", "input_variant", "query_item_number", "candidate_source_id"] + [
    f"{side}_{name}" for side in ("query", "candidate") for name in META_SUFFIXES
]
FORBIDDEN = {"label", "final_label", "final_relevance", "difficulty", "final_conflict_type",
             "prediction", "score", "model_logit", "gold_label", "is_match"}
SPEC_PATTERNS = (
    ("HCS_BCS_GCS_reference", re.compile(r"\(\s*(?:HCS|BCS|GCS)\s+[^)]*\)", re.I)),
    ("special_provisions_reference", re.compile(r"\(\s*Special\s+Provisions?\s*\)", re.I)),
    ("bridge_file_reference", re.compile(r"\(\s*B\.?\s*F\.?\s*[- ]*\d+[A-Za-z0-9\s-]*\)", re.I)),
)
CLASS_PATTERN = re.compile(r"\bCl\.(?=\s*\d)", re.I)
STAGE_RAW = "case_space_punctuation"
STAGE_CLEANED = "class_abbreviation_expansion"
EXPECTED_QUERY_N = 135
EXPECTED_SOURCE_N = {2024: 237, 2026: 264}
EXPECTED_PAIR_N = sum(EXPECTED_QUERY_N * n for n in EXPECTED_SOURCE_N.values())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def raw_text(value):
    return "" if value is None else str(value)


def unicode_text(value):
    return unicodedata.normalize("NFKC", raw_text(value)).replace("\u2013", "-").replace("\u2014", "-")


def formatting(value):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", unicode_text(value).casefold())).strip()


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def reference_context(item):
    """Preserve reference locations in the original string, including N/S scope."""
    text = raw_text(item["description"])
    contexts = []
    for rule, pattern in SPEC_PATTERNS:
        for match in pattern.finditer(text):
            contexts.append({"rule": rule, "text": match.group(), "start": match.start(),
                             "end_exclusive": match.end(), "coordinate_system": "original_description_unicode_codepoints",
                             "left_context": text[max(0, match.start() - 64):match.start()],
                             "right_context": text[match.end():match.end() + 64]})
    return sorted(contexts, key=lambda x: (x["start"], x["end_exclusive"], x["rule"]))


def verify_item_keys(item, aliases):
    """Independently reconstruct both selected audit keys from raw fields."""
    require(item["stage_keys"][STAGE_RAW]["description"] == formatting(item["description"]),
            "Formatting-only description differs from the existing audit")
    require(item["stage_keys"][STAGE_RAW]["unit"] == formatting(item["unit"]),
            "Formatting-only unit differs from the existing audit")
    desc = unicode_text(item["description"])
    for _, pattern in SPEC_PATTERNS:
        desc = pattern.sub(" ", desc)
    desc = CLASS_PATTERN.sub("Class", unicode_text(desc))
    unit = formatting(item["unit"])
    expected = {"description": formatting(desc), "unit": aliases.get(unit, unit)}
    require(item["stage_keys"][STAGE_CLEANED] == expected,
            "Stage-five keys differ from independently reconstructed audit rules")
    return True


def features(item, side, variant):
    stage = STAGE_CLEANED if variant == "cleaned" else STAGE_RAW
    return {f"{side}_description": raw_text(item["description"]),
            f"{side}_normalized_description": item["stage_keys"][stage]["description"],
            f"{side}_normalized_unit": item["stage_keys"][stage]["unit"] if variant == "cleaned" else raw_text(item["unit"]),
            f"{side}_category": "", f"{side}_spec_tokens": ""}


def metadata(item, side, source_hashes):
    values = {
        "unit": raw_text(item["unit"]),
        "original_audit_id": item["query_id"] if side == "query" else item["source_id"],
        "source_file": item["source_file"], "source_sha256": source_hashes[item["source_file"]],
        "source_sheet": item["source_sheet"], "source_row": str(item["source_row"]),
        "description_cell": item["description_cell"], "unit_cell": item["unit_cell"],
        "removed_reference_spans_json": compact(item["removed_reference_spans"]),
        "reference_context_json": compact(reference_context(item)),
        "class_abbreviation_spans_json": compact(item["class_abbreviation_spans"]),
        "retained_parenthetical_spans_json": compact(item["retained_parenthetical_spans_after_reference_removal"]),
        "category_status": "unknown_not_present_in_raw_schema",
        "spec_tokens_status": "unknown_not_extracted_references_preserved_as_metadata",
        "description_missing": str(item["description"] is None or not raw_text(item["description"]).strip()).lower(),
        "unit_missing": str(item["unit"] is None or not raw_text(item["unit"]).strip()).lower(),
    }
    return {f"{side}_{key}": value for key, value in values.items()}


def iter_rows(raw, source_hashes, variant):
    queries = sorted(raw["queries"], key=lambda x: x["item_number_metadata_only"])
    prepared_q = [(q, features(q, "query", variant), metadata(q, "query", source_hashes)) for q in queries]
    for year in sorted(EXPECTED_SOURCE_N):
        sources = sorted(raw["sources"][str(year)], key=lambda x: x["source_row"])
        prepared_c = [(c, features(c, "candidate", variant), metadata(c, "candidate", source_hashes)) for c in sources]
        for query, query_features, query_meta in prepared_q:
            item_number = query["item_number_metadata_only"]
            for candidate, candidate_features, candidate_meta in prepared_c:
                source_row = candidate["source_row"]
                yield {
                    "pair_id": f"Alberta{year}-Q{item_number:03d}-R{source_row:03d}",
                    "evaluation_split": f"raw_alberta_{year}", "query_id": f"Q{item_number:03d}",
                    "candidate_id": f"{year}_R{source_row:03d}", "initial_rank": "", "retrieval_score": "",
                    **query_features, **candidate_features,
                    "source_year": str(year), "input_variant": variant, "query_item_number": str(item_number),
                    "candidate_source_id": f"{year}_R{source_row:03d}", **query_meta, **candidate_meta,
                }


def export_and_check(path, raw, source_hashes, variant):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(iter_rows(raw, source_hashes, variant))
    identities = set()
    pools = Counter()
    years = Counter()
    row_count = 0
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == COLUMNS, "CSV schema/order differs")
        require(not FORBIDDEN.intersection(reader.fieldnames), "Annotations or predictions in input CSV")
        for actual, expected in zip(reader, iter_rows(raw, source_hashes, variant), strict=True):
            require(actual == expected, f"CSV round-trip mismatch at {actual.get('pair_id')}")
            require(actual["pair_id"] not in identities, "Duplicate pair ID")
            identities.add(actual["pair_id"])
            pool = (actual["source_year"], actual["query_id"])
            pools[pool] += 1
            years[actual["source_year"]] += 1
            row_count += 1
            for side in ("query", "candidate"):
                require(actual[f"{side}_category"] == actual[f"{side}_spec_tokens"] == "",
                        "Unknown feature slot fabricated")
    require(row_count == EXPECTED_PAIR_N, "Incorrect full-pair count")
    require(len(pools) == 270, "Incorrect year/query pool count")
    for year, count in EXPECTED_SOURCE_N.items():
        require(years[str(year)] == EXPECTED_QUERY_N * count, "Yearly pair count differs")
        require(all(pools[(str(year), f"Q{n:03d}")] == count for n in range(1, 136)), "Incomplete candidate pool")
    return {"path": str(path), "variant": variant, "sha256": sha(path), "size_bytes": path.stat().st_size,
            "pairs": row_count, "year_query_pools": len(pools), "yearly_pairs": dict(years),
            "full_round_trip_equality": True, "unique_pair_ids": True, "unknown_slots_empty": True,
            "raw_description_unit_preserved": True, "source_row_id_verified": True, "annotations_present": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw", type=Path, default=DEFAULT_RAW)
    parser.add_argument("--audit", type=Path, default=DEFAULT_AUDIT)
    parser.add_argument("--frozen-manifest", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    raw = json.loads(args.raw.read_text(encoding="utf-8"))
    audit = json.loads(args.audit.read_text(encoding="utf-8"))
    frozen = json.loads(args.frozen_manifest.read_text(encoding="utf-8"))
    require(frozen["inference_input_contract"] == CONTRACT, "Actual frozen inference contract differs")
    policy_path = Path(__file__).with_name("system_policy.py")
    policy_ast = ast.parse(policy_path.read_text(encoding="utf-8"))
    declarations = [ast.literal_eval(node.value) for node in policy_ast.body if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == "TEXT_FIELDS" for target in node.targets)]
    require(declarations == [TEXT_FIELDS], "Actual serializer slot names/order differs")
    require(set(raw) == {"sources", "queries"}, "Unexpected raw JSON schema")
    require(set(raw["sources"]) == {"2024", "2026"}, "Unexpected source year")
    require(len(raw["queries"]) == EXPECTED_QUERY_N, "Expected 135 bid queries")
    require(sorted(x["item_number_metadata_only"] for x in raw["queries"]) == list(range(1, 136)),
            "Actual bid item numbers are not exactly 1–135")
    require(len({x["query_id"] for x in raw["queries"]}) == EXPECTED_QUERY_N, "Duplicate original query ID")
    for year, expected_n in EXPECTED_SOURCE_N.items():
        sources = raw["sources"][str(year)]
        require(len(sources) == expected_n, "Unexpected source-row count")
        require(len({x["source_row"] for x in sources}) == expected_n, "Duplicate source row")
        require(all(x["year"] == year for x in sources), "Source year differs")
    source_hashes = {entry["path"]: entry["sha256"] for entry in audit["sources"]}
    require(len(source_hashes) == 2, "Expected two original workbooks")
    actual_hashes = {path: sha(path) for path in source_hashes}
    require(actual_hashes == source_hashes, "Original workbook bytes differ from the raw audit")
    aliases = {formatting(alias): canonical for canonical, names in audit["unit_alias_groups"].items() for alias in names}
    items = [*raw["queries"], *[item for year in sorted(raw["sources"]) for item in raw["sources"][year]]]
    for item in items:
        require(item["source_file"] in source_hashes, "Unknown source workbook")
        verify_item_keys(item, aliases)
    args.output.mkdir(parents=True, exist_ok=True)
    outputs = [export_and_check(args.output / f"inference_pairs_{variant}.csv", raw, source_hashes, variant)
               for variant in ("cleaned", "raw")]
    after_hashes = {path: sha(path) for path in source_hashes}
    require(after_hashes == source_hashes, "Original workbook changed during input build")
    schema = {
        "schema": "alberta-full-pair-five-slot-inference-v1", "columns": COLUMNS,
        "frozen_inference_contract_prefix": CONTRACT, "serializer_text_fields": list(TEXT_FIELDS),
        "serializer": "Description: {description}. Normalized: {normalized_description}. Pay unit: {normalized_unit}. Category: {category}. Specs: {spec_tokens}.",
        "serializer_case_whitespace_normalization": "system_policy.normalize_text: strip, lower, split/join whitespace",
        "five_slot_columns": {side: [f"{side}_{name}" for name in TEXT_FIELDS] for side in ("query", "candidate")},
        "all_other_columns": "metadata only; never serialize provenance, IDs, or unknown-status fields",
        "variant_definitions": {
            "cleaned": {"description": "original raw value", "normalized_description": STAGE_CLEANED,
                        "normalized_unit": "existing stage-five unit alias key", "category": "empty, unknown",
                        "spec_tokens": "empty, unknown; source references retained in metadata"},
            "raw": {"description": "original raw value", "normalized_description": STAGE_RAW,
                    "normalized_unit": "original raw unit string", "category": "empty, unknown",
                    "spec_tokens": "empty, unknown; source references retained in metadata"}},
        "initial_rank": "empty: exhaustive worksheet pool, no retrieval rank",
        "retrieval_score": "empty: no retrieval score computed",
        "query_id": "Q001–Q135 from actual bid item number, identical across yearly pools",
        "candidate_id": "YEAR_R### from actual worksheet row, e.g. 2024_R005",
        "pair_id": "AlbertaYEAR-Q###-R###",
        "pool_key": ["evaluation_split", "query_id"],
        "evaluation_split": "raw_alberta_2024 or raw_alberta_2026; deployment datasets, no train/test labels",
        "missing_source_value": "empty CSV field with explicit *_missing metadata flags",
        "reference_coordinates": "zero-based, end-exclusive Unicode codepoint offsets in original description",
    }
    write_json(args.output / "input_schema.json", schema)
    qa = {
        "status": "passed", "pairs_per_variant": EXPECTED_PAIR_N, "variants": 2,
        "query_n": EXPECTED_QUERY_N, "source_n_by_year": EXPECTED_SOURCE_N,
        "year_query_pools_per_variant": 270, "normalized_item_keys_independently_verified": len(items),
        "query_item_numbers_complete_unique": True, "csv_outputs": outputs,
        "original_source_hashes_before_after_equal": True,
        "labels_read": False, "predictions_read": False, "model_loaded": False,
        "gpu_used": False, "network_used": False, "workbook_modified": False,
        "item_codes_used_for_features_or_matching": False,
        "source_metadata_scope": "raw descriptions/units and reference context preserved; original full row values remain in raw_items.json",
        "missing_units_query_ids": [f"Q{x['item_number_metadata_only']:03d}" for x in raw["queries"] if not raw_text(x["unit"]).strip()],
    }
    write_json(args.output / "input_qa.json", qa)
    manifest = {
        "status": "passed", "schema": "alberta-no-label-inference-inputs-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(), "builder": str(Path(__file__).resolve()),
        "builder_sha256": sha(__file__), "python_executable": sys.executable,
        "raw_items_path": str(args.raw.resolve()), "raw_items_sha256": sha(args.raw),
        "audit_summary_path": str(args.audit.resolve()), "audit_summary_sha256": sha(args.audit),
        "frozen_manifest_path": str(args.frozen_manifest.resolve()), "frozen_manifest_sha256": sha(args.frozen_manifest),
        "serializer_policy_path": str(policy_path), "serializer_policy_sha256": sha(policy_path),
        "source_workbooks": [{"path": path, "audit_sha256": digest, "actual_sha256_before": actual_hashes[path],
                              "actual_sha256_after": after_hashes[path]} for path, digest in source_hashes.items()],
        "inference_input_contract": CONTRACT, "columns": COLUMNS, "outputs": outputs,
        "input_schema_sha256": sha(args.output / "input_schema.json"),
        "input_qa_sha256": sha(args.output / "input_qa.json"),
        "labels_accessed": False, "models_run": False, "item_codes_used_for_matching": False,
        "full_candidate_pools": True, "candidate_counts_by_year": EXPECTED_SOURCE_N,
        "legacy_cli_compatibility": "Serializer-compatible. predict_top3.py enforces 30-candidate pools; use a full-pool runner for 237/264 candidates.",
    }
    write_json(args.output / "input_manifest.json", manifest)
    print(json.dumps({"status": "passed", "pairs_per_variant": EXPECTED_PAIR_N,
                      "outputs": [{"path": x["path"], "sha256": x["sha256"], "size_bytes": x["size_bytes"]} for x in outputs],
                      "manifest": str(args.output / "input_manifest.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
