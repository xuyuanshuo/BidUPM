#!/usr/bin/env python3
"""Vector figure of the implemented input-only rule-first Top-3 policy.

No gold labels, predicted performance, or unimplemented conflict gates are used.
"""
from pathlib import Path
import argparse
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.path import Path as MplPath
from matplotlib.text import Text


ROOT = Path(__file__).resolve().parents[1]
INK = "#253540"
EDGE = "#68808E"
BLUE = "#246383"
GREEN = "#426F59"


def box(ax, x, y, width, height, title, lines, *, fill="#F4F7F9", color=BLUE,
        title_fs=10.0, body_fs=9.3, dashed=False):
    patch = FancyBboxPatch((x-width/2, y-height/2), width, height,
                          boxstyle="round,pad=0.03,rounding_size=0.10",
                          facecolor=fill, edgecolor=color, linewidth=1.1,
                          linestyle="--" if dashed else "-", zorder=2)
    ax.add_patch(patch)
    contained = []
    if title:
        contained.append(ax.text(x, y + height*.27, title, ha="center", va="center",
                fontweight="bold", fontsize=title_fs, color=color, zorder=4))
        text_y = y - height*.10
    else:
        text_y = y
    contained.append(ax.text(x, text_y, "\n".join(lines), ha="center", va="center",
            fontsize=body_fs, linespacing=1.38, color=INK, zorder=4))
    if not hasattr(ax, "_paper_boxes"):
        ax._paper_boxes = []
    ax._paper_boxes.append((patch, contained))
    return patch


def arrow(ax, points, *, dashed=False, color=EDGE):
    codes = [MplPath.MOVETO] + [MplPath.LINETO] * (len(points)-1)
    path = MplPath(points, codes)
    artist = FancyArrowPatch(path=path, arrowstyle="-|>", mutation_scale=12,
                             linewidth=1.25, color=color,
                             linestyle="--" if dashed else "-", zorder=1)
    ax.add_patch(artist)


def draw(iteration):
    configs = {
        1: dict(size=(9.6, 4.7), top_y=5.7, lower_y=2.8, offline_y=.55,
                title_y=6.92, ylim=(-.3, 7.3), main_bottom=1.50,
                rule_w=3.8, main_fs=9.3),
        2: dict(size=(9.6, 5.1), top_y=6.0, lower_y=2.85, offline_y=.45,
                title_y=7.22, ylim=(-.35, 7.65), main_bottom=1.50,
                rule_w=3.8, main_fs=9.3),
        3: dict(size=(9.2, 5.35), top_y=6.0, lower_y=2.85, offline_y=.45,
                title_y=7.22, ylim=(-.35, 7.65), main_bottom=1.50,
                rule_w=3.8, main_fs=9.6),
    }
    c = configs[iteration]
    plt.rcParams.update({"font.family":"DejaVu Sans", "pdf.fonttype":42,
                         "ps.fonttype":42, "svg.fonttype":"none"})
    fig, ax = plt.subplots(figsize=c["size"])
    fig.subplots_adjust(left=.025, right=.98, top=.96, bottom=.045)
    ax.set_xlim(-.05, 15.25)
    ax.set_ylim(*c["ylim"])
    ax.axis("off")
    top = c["top_y"]
    low = c["lower_y"]
    ax.text(7.55, c["title_y"], "Rule-first Top-3 historical reference screening",
            ha="center", va="center", fontsize=12, fontweight="bold", color=INK)
    input_lines = ["Current item", "+ 30 historical", "candidates"] if iteration<3 else [
        "Current item", "+ 30 historical", "candidates (fixed)"]
    box(ax,1.45,top,2.4,1.6,"Input",input_lines,
        body_fs=c["main_fs"])
    box(ax,4.9,top,c["rule_w"],1.6,"Exact acceptance rule",
        ["Canonical descriptions equal", "AND normalized pay units equal", "Both fields nonempty"],
        body_fs=c["main_fs"])
    box(ax,8.65,top,2.6,1.6,"Count exact accepts" if iteration==1 else "Exact count",
        ["E = number accepted"],
        fill="#F3F5F6", color="#566D79", body_fs=c["main_fs"])
    output_lines = ["Return Top-3", "or an empty list"] if iteration<3 else [
        "Up to 3 references", "or an empty list"]
    box(ax,12.9,top,2.5,1.6,"Output",output_lines,
        body_fs=c["main_fs"])
    arrow(ax,[(2.68,top),(2.97,top)])
    arrow(ax,[(6.83,top),(7.32,top)])
    arrow(ax,[(9.98,top),(11.62,top)])
    ax.text(10.79,top+.40,"E ≥ 3",ha="center",va="center",fontsize=9.4,color=BLUE)
    ax.text(10.79,top-.40,"Skip BGE" if iteration==1 else "Exact Top-3\nNo BGE",
            ha="center",va="center",fontsize=9.0,color=BLUE)

    box(ax,3.75,low,5.15,2.1,"Five input fields per item",
        ["Description / normalized description", "Pay unit / category / specifications"],
        fill="#FFFFFF",color="#6E818C",body_fs=9.1)
    arrow(ax,[(1.45,top-.83),(1.45,low+1.08)])
    model_lines = ["Only remaining candidates", "Frozen checkpoint and threshold τ", "Accept score ≥ τ; reject below τ"] if iteration==1 else [
        "Remaining candidates only", "Frozen checkpoint; original τ", "Accept score ≥ τ", "Reject score < τ"]
    model_title = "Task-specific BGE" if iteration==1 else \
        ("Task-fine-tuned BGE" if iteration==2 else "Fine-tuned BGE")
    box(ax,8.65,low,3.4,2.1,model_title,
        model_lines,
        fill="#F0F6F2",color=GREEN,body_fs=9.1)
    arrow(ax,[(6.355,low),(6.92,low)])
    arrow(ax,[(8.65,top-.83),(8.65,low+1.08)])
    ax.text(9.23,(top-.83+low+1.08)/2,"E < 3",ha="left",va="center",
            fontsize=9.4,color=BLUE)
    merge_lines = ["Exact accepts first", "Then accepted BGE", "by descending score", "At most 3 references"] if iteration==1 else [
        "Exact accepts first", "Then BGE score ≥ τ", "Descending score", "Cap at 3; ID breaks ties"]
    box(ax,12.9,low,2.5,2.1,"Merge and rank", merge_lines,
        fill="#F4F7F9",body_fs=9.0 if iteration==1 else 8.8)
    arrow(ax,[(10.38,low),(11.62,low)])
    arrow(ax,[(12.9,low+1.08),(12.9,top-.83)])
    miss_note = "A rule miss is unresolved, never an automatic rejection." if iteration<3 else \
        "Rule misses remain unresolved until model scoring."
    ax.text(7.50,c["main_bottom"],miss_note,
            ha="center",va="center",fontsize=8.8,color="#566771")

    separation_y = c["offline_y"] + .58
    ax.plot([.25,14.95],[separation_y,separation_y],color="#C7D0D5",linewidth=.8,
            linestyle=(0,(4,3)),zorder=0)
    box(ax,3.70,c["offline_y"],4.8,.8,"",
        ["Gold labels — offline only"],fill="#FCF9F3",color="#A08351",body_fs=9.1,dashed=True)
    box(ax,11.25,c["offline_y"],5.7,.8,"",
        ["Evaluate returned lists against gold labels"],fill="#FCF9F3",color="#A08351",body_fs=9.1,dashed=True)
    arrow(ax,[(6.13,c["offline_y"]),(8.37,c["offline_y"])],dashed=True,color="#A08351")
    arrow(ax,[(14.18,top),(14.75,top),(14.75,c["offline_y"]),(14.13,c["offline_y"])],
          dashed=True,color="#A08351")

    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    texts=[]
    clipping=[]
    for item in fig.findobj(match=Text):
        if not item.get_visible() or not item.get_text().strip():
            continue
        b=item.get_window_extent(renderer)
        texts.append((item.get_text(),b))
        if b.x0<0 or b.y0<0 or b.x1>fig.bbox.x1 or b.y1>fig.bbox.y1:
            clipping.append(item.get_text())
    overlaps=[]
    for i,(txt,b) in enumerate(texts):
        for other_txt,other in texts[i+1:]:
            if min(b.x1,other.x1)-max(b.x0,other.x0)>.5 and min(b.y1,other.y1)-max(b.y0,other.y0)>.5:
                overlaps.append([txt,other_txt])
    box_overflow = []
    for patch, items in ax._paper_boxes:
        bounds = patch.get_window_extent(renderer)
        for item in items:
            text_bounds = item.get_window_extent(renderer)
            if text_bounds.x0 < bounds.x0+2 or text_bounds.y0 < bounds.y0+2 or \
                    text_bounds.x1 > bounds.x1-2 or text_bounds.y1 > bounds.y1-2:
                box_overflow.append(item.get_text())
    qa=ROOT/"qa"/f"method_figure_v{iteration}"
    qa.mkdir(parents=True,exist_ok=True)
    (qa/"text_bounds.json").write_text(json.dumps({"iteration":iteration,"layout":c,
        "text_n":len(texts),"clipped":clipping,"text_overlaps":overlaps,
        "box_text_overflow":box_overflow},indent=2))
    for suffix in ["png","pdf","svg"]:
        fig.savefig(qa/f"method_overview.{suffix}",dpi=240,facecolor="white")
    if iteration==3:
        assert not clipping and not overlaps and not box_overflow, "Final figure has text clipping or overlap"
        dest=ROOT/"figures"
        dest.mkdir(exist_ok=True)
        for suffix in ["png","pdf","svg"]:
            fig.savefig(dest/f"method_overview.{suffix}",dpi=240,facecolor="white")
    plt.close(fig)
    print(qa/"method_overview.png")


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--iteration",type=int,choices=[1,2,3],required=True)
    draw(parser.parse_args().iteration)
