#!/usr/bin/env python3
"""POST-HOC descriptive Boolean complementarity on frozen, completed outputs.

Run --freeze-only first. This creates input/prediction-only counterfactuals and
freezes the family, script, and output hashes without reading gold. --evaluate
then requires that exact freeze. Earlier formal and GPT evaluation was already
seen, so this is not prospective preregistration, model selection, or inference.
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

import evaluate_gpt6_blind as evaluation


FAMILY = {
    "exact_gpt_fallback": {
        "semantic_accept": "GPT accepted_candidates mask",
        "semantic_order": "GPT provided top3 order first; remaining accepted candidates by frozen candidate_id ascending",
        "run_basis": "One completed GPT agent workflow; seed=0 denotes no model-seed replication",
    },
    "exact_bge_and_gpt_fallback": {
        "semantic_accept": "BGE frozen threshold acceptance AND GPT accepted_candidates mask",
        "semantic_order": "Full-BGE recorded score descending, frozen candidate_id ascending for ties",
        "run_basis": "Three existing BGE checkpoint seeds and one shared completed GPT workflow",
    },
    "exact_bge_or_gpt_fallback": {
        "semantic_accept": "BGE frozen threshold acceptance OR GPT accepted_candidates mask",
        "semantic_order": "Full-BGE recorded score descending over the entire union, frozen candidate_id ascending for ties",
        "run_basis": "Three existing BGE checkpoint seeds and one shared completed GPT workflow",
    },
}
CONTROL = "exact_bge_fullscore_control"
UNIVERSAL = {
    "exact_rule": "Existing frozen input-only canonical normalized description equality AND normalized unit equality",
    "gate": "Accept exact candidates; if E>=3, stop and leave all nonexact candidates unobserved (-1)",
    "returned_cap": 3,
    "exact_order": "Frozen candidate_id ascending; exact candidates always precede semantic candidates",
    "new_unit_filter": False,
    "gold_used_in_masks_gate_or_order": False,
    "prospective_preregistration": False,
    "test_selected_best_model_claim": False,
    "new_model_inference": False,
    "time_cost_or_economy_claim": False,
}


def validate_and_construct(project):
    qa = {}
    source = project.parent / "rule_first_system_20261004/results/server"
    blind = project / "blind_gpt6_sol"
    mapping = project / "results/gpt6_sol_blind/private_mapping.csv"
    inputs, gpt, source_manifest = evaluation.validate_blind(blind, mapping, source, qa)
    formal = evaluation.validate_formal(source, inputs, qa)
    exact = gpt[["pair_id", "prediction", "returned_rank", "exact_match"]].rename(
        columns={"prediction": "gpt_accept", "returned_rank": "gpt_original_returned_rank"})
    allbge = formal[formal.policy.eq("all_bge")].drop(columns=["exact_match"]).merge(exact, on="pair_id", validate="many_to_one")
    allbge["bge_accept"] = allbge.prediction.eq(1)
    exact_n = inputs.assign(exact_match=evaluation.system_policy.exact_mask(inputs)).groupby(evaluation.QUERY_KEYS).exact_match.sum()
    allbge["eligible_nonexact"] = ~allbge.exact_match.astype(bool) & allbge[evaluation.QUERY_KEYS].apply(tuple, axis=1).map(exact_n).lt(3)
    rows = []
    specifications = [CONTROL, *FAMILY]
    for policy in specifications:
        seeds = [0] if policy == "exact_gpt_fallback" else sorted(allbge.seed.unique())
        for seed in seeds:
            base = allbge[allbge.seed.eq(seed if seed else sorted(allbge.seed.unique())[0])].copy()
            exact_mask, bge_mask, gpt_mask = base.exact_match.astype(bool), base.bge_accept.astype(bool), base.gpt_accept.eq(1)
            semantic = bge_mask if policy == CONTROL else gpt_mask if policy == "exact_gpt_fallback" else (
                bge_mask & gpt_mask if policy == "exact_bge_and_gpt_fallback" else bge_mask | gpt_mask)
            base["raw_semantic_accept"] = ~exact_mask & semantic
            base["unlimited_accept"] = exact_mask | semantic
            base["prediction"] = exact_mask.astype(int)
            base.loc[base.eligible_nonexact, "prediction"] = semantic[base.eligible_nonexact].astype(int)
            base.loc[~exact_mask & ~base.eligible_nonexact, "prediction"] = -1
            base["returned_rank"] = 0
            for (_, _), pool in base.groupby(evaluation.QUERY_KEYS):
                rules = pool[pool.exact_match.astype(bool)].sort_values("candidate_id")
                fallback = pool[pool.eligible_nonexact & pool.prediction.eq(1)]
                if policy == "exact_gpt_fallback":
                    fallback = fallback.assign(gpt_order=fallback.gpt_original_returned_rank.where(fallback.gpt_original_returned_rank.gt(0), 4))
                    fallback = fallback.sort_values(["gpt_order", "candidate_id"])
                else:
                    fallback = fallback.sort_values(["score", "candidate_id"], ascending=[False, True])
                order = pd.concat([rules, fallback]).head(3)
                base.loc[order.index, "returned_rank"] = list(range(1, len(order) + 1))
                evaluation.require(pool.loc[pool.prediction.eq(-1), "exact_match"].eq(0).all(), "An exact candidate was skipped")
            base["source"], base["policy"], base["seed"] = "posthoc_counterfactual", policy, seed
            base["batch_size"] = 0 if policy == "exact_gpt_fallback" else 64
            rows.append(base)
    counterfactual = pd.concat(rows, ignore_index=True)
    evaluation.require(counterfactual.groupby(["policy", "seed", *evaluation.QUERY_KEYS]).returned_rank.apply(lambda x: x.gt(0).sum()).le(3).all(), "Counterfactual cap violated")
    baseline = formal.copy()
    baseline["policy"] = baseline.policy.replace({"system_top3": "system_top3_actual"})
    baseline["source"] = "formal_actual_baseline"
    baseline["raw_semantic_accept"] = np.nan
    baseline["unlimited_accept"] = np.nan
    baseline["eligible_nonexact"] = baseline.prediction.ne(-1) & ~baseline.exact_match.astype(bool)
    original_gpt = gpt.copy()
    original_gpt["source"], original_gpt["policy"] = "gpt6_agent_blind_baseline", "gpt6_original_top3"
    original_gpt["raw_semantic_accept"] = original_gpt.prediction.eq(1) & ~original_gpt.exact_match.astype(bool)
    original_gpt["unlimited_accept"] = original_gpt.prediction.eq(1)
    original_gpt["eligible_nonexact"] = ~original_gpt.exact_match.astype(bool)
    predictions = pd.concat([baseline, original_gpt, counterfactual], ignore_index=True)
    frozen_files = {"blind_input": blind / "inputs/query_pools.jsonl", "gpt_output": blind / "outputs/predictions.jsonl",
                    "mapping": mapping, "source_inputs": source / "inputs.csv", "source_manifest": source / "source_manifest.json",
                    "formal_execution_manifest": source / "execution_manifest.json"}
    frozen_files.update({f"formal_prediction_seed_{seed}": source / f"predictions_seed_{seed}.csv" for seed in sorted(allbge.seed.unique())})
    hashes = {key: {"path": str(path.resolve()), "sha256": evaluation.sha(path)} for key, path in frozen_files.items()}
    return predictions, allbge, source, source_manifest, hashes, qa


def loss_decomposition(part):
    gold, exact = part.final_label.eq(1), part.exact_match.astype(bool)
    accepted, returned, skipped = part.prediction.eq(1), part.returned_rank.gt(0), part.prediction.eq(-1)
    result = {"accepted_n": int(accepted.sum()), "accepted_tp_n": int((accepted & gold).sum()), "accepted_fp_n": int((accepted & ~gold).sum()),
              "accepted_precision_pct": evaluation.rate((accepted & gold).sum(), accepted.sum()),
              "nonexact_accepted_n": int((accepted & ~exact).sum()), "nonexact_accepted_tp_n": int((accepted & gold & ~exact).sum()),
              "nonexact_accepted_fp_n": int((accepted & ~gold & ~exact).sum()),
              "nonexact_returned_tp_n": int((returned & gold & ~exact).sum()), "nonexact_returned_fp_n": int((returned & ~gold & ~exact).sum()),
              "gate_skipped_pair_n": int(skipped.sum()), "gate_skipped_positive_n": int((gold & skipped).sum()),
              "rejected_positive_n": int((gold & part.prediction.eq(0)).sum()),
              "accepted_positive_not_returned_n": int((gold & accepted & ~returned).sum()),
              "accepted_nonexact_positive_not_returned_n": int((gold & ~exact & accepted & ~returned).sum())}
    evaluation.require(result["gate_skipped_positive_n"] + result["rejected_positive_n"] + result["accepted_positive_not_returned_n"] + int((returned & gold).sum()) == int(gold.sum()), "Positive loss decomposition does not sum")
    if part.unlimited_accept.notna().all():
        unlimited = part.unlimited_accept.astype(bool)
        raw = part.raw_semantic_accept.astype(bool)
        result.update({"unlimited_mask_tp_n": int((unlimited & gold).sum()), "unlimited_mask_fp_n": int((unlimited & ~gold).sum()),
                       "unlimited_mask_fn_n": int((~unlimited & gold).sum()),
                       "unlimited_nonexact_tp_n": int((raw & gold).sum()), "unlimited_nonexact_fp_n": int((raw & ~gold).sum()),
                       "uncovered_nonexact_positive_n": int((~unlimited & ~exact & gold).sum())})
    else:
        result.update({key: np.nan for key in ["unlimited_mask_tp_n", "unlimited_mask_fp_n", "unlimited_mask_fn_n", "unlimited_nonexact_tp_n", "unlimited_nonexact_fp_n", "uncovered_nonexact_positive_n"]})
    return result


def complementarity(allbge):
    rows = []
    for group, splits in evaluation.GROUPS.items():
        selected = allbge[allbge.evaluation_split.isin(splits) & ~allbge.exact_match.astype(bool)]
        for seed, part in selected.groupby("seed"):
            for scope in ["all_nonexact", "gate_eligible_nonexact"]:
                chosen = part if scope == "all_nonexact" else part[part.eligible_nonexact]
                bge, gpt = chosen.bge_accept.astype(bool), chosen.gpt_accept.eq(1)
                masks = {"both_accept": bge & gpt, "bge_only_accept": bge & ~gpt,
                         "gpt_only_accept": ~bge & gpt, "neither_accept": ~bge & ~gpt}
                for overlap, mask in masks.items():
                    subgroup = chosen[mask]
                    rows.append({"evaluation_group": group, "seed": seed, "scope": scope, "overlap": overlap,
                                 "pair_n": len(subgroup), "gold_positive_n": int(subgroup.final_label.sum()),
                                 "gold_negative_n": int(subgroup.final_label.eq(0).sum()),
                                 "query_n": len(subgroup[evaluation.QUERY_KEYS].drop_duplicates())})
    return pd.DataFrame(rows)


def residual_queries(predictions):
    rows = []
    for key, pool in predictions.groupby(["source", "policy", "seed", "batch_size", *evaluation.QUERY_KEYS]):
        gold, returned = pool.final_label.eq(1), pool.returned_rank.gt(0)
        positives, tp, fp = int(gold.sum()), int((gold & returned).sum()), int((~gold & returned).sum())
        if tp == positives and not fp:
            continue
        loss = loss_decomposition(pool)
        rows.append({**dict(zip(["source", "policy", "seed", "batch_size", *evaluation.QUERY_KEYS], key)),
                     "query_description": pool.query_description.iloc[0], "positive_n": positives, "returned_tp_n": tp, "returned_fp_n": fp,
                     "missing_positive_n": positives - tp, "minimum_unavoidable_cap_loss_n": max(positives - 3, 0),
                     "recoverable_at3_shortfall_n": min(3, positives) - tp, "no_reference_false_output": positives == 0 and fp > 0,
                     **loss,
                     "returned_pairs": json.dumps(pool[returned].sort_values("returned_rank").pair_id.tolist()),
                     "missing_positive_pairs": json.dumps(pool[gold & ~returned].pair_id.tolist()),
                     "returned_false_positive_pairs": json.dumps(pool[~gold & returned].pair_id.tolist())})
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--freeze-only", action="store_true")
    mode.add_argument("--evaluate", action="store_true")
    project = Path(__file__).resolve().parents[1]
    parser.add_argument("--output", type=Path, default=project / "results/gpt6_sol_blind/posthoc_complementarity")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    freeze_path, prediction_path = out / "family_freeze.json", out / "frozen_counterfactual_predictions.csv"
    predictions, allbge, source, source_manifest, input_hashes, input_qa = validate_and_construct(project)
    script_sha = evaluation.sha(Path(__file__))
    if args.freeze_only:
        evaluation.require(not freeze_path.exists(), "A family freeze already exists; do not overwrite a completed freeze")
        columns = ["source", "policy", "seed", "batch_size", "pair_id", *evaluation.QUERY_KEYS, "candidate_id", "exact_match",
                   "eligible_nonexact", "raw_semantic_accept", "unlimited_accept", "prediction", "returned_rank"]
        predictions[columns].to_csv(prediction_path, index=False)
        freeze = {"status": "frozen_before_complementarity_gold_join", "created_utc": datetime.now(timezone.utc).isoformat(),
                  "study_type": "POST-HOC descriptive counterfactual complementarity study",
                  "earlier_formal_and_gpt_metrics_already_seen": True, "prospective_preregistration": False,
                  "family": FAMILY, "universal_rules": UNIVERSAL,
                  "analysis_control": "Exact+BGE using full-BGE recorded scores with the same gate/order, distinct from actual old subset-scored system",
                  "script_sha256": script_sha, "frozen_input_hashes": input_hashes,
                  "counterfactual_prediction_sha256": evaluation.sha(prediction_path),
                  "counterfactual_predictions_contain_gold": False, "gold_read_by_freeze_stage": False,
                  "candidate_pools": 220, "candidates_per_pool": 30, "candidate_pairs": 6600,
                  "all_gpt_candidates_previously_screened": True,
                  "new_inference_timing_currency_or_cost_data": False}
        evaluation.dump_json(freeze_path, freeze)
        print(json.dumps({"status": "frozen", "freeze_sha256": evaluation.sha(freeze_path), "script_sha256": script_sha,
                          "prediction_sha256": freeze["counterfactual_prediction_sha256"], "gold_read": False, "path": str(freeze_path)}))
        return
    evaluation.require(freeze_path.exists(), "Run --freeze-only before any complementarity evaluation")
    freeze = json.loads(freeze_path.read_text())
    evaluation.require(freeze["script_sha256"] == script_sha, "Script changed after family freeze")
    evaluation.require(freeze["family"] == FAMILY and freeze["universal_rules"] == UNIVERSAL, "Frozen policy family changed")
    evaluation.require(freeze["frozen_input_hashes"] == input_hashes, "Frozen inputs or predictions changed")
    evaluation.require(evaluation.sha(prediction_path) == freeze["counterfactual_prediction_sha256"], "Frozen counterfactual outputs changed")
    frozen_predictions = pd.read_csv(prediction_path)
    key = ["source", "policy", "seed", "batch_size", "pair_id"]
    check = predictions.merge(frozen_predictions[key + ["prediction", "returned_rank"]], on=key, validate="one_to_one", suffixes=("", "_frozen"))
    evaluation.require(len(check) == len(predictions) and check.prediction.eq(check.prediction_frozen).all() and check.returned_rank.eq(check.returned_rank_frozen).all(), "Prediction-only reconstruction differs from freeze")
    # First gold access for this complementary family occurs only here.
    label_path = source / "labels.csv"
    evaluation.require(evaluation.sha(label_path) == source_manifest["labels_sha256"], "Frozen labels changed")
    labels = pd.read_csv(label_path, keep_default_na=False)
    predictions = predictions.merge(labels, on="pair_id", validate="many_to_one")
    allbge = allbge.merge(labels, on="pair_id", validate="many_to_one")
    queries = evaluation.per_query(predictions)
    summary = evaluation.summarize(predictions, queries)
    # Loss columns use full actual pools, never gold-selected routing.
    decompositions = []
    for group, splits in evaluation.GROUPS.items():
        chosen = predictions[predictions.evaluation_split.isin(splits)]
        for identity, part in chosen.groupby(["source", "policy", "seed", "batch_size"]):
            decompositions.append({**dict(zip(["source", "policy", "seed", "batch_size"], identity)),
                                   "evaluation_group": group, **loss_decomposition(part)})
    decomposition = pd.DataFrame(decompositions)
    primary_summary = summary[summary.query_subset.eq("all_queries")].merge(decomposition,
        on=["source", "policy", "seed", "batch_size", "evaluation_group"], validate="one_to_one")
    aggregate = evaluation.aggregate(primary_summary)
    summary.to_csv(out / "summary_with_difficult_query_view.csv", index=False)
    primary_summary.to_csv(out / "summary_per_seed.csv", index=False)
    aggregate.to_csv(out / "summary_aggregate.csv", index=False)
    queries.to_csv(out / "per_query.csv", index=False)
    overlap = complementarity(allbge)
    overlap.to_csv(out / "nonexact_acceptance_overlap_per_seed.csv", index=False)
    overlap.groupby(["evaluation_group", "scope", "overlap"])[["pair_n", "gold_positive_n", "gold_negative_n", "query_n"]].agg(["mean", "std"]).to_csv(out / "nonexact_acceptance_overlap_aggregate.csv")
    residual_queries(predictions).to_csv(out / "residual_query_failures.csv", index=False)
    main_rows = primary_summary[primary_summary.evaluation_group.eq("all_formal")]
    display = []
    for (source_name, policy), part in main_rows.groupby(["source", "policy"]):
        row = {"source": source_name, "policy": policy, "run_n": len(part)}
        for metric in ["returned_precision_pct", "macro_recall_at3_pct", "micro_recall_at3_pct", "hit_at3_pct", "wrong_reference_query_rate_pct",
                       "no_reference_pool_rejection_pct", "nonexact_accepted_tp_n", "nonexact_accepted_fp_n", "nonexact_returned_tp_n",
                       "nonexact_returned_fp_n", "gate_skipped_positive_n", "rejected_positive_n", "accepted_positive_not_returned_n"]:
            value = part[metric].to_numpy(float)
            row[metric] = f"{value.mean():.8f}" if len(value) == 1 else f"{value.mean():.8f} ± {value.std(ddof=1):.8f}"
        display.append(row)
    pd.DataFrame(display).to_csv(out / "all_formal_display.csv", index=False)
    readme = """# POST-HOC descriptive GPT/BGE complementarity study

Earlier formal and GPT evaluation results had already been seen. family_freeze.json therefore freezes this family before its own metrics, not before any test-label exposure and not as prospective preregistration. The three family policies are exact+GPT, exact+(BGE AND GPT), and exact+(BGE OR GPT). No policy is designated a test-selected best model. This analysis motivates possible prospective evaluation on a new, independently frozen dataset only.

Every family keeps the existing input-only description+unit exact rule. Exact candidates are returned first by candidate ID. E>=3 stops nonexact fallback; other nonexact candidates use the frozen published BGE threshold mask and completed GPT acceptance mask. No additional unit/conflict rejection uses gold. Pure GPT fallback respects GPT's provided Top3 order, then candidate ID for accepted candidates absent from that list. AND and OR use original full-BGE score descending, then candidate ID. No ranking or threshold is tuned using the new results.

The actual old system uses its recorded subset-scored predictions. exact_bge_fullscore_control is a separate counterfactual using the full-BGE score file because BF16 scoring and ranking may differ. Rule, full BGE, actual old system, and original GPT Top3 are separately identified baselines. Three BGE seeds reuse the same single completed GPT agent judgment file; variability is across BGE checkpoints, not across independent GPT reruns. Pure GPT has one workflow and no measured SD.

summary_per_seed.csv contains exact counts and Top3 outcomes; summary_aggregate.csv reports mean and sample SD (ddof=1); all_formal_display.csv is the compact comparison. nonexact_acceptance_overlap_per_seed.csv separates both-accepted, BGE-only, GPT-only, and neither for all nonexact candidates and gate-eligible nonexact candidates, including positive/negative counts. Frozen difficulty==hard views remain in summary_with_difficult_query_view.csv.

Loss accounting separates positives skipped by the E>=3 gate, eligible positives rejected by candidate masks, accepted positives omitted by Top3, and returned positives; these counts sum to all frozen positives. Unlimited mask counts are descriptive combinations of already-computed judgments without the stopping gate or returned-list cap. They do not represent a measured live pipeline. Missing positives also include genuinely uncovered semantic positives. residual_query_failures.csv distinguishes the unavoidable cap floor max(positive_n-3,0) from recoverable shortfall min(3,positive_n)-returned_tp and preserves false outputs on genuine no-reference pools.

All outcomes are counterfactual or reused actual outputs. There is no new GPT/GPU inference, API token measurement, request timing, runtime timing, price, currency, or monetary saving; all 6,600 GPT judgments already exist. Candidate mask counts are not measured workload/cost estimates. No latency, economy, prospective superiority, or model-selection conclusion is supported. No labels were changed or rejudged.
"""
    (out / "README.md").write_text(readme)
    qa = {"status": "passed", "study_type": "POST-HOC descriptive counterfactual complementarity study",
          "family_freeze_sha256": evaluation.sha(freeze_path), "family_freeze_created_utc": freeze["created_utc"],
          "script_sha256": script_sha, "labels_sha256": evaluation.sha(label_path),
          "frozen_predictions_reconstructed_without_gold": True, "unlimited_acceptance_and_loss_decomposition": True,
          "positive_loss_decomposition_exact": True, "no_gold_rejudging": True, "no_threshold_ranking_or_gate_tuning": True,
          "earlier_formal_and_gpt_metrics_already_seen": True, "prospective_preregistration": False,
          "test_selected_best_model_claim": False, "new_inference": False, "measured_time_cost_or_currency_available": False,
          "input_integrity": input_qa,
          "output_hashes": {path.name: evaluation.sha(path) for path in sorted(out.iterdir()) if path.is_file() and path.name != "qa.json"}}
    evaluation.dump_json(out / "qa.json", qa)
    print(json.dumps({"status": "passed", "path": str(out), "all_formal": main_rows[["policy", "seed", "returned_tp_n", "returned_fp_n", "returned_precision_pct", "macro_recall_at3_pct", "nonexact_accepted_tp_n", "nonexact_accepted_fp_n", "gate_skipped_positive_n", "rejected_positive_n", "accepted_positive_not_returned_n"]].to_dict("records")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
