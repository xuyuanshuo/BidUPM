"""Package only verified Top3 outputs; never modify the original paper or models."""
import argparse, hashlib, json, shutil, zipfile
from pathlib import Path

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def archive(directory,path):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(directory.rglob('*')):
            if f.is_file():z.write(f,f.relative_to(directory))
    with zipfile.ZipFile(path) as z:assert z.testzip() is None

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--directory',type=Path,required=True)
    ap.add_argument('--original-source',type=Path,required=True);ap.add_argument('--report',type=Path,required=True)
    ap.add_argument('--destination',type=Path,required=True);a=ap.parse_args()
    base=a.directory.resolve();dest=a.destination.resolve();old=a.original_source.resolve()
    checks=['results/supplemental_qa.json','results/qa/system_policy_report.json',
            'results/runtime_analysis/runtime_validation_qa.json','results/cli_smoke/qa.json',
            'qa/report_visual_review.json','qa/paper_consistency_qa.json']
    for f in checks:assert json.loads((base/f).read_text())['status']=='passed',f
    assert json.loads((base/'results/runtime/execution_manifest.json').read_text())['status']=='complete'
    assert (base/'overleaf_system_top3/main.tex').exists()
    dest.mkdir(parents=True,exist_ok=True)
    ignored=shutil.ignore_patterns('__pycache__','runtime_analyzer_fixture')
    for name in ['scripts','figures','results','overleaf_system_top3']:
        shutil.copytree(base/name,dest/name,dirs_exist_ok=True,ignore=ignored)
    (dest/'qa').mkdir(exist_ok=True)
    for f in (base/'qa').glob('*'):
        if f.is_file():shutil.copy2(f,dest/'qa'/f.name)
    for name in ['使用说明.txt','验证方案.txt']:shutil.copy2(base/name,dest/name)
    shutil.copy2(a.report,dest/a.report.name)
    source=dest/'sources/original_server_results';source.mkdir(parents=True,exist_ok=True)
    names=['inputs.csv','labels.csv','source_manifest.json','execution_manifest.json','qa.json','timing_qa.json','timing_query.csv']
    names += [f'predictions_seed_{seed}.csv' for seed in [20260904,20260905,20260906]]
    for name in names:shutil.copy2(old/name,source/name)
    (source/'query_mode').mkdir(exist_ok=True)
    for seed in [20260904,20260905,20260906]:
        name=f'predictions_seed_{seed}.csv';shutil.copy2(old/'query_mode'/name,source/'query_mode'/name)
    shutil.copy2(old.parents[1]/'scripts/run_system_experiment.py',dest/'scripts/run_system_experiment.py')
    archive(dest/'overleaf_system_top3',dest/'Overleaf英文系统覆盖件.zip')
    verification={'status':'passed','real_gpu_measurements':81,'existing_checkpoints':3,'formal_queries':220,
                  'candidate_pairs':6600,'maximum_returned':3,'system_model_scored_pairs':3063,
                  'new_labels_or_training':False,'cli_full_server_smoke':'passed','report_pages':4,
                  'paper_source_static_qa':'passed','full_paper_compilation':'Not verified; compile the supplied project in Overleaf',
                  'original_paper_and_models_preserved':True,'checks':checks}
    (dest/'交付验收.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2))
    hashes={str(f.relative_to(dest)):sha(f) for f in sorted(dest.rglob('*')) if f.is_file() and f.name!='文件校验.json'}
    (dest/'文件校验.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2))
    outer=dest.with_suffix('.zip');archive(dest,outer)
    with zipfile.ZipFile(outer) as z:
        for name,expected in hashes.items():assert hashlib.sha256(z.read(name)).hexdigest()==expected,name
    print(json.dumps({'folder':str(dest),'zip':str(outer),'verified_files':len(hashes),'crc_and_hashes':'passed'},ensure_ascii=False))

if __name__=='__main__':main()
