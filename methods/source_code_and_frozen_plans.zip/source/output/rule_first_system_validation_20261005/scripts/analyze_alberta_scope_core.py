#!/usr/bin/env python3
"""Read-only independent output QA for the Alberta scope-core diagnostic.

No inference, remote access, labels, threshold search, or semantic adjudication.
All old files are read only; exports are restricted to scope_core/analysis.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from itertools import combinations
import json
import math
from pathlib import Path
import re
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SEEDS = (20260904, 20260905, 20260906)
VARIANTS = ("raw", "cleaned", "scope_core")
THRESHOLDS = {20260904: 9.1875, 20260905: -1.453125, 20260906: 8.4375}
YEAR_N = {2024: 237, 2026: 264}
PAIR_N, POOL_N, QUERY_N = 67635, 270, 135
IDENTITY = ["pair_id", "evaluation_split", "query_id", "source_year", "candidate_id"]
TEXT_FIELDS = ("description", "normalized_description", "normalized_unit", "category", "spec_tokens")
CONTRACT = ["pair_id", "evaluation_split", "query_id", "candidate_id", "initial_rank", "retrieval_score",
            *[f"{side}_{suffix}" for side in ("query", "candidate") for suffix in TEXT_FIELDS]]
FORBIDDEN = {"label", "final_label", "final_relevance", "difficulty", "final_conflict_type",
             "prediction", "score", "model_logit", "gold_label", "is_match"}
STAGE = "class_abbreviation_expansion"


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def dump_csv(path, rows):
    frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
    frame.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n")


def text(value):
    return "" if value is None else str(value)


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def norm(value):
    return " ".join(text(value).strip().lower().split())


def canonical(value):
    return " ".join(re.sub(r"[^a-z0-9]+", " ", text(value).lower().replace("&", " and ")).split())


def jaccard(a, b):
    return len(a & b) / len(a | b) if a | b else 1.0


def serialized_hash(frame, side):
    """Independent copy of the frozen five-slot text format, SHA over JSONL strings."""
    digest = hashlib.sha256()
    columns = [f"{side}_{s}" for s in TEXT_FIELDS]
    for row in frame[columns].itertuples(index=False, name=None):
        d, n, u, c, s = (norm(v) for v in row)
        line = f"Description: {d}. Normalized: {n}. Pay unit: {u}. Category: {c}. Specs: {s}."
        digest.update((compact(line) + "\n").encode("utf-8"))
    return digest.hexdigest()


class Audit:
    def __init__(self):
        self.checks, self.integrity, self.original_hashes = [], [], {}

    def check(self, name, condition, details=""):
        require(condition, name)
        self.checks.append({"check": name, "status": "passed", "details": details})

    def verify(self, path, expected=None, role=""):
        path = Path(path).resolve()
        actual = sha(path)
        if expected is not None:
            self.check(f"SHA-256 {path.name}", actual == expected, role)
        if str(path) not in self.original_hashes:
            self.original_hashes[str(path)] = actual
            self.integrity.append({"path": str(path), "actual_sha256": actual,
                                   "expected_sha256": expected or "", "matches_expected": expected is None or actual == expected,
                                   "role": role, "read_only": True})
        else:
            self.check(f"unchanged between reads {path.name}", self.original_hashes[str(path)] == actual)
        return actual


def validate_inputs(args, audit):
    inputs_manifest = load_json(args.inputs / "input_manifest.json")
    frozen = load_json(args.source)
    raw = load_json(args.raw)
    source_audit = load_json(args.audit)
    audit.verify(args.inputs / "input_manifest.json", role="original full-pool input manifest")
    audit.verify(args.source, inputs_manifest["frozen_manifest_sha256"], "original frozen checkpoint/threshold provenance")
    audit.verify(args.raw, inputs_manifest["raw_items_sha256"], "original item values; no labels")
    audit.verify(args.audit, inputs_manifest["audit_summary_sha256"], "original deterministic rule audit")
    audit.verify(ROOT / "scripts/system_policy.py", inputs_manifest["serializer_policy_sha256"], "frozen serializer and policy")
    audit.verify(ROOT / "scripts/build_raw_alberta_model_inputs.py", inputs_manifest["builder_sha256"], "original input builder")
    for name in ("input_qa", "input_schema"):
        audit.verify(args.inputs / f"{name}.json", inputs_manifest[f"{name}_sha256"], "original input QA/schema")
    for wb in inputs_manifest["source_workbooks"]:
        audit.verify(wb["path"], wb["audit_sha256"], "source workbook bytes only; no parsing/writing")
    input_qa = load_json(args.inputs / "input_qa.json")
    audit.check("input creation passed with no labels/models/item-code matching", inputs_manifest["status"] == "passed" and
                inputs_manifest["labels_accessed"] is False and inputs_manifest["models_run"] is False and
                inputs_manifest["item_codes_used_for_matching"] is False and inputs_manifest["full_candidate_pools"] is True)
    audit.check("input QA complete and no labels/predictions", input_qa["status"] == "passed" and input_qa["pairs_per_variant"] == PAIR_N and
                input_qa["labels_read"] is False and input_qa["predictions_read"] is False)
    audit.check("frozen original seeds/thresholds/contract", tuple(int(r["seed"]) for r in frozen["runs"]) == SEEDS and
                {int(r["seed"]): float(r["threshold"]) for r in frozen["runs"]} == THRESHOLDS and
                frozen["inference_input_contract"] == CONTRACT == inputs_manifest["inference_input_contract"])
    audit.check("source import has no gold", source_audit["gold_labels_available"] is False)
    queries = {f"Q{int(q['item_number_metadata_only']):03d}": q for q in raw["queries"]}
    candidates = {f"{y}_R{int(c['source_row']):03d}": c for y in YEAR_N for c in raw["sources"][str(y)]}
    audit.check("complete unique source/query IDs", len(queries) == QUERY_N and len(candidates) == sum(YEAR_N.values()) and
                set(queries) == {f"Q{i:03d}" for i in range(1, 136)})
    frames = {}
    entries = {e["variant"]: e for e in inputs_manifest["outputs"]}
    for variant in ("raw", "cleaned"):
        path = args.inputs / f"inference_pairs_{variant}.csv"
        audit.verify(path, entries[variant]["sha256"], "original full-pool input CSV")
        frame = pd.read_csv(path, dtype=str, keep_default_na=False)
        audit.check(f"exact input schema/no forbidden columns {variant}", list(frame.columns) == inputs_manifest["columns"] and
                    list(frame.columns[:len(CONTRACT)]) == CONTRACT and not FORBIDDEN.intersection(frame.columns))
        audit.check(f"pair/source/pool ID uniqueness {variant}", len(frame) == PAIR_N and not frame.pair_id.duplicated().any() and
                    not frame.duplicated(["source_year", "query_id", "candidate_id"]).any() and
                    frame[["source_year", "query_id"]].drop_duplicates().shape[0] == POOL_N)
        audit.check(f"exhaustive unranked input metadata {variant}", frame.input_variant.eq(variant).all() and frame.initial_rank.eq("").all() and
                    frame.retrieval_score.eq("").all() and set(frame.query_id) == set(queries))
        expected_pid = "Alberta" + frame.source_year + "-" + frame.query_id + "-" + frame.candidate_id.str.split("_").str[-1]
        audit.check(f"pair/query/source row ID formulas {variant}", frame.pair_id.eq(expected_pid).all() and
                    frame.query_item_number.eq(frame.query_id.str[1:].astype(int).astype(str)).all() and
                    frame.candidate_source_id.eq(frame.candidate_id).all())
        for side, idfield, items in (("query", "query_id", queries), ("candidate", "candidate_id", candidates)):
            audit.check(f"empty unknown slots {variant}/{side}", frame[f"{side}_category"].eq("").all() and frame[f"{side}_spec_tokens"].eq("").all())
            fields = [c for c in frame if c.startswith(side + "_")]
            audit.check(f"source features constant by ID {variant}/{side}", frame.groupby(idfield)[fields].nunique().le(1).all().all())
            unique = frame.drop_duplicates(idfield).set_index(idfield)
            for field in ("description", "unit", "source_file", "source_sheet", "source_row", "description_cell", "unit_cell"):
                expected = unique.index.map(lambda i: text(items[i][field]))
                audit.check(f"raw source {field} preserved {variant}/{side}", np.array_equal(unique[f"{side}_{field}"].to_numpy(), expected))
            stage = STAGE if variant == "cleaned" else "case_space_punctuation"
            expected_d = unique.index.map(lambda i: items[i]["stage_keys"][stage]["description"])
            expected_u = unique.index.map(lambda i: items[i]["stage_keys"][stage]["unit"] if variant == "cleaned" else text(items[i]["unit"]))
            audit.check(f"audited normalized features {variant}/{side}", np.array_equal(unique[f"{side}_normalized_description"], expected_d) and
                        np.array_equal(unique[f"{side}_normalized_unit"], expected_u))
            audit.check(f"removed reference spans preserved {variant}/{side}", all(
                json.loads(row[f"{side}_removed_reference_spans_json"]) == items[item_id]["removed_reference_spans"]
                for item_id, row in unique.iterrows()))
        for year, count in YEAR_N.items():
            yearly = frame.loc[frame.source_year.eq(str(year))]
            audit.check(f"complete yearly candidate pools {variant}/{year}", len(yearly) == count * QUERY_N and
                        yearly.groupby("query_id").size().eq(count).all() and
                        set(yearly.candidate_id) == {i for i in candidates if i.startswith(str(year) + "_")} and
                        yearly.evaluation_split.eq(f"raw_alberta_{year}").all())
        frames[variant] = frame
    audit.check("raw/cleaned pair identity and original raw values retained", frames["raw"][IDENTITY].equals(frames["cleaned"][IDENTITY]) and
                frames["raw"][["query_description", "query_unit", "candidate_description", "candidate_unit"]].equals(
                    frames["cleaned"][["query_description", "query_unit", "candidate_description", "candidate_unit"]]))
    core = frames["cleaned"].copy()
    changed = {side: int(core[f"{side}_description"].ne(core[f"{side}_normalized_description"]).sum()) for side in ("query", "candidate")}
    for side in ("query", "candidate"):
        core[f"{side}_description"] = core[f"{side}_normalized_description"]
    core["input_variant"] = "scope_core"
    frames["scope_core"] = core
    unchanged_cols = [c for c in core if c not in ("query_description", "candidate_description", "input_variant")]
    audit.check("core transformation limited to Description and representation name", core[unchanged_cols].equals(frames["cleaned"][unchanged_cols]) and
                all(core[f"{s}_description"].equals(core[f"{s}_normalized_description"]) for s in ("query", "candidate")))
    clean = frames["cleaned"]
    exact = (clean.query_normalized_description.map(canonical).ne("") & clean.query_normalized_unit.map(norm).ne("") &
             clean.query_normalized_description.map(canonical).eq(clean.candidate_normalized_description.map(canonical)) &
             clean.query_normalized_unit.map(norm).eq(clean.candidate_normalized_unit.map(norm))).to_numpy()
    indices = clean.groupby(["source_year", "query_id"], sort=False).indices
    fixed = {key: set(clean.iloc[idx[exact[idx]]].candidate_id) for key, idx in indices.items()}
    rule_path = args.audit.parent / "per_query_matches.json"
    audit.verify(rule_path, role="frozen rule audit candidate IDs; no semantic labels")
    recorded_fixed = {(str(r["year"]), f"Q{int(r['query_item_number_metadata_only']):03d}"):
                      {f"{r['year']}_R{int(c['source_row']):03d}" for c in r["candidates"]}
                      for r in load_json(rule_path) if r["stage"] == STAGE}
    audit.check("independently reconstructed exact sets equal frozen rule audit", fixed == recorded_fixed)
    for year in YEAR_N:
        sets = [v for (y, _), v in fixed.items() if int(y) == year]
        audit.check(f"fixed rule {year}: 45 covered/90 uncovered/47 candidate IDs", len(sets) == QUERY_N and
                    sum(bool(v) for v in sets) == 45 and sum(not v for v in sets) == 90 and sum(len(v) for v in sets) == 47)
    representation = {"representation": "scope_core", "changed_description_slots": changed,
                      "derived_from_cleaned_sha256": entries["cleaned"]["sha256"],
                      "pair_n": PAIR_N, "pool_n": POOL_N, "query_n": QUERY_N,
                      "hash_format": "Ordered model-side strings encoded as compact JSON strings, UTF-8, newline delimited",
                      "query_serialized_sha256_independently_reconstructed": serialized_hash(core, "query"),
                      "candidate_serialized_sha256_independently_reconstructed": serialized_hash(core, "candidate"),
                      "raw_metadata_preserved_in_original_inputs": True,
                      "limitation": "Derived representation hashes are analyzer exports; execution manifest has no transformed-serialization hash to compare."}
    return inputs_manifest, frozen, frames, queries, candidates, indices, fixed, representation


def validate_manifest(args, audit, inputs_manifest, frozen, representation, core=False):
    directory = args.runs if core else args.original_runs
    manifest = load_json(directory / "execution_manifest.json")
    audit.verify(directory / "execution_manifest.json", role="completed core execution manifest" if core else "original six-condition manifest")
    audit.verify(args.inputs / "input_manifest.json", manifest["input_manifest_sha256"], "input manifest linked to execution")
    audit.verify(args.source, manifest["source_manifest_sha256"], "frozen manifest linked to execution")
    runner = ROOT / "scripts" / ("run_alberta_scope_core.py" if core else "run_alberta_frozen_models.py")
    audit.verify(runner, manifest["script_sha256"], "exact executed runner bytes")
    audit.verify(ROOT / "scripts/system_policy.py", manifest["policy_sha256"], "exact frozen policy bytes")
    if core:
        audit.verify(ROOT / "scripts/run_alberta_frozen_models.py", manifest["original_runner_sha256"], "shared original input loader bytes")
    audit.check(f"{'core' if core else 'original'} exact source checkpoint plan", manifest["source_runs"] == frozen["runs"])
    wanted = {(s, "scope_core") for s in SEEDS} if core else {(s, v) for s in SEEDS for v in ("raw", "cleaned")}
    completed = manifest["completed_conditions"]
    audit.check(f"{'core' if core else 'original'} completed expected unique conditions", manifest["status"] == "complete" and
                len(completed) == len(wanted) and {(int(c["seed"]), c["variant"]) for c in completed} == wanted)
    for flag in ("labels_accessed", "labels_available", "training_performed", "thresholds_retuned"):
        audit.check(f"{'core' if core else 'original'} {flag}=false", manifest[flag] is False)
    entries = {e["variant"]: e for e in inputs_manifest["outputs"]}
    audit.check(f"{'core' if core else 'original'} original CSV hashes recorded", len(manifest["input_csvs"]) == 2 and
                all(e["sha256"] == entries[e["variant"]]["sha256"] and int(e["pairs"]) == PAIR_N and
                    int(e["year_query_pools"]) == POOL_N for e in manifest["input_csvs"]))
    audit.check(f"{'core' if core else 'original'} frozen batch/length", manifest["batch_size"] == 64 and manifest["max_length"] == 256)
    if core:
        audit.check("core representation/counts/changed slots", manifest["representation"] == "scope_core" and
                    manifest["pair_n"] == PAIR_N and manifest["pool_n"] == POOL_N and manifest["query_n"] == QUERY_N and
                    manifest["changed_description_slots"] == representation["changed_description_slots"])
        audit.verify(directory / "query_recommendation_summary.csv", manifest["query_summary_sha256"], "core query summary bytes")
    else:
        audit.check("original exact full-pool counts", manifest["pairs_per_condition"] == PAIR_N and manifest["year_query_pools_per_condition"] == POOL_N and
                    manifest["unique_bid_items"] == QUERY_N and {int(k): int(v) for k, v in manifest["source_count_by_year"].items()} == YEAR_N)
        audit.verify(directory / "query_recommendation_summary.csv", manifest["query_recommendation_summary_sha256"], "original query summary bytes")
        audit.verify(directory / "run_qa.json", manifest["run_qa_sha256"], "original execution QA bytes")
        remote_qa = load_json(directory / "run_qa.json")
        for flag in ("labels_accessed", "labels_available", "gold_metrics_computed", "training_performed", "thresholds_retuned"):
            audit.check(f"original execution QA {flag}=false", remote_qa[flag] is False)
        audit.check("original recorded checkpoint byte checks", len(manifest["model_loads"]) == 3 and
                    all(r["checkpoint_hashes_verified"] is True for r in manifest["model_loads"]))
    audit.verify(directory / "timing.csv", manifest["timing_sha256"], "actual full-pass timing bytes")
    timing = pd.read_csv(directory / "timing.csv", keep_default_na=False, float_precision="round_trip")
    summary = pd.read_csv(directory / "query_recommendation_summary.csv", keep_default_na=False, float_precision="round_trip")
    audit.check(f"{'core' if core else 'original'} timing one actual observation/condition", len(timing) == len(wanted) and
                not timing.duplicated(["seed", "variant"]).any() and set(zip(timing.seed.astype(int), timing.variant)) == wanted and
                timing.repeat.eq(0).all() and timing.pairs.eq(PAIR_N).all() and timing.batch_size.eq(64).all() and
                np.isfinite(timing.seconds).all() and timing.seconds.gt(0).all() and
                np.isfinite(timing.model_load_seconds).all() and timing.model_load_seconds.gt(0).all())
    audit.check(f"{'core' if core else 'original'} timing query/pool counts", (timing.queries.eq(QUERY_N).all() and timing.pools.eq(POOL_N).all()) if core else
                (timing.unique_bid_items.eq(QUERY_N).all() and timing.year_query_pools.eq(POOL_N).all() and timing.model_batches.eq(math.ceil(PAIR_N / 64)).all()))
    audit.check(f"{'core' if core else 'original'} unique full query summaries", len(summary) == POOL_N * len(wanted) and
                not summary.duplicated(["seed", "variant", "source_year", "query_id"]).any())
    return manifest, timing, summary


def analyze_conditions(directory, manifest, timing, summary, frames, queries, candidates, indices, fixed, audit):
    structures, per_query, returned_rows, stats, boundaries = {}, [], [], [], []
    for condition in manifest["completed_conditions"]:
        seed, variant = int(condition["seed"]), condition["variant"]
        threshold = THRESHOLDS[seed]
        frame = frames[variant]
        path = directory / condition["prediction_file"]
        require(path.resolve().parent == directory.resolve(), "Prediction filename escapes expected results directory")
        audit.verify(path, condition["prediction_sha256"], "actual scored predictions, read only")
        pred = pd.read_csv(path, dtype={c: str for c in IDENTITY}, keep_default_na=False, float_precision="round_trip")
        audit.check(f"{variant}/{seed} expected prediction columns", list(pred.columns) == [*IDENTITY, "seed", "variant", "threshold", "score", "prediction", "returned_rank"])
        audit.check(f"{variant}/{seed} input bijection/identity/order", len(pred) == PAIR_N and not pred.pair_id.duplicated().any() and
                    pred[IDENTITY].equals(frame[IDENTITY]))
        audit.check(f"{variant}/{seed} frozen metadata/threshold", pred.seed.eq(seed).all() and pred.variant.eq(variant).all() and pred.threshold.eq(threshold).all() and
                    float(condition["threshold"]) == threshold)
        scores = pred.score.to_numpy(float)
        audit.check(f"{variant}/{seed} finite scores/threshold decisions", np.isfinite(scores).all() and
                    np.array_equal(pred.prediction.to_numpy(), (scores >= threshold).astype(int)))
        ranks = np.zeros(PAIR_N, dtype=int)
        rows = []
        for (year, query_id), idx in indices.items():
            pool = pred.iloc[idx]
            # Independent dataframe sorting; never call the scoring policy or runner.
            chosen = pool.loc[pool.score.ge(threshold)].sort_values(["score", "candidate_id"], ascending=[False, True], kind="stable").head(3)
            ranks[chosen.index] = np.arange(1, len(chosen) + 1)
            ids = tuple(chosen.candidate_id)
            accepted_ids = set(pool.loc[pool.score.ge(threshold)].candidate_id)
            exact_ids = fixed[(year, query_id)]
            expected = summary.loc[summary.seed.eq(seed) & summary.variant.eq(variant) & summary.source_year.eq(int(year)) & summary.query_id.eq(query_id)]
            require(len(expected) == 1, "Summary pool must have exactly one row")
            expected = expected.iloc[0]
            require(int(expected.candidate_count) == len(pool) and int(expected.above_threshold_candidates) == len(accepted_ids) and
                    int(expected.returned_recommendations) == len(ids) and float(expected.maximum_logit) == float(pool.score.max()) and
                    float(expected.threshold) == threshold and expected.evaluation_split == f"raw_alberta_{year}", "Independent query summary reconstruction differs")
            item = queries[query_id]
            rec = {"seed": seed, "variant": variant, "source_year": int(year), "query_id": query_id,
                   "query_raw_description": item["description"], "query_raw_unit": text(item["unit"]),
                   "query_source_file": item["source_file"], "query_source_sheet": item["source_sheet"], "query_source_row": item["source_row"],
                   "query_description_cell": item["description_cell"], "query_unit_cell": item["unit_cell"],
                   "query_description_model_slot": frame.iloc[idx[0]].query_description,
                   "query_normalized_description_model_slot": frame.iloc[idx[0]].query_normalized_description,
                   "query_normalized_unit_model_slot": frame.iloc[idx[0]].query_normalized_unit,
                   "candidate_pool_size": len(pool), "frozen_threshold": threshold,
                   "maximum_logit": float(pool.score.max()), "maximum_logit_minus_threshold": float(pool.score.max()) - threshold,
                   "above_threshold_candidates": len(accepted_ids), "returned_recommendations": len(ids),
                   "returned_candidate_ids_json": compact(ids), "fixed_rule_covered": bool(exact_ids),
                   "fixed_rule_candidate_ids_json": compact(sorted(exact_ids)), "fixed_rule_candidate_count": len(exact_ids),
                   "fixed_rule_candidates_above_threshold": len(exact_ids & accepted_ids), "fixed_rule_candidates_returned": len(exact_ids & set(ids))}
            rows.append(rec)
            structures[(variant, seed, year, query_id)] = {"returned": ids, "accepted": accepted_ids}
            for rank, (_, chosen_row) in enumerate(chosen.iterrows(), 1):
                candidate = candidates[chosen_row.candidate_id]
                returned_rows.append({"seed": seed, "variant": variant, "source_year": int(year), "query_id": query_id,
                                      "query_raw_description": item["description"], "query_raw_unit": text(item["unit"]),
                                      "query_source_row": item["source_row"], "candidate_id": chosen_row.candidate_id,
                                      "returned_rank": rank, "score": float(chosen_row.score), "threshold": threshold,
                                      "candidate_raw_description": candidate["description"], "candidate_raw_unit": text(candidate["unit"]),
                                      "candidate_source_file": candidate["source_file"], "candidate_source_sheet": candidate["source_sheet"],
                                      "candidate_source_row": candidate["source_row"], "candidate_description_cell": candidate["description_cell"],
                                      "candidate_unit_cell": candidate["unit_cell"], "fixed_rule_exact_candidate": chosen_row.candidate_id in exact_ids})
        audit.check(f"{variant}/{seed} deterministic score-desc/ID-asc top-three", np.array_equal(ranks, pred.returned_rank.to_numpy()) and
                    pred.returned_rank.isin([0, 1, 2, 3]).all())
        audit.check(f"{variant}/{seed} all query summaries recomputed", len(rows) == POOL_N)
        t = timing.loc[timing.seed.eq(seed) & timing.variant.eq(variant)].iloc[0]
        audit.check(f"{variant}/{seed} timing linked to manifest/threshold", float(t.seconds) == float(condition["seconds"]) and float(t.threshold) == threshold)
        if variant != "scope_core":
            load = next(r for r in manifest["model_loads"] if int(r["seed"]) == seed)
            audit.check(f"{variant}/{seed} model loading time linked", float(t.model_load_seconds) == float(load["seconds"]))
        for year in YEAR_N:
            subset = [r for r in rows if r["source_year"] == year]
            covered = [r for r in subset if r["fixed_rule_covered"]]
            uncovered = [r for r in subset if not r["fixed_rule_covered"]]
            stats.append({"seed": seed, "variant": variant, "source_year": year, "threshold": threshold,
                          "query_pools": len(subset), "scored_pairs": YEAR_N[year] * QUERY_N,
                          "nonempty_queries": sum(r["returned_recommendations"] > 0 for r in subset),
                          "empty_queries": sum(r["returned_recommendations"] == 0 for r in subset),
                          "above_threshold_candidates": sum(r["above_threshold_candidates"] for r in subset),
                          "returned_recommendations": sum(r["returned_recommendations"] for r in subset),
                          "fixed_rule_covered_queries": len(covered), "fixed_rule_uncovered_queries": len(uncovered),
                          "rule_covered_nonempty_queries": sum(r["returned_recommendations"] > 0 for r in covered),
                          "rule_uncovered_nonempty_queries": sum(r["returned_recommendations"] > 0 for r in uncovered),
                          "rule_covered_queries_with_exact_candidate_returned": sum(r["fixed_rule_candidates_returned"] > 0 for r in covered),
                          "fixed_rule_candidates_above_threshold": sum(r["fixed_rule_candidates_above_threshold"] for r in subset),
                          "fixed_rule_candidates_returned": sum(r["fixed_rule_candidates_returned"] for r in subset),
                          "rule_or_model_nonempty_union_queries": 45 + sum(r["returned_recommendations"] > 0 for r in uncovered),
                          **{f"queries_returning_{n}": sum(r["returned_recommendations"] == n for r in subset) for n in range(4)}})
            y_scores = pred.loc[pred.source_year.eq(str(year)), "score"].to_numpy(float)
            y_returned = pred.loc[pred.source_year.eq(str(year)) & pred.returned_rank.gt(0)]
            boundaries.append({"seed": seed, "variant": variant, "source_year": year, "frozen_threshold": threshold,
                               "scored_pairs": len(y_scores), "minimum_logit": float(y_scores.min()), "median_logit": float(np.median(y_scores)),
                               "maximum_logit": float(y_scores.max()), "pairs_exactly_equal_threshold": int((y_scores == threshold).sum()),
                               "pairs_at_threshold_accepted": int((y_scores == threshold).sum()),
                               "maximum_accepted_candidates_in_pool": max(r["above_threshold_candidates"] for r in subset),
                               "pools_with_more_than_three_accepted_candidates": sum(r["above_threshold_candidates"] > 3 for r in subset),
                               "pools_with_tied_returned_logits": sum(g.score.duplicated().any() for _, g in y_returned.groupby("query_id")),
                               "interpretation": "Within-checkpoint range only; checkpoint score scales are not directly comparable"})
        per_query.extend(rows)
    return structures, per_query, returned_rows, stats, boundaries


def compare_outputs(structures, indices, fixed):
    agreement, pairwise, differences = [], [], []
    for variant in VARIANTS:
        for (year, query_id), _ in indices.items():
            st = [structures[(variant, seed, year, query_id)] for seed in SEEDS]
            lists, accepted = [r["returned"] for r in st], [r["accepted"] for r in st]
            sets = [set(v) for v in lists]
            nonempty = [bool(v) for v in lists]
            agreement.append({"variant": variant, "source_year": int(year), "query_id": query_id, "fixed_rule_covered": bool(fixed[(year, query_id)]),
                              "models_with_recommendations": sum(nonempty), "all_models_empty": not any(nonempty), "all_models_nonempty": all(nonempty),
                              "mixed_nonempty_status": len(set(nonempty)) > 1, "ordered_lists_identical": len(set(lists)) == 1,
                              "returned_sets_identical": sets[0] == sets[1] == sets[2], "accepted_sets_identical": accepted[0] == accepted[1] == accepted[2],
                              "top1_same_all_three_nonempty": all(nonempty) and len({v[0] for v in lists}) == 1,
                              "returned_three_seed_intersection": len(set.intersection(*sets)), "returned_three_seed_union": len(set.union(*sets)),
                              "mean_pairwise_returned_jaccard": float(np.mean([jaccard(sets[i], sets[j]) for i, j in combinations(range(3), 2)])),
                              **{f"seed_{seed}_returned_ids_json": compact(r["returned"]) for seed, r in zip(SEEDS, st)}})
            for i, j in combinations(range(3), 2):
                pairwise.append({"variant": variant, "source_year": int(year), "query_id": query_id, "seed_a": SEEDS[i], "seed_b": SEEDS[j],
                                 "ordered_lists_equal": lists[i] == lists[j], "nonempty_status_equal": nonempty[i] == nonempty[j],
                                 "returned_intersection": len(sets[i] & sets[j]), "returned_union": len(sets[i] | sets[j]),
                                 "returned_jaccard": jaccard(sets[i], sets[j]), "accepted_jaccard": jaccard(accepted[i], accepted[j])})
    for seed in SEEDS:
        for (year, query_id), _ in indices.items():
            for before, after in (("raw", "cleaned"), ("raw", "scope_core"), ("cleaned", "scope_core")):
                a, b = structures[(before, seed, year, query_id)], structures[(after, seed, year, query_id)]
                sa, sb = set(a["returned"]), set(b["returned"])
                differences.append({"seed": seed, "source_year": int(year), "query_id": query_id, "before_variant": before, "after_variant": after,
                                    "fixed_rule_covered": bool(fixed[(year, query_id)]), "before_nonempty": bool(sa), "after_nonempty": bool(sb),
                                    "gains_nonempty": bool(sb) and not bool(sa), "loses_nonempty": bool(sa) and not bool(sb),
                                    "ordered_lists_identical": a["returned"] == b["returned"], "returned_sets_identical": sa == sb,
                                    "before_returned_n": len(sa), "after_returned_n": len(sb), "before_accepted_n": len(a["accepted"]), "after_accepted_n": len(b["accepted"]),
                                    "returned_intersection": len(sa & sb), "returned_union": len(sa | sb), "returned_jaccard": jaccard(sa, sb),
                                    "accepted_jaccard": jaccard(a["accepted"], b["accepted"]), "added_returned_ids_json": compact(sorted(sb - sa)),
                                    "removed_returned_ids_json": compact(sorted(sa - sb)), "before_returned_ids_json": compact(a["returned"]), "after_returned_ids_json": compact(b["returned"])})
    agreement, differences = pd.DataFrame(agreement), pd.DataFrame(differences)
    agreement_summary, difference_summary = [], []
    for (variant, year), g in agreement.groupby(["variant", "source_year"], sort=False):
        any_nonempty = g.loc[~g.all_models_empty]
        agreement_summary.append({"variant": variant, "source_year": int(year), "query_pools": len(g),
                                  "all_models_empty_queries": int(g.all_models_empty.sum()), "all_models_nonempty_queries": int(g.all_models_nonempty.sum()),
                                  "mixed_nonempty_status_queries": int(g.mixed_nonempty_status.sum()), "ordered_lists_identical_queries": int(g.ordered_lists_identical.sum()),
                                  "ordered_lists_identical_among_any_nonempty": int(any_nonempty.ordered_lists_identical.sum()), "any_model_nonempty_queries": len(any_nonempty),
                                  "returned_sets_identical_queries": int(g.returned_sets_identical.sum()), "top1_same_all_three_nonempty_queries": int(g.top1_same_all_three_nonempty.sum()),
                                  "rule_uncovered_any_model_nonempty_queries": int((~g.fixed_rule_covered & ~g.all_models_empty).sum()),
                                  "mean_returned_jaccard_all_queries": float(g.mean_pairwise_returned_jaccard.mean()),
                                  "mean_returned_jaccard_any_nonempty": float(any_nonempty.mean_pairwise_returned_jaccard.mean()) if len(any_nonempty) else None})
    for (seed, year, before, after), g in differences.groupby(["seed", "source_year", "before_variant", "after_variant"], sort=False):
        difference_summary.append({"seed": int(seed), "source_year": int(year), "before_variant": before, "after_variant": after, "query_pools": len(g),
                                   "before_nonempty_queries": int(g.before_nonempty.sum()), "after_nonempty_queries": int(g.after_nonempty.sum()),
                                   "gains_nonempty_queries": int(g.gains_nonempty.sum()), "loses_nonempty_queries": int(g.loses_nonempty.sum()),
                                   "ordered_lists_identical_queries": int(g.ordered_lists_identical.sum()), "returned_sets_identical_queries": int(g.returned_sets_identical.sum()),
                                   "rule_uncovered_gains_nonempty_queries": int((~g.fixed_rule_covered & g.gains_nonempty).sum()),
                                   "rule_uncovered_loses_nonempty_queries": int((~g.fixed_rule_covered & g.loses_nonempty).sum()),
                                   "returned_candidate_intersections_sum": int(g.returned_intersection.sum()), "returned_candidate_unions_sum": int(g.returned_union.sum()),
                                   "mean_returned_jaccard": float(g.returned_jaccard.mean()), "mean_accepted_jaccard": float(g.accepted_jaccard.mean())})
    return agreement, pd.DataFrame(agreement_summary), pairwise, differences, pd.DataFrame(difference_summary)


def analyze(args):
    require(args.output.resolve() == (args.runs / "analysis").resolve(), "Exports must stay in scope-core results/analysis")
    audit = Audit()
    inputs_manifest, frozen, frames, queries, candidates, indices, fixed, representation = validate_inputs(args, audit)
    original_manifest, original_timing, original_summary = validate_manifest(args, audit, inputs_manifest, frozen, representation)
    baseline = analyze_conditions(args.original_runs, original_manifest, original_timing, original_summary, frames, queries, candidates, indices, fixed, audit)
    prior_qa_path = args.original_runs / "analysis/analysis_validation_qa.json"
    if prior_qa_path.exists():
        audit.verify(prior_qa_path, role="original six-condition independent analysis QA")
        prior_qa = load_json(prior_qa_path)
        audit.check("original independent QA passed without gold/semantic metrics", prior_qa["status"] == "passed" and
                    prior_qa["gold_metrics_computed"] is False and prior_qa["semantic_quality_computed"] is False and
                    prior_qa["labels_accessed"] is False and prior_qa["original_files_changed"] is False)
        audit.verify(ROOT / "scripts/analyze_alberta_frozen_models.py", prior_qa["analysis_script_sha256"], "original independent analyzer bytes")
        for entry in prior_qa["outputs"]:
            path = prior_qa_path.parent / entry["name"]
            require(path.resolve().parent == prior_qa_path.parent.resolve(), "Old analysis output filename escapes its directory")
            audit.verify(path, entry["sha256"], "unchanged previously hashed original analysis export")
    # Snapshot all old result artifacts, including previously prepared analysis exports.
    for path in sorted(args.original_runs.rglob("*")):
        if path.is_file() and str(path.resolve()) not in audit.original_hashes:
            audit.verify(path, role="unchanged original model-run or analysis artifact")
    if args.preflight:
        audit.check("all read-only original files unchanged", all(sha(p) == h for p, h in audit.original_hashes.items()))
        print(compact({"status": "baseline_preflight_passed", "checks": len(audit.checks), "conditions": 6,
                       "core_inputs_reconstructed": True, "changed_description_slots": representation["changed_description_slots"],
                       "baseline_stats": baseline[3]}))
        return
    core_manifest, core_timing, core_summary = validate_manifest(args, audit, inputs_manifest, frozen, representation, core=True)
    core = analyze_conditions(args.runs, core_manifest, core_timing, core_summary, frames, queries, candidates, indices, fixed, audit)
    structures = {**baseline[0], **core[0]}
    per_query = pd.DataFrame(baseline[1] + core[1])
    returned = pd.DataFrame(baseline[2] + core[2])
    stats = pd.DataFrame(baseline[3] + core[3]).sort_values(["seed", "source_year", "variant"])
    boundary = pd.DataFrame(baseline[4] + core[4]).sort_values(["seed", "source_year", "variant"])
    agreement, agreement_stats, pairwise, differences, difference_stats = compare_outputs(structures, indices, fixed)
    audit.check("all nine conditions/2430 query pools/returned cardinality", len(structures) == 9 * POOL_N and len(per_query) == 9 * POOL_N and
                len(core[1]) == 3 * POOL_N and len(returned) == int(per_query.returned_recommendations.sum()))
    # Reconfirm pre-existing six-condition summaries without trusting them for calculations.
    old_stats_path = args.original_runs / "analysis/output_summary_by_seed_variant_year.csv"
    if old_stats_path.exists():
        old_stats = pd.read_csv(old_stats_path, keep_default_na=False)
        replicated = stats.loc[stats.variant.isin(["raw", "cleaned"])]
        for row in replicated.itertuples(index=False):
            old = old_stats.loc[old_stats.seed.eq(row.seed) & old_stats.variant.eq(row.variant) & old_stats.source_year.eq(row.source_year)]
            require(len(old) == 1, "Unique old summary row missing")
            old = old.iloc[0]
            require(int(old.queries_with_model_recommendations) == row.nonempty_queries and int(old.returned_recommendations) == row.returned_recommendations and
                    int(old.rule_uncovered_model_nonempty_queries) == row.rule_uncovered_nonempty_queries, "Old summary differs from independent baseline reconstruction")
        audit.check("old descriptive summary independently replicated", len(replicated) == 12)
    timing = pd.concat([original_timing, core_timing], ignore_index=True, sort=False)
    timing_descriptive = []
    ranges = []
    for (variant, year), g in stats.groupby(["variant", "source_year"], sort=False):
        ranges.append({"variant": variant, "source_year": int(year), "frozen_models": 3,
                       "nonempty_queries_min": int(g.nonempty_queries.min()), "nonempty_queries_max": int(g.nonempty_queries.max()),
                       "returned_recommendations_min": int(g.returned_recommendations.min()), "returned_recommendations_max": int(g.returned_recommendations.max()),
                       "rule_uncovered_nonempty_queries_min": int(g.rule_uncovered_nonempty_queries.min()), "rule_uncovered_nonempty_queries_max": int(g.rule_uncovered_nonempty_queries.max()),
                       "interpretation": "Descriptive range across frozen checkpoints; no quality or uncertainty estimate"})
    for variant, g in timing.groupby("variant", sort=False):
        timing_descriptive.append({"variant": variant, "actual_observations": len(g), "passes_per_condition": 1,
                                   "mean_full_pass_seconds": float(g.seconds.mean()), "minimum_full_pass_seconds": float(g.seconds.min()),
                                   "maximum_full_pass_seconds": float(g.seconds.max()), "confidence_intervals_computed": False,
                                   "interpretation": "Three distinct checkpoint single passes; descriptive mean, no repeated-run uncertainty"})
    args.output.mkdir(parents=True, exist_ok=True)
    exports = {"output_summary_by_seed_variant_year.csv": stats, "output_ranges_across_three_seeds.csv": ranges,
               "per_query_output_diagnostics.csv": per_query, "returned_recommendations_all_variants.csv": returned,
               "score_and_threshold_boundary_ranges.csv": boundary, "three_seed_agreement_per_query.csv": agreement,
               "three_seed_agreement_summary.csv": agreement_stats, "three_seed_pairwise_per_query.csv": pairwise,
               "representation_differences_per_query.csv": differences, "representation_differences_summary.csv": difference_stats,
               "actual_full_pass_timing_all_variants.csv": timing, "timing_descriptive_three_model_summary.csv": timing_descriptive}
    for filename, value in exports.items():
        dump_csv(args.output / filename, value)
    for seed in SEEDS:
        dump_csv(args.output / f"scope_core_recommendations_seed_{seed}.csv", per_query.loc[per_query.variant.eq("scope_core") & per_query.seed.eq(seed)])
    dump_csv(args.output / "returned_recommendations_scope_core.csv", returned.loc[returned.variant.eq("scope_core")])
    write_json(args.output / "representation_reconstruction.json", representation)
    lines = ["Alberta scope-core：独立输出核验与表示诊断", "",
             "本次 scope-core 为事后研究诊断：将 cleaned 输入的 Description 槽替换为已经清理的 Normalized description；Normalized description、规范化单位、空类别与空规格槽保持原值。原文、单位、删除的规范/桥号跨度、来源行号仍保留在原始 SHA-256 锁定 CSV 和 raw_items.json 中。",
             "三个原冻结 checkpoint 各完成一次真实 GPU 全池推理，每条件 67,635 对、270 个年度查询池、135 条实际投标项。2024 年目录 237 条，2026 年 264 条。三个原阈值为 20260904=9.1875、20260905=-1.453125、20260906=8.4375；没有在 Alberta 上训练、重新校准或搜索阈值。", "",
             "没有 Alberta 人工确认金标准；本分析未读取人工标注或计算 accuracy、precision、recall、F1、语义正确率。‘有输出’仅指至少一条候选达到冻结阈值并进入至多三条审阅建议。输出增减、重叠或种子一致性不能直接解释为质量提升或下降。",
             "独立检查从原始全池输入、冻结 manifest 和预测文件重算：SHA-256；逐行 pair/query/year/source-row ID 及候选全集；来源描述/单位/文件/工作表/行/单元格；有限分数；prediction=(score>=原阈值)；按分数降序、候选 ID 升序解并列的 Top-3；全部 2,430 条查询摘要；实际计时与完成条件的一致性。旧 six-run 文件与旧分析文件均在结束后重算哈希确认未变。",
             "核心表示从原始 cleaned CSV 独立重建，Description 改动槽数为 query=" + str(representation["changed_description_slots"]["query"]) + "，candidate=" + str(representation["changed_description_slots"]["candidate"]) + "。派生序列化哈希见 representation_reconstruction.json；运行器没有保存转换后序列化哈希，因此这些哈希没有独立运行产物可作逐字节对照。",
             "执行 manifest 的完整源模型计划和 checkpoint 哈希条目与原冻结来源完全相同，且实际运行脚本字节与 manifest 记录相同。本地没有远端 checkpoint，分析没有独立重哈希模型权重或重运行模型。核心运行脚本在加载前逐文件哈希核对 checkpoint；本报告不将脚本核验等同于本地权重独立复核。", "",
             "各种子、年度与表示的非空查询/接受候选/实际返回数量：",
             stats[["seed", "variant", "source_year", "nonempty_queries", "empty_queries", "above_threshold_candidates", "returned_recommendations"]].to_string(index=False), "",
             "固定 deterministic cleaned exact 规则每年度覆盖 45 条查询、未覆盖 90 条；覆盖查询含 47 条 exact 候选。以下只记录模型对规则覆盖或未覆盖查询是否产生建议，规则未充当金标准：",
             stats[["seed", "variant", "source_year", "rule_covered_nonempty_queries", "rule_uncovered_nonempty_queries", "fixed_rule_candidates_returned", "rule_or_model_nonempty_union_queries"]].to_string(index=False), "",
             "种子间稳定性同时保留空列表一致的总体分母，以及至少一个模型有输出的子集分母：",
             agreement_stats[["variant", "source_year", "all_models_empty_queries", "all_models_nonempty_queries", "mixed_nonempty_status_queries", "ordered_lists_identical_queries", "ordered_lists_identical_among_any_nonempty", "any_model_nonempty_queries"]].to_string(index=False), "",
             "raw/cleaned/core 逐查询和年度差异：",
             difference_stats[["seed", "source_year", "before_variant", "after_variant", "gains_nonempty_queries", "loses_nonempty_queries", "ordered_lists_identical_queries", "rule_uncovered_gains_nonempty_queries", "rule_uncovered_loses_nonempty_queries"]].to_string(index=False), "",
             "集合 Jaccard 为交集/并集，双方空定义为 1。差异表给出新增/移除 ID 与有序列表，种子表给出 Top-3 集合交并集；以上是描述性行为统计。output_ranges_across_three_seeds.csv 给出输出数量跨模型范围；score_and_threshold_boundary_ranges.csv 给出每模型、每年度的分数范围和阈值相等边界。不同 checkpoint 的分数尺度不能直接比较。", "",
             "实际完整推理时间（每条件 repeat=0，仅一次；包括序列化、分词、同步 GPU 评分、阈值判断和排序，排除预热、加载、文件 I/O 和校验）：",
             timing[["seed", "variant", "threshold", "seconds", "model_load_seconds", "pairs", "repeat"]].to_string(index=False), "",
             "三个冻结模型单次观测的描述性均值与范围：",
             pd.DataFrame(timing_descriptive)[["variant", "actual_observations", "mean_full_pass_seconds", "minimum_full_pass_seconds", "maximum_full_pass_seconds"]].to_string(index=False),
             "没有计算计时置信区间、货币成本或逐查询独立延迟；没有将表示之间的运行秒数变化归因为单一因素。实际硬件/精度沿执行 manifest：" + text(core_manifest.get("gpu", "")) + "；" + text(core_manifest.get("precision", "")) + "。", "",
             "核心建议来源长表见 returned_recommendations_scope_core.csv，保留源查询原文/单位/行和候选原文/单位/工作表/行/单元格。查询级导出每种子 270 行，保留零输出池。完整比较表包含九个条件。源价格未用作评分、规则判定或本分析指标。",
             "本分析脚本只读已完成本地结果，不导入 torch/transformers、不访问 GPU/远端、不读取 gold；所有产物写入 raw_alberta_scope_core/analysis。"]
    report = args.output / "Alberta_scope_core_独立输出核验与比较报告.txt"
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    audit.check("all old source/input/run/analysis bytes unchanged after exports", all(sha(p) == h for p, h in audit.original_hashes.items()),
                f"{len(audit.original_hashes)} read-only files rehashed")
    dump_csv(args.output / "file_integrity_verified.csv", audit.integrity)
    dump_csv(args.output / "validation_checks.csv", audit.checks)
    outputs = [{"name": p.name, "sha256": sha(p), "bytes": p.stat().st_size} for p in sorted(args.output.iterdir())
               if p.is_file() and p.name != "analysis_validation_qa.json"]
    qa = {"status": "passed", "schema": "alberta-scope-core-output-only-independent-analysis-v1", "created_utc": datetime.now(timezone.utc).isoformat(),
          "analysis_script_sha256": sha(__file__), "analysis_python": sys.executable, "core_conditions": 3, "comparison_conditions": 9,
          "pairs_per_condition": PAIR_N, "core_scored_pairs": PAIR_N * 3, "comparison_scored_pairs": PAIR_N * 9,
          "year_query_pools_per_condition": POOL_N, "core_per_query_rows": len(core[1]), "comparison_per_query_rows": len(per_query),
          "core_returned_recommendation_rows": len(core[2]), "candidate_counts_by_year": YEAR_N,
          "fixed_rule_covered_queries_by_year": {y: 45 for y in YEAR_N}, "fixed_rule_uncovered_queries_by_year": {y: 90 for y in YEAR_N},
          "checks_passed": len(audit.checks), "read_only_files_rehashed": len(audit.original_hashes),
          "labels_available": False, "labels_accessed": False, "human_annotation_values_read": False, "gold_metrics_computed": False,
          "semantic_quality_computed": False, "models_executed_by_analysis": False, "remote_access_used": False, "training_performed": False,
          "thresholds_retuned": False, "original_files_changed": False, "prediction_threshold_rank_summary_independently_verified": True,
          "checkpoint_provenance": {"frozen_run_entries_match_exactly": True, "executed_runner_script_hash_matches": True,
                                    "core_runner_contains_preload_byte_checks": True, "checkpoint_bytes_independently_rehashed_locally": False},
          "transformed_serialization_hash_independently_comparable_to_run": False,
          "actual_full_timing_passes_per_condition": 1, "timing_confidence_intervals_computed": False, "monetary_cost_computed": False,
          "outputs": outputs, "limitations": ["No adjudicated Alberta gold; outputs are unverified review suggestions.",
          "Original validation thresholds transferred unchanged; deployment inputs can differ from validation.",
          "No independently comparable transformed-serialization hash was exported by the actual runner.",
          "Remote checkpoint bytes are unavailable locally; provenance and actual runner bytes were audited, not weights re-executed.",
          "One actual full inference pass per condition; across-model means/ranges are descriptive."]}
    write_json(args.output / "analysis_validation_qa.json", qa)
    print(compact({"status": "passed", "checks": len(audit.checks), "core_returned_rows": len(core[2]), "report": str(report),
                   "core_stats": stats.loc[stats.variant.eq("scope_core")].to_dict("records")}))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--runs", type=Path, default=ROOT / "results/raw_alberta_scope_core")
    ap.add_argument("--original-runs", type=Path, default=ROOT / "results/raw_alberta_models")
    ap.add_argument("--inputs", type=Path, default=ROOT / "results/raw_alberta_model")
    ap.add_argument("--source", type=Path, default=ROOT.parent / "rule_first_system_20261004/results/server/source_manifest.json")
    ap.add_argument("--raw", type=Path, default=ROOT / "results/raw_alberta_import/raw_items.json")
    ap.add_argument("--audit", type=Path, default=ROOT / "results/raw_alberta_import/audit_summary.json")
    ap.add_argument("--output", type=Path, default=ROOT / "results/raw_alberta_scope_core/analysis")
    ap.add_argument("--preflight", action="store_true", help="Verify existing six conditions and reconstruct core inputs; write no files")
    analyze(ap.parse_args())


if __name__ == "__main__":
    main()
