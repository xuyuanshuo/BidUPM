#!/usr/bin/env python3
"""Evidence-led research decision report. Never invent unmeasured gold or costs."""
import argparse
import hashlib
import json
from pathlib import Path
from xml.sax.saxutils import escape

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak


def read_json(path):
    return json.loads(path.read_text())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--directory', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    a = ap.parse_args()
    results = a.directory / 'results'
    checked = [results/'runtime_analysis/runtime_validation_qa.json',
               results/'input_preprocessing_ablation/analysis/qa.json',
               results/'gpt6_sol_blind/evaluation/qa.json',
               results/'gpt6_sol_blind/posthoc_complementarity/qa.json',
               results/'selective_gpt6_sol/evaluation/qa.json',
               results/'raw_alberta_models/analysis/analysis_validation_qa.json',
               results/'engineering_evidence_inventory/qa.json',
               a.directory/'annotation/qa/annotation_export_validation.json']
    for path in checked:
        obj = read_json(path)
        assert obj.get('status') == 'passed' or obj.get('passed') is True, (path, obj.get('status'))
    compare = pd.read_csv(results/'gpt6_sol_blind/evaluation/comparison_aggregate.csv')
    posthoc = pd.read_csv(results/'gpt6_sol_blind/posthoc_complementarity/summary_aggregate.csv')
    ablation = pd.read_csv(results/'input_preprocessing_ablation/analysis/summary_aggregate.csv')
    runtime = pd.read_csv(results/'runtime_analysis/runtime_timing_seed_summary.csv')
    raw = read_json(results/'raw_alberta_import/audit_summary.json')
    policy = read_json(results/'policy_exploration/research_findings.json')
    selective = pd.read_csv(results/'selective_gpt6_sol/evaluation/summary_aggregate.csv')
    alberta_summary = pd.read_csv(results/'raw_alberta_models/analysis/output_summary_by_seed_variant_year.csv')
    evidence = read_json(results/'engineering_evidence_inventory/qa.json')

    def selected_value(metric):
        x = selective[(selective.policy == 'selective_gpt_top3') &
                      (selective.evaluation_group == 'all_formal') & (selective.metric == metric)]
        assert len(x) == 1
        return float(x.iloc[0]['mean'])

    def comp(policy_name, metric, group='all_formal', source=None, frame=compare):
        x = frame[(frame.policy == policy_name) & (frame.evaluation_group == group) &
                  (frame.query_subset == 'all_queries') & (frame.metric == metric)]
        if source:
            x = x[x.source == source]
        elif policy_name != 'gpt6_sol_agent':
            x = x[x.source.str.startswith('formal_actual')]
        assert len(x) == 1, (policy_name, metric, group, x.shape)
        return float(x.iloc[0]['mean'])

    def post(metric):
        x = posthoc[(posthoc.policy == 'exact_bge_and_gpt_fallback') &
                    (posthoc.evaluation_group == 'all_formal') &
                    (posthoc.query_subset == 'all_queries') & (posthoc.metric == metric)]
        assert len(x) == 1, (metric, x.shape)
        return float(x.iloc[0]['mean'])

    def abl(variant, group, metric):
        x = ablation[(ablation.variant == variant) & (ablation.evaluation_group == group)]
        assert len(x) == 1
        return float(x.iloc[0][metric+'_mean'])

    def time_value(policy_name, batch, metric):
        x = runtime[(runtime.policy == policy_name) & (runtime.batch_size == batch) & (runtime.metric == metric)]
        assert len(x) == 1
        return float(x.iloc[0]['mean'])

    pdfmetrics.registerFont(TTFont('ResearchCJK', '/System/Library/Fonts/Supplemental/Arial Unicode.ttf'))
    body = ParagraphStyle('body', fontName='ResearchCJK', fontSize=10, leading=17,
                          spaceAfter=10, wordWrap='CJK', textColor=colors.HexColor('#223844'))
    small = ParagraphStyle('small', parent=body, fontSize=8.7, leading=14, textColor=colors.HexColor('#526774'))
    title = ParagraphStyle('title', parent=body, fontSize=20, leading=28, spaceAfter=15,
                           textColor=colors.HexColor('#17364a'))
    heading = ParagraphStyle('heading', parent=body, fontSize=13, leading=19, spaceBefore=9, spaceAfter=6)
    cell = ParagraphStyle('cell', parent=body, fontSize=9, leading=14, alignment=TA_CENTER, spaceAfter=0)
    story = []

    def p(text, style=body):
        story.append(Paragraph(text, style))

    def table(rows, widths):
        tab = Table([[Paragraph(escape(str(v)), cell) for v in row] for row in rows],
                    colWidths=widths, hAlign='CENTER', repeatRows=1)
        tab.setStyle(TableStyle([
            ('LINEABOVE', (0,0), (-1,0), 1, colors.HexColor('#304d5a')),
            ('LINEBELOW', (0,0), (-1,0), .6, colors.HexColor('#304d5a')),
            ('LINEBELOW', (0,-1), (-1,-1), 1, colors.HexColor('#304d5a')),
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#edf3f6')),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('TOPPADDING', (0,0), (-1,-1), 7), ('BOTTOMPADDING', (0,0), (-1,-1), 7)]))
        story.extend([tab, Spacer(1,10)])

    p('工程参考匹配：方案探索与证据', title)
    p('2026-10-05　原金标保留　真实GPU复测　GPT-6 Sol盲测　阿尔伯塔原表导入', small)
    p('当前判断', heading)
    p('本轮找到了比原路由更可靠的候选：规则优先BGE，再对少量拟补充候选独立核验，在旧正式集上保留精确率100%，并小幅提高召回。它尚未在来源独立的新数据上证明泛化，核验后的实际总费用和时延也没有测到。建议把核心研究转向带原文依据的工程范围兼容性判定，先确认规则未覆盖的真实需求，再验证语义补充、工程约束和少量核验各自带来的增量。')
    p('已经完成的同池比较', heading)
    rows = [['方案','返回精确率 (%)','宏Recall@3 (%)','Hit@3 (%)','错误返回数']]
    for name, label in [('rule_only','仅规则'),('all_bge','全量专项微调BGE'),
                        ('system_top3','规则优先BGE'),('gpt6_sol_agent','GPT-6 Sol盲测')]:
        rows.append([label, f"{comp(name,'returned_precision_pct'):.2f}",
                     f"{comp(name,'macro_recall_at3_pct'):.2f}", f"{comp(name,'hit_at3_pct'):.2f}",
                     f"{comp(name,'returned_fp_n'):.2f}"])
    rows.append(['规则BGE＋少量核验*',f"{selected_value('returned_precision_pct'):.2f}",
                 f"{selected_value('macro_recall_at3_pct'):.2f}",f"{selected_value('hit_at3_pct'):.2f}",
                 f"{selected_value('returned_fp_n'):.2f}"])
    table(rows, [130,94,102,73,84])
    p('同一220个正式查询、每查询30个候选，最多返回3条；434个兼容对，57个无参考池。BGE为三个既有检查点均值，规则为确定性输出。全池GPT来自gpt-6-sol／medium代理盲测。*少量核验另做了新的窄上下文盲判：9个查询、25个候选；属于看到既有测试后形成的机制探索，不是独立测试。两轮代理都没有可用于API费用或时延比较的用量记录。', small)
    p('微调的具体作用', heading)
    p(f"内部锁定集的困难候选对F1，专项微调BGE为{comp('all_bge','hard_pair_f1_pct','locked'):.2f}%，GPT盲测为{comp('gpt6_sol_agent','hard_pair_f1_pct','locked'):.2f}%，精确规则为0%。这是专项模型识别部分非精确兼容关系的证据。最终Top3指标与候选对F1回答不同问题，不能因两张表数值不同就判定微调无效。")
    p('高精确率只表示已经返回的项中错误少，不能代表没有漏配。仅规则返回405个正确项、0个错误项，仍漏掉29个非精确正例。GPT返回412个正确项、29个错误项，召回更高，却让更多不适用候选进入名单。', small)

    story.append(PageBreak())
    p('规则为何很强：数据选择与真实原表', title)
    p('原构建代码对内部验证和锁定测试查询要求存在历史精确匹配，并要求Top30有拟兼容候选。检索又对描述与单位相同、条目编码相同的记录加分。人工最终标签与拟标签是不同字段；当前核查说明了采样和检索对重复条目的偏好，没有据此推断标签泄漏。')
    table([['检查项','结果'],['正式集精确兼容项','405 / 434'],
           ['验证查询已有3条精确参考','27 / 30'],['验证集无参考查询','0'],
           ['验证集最多3条理论可返回正例','86 / 107，精确规则已达到']], [236,247])
    p('八种预先定义的候选上限／单位筛选族，按各检查点的验证分数独立选择阈值；固定选择标准要求返回精度及语义补充精度达到99%经验值，再最大化召回、减少调用。三个检查点均选择纯规则。原因是该验证集的Top3上限已由精确项占满，没有一个阈值能返回额外非精确正例；它无法有效校准语义补充和无参考拒绝。', small)
    p('在正式池中，最多3条的理论上限为415个正确返回，而规则已有405个。任何方法最多再增加10个正确返回；19个非精确正例所在池已有3个精确正例，其漏配受输出容量限制。不能将全部29个非精确正例都当作Top3可恢复的空间。', small)
    p('同一种规则在原始阿尔伯塔表上的表现', heading)
    table([['自动处理阶段','有精确候选的清单项 / 135'],
           ['原始描述＋原始单位','0'],['大小写、空白及标点统一','0'],
           ['进一步统一单位别名','0'],['进一步清理列出的规格引用','44'],
           ['进一步展开Cl.为Class','45（33.33%）']], [315,168])
    p('这是两份真实Excel的自动导入实验，2024和2026目录分别237、264行。最终43项只有一个同键候选，2项有重复候选，90项没有同键候选；45是候选覆盖量，尚无独立人工金标准，不能写成45项匹配正确或33.33%准确率。去掉单位别名后仅3项覆盖，去掉规格引用清理后为0项，两者共同起作用。')
    p('五次重复的原表导入、解析、清理、建索引及135项精确检索总流程中位耗时为35.37ms／35.77ms。这是针对这两种已验证表结构的自动适配器，不需要审核员逐条手工清洗，也不是任意Excel格式的通用解析器。清理后原始文本和BF／HCS等引用仍保留，避免把删除引用误当作工程范围已相同。', small)

    story.append(PageBreak())
    p('减少输入处理后，专项模型是否还能工作', title)
    p('本轮在真实GPU完成四种输入、三个冻结检查点、每条件三次，共36次全池评分。检查点、原阈值、最大长度256和BF16均固定，没有重训或根据测试结果重新选阈值。下列变体保留原五槽文本模板，只改变所提供字段；它们测试已提取条目字段，不能叫作无需解析原始Excel。')
    rows = [['输入','内部锁定F1 (%)','内部困难F1 (%)','全部正式F1 (%)']]
    for variant, label in [('full_frozen','原完整五字段'),('no_normalized_description','去规范化描述槽'),
                           ('raw_description_and_unit','原描述＋原单位'),('raw_description_only','仅原描述')]:
        rows.append([label, f"{abl(variant,'locked','pair_f1_pct'):.2f}",
                     f"{abl(variant,'hard_locked','pair_f1_pct'):.2f}",
                     f"{abl(variant,'all_formal','pair_f1_pct'):.2f}"])
    table(rows, [180,100,105,98])
    p('原描述＋原单位的内部F1仍为97.10%，说明当前模型不完全依赖复杂文本规范化。仅原描述的困难F1降至58.04%，原完整输入为69.86%，说明计量和工程字段对避免困难错配仍有价值。原描述＋原单位同时去掉类别和规格字段，不能将全部变化单独归因于“是否清洗”；小范围测试分数的提高也不能直接选为生产输入。')
    p('原完整输入对之前实际GPU批大小64的预测、分数及排名逐条零差异复现。每条件三次重复的判断与排名一致。所有变体的推理分支只读输入，标签仅在完成保存和完整性检查后加入离线评价。', small)
    p('预处理与推理的分工', heading)
    p('Excel导入负责识别表头、行和原始描述／单位，所有匹配方法都需要这个入口。确定性的清理负责等价标点、同维度单位别名和规格引用的分离，通常很便宜，不能自动证明工程兼容。微调模型负责条目对关系判断；通用模型可以读取更复杂文本，但也需要相同的工程依据和有效的拒绝机制。')
    p('“不满足精确规则”应进入未确定状态，而不是直接判不兼容。可靠的施工动作、计量基础和规格冲突可以成为后续约束，但其判别规则必须在开发数据上确定。现有模型能处理一部分原始描述，不代表它能无需适配地识别任意表格结构、推断缺失单位或理解未提供的施工规范。')

    story.append(PageBreak())
    p('已经测到的效率，以及尚未测到的钱', title)
    table([['方法','逐查询筛选耗时 (ms)'],['仅规则','1.51'],
           ['全量专项微调BGE','27.08'],['规则优先BGE','14.56']], [285,198])
    p('逐查询测试包含同硬件上的规则判断、文本序列化、分词、GPU评分和名单合并，不含检索、文件导入和模型加载。系统相对全量BGE减少46.25%的筛选耗时，仍比仅规则慢。新增81次批量复测进一步检查三个检查点、三种批上限、三种策略及三次重复。', small)
    rows = [['批上限','全量BGE / 220查询 (s)','系统 / 220查询 (s)','耗时减少 (%)']]
    for batch in [1,16,64]:
        rows.append([batch, f"{time_value('all_bge',batch,'seconds_median'):.2f}",
                     f"{time_value('system_top3',batch,'seconds_median'):.2f}",
                     f"{time_value('system_top3',batch,'wall_time_saving_pct'):.2f}"])
    table(rows, [70,151,138,124])
    p('系统评分6,600→3,063对，减少53.59%；不同批上限的总耗时减少51.46%–54.61%。这是已有固定候选池的吞吐，不能替代单查询延迟。规则和模型加载、检索、原表解析、人工标注与训练成本应分别记录后再合计。')
    p('实际货币成本尚不可得', heading)
    p('服务器实际租赁单价尚未提供，当前本机与服务器也没有配置可用的OpenAI API密钥。GPT盲测代理工作流没有可用于此比较的API账单、输入／输出token和请求时延。因此，本报告没有把它包装成真实API费用实验，也没有用模型评分下降比例冒充费用节省。')
    p('已准备固定gpt-6-sol、medium、同一候选信息和至多3条结构化输出的Responses API运行器。配置密钥后可记录每个真实请求的时延、成功状态和usage，再按照实际服务档及价格计算token费用。当前官方Standard短上下文标价为输入$2、缓存输入$0.20、输出$10／百万token；这是价目表，不是此次实验账单。<link href="https://developers.openai.com/api/docs/models/gpt-6-sol" color="#176d98">官方模型及价格页</link>。', small)
    p('本地持续批处理可按测得秒数／3600×实际小时租价估算分摊推理费用；整机租赁账单还包含空闲时间。API费用需要包括推理输出token、失败或重试的已消耗usage，训练与标注则需要单独分摊。不同币种、并发和服务档必须一致说明，才能回答“哪种方案最节省”。', small)

    story.append(PageBreak())
    p('值得继续检验的方案：少量残余核验', title)
    p('完成盲测后，对已冻结的BGE和GPT预测做了明确标注为事后探索的三种交叉分析。它们先保留精确参考，不足三条时分别接受GPT结果、两个模型同时接受的结果，或任一模型接受的结果。这个过程没有重新改标签或寻找测试阈值，但此前正式结果已经可见，因此不能宣称它是新的独立验证。')
    rows = [['探索方式','返回精确率 (%)','宏Recall@3 (%)','错误返回数']]
    for name, label in [('exact_gpt_fallback','规则＋GPT'),('exact_bge_and_gpt_fallback','规则＋两模型均接受'),
                        ('exact_bge_or_gpt_fallback','规则＋任一模型接受')]:
        values = []
        for metric in ['returned_precision_pct','macro_recall_at3_pct','returned_fp_n']:
            x = posthoc[(posthoc.policy == name) & (posthoc.evaluation_group == 'all_formal') &
                        (posthoc.query_subset == 'all_queries') & (posthoc.metric == metric)]
            assert len(x) == 1
            values.append(f"{float(x.iloc[0]['mean']):.2f}")
        rows.append([label, *values])
    table(rows, [210,96,99,78])
    p('两模型均接受的方式保留原系统406／406／407个正确返回，错误返回从3／10／8减少到0／3／0，均值精度99.76%。它展示了核验的潜力，但还没有真正按残余候选调用GPT，因此不代表同样输入范围下的核验质量、延迟或费用。通用模型在完整候选池中的判断可能受上下文影响，缩小到少量候选后需要重新盲测。')
    p('这两种是待验证候选，而非已选定生产方案', heading)
    table([['候选','具体做法','要证明的收益'],
           ['低成本版本','自动导入；可靠规则；专项BGE判断剩余关系；不足时拒绝','比规则找回更多非精确参考，控制错误率'],
           ['高可靠版本','在上述基础上，只核验少量拟补充／不确定项；核验未通过则待审','接近全量通用模型的覆盖，降低错误与真实费用']], [100,245,138])
    p('阈值应按开发集上的语义补充精度和查询覆盖校准，单独报告规则无法解决的查询，避免精确项掩盖补充错误。达到所需参考量后停止，最多返回3条且不强制凑满；不确定项应作为待核验信息，不能偷偷计作正确自动匹配。模型和核验器都可能失败，最终选择应由独立测试上的质量、费用与时延共同决定。')
    p('级联节省费用已有研究基础，单纯组合规则和两个模型本身不足以支撑新颖性。本研究更需要证明工程约束、真实无参考识别及原表处理的具体收益。相关基础：<link href="https://arxiv.org/abs/2305.05176" color="#176d98">FrugalGPT</link>；<link href="https://www.ijcai.org/proceedings/2025/1012.pdf" color="#176d98">两阶段检索风险控制</link>。模型组合的相关工作还有<link href="https://aclanthology.org/2025.coling-main.8/" color="#176d98">ComEM（COLING 2025）</link>与<link href="https://arxiv.org/abs/2609.01195" color="#176d98">CaRL-EM（2026预印本）</link>。没有声称已复现这些论文或获得其保证。', small)

    story.append(PageBreak())
    p('独立数据与下一轮实验已具体化', title)
    p('保留原BidUPM测试集和全部标签，不删除强规则结果，也不把模型判断或合成条目写成人工金标。阿尔伯塔数据采用全部135个自然查询和两年全部501条目录，模型输入没有“必须存在精确匹配”的采样条件。数据来源年份和原行号完整保留；投标表日期与可用的施工规格尚需确认，当前只能测试描述兼容，不能声称历史价格预测或时序泛化已经验证。')
    table([['已经准备／执行','规模与状态'],
           ['独立标注A、B','各135个查询，501条完整目录，所有标签为空'],
           ['两个输入版本','原字段／自动清理，各67,635对，输入哈希与来源验证通过'],
           ['冻结模型应用','两输入×三个检查点；记录建议，不将建议当作真值'],
           ['真实API对比','运行器与预检已准备；实际执行需要配置密钥'],
           ['后续金标准','两人独立选择可参考ID／无参考／信息不足，再仲裁']], [205,278])
    alberta_dir = results/'raw_alberta_models'
    if (alberta_dir/'execution_manifest.json').is_file():
        m = read_json(alberta_dir/'execution_manifest.json')
        if m.get('status') == 'complete':
            p('阿尔伯塔冻结模型真实评分已完成', heading)
            times = pd.read_csv(alberta_dir/'timing.csv')
            rows = [['检查点','原字段有输出查询','清理后有输出查询','清理后规则未覆盖中的输出']]
            for seed in [20260904,20260905,20260906]:
                raw_row=alberta_summary[(alberta_summary.seed==seed)&(alberta_summary.variant=='raw')&(alberta_summary.source_year==2024)].iloc[0]
                clean_row=alberta_summary[(alberta_summary.seed==seed)&(alberta_summary.variant=='cleaned')&(alberta_summary.source_year==2024)].iloc[0]
                rows.append([seed,f"{int(raw_row.queries_with_model_recommendations)} / 135",
                             f"{int(clean_row.queries_with_model_recommendations)} / 135",
                             f"{int(clean_row.rule_uncovered_model_nonempty_queries)} / 90"])
            table(rows, [80,126,130,147])
            p(f"两年度的上述数量相同；它们来自同一份135项投标表，不能当作270个独立查询。共405,810次评分，沿用原阈值不调参。原字段／清理后全67,635对跨检查点平均耗时分别{times[times.variant=='raw'].seconds.mean():.2f}／{times[times.variant=='cleaned'].seconds.mean():.2f}秒，每条件一次，模型加载另记。157项独立输出核验通过；有输出不等于输出正确。原阈值迁移后差异很大，旧模型不能直接当作Alberta成熟方案。", small)
    p('评价与实验顺序', heading)
    p('先确认参考适用性、计量基础和关键工程差异的标注规范，再完成独立标注及仲裁。按项目／来源组与可确认时间划分开发、校准和测试数据，开发阶段决定单位及规格处理、提示、阈值和核验分流；冻结后再打开测试结果。如果单份投标表不足以支持稳定划分，应再收集独立项目，而不是在这135项中反复挑选胜出的子集。')
    p('新测试同时比较人工流程、仅规则、全量BGE、规则BGE、全量通用模型与少量核验版本。分别测自然总体、非精确兼容、动作／规格／单位冲突和真正无参考查询，记录返回错误、查询成功、漏配、待审比例、审核时间及真实费用。600个条目对可作为困难对诊断的起点，不能替代足够多的独立查询、项目和无参考案例，更不能预先保证SOTA或期刊档次。')
    p('现阶段最合理的决定，是保留已证实有用的微调模型，补足真实业务数据和可靠性评价，再判断廉价版本或残余核验版本是否占优。暂不依据这些补充结果大改论文主线或宣布最终最优。全部实验预测、哈希、真实计时、离线统计、原表审计及独立标注模板均随报告保留，便于逐项复核。', small)

    story.append(PageBreak())
    p('真正只看少量候选的核验，是否可行', title)
    p('新的gpt-6-sol／medium盲审代理只看三个BGE检查点在规则未占满三条时提出的非精确阳性候选并集。输入先冻结为9个匿名查询、25个候选，不含标签、BGE分数、种子或旧GPT结论。全部候选逐一判断，接受2个；判断文件完整落盘后，评估器才加入原金标。这里是真正的新判断，不是套用之前全池GPT预测。')
    table([['检查点','原系统正确／错误返回','少量核验后正确／错误返回'],
           ['20260904','406 / 3','406 / 0'],['20260905','406 / 10','407 / 0'],
           ['20260906','407 / 8','407 / 0']], [105,187,191])
    p(f"核验后平均返回精度{selected_value('returned_precision_pct'):.2f}%，宏Recall@3 {selected_value('macro_recall_at3_pct'):.2f}%，Hit@3 {selected_value('hit_at3_pct'):.2f}%。与规则相比平均多1.67个正确返回；与原系统相比去掉平均7个错误返回，且没有丢失原已返回的正确项。第二个检查点移除三个Class IV错误候选后，释放名单位置并补回一个正确参考。")
    p('新判断与旧全池GPT在25个候选上有3处不同，说明上下文缩小后必须重做核验。1,260项独立计数／比例检查、360项既有基线指标检查通过。三个检查点共享这一次新的GPT判定，标准差只能表示BGE检查点差异，不能表示三次GPT重测的稳定性。', small)
    p('仍然不足以证明“最优”', heading)
    p('核验只能处理BGE已提出的候选，不能救回BGE全部拒绝的正确项。该方案最终找回的非精确正例只有1／2／2个，分母29；本轮结果说明错误控制有潜力，并没有证明困难匹配已被全面解决。测试结果在构思时已经可见，它是事后探索；须在新的来源独立金标上冻结并验证。')
    p('模型评分仍沿用规则优先策略，新增核验的真实API时延与费用未测量。输入25个候选不是实际API调用数量或费用节省比例；不同检查点分别提出7、15、11个候选，涉及3、6、6个查询。线上提示是否使用每种子自己的候选集、还是多个模型并集，会改变上下文和开销，都应冻结后重新测量。', small)
    p('规格输入补测的状态', heading)
    scope_qa=results/'raw_alberta_scope_core/analysis/analysis_validation_qa.json'
    if scope_qa.is_file():
        assert read_json(scope_qa)['status']=='passed'
        checked.append(scope_qa)
        core_summary=pd.read_csv(scope_qa.parent/'output_summary_by_seed_variant_year.csv')
        core=core_summary[(core_summary.variant=='scope_core')&(core_summary.source_year==2024)]
        p('原文及引用在来源文件中保留，将模型Description槽改为已经清理的工作描述，并沿用三个原阈值。实际GPU评分与本地逐项核验均完成，以下仍是输出量而非准确率。', small)
        table([['检查点','scope core有输出查询／135'],*[[int(x.seed),int(x.queries_with_model_recommendations)] for x in core.itertuples()]], [180,303])
    else:
        p('已将模型Description槽改为已经清理的工作描述，原文与引用保留在来源文件，继续沿用原阈值。服务器日志报告三个GPU运行结束，但随后SSH连接重置，完整结果尚未取回和独立核验。本报告不填入这一条件的匹配结果，分析程序已准备，恢复连接后即可取回。', small)

    story.append(PageBreak())
    p('推荐的核心idea：工程范围证据匹配', title)
    p('需要判断的是候选能否成为查询的工程价格参考，而不是两句话是否相似或是否指向同一个实体。建议为每条记录缓存带原文出处的工程证据卡：施工动作与对象、材料／类型、尺寸或范围、计量及支付口径、包含／排除工作、规范及适用版本。只从可定位原文和条款取得字段；没有出现的属性记为未知，不能伪装成一致。')
    table([['阶段','具体处理','作用与验证重点'],
           ['自动导入与证据缓存','原表自动解析；原描述、单位、引用分离保留；目录一次解析','减少重复处理，同时核对字段提取是否正确'],
           ['便宜检索与明确判断','词汇与语义检索；有充分依据的兼容接受、明确范围冲突否决','测全目录检索召回；精确文字不能代替支付范围判断'],
           ['专项语义与范围核验','在自然非精确残差上训练／校准小模型，比较必要工程条件','区分兼容、明确冲突、证据不足；控制错误参考'],
           ['少量通用模型与人审','仅处理证据模糊或拟补充项；保留理由，未确定则待审','同质量下减少真实总费用，避免默认凑满3条']], [89,218,176])
    p(f"已整理原135项中的{evidence['reference_spans']}处规范／项目引用，135项全部带引用。官方目录可定位GCS／HCS第16版2019和BCS第17版2020，但出版页正文获取返回403，实际合同适用版本、Special Provisions、BF项目文件也尚未提供。证据卡语义字段仍为空，没有虚构条款或标注。<link href='https://www.alberta.ca/construction-contract-templates-and-specifications' color='#176d98'>Alberta官方规范目录</link>要求按具体合同确认适用文件。", small)
    p('先做有信息量的小试验，再决定是否重训', heading)
    p('把已查看预测的Alberta135项用作开发材料：先从90个规则未覆盖查询中按输入属性预先随机抽30–50项，另审计10–15个覆盖项；两人独立扫描完整目录并查适用条款，标明可参考／无参考／证据不足。首先确认残差是否真有可用参考，以及加入工程依据能否消除歧义。没有可用信息时，继续调模型或阈值不能保证解决问题。')
    p('再在独立合同上冻结比较规则、全量BGE、残差小模型、证据约束小模型、少量核验和相同证据的全量GPT。关键消融为有无工程字段、有无出处条款、有无少量GPT。自然总体与预先定义的冲突挑战集分开；所有模型获得相同可用证据。按相同错误参考风险比较查询成功、待审量、审核时间和实测总费用，而不是只要求所有指标第一。')
    p('可推翻的成功条件：工程证据减少范围错配且不明显损失可用参考；残差训练改善跨项目表现；缓存与少量核验在同质量下节省总费用。若证据没有增量、自然残差很少或规则已足够，应删去无效模块。当前推荐是最值得检验的方向，没有宣称该组合或证据表示首次提出，也没有保证SOTA、会议录用或期刊分区。', small)

    def footer(c, doc):
        c.setFont('ResearchCJK', 8)
        c.setFillColor(colors.HexColor('#617b89'))
        c.drawString(45, 24, '工程参考匹配方案探索　2026-10-05')
        c.drawRightString(A4[0]-45, 24, str(doc.page))
    a.output.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(a.output), pagesize=A4, leftMargin=56, rightMargin=56,
                            topMargin=42, bottomMargin=44)
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print(json.dumps({'output': str(a.output), 'qa_inputs': [str(x) for x in checked]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
