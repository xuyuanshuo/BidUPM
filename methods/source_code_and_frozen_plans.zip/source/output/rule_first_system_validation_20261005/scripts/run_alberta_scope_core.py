#!/usr/bin/env python3
"""Prospective representation diagnostic; no labels, calibration or claimed accuracy.

Original raw/reference context remains in hashed CSVs. Only the model's Description
slot is replaced by the already computed cleaned scope, so source references no
longer occupy a duplicate scoring slot. Category/specification slots stay unknown.
"""
import argparse
import gc
import json
import os
from pathlib import Path
import time

import numpy as np
import pandas as pd
import run_alberta_frozen_models as original
import system_policy


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--inputs', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--check-inputs', action='store_true')
    a = ap.parse_args()
    frames, frozen, inputs, provenance = original.read_inputs(a)
    core = frames['cleaned'].copy()
    changed = {}
    for side in ['query', 'candidate']:
        changed[side] = int(core[f'{side}_description'].ne(core[f'{side}_normalized_description']).sum())
        core[f'{side}_description'] = core[f'{side}_normalized_description']
    core['input_variant'] = 'scope_core'
    assert len(core) == 67635
    assert not original.FORBIDDEN.intersection(core.columns)
    plan = {'status': 'input_preflight', 'representation': 'scope_core',
            'transformation': 'Description := already-cleaned Normalized description; Normalized and normalized unit unchanged; category/specification slots empty. Original raw texts and reference spans retained in hashed source inputs.',
            'scope': 'Post-hoc research diagnosis motivated by sparse original-threshold deployment recommendations; no gold, threshold retuning, or accuracy comparison.',
            'source_runs': frozen['runs'], 'input_csvs': provenance,
            'script_sha256': original.sha(__file__),
            'original_runner_sha256': original.sha(original.__file__),
            'policy_sha256': original.sha(system_policy.__file__),
            'input_manifest_sha256': original.sha(a.inputs/'input_manifest.json'),
            'source_manifest_sha256': original.sha(a.source/'source_manifest.json'),
            'pair_n': 67635, 'pool_n': 270, 'query_n': 135,
            'labels_accessed': False, 'labels_available': False,
            'training_performed': False, 'thresholds_retuned': False,
            'changed_description_slots': changed,
            'batch_size': 64, 'max_length': 256,
            'precision': 'BF16 autocast; TF32 disabled; threads8',
            'timing': 'One actual synchronized full inference pass per frozen checkpoint, includes serialization/tokenization/GPU scoring/threshold/ranking; excludes CSV reading, transformation, model loading, integrity checks.',
            'warmup': 'first64 scope-core pairs per checkpoint, excluded',
            'completed_conditions': []}
    if a.check_inputs:
        print(json.dumps(plan, ensure_ascii=False))
        return
    original.require(not a.output.exists() or not any(a.output.iterdir()), 'Refusing existing results directory')
    os.environ.setdefault('HF_HUB_OFFLINE', '1')
    os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
    os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')
    import torch
    from transformers import AutoTokenizer, AutoModelForSequenceClassification
    original.require(torch.cuda.is_available() and torch.cuda.is_bf16_supported(), 'Real BF16 GPU required')
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    a.output.mkdir(parents=True)
    plan.update(status='running', gpu=torch.cuda.get_device_name(0), torch_version=torch.__version__)
    original.write_json(a.output/'execution_manifest.json', plan)

    @torch.inference_mode()
    def infer(frame, model, tokenizer, threshold):
        torch.cuda.synchronize()
        started = time.perf_counter()
        q = system_policy.serialize(frame, 'query')
        c = system_policy.serialize(frame, 'candidate')
        scores = np.empty(len(frame))
        for lo in range(0, len(frame), 64):
            token = tokenizer(q[lo:lo+64], c[lo:lo+64], padding=True, truncation=True, max_length=256, return_tensors='pt')
            token = {k:v.to('cuda') for k,v in token.items()}
            with torch.autocast('cuda', dtype=torch.bfloat16):
                logit = model(**token).logits.reshape(-1)
            scores[lo:lo+64] = logit.float().cpu().numpy()
        original.require(np.isfinite(scores).all(), 'Invalid logits')
        prediction = (scores >= threshold).astype(np.int8)
        rank = system_policy.rank_returned(frame, np.zeros(len(frame), bool), scores, threshold)
        torch.cuda.synchronize()
        return scores, prediction, rank, time.perf_counter()-started

    times, summaries = [], []
    for run in frozen['runs']:
        seed, threshold, checkpoint = int(run['seed']), float(run['threshold']), Path(run['checkpoint'])
        for name, expected in run['checkpoint_files'].items():
            original.require(original.sha(checkpoint/name) == expected, f'Checkpoint mismatch {seed}/{name}')
        print(f'LOAD {seed}', flush=True)
        torch.manual_seed(seed)
        torch.cuda.synchronize()
        started = time.perf_counter()
        tokenizer = AutoTokenizer.from_pretrained(checkpoint, local_files_only=True)
        model = AutoModelForSequenceClassification.from_pretrained(checkpoint, local_files_only=True).to('cuda').eval()
        torch.cuda.synchronize()
        loading_seconds = time.perf_counter()-started
        infer(core.head(64), model, tokenizer, threshold)
        scores, pred, rank, seconds = infer(core, model, tokenizer, threshold)
        out = core[['pair_id', *original.KEYS, 'source_year', 'candidate_id']].copy()
        out['seed'], out['variant'], out['threshold'] = seed, 'scope_core', threshold
        out['score'], out['prediction'], out['returned_rank'] = scores, pred, rank
        path = a.output/f'predictions_scope_core_seed_{seed}.csv'
        out.to_csv(path, index=False)
        times.append({'seed': seed, 'variant':'scope_core', 'threshold': threshold,
                      'pairs':len(core), 'queries':135, 'pools':270, 'seconds':seconds,
                      'model_load_seconds':loading_seconds, 'repeat':0, 'batch_size':64})
        summaries.extend(original.diagnostic_summary(core, scores, pred, rank, seed, 'scope_core', threshold))
        pd.DataFrame(times).to_csv(a.output/'timing.csv', index=False)
        pd.DataFrame(summaries).to_csv(a.output/'query_recommendation_summary.csv', index=False)
        plan['completed_conditions'].append({'seed':seed, 'variant':'scope_core', 'threshold':threshold,
                                            'prediction_file':path.name, 'prediction_sha256':original.sha(path),
                                            'seconds':seconds})
        original.write_json(a.output/'execution_manifest.json', plan)
        print(f'FINISH {seed} {seconds:.3f}s', flush=True)
        del model, tokenizer
        gc.collect()
        torch.cuda.empty_cache()
    original.require(len(times)==3 and len(summaries)==810, 'Incomplete research diagnostic')
    plan.update(status='complete', timing_sha256=original.sha(a.output/'timing.csv'),
                query_summary_sha256=original.sha(a.output/'query_recommendation_summary.csv'))
    original.write_json(a.output/'execution_manifest.json', plan)
    print('ALL_COMPLETE', flush=True)


if __name__ == '__main__':
    main()
