#!/usr/bin/env python3
"""CPU-only exact-rule sensitivity to exported description preprocessing.

Gold labels are used only after four input-only masks and Top3 lists are built.
No model inference, threshold search, candidate retrieval, or label changes.
Original-unit columns are absent: all variants use exported normalized units.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

import system_policy


VARIANTS = ["raw_literal", "raw_lower_whitespace", "raw_canonical", "exported_normalized"]
DEFINITIONS = {
    "raw_literal": "Exported original-description strings exactly equal; exported normalized-unit strings exactly equal; nonblank fields.",
    "raw_lower_whitespace": "Lowercase/strip/collapse whitespace in exported original descriptions and exported normalized units; exact equality; nonempty.",
    "raw_canonical": "Canonical original descriptions: lowercase, & to and, non-[a-z0-9] to spaces, collapse whitespace; normalized-unit lowercase/whitespace equality; nonempty.",
    "exported_normalized": "Current rule: canonical exported normalized_description equality and normalized-unit lowercase/whitespace equality; nonempty."}
QKEY = ["evaluation_split", "query_id"]


def require(condition: bool, message: str) -> None:
    if not bool(condition):
        raise ValueError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def percentage(numerator, denominator) -> float:
    return 100.0 * numerator / denominator if denominator else np.nan


def masks_from_inputs(inputs: pd.DataFrame) -> dict[str, np.ndarray]:
    result = {}
    for variant in VARIANTS:
        description_field = "normalized_description" if variant == "exported_normalized" else "description"
        if variant == "raw_literal":
            description_norm = lambda value: str(value)
            unit_norm = lambda value: str(value)
        elif variant == "raw_lower_whitespace":
            description_norm, unit_norm = system_policy.normalize_text, system_policy.normalize_unit
        else:
            description_norm, unit_norm = system_policy.canonical_description, system_policy.normalize_unit
        qd = inputs[f"query_{description_field}"].map(description_norm)
        cd = inputs[f"candidate_{description_field}"].map(description_norm)
        qu = inputs.query_normalized_unit.map(unit_norm)
        cu = inputs.candidate_normalized_unit.map(unit_norm)
        # Literal equality never converts blank/whitespace-only fields to a
        # match. Canonical punctuation-only descriptions are empty as well.
        nonempty = qd.str.strip().ne("") & cd.str.strip().ne("") & qu.str.strip().ne("") & cu.str.strip().ne("")
        result[variant] = (nonempty & qd.eq(cd) & qu.eq(cu)).to_numpy(bool)
    require(np.array_equal(result["exported_normalized"], system_policy.exact_mask(inputs)), "Current-rule independent mask mismatch")
    return result


def groups_for(inputs: pd.DataFrame) -> dict[str, list[str]]:
    groups = {name: [name] for name in sorted(inputs.evaluation_split.unique())}
    groups["all_formal"] = sorted(inputs.evaluation_split.unique())
    internal = [name for name in ["locked", "no_reference", "no_reference_reclassified"] if name in groups]
    if len(internal) > 1:
        groups["internal_combined"] = internal
    return groups


def summaries(evaluated: pd.DataFrame, masks: dict, ranks: dict, groups: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    query_rows = []
    for variant in VARIANTS:
        table = evaluated[[*QKEY, "final_label"]].copy()
        table["accepted"] = masks[variant]
        table["returned"] = ranks[variant] > 0
        table["accepted_tp"] = table.accepted & table.final_label.eq(1)
        table["returned_tp"] = table.returned & table.final_label.eq(1)
        table["returned_fp"] = table.returned & table.final_label.eq(0)
        for (split, query_id), part in table.groupby(QKEY):
            positive = int(part.final_label.sum())
            tp, fp = int(part.returned_tp.sum()), int(part.returned_fp.sum())
            query_rows.append({"variant": variant, "evaluation_split": split, "query_id": query_id,
                               "positive_n": positive, "accepted_n": int(part.accepted.sum()),
                               "accepted_tp": int(part.accepted_tp.sum()), "returned_tp": tp, "returned_fp": fp,
                               "returned_n": tp + fp, "hit": tp > 0,
                               "recall_at3": tp / positive if positive else np.nan, "no_output": tp + fp == 0})
    queries = pd.DataFrame(query_rows)
    rows = []
    for name, splits in groups.items():
        selected = evaluated.evaluation_split.isin(splits).to_numpy()
        gold = evaluated.final_label.eq(1).to_numpy()[selected]
        for variant in VARIANTS:
            accepted = masks[variant][selected]
            tp, fp, fn, tn = (int(np.sum(condition)) for condition in
                              [accepted & gold, accepted & ~gold, ~accepted & gold, ~accepted & ~gold])
            q = queries[(queries.variant == variant) & queries.evaluation_split.isin(splits)]
            positive_queries, no_ref_queries = q.positive_n.gt(0), q.positive_n.eq(0)
            returned_tp, returned_fp = int(q.returned_tp.sum()), int(q.returned_fp.sum())
            rows.append({"evaluation_group": name, "variant": variant, "pairs": int(selected.sum()), "queries": len(q),
                         "positive_pairs": int(gold.sum()), "tp": tp, "fp": fp, "fn": fn, "tn": tn,
                         "pair_precision_pct": percentage(tp, tp + fp), "pair_recall_pct": percentage(tp, tp + fn),
                         "pair_f1_pct": percentage(2 * tp, 2 * tp + fp + fn),
                         "accepted_pairs": int(accepted.sum()), "accepted_query_n": int(q.accepted_n.gt(0).sum()),
                         "zero_accepted_query_n": int(q.accepted_n.eq(0).sum()),
                         "one_accepted_query_n": int(q.accepted_n.eq(1).sum()), "two_accepted_query_n": int(q.accepted_n.eq(2).sum()),
                         "at_least_three_accepted_query_n": int(q.accepted_n.ge(3).sum()),
                         "at_least_three_accepted_query_pct": percentage(q.accepted_n.ge(3).sum(), len(q)),
                         "returned_tp": returned_tp, "returned_fp": returned_fp,
                         "returned_precision_pct": percentage(returned_tp, returned_tp + returned_fp),
                         "macro_recall_at3_pct": 100 * q.loc[positive_queries, "recall_at3"].mean(),
                         "hit_at3_pct": percentage(q.loc[positive_queries, "hit"].sum(), positive_queries.sum()),
                         "positive_query_n": int(positive_queries.sum()),
                         "no_reference_rejection_pct": percentage(q.loc[no_ref_queries, "no_output"].sum(), no_ref_queries.sum())})
    return pd.DataFrame(rows), queries


def sample_tables(evaluated: pd.DataFrame, masks: dict) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    fields = ["pair_id", *QKEY, "candidate_id", "query_description", "candidate_description",
              "query_normalized_description", "candidate_normalized_description", "query_normalized_unit", "candidate_normalized_unit", "final_label"]
    samples = evaluated[fields].copy()
    for variant in VARIANTS:
        samples[f"accept_{variant}"] = masks[variant].astype(int)
    recovered_parts = []
    for previous, current in zip(VARIANTS[:-1], VARIANTS[1:]):
        rescued = evaluated.final_label.eq(1).to_numpy() & ~masks[previous] & masks[current]
        part = samples.loc[rescued].copy()
        part["transition"] = f"{previous} -> {current}"
        part["explanation"] = {"raw_lower_whitespace": "Case/leading/trailing/repeated whitespace normalization made the exported fields equal.",
                               "raw_canonical": "Description punctuation/ampersand canonicalization made original descriptions equal.",
                               "exported_normalized": "Exported normalized descriptions became canonically equal although canonical original descriptions were unequal."}[current]
        recovered_parts.append(part)
    recovered = pd.concat(recovered_parts, ignore_index=True)
    missed = samples.loc[evaluated.final_label.eq(1).to_numpy() & ~masks["exported_normalized"]].copy()
    def reason(row):
        qd = system_policy.canonical_description(row.query_normalized_description)
        cd = system_policy.canonical_description(row.candidate_normalized_description)
        qu = system_policy.normalize_unit(row.query_normalized_unit)
        cu = system_policy.normalize_unit(row.candidate_normalized_unit)
        causes = []
        if not qd or not cd:
            causes.append("missing/effectively-empty normalized description")
        elif qd != cd:
            causes.append("canonical normalized descriptions differ")
        if not qu or not cu:
            causes.append("missing normalized unit")
        elif qu != cu:
            causes.append("normalized units differ")
        return "; ".join(causes) + "; input rule remains unresolved; gold positive is used only for this offline diagnostic"
    missed["explanation"] = missed.apply(reason, axis=1)
    changed = samples.loc[
        evaluated.query_description.ne(evaluated.query_normalized_description)
        | evaluated.candidate_description.ne(evaluated.candidate_normalized_description)].copy()
    return recovered, missed, changed


def transition_summary(evaluated: pd.DataFrame, masks: dict, groups: dict) -> pd.DataFrame:
    rows = []
    comparisons = list(zip(VARIANTS[:-1], VARIANTS[1:])) + [(VARIANTS[0], VARIANTS[-1])]
    for name, splits in groups.items():
        selected = evaluated.evaluation_split.isin(splits).to_numpy()
        gold = evaluated.final_label.eq(1).to_numpy()
        for previous, current in comparisons:
            gained = selected & ~masks[previous] & masks[current]
            lost = selected & masks[previous] & ~masks[current]
            rows.append({"evaluation_group": name, "from_variant": previous, "to_variant": current,
                         "gained_positive_pairs": int((gained & gold).sum()), "gained_negative_pairs": int((gained & ~gold).sum()),
                         "lost_positive_pairs": int((lost & gold).sum()), "lost_negative_pairs": int((lost & ~gold).sum())})
    return pd.DataFrame(rows)


def transformation_summary(inputs: pd.DataFrame) -> dict:
    result = {}
    for side, identifier in [("query", "query_id"), ("candidate", "candidate_id")]:
        fields = [identifier, f"{side}_description", f"{side}_normalized_description", f"{side}_normalized_unit"]
        items = inputs[fields].drop_duplicates()
        raw = items[f"{side}_description"]
        exported = items[f"{side}_normalized_description"]
        literal_change = raw.ne(exported)
        beyond_canonical = raw.map(system_policy.canonical_description).ne(exported.map(system_policy.canonical_description))
        result[side] = {"unique_exported_item_record_n": len(items), "literal_description_changed_n": int(literal_change.sum()),
                        "literal_description_changed_pct": percentage(literal_change.sum(), len(items)),
                        "description_changed_beyond_current_canonicalization_n": int(beyond_canonical.sum()),
                        "description_changed_beyond_current_canonicalization_pct": percentage(beyond_canonical.sum(), len(items)),
                        "unique_record_definition": "identifier + original description + normalized description + normalized unit; no repeated candidate-pair weighting"}
    return result


def json_clean(value):
    if isinstance(value, dict):
        return {str(key): json_clean(item) for key, item in value.items()}
    if isinstance(value, list):
        return [json_clean(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parents[2] / "rule_first_system_20261004" / "results" / "server")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "results" / "preprocessing_audit")
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    report = {"status": "started", "script_sha256": sha256(Path(__file__)), "new_model_inference": False,
              "threshold_selection": False, "candidate_retrieval_performed": False, "source_predictions_read": False,
              "labels_used_for_rules": False, "rule_definitions": DEFINITIONS,
              "scope": "Existing fixed 30-candidate pools; formal queries only; Top3 candidate-ID ordering.",
              "important_interpretation": "Original unit columns are absent. All four rules use extracted fields and exported normalized units, so even raw_literal is not a direct match of untouched Excel cells. No upstream AI use is inferred.",
              "upstream_preprocessing": "This audit observes exported original/normalized fields; it does not identify how they were created or whether AI was used."}
    try:
        manifest_path = source / "source_manifest.json"
        manifest = json.loads(manifest_path.read_text())
        input_path, label_path = source / "inputs.csv", source / "labels.csv"
        require(sha256(input_path) == manifest["inputs_sha256"], "Input source hash mismatch")
        require(sha256(label_path) == manifest["labels_sha256"], "Gold source hash mismatch")
        inputs = pd.read_csv(input_path, dtype=str, keep_default_na=False)
        require(not {"final_label", "difficulty", "final_conflict_type"}.intersection(inputs.columns), "Input-only file contains annotations")
        require(not {"query_unit", "candidate_unit", "query_original_unit", "candidate_original_unit"}.intersection(inputs.columns),
                "Original unit columns exist; revise the stated limitation before using this audit")
        inputs = inputs[inputs.evaluation_split.ne("validation")].reset_index(drop=True)
        require(len(inputs) == 6600 and inputs[QKEY].drop_duplicates().shape[0] == 220, "Expected 220 formal queries/6600 candidates")
        require(inputs.groupby(QKEY).size().eq(30).all() and not inputs.pair_id.duplicated().any(), "Invalid candidate pools")
        masks = masks_from_inputs(inputs)
        ranks = {variant: system_policy.rank_returned(inputs, mask, np.full(len(inputs), np.nan), 1.0)
                 for variant, mask in masks.items()}
        # Gold is parsed only after input-only masks and reference lists exist.
        labels = pd.read_csv(label_path, dtype={"pair_id": str}, keep_default_na=False)
        require(not labels.pair_id.duplicated().any() and labels.final_label.isin([0, 1]).all(), "Invalid gold labels")
        require(set(inputs.pair_id).issubset(labels.pair_id), "Missing formal gold labels")
        evaluated = inputs.merge(labels[["pair_id", "final_label"]], on="pair_id", validate="one_to_one", how="left")
        groups = groups_for(inputs)
        summary, queries = summaries(evaluated, masks, ranks, groups)
        recovered, missed, changed = sample_tables(evaluated, masks)
        outputs = {"rule_preprocessing_summary.csv": summary, "rule_preprocessing_per_query.csv": queries,
                   "rule_preprocessing_transitions.csv": transition_summary(evaluated, masks, groups),
                   "preprocessing_recovered_gold_positives.csv": recovered,
                   "current_rule_unresolved_gold_positives.csv": missed, "original_to_normalized_examples.csv": changed}
        for name, frame in outputs.items():
            frame.to_csv(output / name, index=False)
        report.update({"status": "passed", "source_hashes": {"inputs.csv": sha256(input_path), "labels.csv": sha256(label_path),
                                                               "source_manifest.json": sha256(manifest_path)},
                       "system_policy_sha256": sha256(Path(system_policy.__file__)), "formal_pairs": len(inputs), "formal_queries": 220,
                       "label_use": "Offline evaluation and example selection only; no masks/ranks depend on labels.",
                       "evaluation_groups": groups, "unique_item_transformations": transformation_summary(inputs),
                       "all_formal_results": summary[summary.evaluation_group.eq("all_formal")].to_dict("records"),
                       "output_files": {name: {"rows": len(frame), "sha256": sha256(output / name)} for name, frame in outputs.items()}})
        print(json.dumps(json_clean({"status": "passed", "all_formal_results": report["all_formal_results"],
                                     "output_directory": str(output)}), ensure_ascii=False))
    except Exception as error:
        report["status"] = "failed"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "rule_preprocessing_report.json").write_text(json.dumps(json_clean(report), indent=2, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
