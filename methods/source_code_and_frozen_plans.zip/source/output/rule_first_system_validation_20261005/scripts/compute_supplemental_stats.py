#!/usr/bin/env python3
"""Independent 30-candidate / <=3-output evaluation of existing real predictions.

This script reads gold labels only for evaluation, never for inference, routing,
threshold selection, or ranking. It performs no GPU inference or new timing.
All confidence intervals resample complete query pools, paired across policies
and across the three existing seeds, with no invented noninferiority margin.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd


POLICIES = ['rule_only', 'all_bge', 'stop_3']
FORMAL_SPLITS = ['locked', 'no_reference', 'no_reference_reclassified', 'external']
QUERY_KEYS = ['evaluation_split', 'query_id']


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def ratio(numerator, denominator):
    return 100 * numerator / denominator if denominator else np.nan


def array_ratio(numerator, denominator):
    result = np.full(np.shape(numerator), np.nan, dtype=float)
    np.divide(100 * numerator, denominator, out=result, where=denominator != 0)
    return result


def canonical_description(value):
    return ' '.join(re.sub(r'[^a-z0-9]+', ' ', str(value or '').lower().replace('&', ' and ')).split())


def exact_feature(frame):
    qd = frame.query_normalized_description.map(canonical_description)
    cd = frame.candidate_normalized_description.map(canonical_description)
    qu = frame.query_normalized_unit.map(lambda value: ' '.join(str(value).lower().split()))
    cu = frame.candidate_normalized_unit.map(lambda value: ' '.join(str(value).lower().split()))
    return qd.ne('') & qu.ne('') & qd.eq(cd) & qu.eq(cu)


def observed_metrics(query):
    positive = query.positive_n.gt(0)
    no_reference = ~positive
    nonexact_positive = query.nonexact_positive_n.gt(0)
    no_exact_positive = positive & query.exact_positive_n.eq(0)
    tp, fp = query.returned_tp.sum(), query.returned_fp.sum()
    return {
        'query_n': len(query), 'positive_query_n': int(positive.sum()),
        'no_reference_query_n': int(no_reference.sum()),
        'returned_tp_n': int(tp), 'returned_fp_n': int(fp),
        'returned_precision_pct': ratio(tp, tp + fp),
        'macro_recall_at3_pct': 100 * query.loc[positive, 'recall_at3'].mean(),
        'micro_recall_at3_pct': ratio(tp, query.positive_n.sum()),
        'hit_at3_pct': ratio(query.loc[positive, 'hit'].sum(), positive.sum()),
        'wrong_reference_query_rate_pct': 100 * query.any_wrong.mean(),
        'average_returned_n': query.returned_n.mean(),
        'model_called_n': int(query.model_called_n.sum()),
        'model_candidate_fraction_pct': ratio(query.model_called_n.sum(), query.candidate_n.sum()),
        'model_scoring_reduction_pct': 100 - ratio(query.model_called_n.sum(), query.candidate_n.sum()),
        'no_reference_pool_rejection_pct': ratio(query.loc[no_reference, 'pool_rejected'].sum(), no_reference.sum()),
        'nonexact_positive_query_n': int(nonexact_positive.sum()),
        'returned_nonexact_tp_n': int(query.returned_nonexact_tp.sum()),
        'nonexact_positive_query_rescue_pct': ratio(query.loc[nonexact_positive, 'returned_nonexact_tp'].gt(0).sum(), nonexact_positive.sum()),
        'no_exact_positive_query_n': int(no_exact_positive.sum()),
        'no_exact_positive_query_hit_n': int(query.loc[no_exact_positive, 'hit'].sum()),
        'no_exact_positive_query_hit_pct': ratio(query.loc[no_exact_positive, 'hit'].sum(), no_exact_positive.sum()),
    }


def resampled_quality_metrics(query, draws):
    def sample(column):
        return query[column].to_numpy(dtype=float)[draws]
    positive = sample('positive_n') > 0
    return {
        'returned_precision_pct': array_ratio(sample('returned_tp').sum(1), sample('returned_n').sum(1)),
        'macro_recall_at3_pct': array_ratio(np.nan_to_num(sample('recall_at3')).sum(1), positive.sum(1)),
        'micro_recall_at3_pct': array_ratio(sample('returned_tp').sum(1), sample('positive_n').sum(1)),
        'hit_at3_pct': array_ratio((sample('hit') * positive).sum(1), positive.sum(1)),
        'wrong_reference_query_rate_pct': 100 * sample('any_wrong').mean(1),
    }


def ci_record(group, seed, baseline, metric, estimate, samples, iterations, unit, better):
    finite = samples[np.isfinite(samples)]
    low, high = np.quantile(finite, [.025, .975]) if len(finite) else (np.nan, np.nan)
    if better == 'higher':
        possible_deterioration = bool(low < 0) if np.isfinite(low) else None
    else:
        possible_deterioration = bool(high > 0) if np.isfinite(high) else None
    return {'evaluation_group': group, 'seed': seed, 'baseline': baseline,
            'tested_policy': 'stop_3', 'metric': metric, 'estimate': estimate,
            'ci95_low': low, 'ci95_high': high, 'unit': unit,
            'better_direction': better, 'interval_includes_deterioration': possible_deterioration,
            'prespecified_noninferiority_margin': None,
            'noninferiority_test_claimed': False,
            'bootstrap_n': iterations, 'finite_bootstrap_n': len(finite),
            'query_n': 220, 'paired_unit': 'query_pool',
            'delta_definition': 'stop_3 minus baseline' if metric != 'latency_saving_pct' else '100*(1-stop_3_mean/baseline_mean)'}


def aggregate(frame, identifiers):
    metrics = [col for col in frame if col not in identifiers + ['seed']]
    result = frame.groupby(identifiers)[metrics].agg(['mean', 'std', 'count']).reset_index()
    result.columns = ['_'.join(filter(None, col)) for col in result.columns]
    result.rename(columns={col: col[:-4] + '_sample_sd' for col in result if col.endswith('_std')}, inplace=True)
    result.rename(columns={col: col[:-6] + '_finite_seed_n' for col in result if col.endswith('_count')}, inplace=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    project_root = Path(__file__).resolve().parents[1]
    parser.add_argument('--source-directory', type=Path, default=project_root.parent / 'rule_first_system_20261004/results/server')
    parser.add_argument('--output-directory', type=Path, default=project_root / 'results')
    parser.add_argument('--bootstrap', type=int, default=5000)
    parser.add_argument('--bootstrap-seed', type=int, default=20261005)
    args = parser.parse_args()
    source, output = args.source_directory.resolve(), args.output_directory.resolve()
    output.mkdir(parents=True, exist_ok=True)
    qa = {'status': 'started', 'gpu_inference_performed': False,
          'new_timing_performed': False, 'thresholds_retuned': False,
          'candidate_pool_size': 30, 'maximum_output': 3,
          'noninferiority_test_claimed': False, 'prespecified_noninferiority_margin': None,
          'analysis_only_gold_access': True, 'script_sha256': sha(Path(__file__))}
    try:
        source_manifest = json.loads((source / 'source_manifest.json').read_text())
        execution = json.loads((source / 'execution_manifest.json').read_text())
        require(execution['status'] == 'complete', 'original execution incomplete')
        require(execution['labels_accessed_by_runner'] is False and execution['gate_label_access'] is False,
                'original inference manifest reports gold access')
        for filename in ['qa.json', 'timing_qa.json']:
            require(json.loads((source / filename).read_text())['status'] == 'passed', filename + ' did not pass')
        require(sha(source / 'inputs.csv') == source_manifest['inputs_sha256'], 'inputs source hash mismatch')
        require(sha(source / 'labels.csv') == source_manifest['labels_sha256'], 'labels source hash mismatch')
        runner = source.parents[1] / 'scripts/run_system_experiment.py'
        require(sha(runner) == execution['script_sha256'], 'original runner script hash mismatch')
        tree = ast.parse(runner.read_text())
        csv_reads = [ast.unparse(call.args[0]) for call in ast.walk(tree)
                     if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
                     and call.func.attr == 'read_csv']
        require(len(csv_reads) == 1 and 'inputs.csv' in csv_reads[0],
                'original runner CSV reads are not input-only')
        inputs = pd.read_csv(source / 'inputs.csv', keep_default_na=False, float_precision='round_trip')
        require(not {'final_label', 'final_relevance', 'difficulty'}.intersection(inputs.columns),
                'inference input contract contains labels')
        require(not inputs.pair_id.duplicated().any(), 'duplicated input pair ID')
        inputs['exact_expected'] = exact_feature(inputs)
        formal_inputs = inputs[inputs.evaluation_split.isin(FORMAL_SPLITS)]
        sizes = formal_inputs.groupby(QUERY_KEYS).size()
        require(len(formal_inputs) == 6600 and len(sizes) == 220 and sizes.eq(30).all(),
                'formal query/pool sizes mismatch')
        feature_queries = formal_inputs.groupby(QUERY_KEYS, as_index=False).agg(
            exact_n=('exact_expected', 'sum'), candidate_n=('pair_id', 'size'))
        require(feature_queries.exact_n.isin([0, 1, 2, 3]).all(), 'unexpected exact-match count group')
        labels = pd.read_csv(source / 'labels.csv', keep_default_na=False)
        require(not labels.pair_id.duplicated().any(), 'duplicated label pair ID')
        require(labels.final_label.isin([0, 1]).all(), 'gold label not binary')
        gold = formal_inputs.merge(labels, on='pair_id', validate='one_to_one')
        require(len(gold) == 6600 and gold.final_label.sum() == 434, 'formal gold-positive count mismatch')
        rows, source_files = [], []
        runs = {int(run['seed']): run for run in execution['runs']}
        for seed, run in sorted(runs.items()):
            path = source / f'predictions_seed_{seed}.csv'
            require(sha(path) == run['prediction_sha256'], 'prediction hash mismatch')
            prediction = pd.read_csv(path, float_precision='round_trip')
            prediction = prediction[prediction.policy.isin(POLICIES)]
            require(not prediction.duplicated(['pair_id', 'policy']).any(), 'duplicated prediction key')
            # Gold is not used in these routing/ranking checks.
            checked = prediction.merge(formal_inputs, on='pair_id', validate='many_to_one')
            require(len(checked) == 6600 * len(POLICIES), 'formal prediction count mismatch')
            require(checked.threshold.eq(run['threshold']).all(), 'original threshold mismatch')
            require(checked.exact_match.eq(checked.exact_expected.astype(int)).all(), 'exact feature mismatch')
            for (policy, split, query), pool in checked.groupby(['policy', *QUERY_KEYS]):
                exact = pool.exact_expected
                if policy == 'all_bge':
                    called = pd.Series(True, index=pool.index)
                    expected_prediction = pool.score.ge(pool.threshold).astype(int)
                    ordered = pool[expected_prediction.eq(1)].sort_values(['score', 'candidate_id'], ascending=[False, True])
                    require(pool.rule_accept.eq(0).all(), 'all_bge has a direct rule acceptance')
                else:
                    called = pd.Series(False, index=pool.index) if policy == 'rule_only' or exact.sum() >= 3 else ~exact
                    expected_prediction = exact.astype(int)
                    expected_prediction.loc[called] = pool.loc[called, 'score'].ge(pool.loc[called, 'threshold']).astype(int)
                    if policy == 'stop_3' and exact.sum() >= 3:
                        expected_prediction.loc[~exact] = -1
                    require(pool.rule_accept.eq(exact.astype(int)).all(), 'direct rule acceptance mismatch')
                    rule = pool[exact].sort_values('candidate_id')
                    model = pool[called & expected_prediction.eq(1)].sort_values(['score', 'candidate_id'], ascending=[False, True])
                    ordered = pd.concat([rule, model])
                require(pool.model_called.eq(called.astype(int)).all(), 'model-call mask mismatch')
                require(pool.prediction.eq(expected_prediction).all(), 'threshold/routing decision mismatch')
                require(pool.loc[~called, 'score'].isna().all(), 'uncalled model has a score')
                require(np.isfinite(pool.loc[called, 'score']).all(), 'called model has a nonfinite score')
                actual_list = pool[pool.returned_rank.gt(0)].sort_values('returned_rank').pair_id.tolist()
                require(actual_list == ordered.head(3).pair_id.tolist(), 'actual Top3 list mismatch')
                require(sorted(pool.loc[pool.returned_rank.gt(0), 'returned_rank']) ==
                        list(range(1, len(actual_list) + 1)), 'returned ranks are not consecutive')
            # Labels enter only after routing/ranking verification.
            evaluated = checked.merge(labels, on='pair_id', validate='many_to_one')
            for (policy, split, query), pool in evaluated.groupby(['policy', *QUERY_KEYS]):
                positive = pool.final_label.eq(1)
                returned = pool.returned_rank.gt(0)
                nonexact_positive = positive & ~pool.exact_expected
                tp = int((positive & returned).sum())
                fp = int((~positive & returned).sum())
                positive_n = int(positive.sum())
                rows.append({'seed': seed, 'policy': policy, 'evaluation_split': split,
                             'query_id': query, 'exact_n': int(pool.exact_expected.sum()),
                             'candidate_n': len(pool), 'positive_n': positive_n,
                             'exact_positive_n': int((positive & pool.exact_expected).sum()),
                             'nonexact_positive_n': int(nonexact_positive.sum()),
                             'returned_n': int(returned.sum()), 'returned_tp': tp, 'returned_fp': fp,
                             'returned_nonexact_tp': int((nonexact_positive & returned).sum()),
                             'recall_at3': tp / positive_n if positive_n else np.nan,
                             'hit': tp > 0, 'any_wrong': fp > 0,
                             'pool_rejected': not returned.any(),
                             'model_called_n': int(pool.model_called.sum())})
            source_files.append({'file': path.name, 'sha256': sha(path)})
        queries = pd.DataFrame(rows)
        queries.to_csv(output / 'formal_per_query.csv', index=False)
        summary, groups = [], []
        for (seed, policy), sub in queries.groupby(['seed', 'policy']):
            summary.append({'seed': seed, 'policy': policy, **observed_metrics(sub)})
            for exact_n, exact_group in sub.groupby('exact_n'):
                groups.append({'seed': seed, 'policy': policy, 'exact_n': exact_n,
                               **observed_metrics(exact_group)})
        summary = pd.DataFrame(summary)
        group_summary = pd.DataFrame(groups)
        summary.to_csv(output / 'formal_summary_per_seed.csv', index=False)
        aggregate(summary, ['policy']).to_csv(output / 'formal_summary_aggregate.csv', index=False)
        group_summary.to_csv(output / 'exact_count_groups_per_seed.csv', index=False)
        aggregate(group_summary, ['policy', 'exact_n']).to_csv(output / 'exact_count_groups_aggregate.csv', index=False)
        keys = pd.MultiIndex.from_frame(feature_queries[QUERY_KEYS].sort_values(QUERY_KEYS))
        seeds = sorted(queries.seed.unique())
        rng = np.random.default_rng(args.bootstrap_seed)
        draws = rng.integers(0, len(keys), size=(args.bootstrap, len(keys)))
        quality_values, quality_points = {}, {}
        for seed in seeds:
            for policy in POLICIES:
                sub = queries[(queries.seed == seed) & (queries.policy == policy)].set_index(QUERY_KEYS).reindex(keys)
                require(not sub.seed.isna().any(), 'unmatched query for quality bootstrap')
                quality_values[(seed, policy)] = resampled_quality_metrics(sub, draws)
                quality_points[(seed, policy)] = observed_metrics(sub)
        comparisons = []
        for baseline in ['all_bge', 'rule_only']:
            for metric in quality_values[(seeds[0], baseline)]:
                better = 'lower' if metric == 'wrong_reference_query_rate_pct' else 'higher'
                differences = []
                points = []
                for seed in seeds:
                    delta = quality_values[(seed, 'stop_3')][metric] - quality_values[(seed, baseline)][metric]
                    point = quality_points[(seed, 'stop_3')][metric] - quality_points[(seed, baseline)][metric]
                    differences.append(delta)
                    points.append(point)
                    comparisons.append(ci_record('formal_220_queries', seed, baseline, metric,
                                                 point, delta, args.bootstrap, 'percentage_points', better))
                comparisons.append(ci_record('formal_220_queries', 'mean_seed', baseline, metric,
                                             np.mean(points), np.mean(np.stack(differences), axis=0),
                                             args.bootstrap, 'percentage_points', better))
        pd.DataFrame(comparisons).to_csv(output / 'formal_quality_paired_bootstrap.csv', index=False)
        # Independently reconstruct repeat-median latencies from raw request timings.
        raw_time = pd.read_csv(source / 'timing_query.csv', float_precision='round_trip').rename(columns={'split': 'evaluation_split'})
        raw_time = raw_time[raw_time.evaluation_split.isin(FORMAL_SPLITS) & raw_time.policy.isin(POLICIES)]
        require(not raw_time.duplicated(['seed', 'policy', *QUERY_KEYS, 'repeat']).any(), 'duplicated query timing repeat')
        timed = raw_time.groupby(['seed', 'policy', *QUERY_KEYS], as_index=False).agg(
            repeat_n=('seconds', 'size'), seconds_median=('seconds', 'median'),
            timed_model_n=('model_pairs', 'first'), timed_candidate_n=('pairs', 'first'))
        require(timed.repeat_n.eq(3).all(), 'query latency repeat count mismatch')
        joined_timing = timed.merge(queries, on=['seed', 'policy', *QUERY_KEYS], validate='one_to_one')
        require(len(joined_timing) == len(queries), 'timing/query ID mismatch')
        require(joined_timing.timed_model_n.eq(joined_timing.model_called_n).all(), 'timing/inference routing differs')
        require(joined_timing.timed_candidate_n.eq(30).all(), 'timed candidate pool is not 30')
        joined_timing.to_csv(output / 'formal_query_latency.csv', index=False)
        latency_points, latency_values, latency_summary = {}, {}, []
        for seed in seeds:
            for policy in POLICIES:
                sub = joined_timing[(joined_timing.seed == seed) & (joined_timing.policy == policy)].set_index(QUERY_KEYS).reindex(keys)
                require(not sub.seed.isna().any(), 'unmatched query for latency bootstrap')
                milliseconds = sub.seconds_median.to_numpy() * 1000
                latency_values[(seed, policy)] = milliseconds[draws].mean(axis=1)
                latency_points[(seed, policy)] = milliseconds.mean()
                latency_summary.append({'seed': seed, 'policy': policy, 'query_n': len(sub),
                                        'weighted_mean_latency_ms': milliseconds.mean(),
                                        'query_median_latency_ms': np.median(milliseconds),
                                        'query_p95_latency_ms': np.quantile(milliseconds, .95)})
        pd.DataFrame(latency_summary).to_csv(output / 'formal_latency_per_seed.csv', index=False)
        aggregate(pd.DataFrame(latency_summary), ['policy']).to_csv(output / 'formal_latency_aggregate.csv', index=False)
        latency_comparisons = []
        for baseline in ['all_bge', 'rule_only']:
            by_metric = {'mean_latency_delta_ms': ([], []), 'latency_saving_pct': ([], [])}
            for seed in seeds:
                tested, base = latency_values[(seed, 'stop_3')], latency_values[(seed, baseline)]
                tested_point, base_point = latency_points[(seed, 'stop_3')], latency_points[(seed, baseline)]
                metrics = {'mean_latency_delta_ms': (tested_point - base_point, tested - base),
                           'latency_saving_pct': (100 * (1 - tested_point / base_point), 100 * (1 - tested / base))}
                for metric, (point, delta) in metrics.items():
                    by_metric[metric][0].append(point)
                    by_metric[metric][1].append(delta)
                    latency_comparisons.append(ci_record('formal_220_queries', seed, baseline, metric,
                        point, delta, args.bootstrap, 'milliseconds' if metric.endswith('_ms') else 'percent',
                        'lower' if metric.endswith('_ms') else 'higher'))
            for metric, (points, deltas) in by_metric.items():
                latency_comparisons.append(ci_record('formal_220_queries', 'mean_seed', baseline, metric,
                    np.mean(points), np.mean(np.stack(deltas), axis=0), args.bootstrap,
                    'milliseconds' if metric.endswith('_ms') else 'percent',
                    'lower' if metric.endswith('_ms') else 'higher'))
        pd.DataFrame(latency_comparisons).to_csv(output / 'formal_latency_paired_bootstrap.csv', index=False)
        feature_queries.to_csv(output / 'input_only_exact_count_per_query.csv', index=False)
        qa.update({'status': 'passed', 'formal_query_n': 220, 'formal_candidate_pair_n': 6600,
                   'formal_gold_positive_n': 434, 'seeds': list(map(int, seeds)),
                   'original_runner_csv_reads': csv_reads,
                   'original_runner_manifest_gold_access': False,
                   'exact_query_count_distribution': {str(k): int(v) for k, v in feature_queries.exact_n.value_counts().sort_index().items()},
                   'prediction_source_files': source_files,
                   'timing_query_sha256': sha(source / 'timing_query.csv'),
                   'inputs_sha256': sha(source / 'inputs.csv'), 'labels_sha256': sha(source / 'labels.csv'),
                   'bootstrap_iterations': args.bootstrap, 'bootstrap_random_seed': args.bootstrap_seed,
                   'bootstrap_design': '220 complete formal query pools sampled with replacement; identical draws across policies and fixed existing seeds; point latency uses three-repeat median per query.',
                   'latency_weighting': 'Each of the 220 actual query pools gets equal weight. Split-specific means are not averaged equally.',
                   'quality_mode': 'Existing real batched candidate predictions, original frozen thresholds.',
                   'inference_label_flow': 'Existing hash-verified runner only reads inputs.csv; this supplemental analysis joins gold only after input-only routing/ranking verification.',
                   'noninferiority_limit': 'CIs are empirical paired percentile estimates. No predeclared tolerance exists; no formal noninferiority pass/fail is claimed. Mean-seed CI conditions on these seeds and does not account for label uncertainty or new-agency variation.',
                   'cost_scope': 'Resident-model reference filtering only; candidate retrieval and model loading excluded. No monetary cost or human-review time measured.'})
        output_names = ['formal_per_query.csv', 'formal_summary_per_seed.csv', 'formal_summary_aggregate.csv',
                        'exact_count_groups_per_seed.csv', 'exact_count_groups_aggregate.csv',
                        'formal_quality_paired_bootstrap.csv', 'formal_query_latency.csv',
                        'formal_latency_per_seed.csv', 'formal_latency_aggregate.csv',
                        'formal_latency_paired_bootstrap.csv', 'input_only_exact_count_per_query.csv']
        qa['output_sha256'] = {name: sha(output / name) for name in output_names}
        (output / 'supplemental_README.txt').write_text(
            '本目录是已有真实30候选/最多3输出系统预测的独立补充统计，不执行新GPU推理、训练、调参或测时。\n'
            '正式测试合并locked、no_reference、no_reference_reclassified、external：220个查询、6600候选对，排除validation。\n'
            '精确数量分组只使用输入的描述与单位；金标仅用于统计兼容关系与实际返回名单，不用于分流或排序。\n'
            '每个模型的阈值来自原验证集并保持不变；既有runner的文件哈希和仅inputs.csv读取合约被独立检查。\n'
            '质量置信区间由完整query pool配对bootstrap 5000次获得，所有政策和三个固定训练种子使用同一查询抽样。\n'
            '逐查询时间从原始timing_query.csv重算每查询3次实测中位数；所有220个查询各占一个权重，不等权平均分区。\n'
            'seed=mean_seed表示现有三个模型的均值；其区间不包含新训练种子、金标不确定性或新机构变化。\n'
            '所有比例均以百分比给出；质量差值为stop3减baseline（百分点），错误查询率较低更好。\n'
            '时间差值为stop3减baseline（毫秒）；latency_saving_pct=100*(1-stop3平均时间/baseline平均时间)。\n'
            '没有预设非劣容差，不宣称通过正式非劣检验。interval_includes_deterioration只描述此次查询重采样区间是否含不利方向。\n'
            '没有正例或没有返回项时，对应召回或精确率为空；aggregate的finite_seed_n列明确有效种子数，不填造0或100。\n'
            '补救指标区分：返回非精确正例的查询，及原本没有任何精确正例的查询首次命中；不能混称。\n', encoding='utf-8')
    except Exception as error:
        qa['status'] = 'failed'
        qa['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        (output / 'supplemental_qa.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'status': 'passed', 'output_directory': str(output), 'formal_query_n': 220}, ensure_ascii=False))


if __name__ == '__main__':
    main()
