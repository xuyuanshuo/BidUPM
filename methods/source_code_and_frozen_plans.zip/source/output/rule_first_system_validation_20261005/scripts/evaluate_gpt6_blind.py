#!/usr/bin/env python3
"""Evaluate the completed, blinded GPT-6 Sol agent workflow without rejudging.

No inference, training, threshold selection, remote work, or timing is performed.
All blind inputs, mappings, and output keys are validated before labels are read.
Actual formal and runtime predictions are retained separately, including BF16
batch differences and unobserved (-1) system candidates. Percentages use 0..100.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

import analyze_runtime_validation as runtime_analysis
import system_policy


FIELDS = ["description", "normalized_description", "normalized_unit", "category", "spec_tokens"]
QUERY_KEYS = ["evaluation_split", "query_id"]
FORMAL_SPLITS = ["locked", "no_reference", "no_reference_reclassified", "external"]
FORMAL_POLICIES = ["rule_only", "all_bge", "stop_3"]
METADATA = ["source", "policy", "seed", "batch_size", "evaluation_group", "query_subset"]
GROUPS = {
    "locked": ["locked"],
    "no_reference": ["no_reference"],
    "no_reference_reclassified": ["no_reference_reclassified"],
    "external": ["external"],
    "internal_locked_plus_original_noref": ["locked", "no_reference"],
    "internal_combined": ["locked", "no_reference", "no_reference_reclassified"],
    "all_formal": FORMAL_SPLITS,
}


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rate(n, d):
    return 100.0 * n / d if d else np.nan


def json_safe(value):
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    return value


def dump_json(path, value):
    Path(path).write_text(json.dumps(json_safe(value), indent=2, ensure_ascii=False) + "\n")


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def validate_blind(blind, mapping_path, source, qa):
    """Gold fields are never read here; the exact allowlist excludes annotations."""
    plan_path = mapping_path.parent / "plan.json"
    plan = json.loads(plan_path.read_text())
    manifest_path = blind / "output_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    input_path = blind / "inputs/query_pools.jsonl"
    output_path = blind / "outputs/predictions.jsonl"
    require(manifest["input_file"] == "inputs/query_pools.jsonl", "Unexpected blind input path")
    require(manifest["prediction_file"] == "outputs/predictions.jsonl", "Unexpected prediction path")
    require(sha(input_path) == plan["input_sha256"] == manifest["input_sha256"], "Blind input SHA mismatch")
    require(plan["model_requested"] == manifest["requested_model"] == "gpt-6-sol", "Model request mismatch")
    require(plan["gold_available_to_judge"] is False and manifest["gold_access"] is False,
            "Blind workflow does not declare gold isolation")
    require(manifest["all_pools_judged"] is True and manifest["pools_judged"] == 220,
            "Blind workflow did not complete every pool")
    require(plan["query_pools"] == 220 and plan["candidate_pairs"] == 6600, "Unexpected planned scope")
    pools, predictions = read_jsonl(input_path), read_jsonl(output_path)
    require(len(pools) == len(predictions) == 220, "Expected 220 input and output pools")
    require(len({row["query_key"] for row in pools}) == 220, "Duplicate blind query key")
    require(len({row["query_key"] for row in predictions}) == 220, "Duplicate prediction query key")
    require({row["query_key"] for row in pools} == {row["query_key"] for row in predictions},
            "Input/output blind query key sets differ")
    pool_index = {row["query_key"]: row for row in pools}
    flat, prediction_records = [], []
    for pool in pools:
        require(set(pool) == {"query_key", "query", "candidates"}, "Blind pool contains unapproved fields")
        require(set(pool["query"]) == set(FIELDS), "Blind query contains metadata/annotation fields")
        require(all(isinstance(pool["query"][name], str) for name in FIELDS), "Non-string blind query field")
        require(len(pool["candidates"]) == 30, "Blind pool does not have 30 candidates")
        candidate_keys = [row["candidate_key"] for row in pool["candidates"]]
        require(len(set(candidate_keys)) == 30 and set(candidate_keys) == {f"C{i:02d}" for i in range(30)},
                "Candidate keys are not unique C00..C29")
        for candidate in pool["candidates"]:
            require(set(candidate) == {"candidate_key", *FIELDS}, "Blind candidate contains metadata/annotation fields")
            require(all(isinstance(candidate[name], str) for name in FIELDS), "Non-string blind candidate field")
            flat.append({"query_key": pool["query_key"], "candidate_key": candidate["candidate_key"],
                         **{"query_" + name: pool["query"][name] for name in FIELDS},
                         **{"candidate_" + name: candidate[name] for name in FIELDS}})
    require({row["query_key"] for row in pools} == {f"Q{i:03d}" for i in range(220)}, "Unexpected query keys")
    for row in predictions:
        require(set(row) == {"query_key", "accepted_candidates", "top3", "adjudication_complete"},
                "Prediction record has unexpected fields")
        require(row["adjudication_complete"] is True, "An output pool is incomplete")
        candidates = {x["candidate_key"] for x in pool_index[row["query_key"]]["candidates"]}
        accepted, top3 = row["accepted_candidates"], row["top3"]
        require(isinstance(accepted, list) and isinstance(top3, list), "Prediction lists malformed")
        require(len(set(accepted)) == len(accepted) and set(accepted).issubset(candidates), "Invalid accepted keys")
        require(len(set(top3)) == len(top3) and len(top3) <= 3 and set(top3).issubset(accepted), "Invalid Top3")
        for candidate in sorted(candidates):
            prediction_records.append({"query_key": row["query_key"], "candidate_key": candidate,
                                       "prediction": int(candidate in accepted),
                                       "returned_rank": top3.index(candidate) + 1 if candidate in top3 else 0})
    mapping = pd.read_csv(mapping_path, dtype=str, keep_default_na=False)
    require(list(mapping.columns) == ["query_key", "candidate_key", "pair_id"], "Mapping schema differs")
    require(len(mapping) == 6600 and not mapping.pair_id.duplicated().any(), "Mapping pair IDs not bijective")
    require(not mapping.duplicated(["query_key", "candidate_key"]).any(), "Duplicate mapping key")
    blind_frame = pd.DataFrame(flat)
    require(set(map(tuple, mapping[["query_key", "candidate_key"]].to_numpy())) ==
            set(map(tuple, blind_frame[["query_key", "candidate_key"]].to_numpy())), "Mapping key set differs")
    source_manifest = json.loads((source / "source_manifest.json").read_text())
    require(sha(source / "inputs.csv") == source_manifest["inputs_sha256"], "Frozen inputs SHA mismatch")
    inputs = pd.read_csv(source / "inputs.csv", dtype=str, keep_default_na=False)
    require(list(inputs.columns) == source_manifest["inference_input_contract"], "Frozen input contract differs")
    require(not {"final_label", "final_relevance", "difficulty", "final_conflict_type"}.intersection(inputs.columns),
            "Frozen inference input contains annotations")
    inputs = inputs[inputs.evaluation_split.isin(FORMAL_SPLITS)].copy()
    require(len(inputs) == 6600 and not inputs.pair_id.duplicated().any(), "Frozen formal pair count/key mismatch")
    require(inputs.groupby(QUERY_KEYS).size().eq(30).all() and len(inputs.groupby(QUERY_KEYS)) == 220,
            "Frozen formal pool scope mismatch")
    require(set(mapping.pair_id) == set(inputs.pair_id), "Mapping does not cover frozen formal pair IDs")
    decoded = blind_frame.merge(mapping, on=["query_key", "candidate_key"], validate="one_to_one")
    decoded = decoded.merge(inputs, on="pair_id", validate="one_to_one", suffixes=("_blind", ""))
    for role in ["query", "candidate"]:
        for name in FIELDS:
            column = role + "_" + name
            require(decoded[column].eq(decoded[column + "_blind"]).all(), f"Blind source content changed: {column}")
    require(decoded.groupby("query_key").apply(lambda x: x[QUERY_KEYS].drop_duplicates().shape[0],
            include_groups=False).eq(1).all(), "One blind pool maps to multiple frozen queries")
    require(decoded.groupby(QUERY_KEYS).query_key.nunique().eq(1).all(), "One frozen pool maps to multiple blind pools")
    decoded = mapping.merge(pd.DataFrame(prediction_records), on=["query_key", "candidate_key"], validate="one_to_one")
    decoded = decoded.merge(inputs, on="pair_id", validate="one_to_one")
    decoded["exact_match"] = system_policy.exact_mask(decoded)
    decoded["source"], decoded["policy"], decoded["seed"], decoded["batch_size"] = "gpt6_agent_blind", "gpt6_sol_agent", 0, 0
    batches = {}
    batch_hashes = []
    for path in sorted((blind / "outputs").glob("batch_*.json")):
        part = json.loads(path.read_text())
        require(not set(batches).intersection(part), "Duplicate batch output query")
        batches.update(part)
        batch_hashes.append({"file": path.name, "sha256": sha(path), "query_n": len(part)})
    require(set(batches) == set(pool_index), "Batch files do not cover every input pool")
    require(all(batches[row["query_key"]] == row["accepted_candidates"] for row in predictions),
            "Merged predictions differ from completed batch decisions")
    qa["blind_integrity"] = {
        "input_sha256": sha(input_path), "prediction_sha256": sha(output_path),
        "prediction_hash_recorded_by_evaluator": True,
        "prediction_hash_predeclared_in_judge_manifest": "prediction_sha256" in manifest,
        "output_manifest_sha256": sha(manifest_path), "plan_sha256": sha(plan_path),
        "mapping_sha256": sha(mapping_path), "frozen_inputs_sha256": sha(source / "inputs.csv"),
        "input_query_n": 220, "output_query_n": 220, "candidate_pair_n": 6600,
        "candidates_per_pool": 30, "mapping_bijection": True,
        "blind_contents_equal_frozen_source": True, "input_annotation_fields_absent": True,
        "all_candidate_keys_valid": True, "top3_subset_of_accepted": True, "maximum_returned": 3,
        "batch_merge_consistency": True, "batch_files": batch_hashes,
        "manifest_declares_gold_access": False,
        "predictions_completed_before_evaluator_gold_read": True,
        "top3_is_accepted_first_three_for_all_pools": all(row["top3"] == row["accepted_candidates"][:3] for row in predictions),
    }
    if "prediction_sha256" in manifest:
        require(sha(output_path) == manifest["prediction_sha256"], "Declared prediction hash differs")
    return inputs, decoded, source_manifest


def validate_formal(source, inputs, qa):
    execution = json.loads((source / "execution_manifest.json").read_text())
    source_manifest = json.loads((source / "source_manifest.json").read_text())
    require(execution["status"] == "complete" and execution["labels_accessed_by_runner"] is False
            and execution["gate_label_access"] is False, "Formal execution not complete/blind")
    frozen_runs = {int(row["seed"]): float(row["threshold"]) for row in source_manifest["runs"]}
    actual_runs = {int(row["seed"]): float(row["threshold"]) for row in execution["runs"]}
    require(actual_runs == frozen_runs and len(actual_runs) == 3, "Formal seeds/thresholds differ from frozen source")
    require(all(row["status"] == "complete" for row in execution["runs"]), "Formal seed incomplete")
    rows, records = [], []
    exact_by_id = pd.Series(system_policy.exact_mask(inputs), index=inputs.pair_id)
    for run in execution["runs"]:
        path = source / f"predictions_seed_{run['seed']}.csv"
        require(sha(path) == run["prediction_sha256"], "Formal prediction SHA mismatch")
        raw = pd.read_csv(path, float_precision="round_trip")
        raw = raw[raw.policy.isin(FORMAL_POLICIES) & raw.pair_id.isin(inputs.pair_id)].copy()
        require(len(raw) == len(inputs) * 3 and not raw.duplicated(["policy", "pair_id"]).any(),
                "Formal prediction key/count mismatch")
        require(raw.seed.eq(run["seed"]).all() and raw.threshold.eq(run["threshold"]).all(), "Frozen formal settings differ")
        require(raw.prediction.isin([-1, 0, 1]).all(), "Invalid formal prediction")
        require(raw.returned_rank.isin([0, 1, 2, 3]).all(), "Invalid formal rank")
        frame = raw.merge(inputs, on="pair_id", validate="many_to_one")
        expected_exact = frame.pair_id.map(exact_by_id).to_numpy(bool)
        require(frame.exact_match.eq(expected_exact.astype(int)).all(), "Formal exact feature differs")
        for (policy, split, query), part in frame.groupby(["policy", *QUERY_KEYS]):
            exact = part.exact_match.eq(1)
            called = pd.Series(True, index=part.index) if policy == "all_bge" else (
                pd.Series(False, index=part.index) if policy == "rule_only" or int(exact.sum()) >= 3 else ~exact)
            accepted_rule = pd.Series(False, index=part.index) if policy == "all_bge" else exact
            expected = accepted_rule.astype(int)
            expected.loc[called] = part.loc[called, "score"].ge(part.loc[called, "threshold"]).astype(int)
            if policy == "stop_3" and int(exact.sum()) >= 3:
                expected.loc[~exact] = -1
            require(part.model_called.eq(called.astype(int)).all(), "Formal input-only routing differs")
            require(part.rule_accept.eq(accepted_rule.astype(int)).all(), "Formal direct acceptance differs")
            require(part.prediction.eq(expected).all(), "Formal threshold decisions differ")
            require(part.loc[~called, "score"].isna().all() and np.isfinite(part.loc[called, "score"]).all(),
                    "Formal score visibility differs")
            if policy == "all_bge":
                ordered = part[expected.eq(1)].sort_values(["score", "candidate_id"], ascending=[False, True])
            else:
                ordered = pd.concat([part[accepted_rule].sort_values("candidate_id"),
                                     part[called & expected.eq(1)].sort_values(["score", "candidate_id"], ascending=[False, True])])
            actual = part[part.returned_rank.gt(0)].sort_values("returned_rank")
            require(actual.pair_id.tolist() == ordered.head(3).pair_id.tolist(), "Formal Top3 differs")
            require(actual.returned_rank.tolist() == list(range(1, len(actual) + 1)), "Formal ranks nonconsecutive")
        frame["source"], frame["batch_size"] = "formal_actual", 64
        frame["policy"] = frame.policy.replace({"stop_3": "system_top3"})
        rows.append(frame)
        records.append({"seed": run["seed"], "sha256": sha(path), "file": str(path), "validated_before_gold": True})
    qa["formal_prediction_integrity"] = records
    return pd.concat(rows, ignore_index=True)


def validate_runtime(source, runtime, qa):
    runtime_qa = {}
    inputs, source_manifest, manifest = runtime_analysis.read_inputs(source, runtime, runtime_qa)
    predictions = runtime_analysis.validate_predictions(runtime, inputs, source_manifest, manifest, runtime_qa)
    predictions = predictions.merge(inputs.drop(columns=["evaluation_split", "query_id", "candidate_id"]),
                                    on="pair_id", validate="many_to_one")
    predictions["source"] = "runtime_actual"
    qa["runtime_prediction_integrity"] = runtime_qa
    return predictions


def pair_metrics(part, prefix="pair_"):
    observed = part.prediction.isin([0, 1])
    result = {prefix + "n": len(part), prefix + "gold_positive_n": int(part.final_label.sum()),
              prefix + "observed_n": int(observed.sum()), prefix + "unobserved_n": int((~observed).sum()),
              prefix + "metrics_evaluated": bool(observed.all())}
    names = ["tp", "fp", "fn", "tn", "precision_pct", "recall_pct", "f1_pct", "accuracy_pct"]
    if not len(part) or not observed.all():
        result.update({prefix + name: np.nan for name in names})
        return result
    gold, prediction = part.final_label.eq(1), part.prediction.eq(1)
    tp, fp = int((gold & prediction).sum()), int((~gold & prediction).sum())
    fn, tn = int((gold & ~prediction).sum()), int((~gold & ~prediction).sum())
    result.update({prefix + "tp": tp, prefix + "fp": fp, prefix + "fn": fn, prefix + "tn": tn,
                   prefix + "precision_pct": rate(tp, tp + fp), prefix + "recall_pct": rate(tp, tp + fn),
                   prefix + "f1_pct": rate(2 * tp, 2 * tp + fp + fn), prefix + "accuracy_pct": rate(tp + tn, len(part))})
    return result


def per_query(predictions):
    rows = []
    for key, part in predictions.groupby(["source", "policy", "seed", "batch_size", *QUERY_KEYS]):
        gold, returned, exact = part.final_label.eq(1), part.returned_rank.gt(0), part.exact_match.astype(bool)
        hard = part.difficulty.eq("hard")
        positive, tp, fp = int(gold.sum()), int((gold & returned).sum()), int((~gold & returned).sum())
        rows.append({**dict(zip(["source", "policy", "seed", "batch_size", *QUERY_KEYS], key)),
                     "candidate_n": len(part), "positive_n": positive,
                     "hard_pair_n": int(hard.sum()), "hard_positive_n": int((hard & gold).sum()),
                     "exact_positive_n": int((gold & exact).sum()), "nonexact_positive_n": int((gold & ~exact).sum()),
                     "returned_n": tp + fp, "returned_tp": tp, "returned_fp": fp,
                     "returned_nonexact_tp": int((gold & ~exact & returned).sum()),
                     "recall_at3": tp / positive if positive else np.nan,
                     "hit": tp > 0, "any_wrong": fp > 0, "pool_rejected": tp + fp == 0})
    return pd.DataFrame(rows)


def query_metrics(q):
    positive, noref = q.positive_n.gt(0), q.positive_n.eq(0)
    nonexact, noexact = q.nonexact_positive_n.gt(0), q.positive_n.gt(0) & q.exact_positive_n.eq(0)
    tp, fp = int(q.returned_tp.sum()), int(q.returned_fp.sum())
    return {"query_n": len(q), "positive_query_n": int(positive.sum()), "no_reference_query_n": int(noref.sum()),
            "gold_positive_n": int(q.positive_n.sum()), "returned_n": tp + fp,
            "returned_tp_n": tp, "returned_fp_n": fp, "returned_precision_pct": rate(tp, tp + fp),
            "macro_recall_at3_pct": 100.0 * q.loc[positive, "recall_at3"].mean(),
            "micro_recall_at3_pct": rate(tp, q.positive_n.sum()),
            "hit_query_n": int(q.loc[positive, "hit"].sum()), "hit_at3_pct": rate(q.loc[positive, "hit"].sum(), positive.sum()),
            "wrong_reference_query_n": int(q.any_wrong.sum()), "wrong_reference_query_rate_pct": rate(q.any_wrong.sum(), len(q)),
            "no_reference_rejected_query_n": int(q.loc[noref, "pool_rejected"].sum()),
            "no_reference_pool_rejection_pct": rate(q.loc[noref, "pool_rejected"].sum(), noref.sum()),
            "mean_returned_n": q.returned_n.mean(),
            "nonexact_positive_query_n": int(nonexact.sum()), "nonexact_positive_n": int(q.nonexact_positive_n.sum()),
            "returned_nonexact_tp_n": int(q.returned_nonexact_tp.sum()),
            "nonexact_micro_recall_at3_pct": rate(q.returned_nonexact_tp.sum(), q.nonexact_positive_n.sum()),
            "nonexact_rescued_query_n": int(q.loc[nonexact, "returned_nonexact_tp"].gt(0).sum()),
            "nonexact_positive_query_rescue_pct": rate(q.loc[nonexact, "returned_nonexact_tp"].gt(0).sum(), nonexact.sum()),
            "no_exact_positive_query_n": int(noexact.sum()), "no_exact_positive_hit_query_n": int(q.loc[noexact, "hit"].sum()),
            "no_exact_positive_query_hit_pct": rate(q.loc[noexact, "hit"].sum(), noexact.sum())}


def summarize(predictions, queries):
    rows = []
    for name, splits in GROUPS.items():
        selected = predictions[predictions.evaluation_split.isin(splits)]
        qselected = queries[queries.evaluation_split.isin(splits)]
        for key, part in selected.groupby(["source", "policy", "seed", "batch_size"]):
            identity = dict(zip(["source", "policy", "seed", "batch_size"], key))
            q = qselected.copy()
            for column, value in identity.items():
                q = q[q[column].eq(value)]
            row = {**identity, "evaluation_group": name, "query_subset": "all_queries",
                   **query_metrics(q), **pair_metrics(part), **pair_metrics(part[part.difficulty.eq("hard")], "hard_pair_")}
            rows.append(row)
            # The difficult pair subset is frozen difficulty==hard. For a useful
            # Top3 difficulty view, keep the actual full-pool returned lists and
            # select queries containing at least one frozen hard positive.
            hard_q = q[q.hard_positive_n.gt(0)]
            hard_keys = set(map(tuple, hard_q[QUERY_KEYS].to_numpy()))
            hard_part = part[part[QUERY_KEYS].apply(tuple, axis=1).isin(hard_keys)]
            rows.append({**identity, "evaluation_group": name, "query_subset": "hard_positive_queries",
                         **query_metrics(hard_q), **pair_metrics(hard_part),
                         **pair_metrics(hard_part[hard_part.difficulty.eq("hard")], "hard_pair_")})
    return pd.DataFrame(rows)


def aggregate(frame):
    identifiers = ["source", "policy", "batch_size", "evaluation_group", "query_subset"]
    metrics = [x for x in frame.columns if x not in METADATA and not x.endswith("metrics_evaluated")]
    rows = []
    for key, part in frame.groupby(identifiers):
        identity = dict(zip(identifiers, key))
        for metric in metrics:
            values = pd.to_numeric(part[metric], errors="raise").dropna().to_numpy(float)
            rows.append({**identity, "metric": metric, "run_n": len(part), "finite_run_n": len(values),
                         "mean": values.mean() if len(values) else np.nan,
                         "sample_sd": values.std(ddof=1) if len(values) > 1 else np.nan,
                         "sd_basis": "Existing checkpoint seeds" if identity["source"] != "gpt6_agent_blind" else "Unavailable: one completed blind workflow"})
    return pd.DataFrame(rows)


def error_outputs(gpt, out):
    pred, gold, returned = gpt.prediction.eq(1), gpt.final_label.eq(1), gpt.returned_rank.gt(0)
    errors = gpt[(pred & ~gold) | (~pred & gold)].copy()
    errors["error_type"] = np.where(errors.prediction.eq(1), "accepted_false_positive", "accepted_false_negative")
    errors["returned_false_positive"] = errors.prediction.eq(1) & errors.final_label.eq(0) & errors.returned_rank.gt(0)
    columns = ["error_type", "evaluation_split", "query_key", "candidate_key", "pair_id", "query_id", "candidate_id",
               "query_description", "candidate_description", "query_normalized_unit", "candidate_normalized_unit",
               "prediction", "returned_rank", "returned_false_positive", "final_label", "final_relevance", "difficulty", "exact_match"]
    errors[columns].sort_values(["error_type", "evaluation_split", "pair_id"]).to_csv(out / "all_pair_errors.csv", index=False)
    # Fixed seed sampling is descriptive only; it never changes decisions.
    samples = []
    for (_, _), part in errors.groupby(["error_type", "evaluation_split"]):
        samples.append(part.sample(n=min(3, len(part)), random_state=20261005))
    if samples:
        sampled = pd.concat(samples)[columns].sort_values(["error_type", "evaluation_split", "pair_id"])
        sampled.to_csv(out / "sampled_pair_errors.csv", index=False)
        # These comments describe visible wording and the already-frozen label;
        # they are not a second label judgment or claims about model reasoning.
        differences = {
            "LOC001234": "The candidate specifies a sanitary sewer clean-out; the query uses the broader pipe clean out wording.",
            "LOC001236": "The candidate specifies a sanitary sewer clean-out; the query uses the broader pipe clean out wording.",
            "LOC001642": "The candidate adds SIDE DRAIN to the 24-inch drainage pipe description; diameter and units agree.",
            "NOR001021": "The query specifies black vinyl coating; the shorter chain-link candidate retains 48-inch fabric but omits the coating wording.",
            "NOR001022": "The query specifies black vinyl coating; the shorter chain-link candidate retains 48-inch fabric but omits the coating wording.",
            "EXT000237": "The candidate says drainage structure removal, while the query names a concrete inlet specifically.",
            "EXT000754": "The query names a concrete inlet; the candidate specifies a grate inlet, type 2.",
            "EXT001993": "The query names a painted STOP line; the candidate uses the broader paint line wording.",
            "LOC000438": "Both name I19.0C intermediate asphalt course; the candidate additionally specifies LEVELING COURSE.",
            "LOC002018": "The query specifies repairs to prestressed concrete girders; the candidate only says concrete repairs.",
            "LOC002019": "The query specifies repairs to prestressed concrete girders; the candidate only says concrete repairs.",
            "NOR000070": "The query names reinforced soil slopes; the candidate specifies soil nail slope stabilization.",
            "NOR000606": "Both contain type S9.5C, while the query names asphalt CAP and the candidate names asphalt surface course.",
            "NOR000774": "The query names a culvert diversion channel; the candidate names drainage ditch excavation.",
            "NOR000692": "Both contain CLASS IV stabilization; the query names aggregate and the candidate names subgrade.",
            "NOR000693": "Both contain CLASS IV stabilization; the query names aggregate and the candidate names subgrade.",
            "NOR000694": "Both contain CLASS IV stabilization; the query names aggregate and the candidate names subgrade.",
        }
        sampled["observable_wording_difference"] = sampled.pair_id.map(differences)
        require(sampled.observable_wording_difference.notna().all(), "Error sample explanation coverage changed")
        sampled["evaluation_interpretation"] = sampled.apply(
            lambda row: (f"Frozen gold is {row.final_relevance} (positive), but the blind workflow rejected this candidate. "
                         "This is a false negative under the existing reference standard."
                         if row.error_type == "accepted_false_negative" else
                         f"Frozen gold is {row.final_relevance} (negative), but the blind workflow accepted this candidate. "
                         + ("It was also returned in Top3." if row.returned_rank > 0 else "It was excluded from the final Top3.")), axis=1)
        sampled["internal_model_cause_known"] = False
        sampled.to_csv(out / "failure_examples.csv", index=False)
    omitted = gpt[gold & pred & ~returned].copy()
    omitted[["evaluation_split", "query_key", "candidate_key", "pair_id", "query_description", "candidate_description", "final_relevance", "difficulty"]].to_csv(out / "accepted_positive_not_returned.csv", index=False)
    return {"accepted_false_positive_n": int((pred & ~gold).sum()), "accepted_false_negative_n": int((~pred & gold).sum()),
            "returned_false_positive_n": int((returned & ~gold).sum()), "gold_positive_not_returned_n": int((gold & ~returned).sum()),
            "accepted_positive_excluded_by_top3_n": len(omitted), "sample_seed": 20261005,
            "sample_policy": "At most 3 per error type and raw split, fixed random seed; no rejudging"}


def failure_checks(blind, mapping, source):
    """Adversarial contract checks, using isolated copies and blocking gold reads."""
    records = []
    original_read_csv = pd.read_csv
    gold_reads = []

    def guarded_read(path, *args, **kwargs):
        if Path(path).name == "labels.csv":
            gold_reads.append(str(path))
            raise AssertionError("Gold was read during a pre-gold integrity check")
        return original_read_csv(path, *args, **kwargs)

    for name in ["valid_control", "unknown_accepted_key", "top3_outside_accepted", "over_three_returns",
                 "duplicate_mapping_pair", "annotation_in_blind_input", "changed_blind_unit"]:
        with tempfile.TemporaryDirectory(prefix="gpt6_blind_qa_") as directory:
            temp = Path(directory)
            fake_blind, fake_private = temp / "blind", temp / "private"
            shutil.copytree(blind, fake_blind)
            fake_private.mkdir()
            fake_mapping = fake_private / "private_mapping.csv"
            shutil.copyfile(mapping, fake_mapping)
            shutil.copyfile(mapping.parent / "plan.json", fake_private / "plan.json")
            prediction_path = fake_blind / "outputs/predictions.jsonl"
            prediction = read_jsonl(prediction_path)
            if name == "unknown_accepted_key":
                prediction[0]["accepted_candidates"] = ["C99"]
            elif name == "top3_outside_accepted":
                prediction[0]["top3"] = ["C00"]
            elif name == "over_three_returns":
                prediction[0]["accepted_candidates"] = ["C00", "C01", "C02", "C03"]
                prediction[0]["top3"] = prediction[0]["accepted_candidates"][:]
            if name in ["unknown_accepted_key", "top3_outside_accepted", "over_three_returns"]:
                prediction_path.write_text("".join(json.dumps(row) + "\n" for row in prediction))
            if name == "duplicate_mapping_pair":
                frame = original_read_csv(fake_mapping, dtype=str)
                frame.loc[1, "pair_id"] = frame.loc[0, "pair_id"]
                frame.to_csv(fake_mapping, index=False)
            if name in ["annotation_in_blind_input", "changed_blind_unit"]:
                input_path = fake_blind / "inputs/query_pools.jsonl"
                rows = read_jsonl(input_path)
                if name == "annotation_in_blind_input":
                    rows[0]["query"]["difficulty"] = "hard"
                else:
                    rows[0]["candidates"][0]["normalized_unit"] = "each"
                input_path.write_text("".join(json.dumps(row) + "\n" for row in rows))
                # Update the blind hash only, so semantic/source or annotation
                # checks must still detect corruption after a matching hash.
                for path in [fake_blind / "output_manifest.json", fake_private / "plan.json"]:
                    data = json.loads(path.read_text())
                    data["input_sha256"] = sha(input_path)
                    dump_json(path, data)
            expected_failure = name != "valid_control"
            failed, message = False, ""
            try:
                with patch.object(pd, "read_csv", guarded_read):
                    validate_blind(fake_blind, fake_mapping, source, {})
            except ValueError as error:
                failed, message = True, str(error)
            require(failed == expected_failure, f"Fail-closed QA failed: {name}")
            records.append({"case": name, "expected_failure": expected_failure, "check_passed": True, "error": message})
    require(not gold_reads, "Gold accessed in integrity fixtures")
    return {"status": "passed", "fixture_n": len(records), "gold_reads": 0,
            "isolated_copies_only": True, "original_artifacts_modified": False, "cases": records}


def write_display_table(aggregate_frame, out):
    metrics = ["pair_precision_pct", "pair_recall_pct", "pair_f1_pct", "pair_accuracy_pct",
               "returned_precision_pct", "macro_recall_at3_pct", "micro_recall_at3_pct", "hit_at3_pct",
               "wrong_reference_query_rate_pct", "no_reference_pool_rejection_pct",
               "nonexact_positive_query_rescue_pct", "hard_pair_precision_pct", "hard_pair_recall_pct", "hard_pair_f1_pct"]
    primary = aggregate_frame[aggregate_frame.source.isin(["gpt6_agent_blind", "formal_actual"]) &
                              aggregate_frame.evaluation_group.eq("all_formal") &
                              aggregate_frame.query_subset.eq("all_queries") & aggregate_frame.metric.isin(metrics)]
    rows = []
    for metric in metrics:
        row = {"metric": metric}
        for policy in ["rule_only", "all_bge", "system_top3", "gpt6_sol_agent"]:
            value = primary[primary.metric.eq(metric) & primary.policy.eq(policy)].iloc[0]
            row[policy] = ("undefined" if not np.isfinite(value["mean"]) else
                           f"{value['mean']:.8f}" if value.source == "gpt6_agent_blind" else
                           f"{value['mean']:.8f} ± {value.sample_sd:.8f}")
        rows.append(row)
    pd.DataFrame(rows).to_csv(out / "comparison_primary_display.csv", index=False)


def crosscheck_existing_summaries(summary, source, runtime, out):
    """Confirm the independent computations reproduce already-audited baselines."""
    formal_map = {"pair_precision_pct": "precision_pct", "pair_recall_pct": "recall_pct", "pair_f1_pct": "f1_pct",
                  "hard_pair_precision_pct": "hard_precision_pct", "hard_pair_recall_pct": "hard_recall_pct", "hard_pair_f1_pct": "hard_f1_pct",
                  "query_n": "query_n", "positive_query_n": "positive_query_n", "no_reference_query_n": "no_reference_query_n",
                  "returned_tp_n": "returned_tp_n", "returned_fp_n": "returned_fp_n", "returned_precision_pct": "returned_micro_precision_pct",
                  "macro_recall_at3_pct": "macro_recall_at3_pct", "micro_recall_at3_pct": "returned_micro_recall_at3_pct",
                  "hit_at3_pct": "hit_at3_pct", "wrong_reference_query_rate_pct": "wrong_reference_query_rate_pct",
                  "no_reference_pool_rejection_pct": "no_reference_pool_rejection_pct",
                  "nonexact_positive_query_rescue_pct": "nonexact_positive_query_coverage_pct"}
    runtime_map = {"pair_precision_pct": "pair_precision_pct", "pair_recall_pct": "pair_recall_pct", "pair_f1_pct": "pair_f1_pct",
                   "query_n": "queries", "positive_query_n": "positive_queries", "returned_tp_n": "returned_tp", "returned_fp_n": "returned_fp",
                   "returned_precision_pct": "returned_precision_pct", "macro_recall_at3_pct": "macro_recall_at3_pct", "hit_at3_pct": "hit_at3_pct",
                   "wrong_reference_query_rate_pct": "wrong_reference_query_pct", "no_reference_pool_rejection_pct": "no_reference_rejection_pct"}
    paths = {"formal_actual": source / "summary_per_seed.csv",
             "runtime_actual": runtime.parent / "runtime_analysis/runtime_quality_per_seed.csv"}
    records = []
    for source_name, path in paths.items():
        reference = pd.read_csv(path)
        reference["policy"] = reference.policy.replace({"stop_3": "system_top3"})
        if source_name == "formal_actual":
            reference["batch_size"] = 64
        reference = reference[reference.policy.isin(["rule_only", "all_bge", "system_top3"])]
        selected = summary[summary.source.eq(source_name) & summary.query_subset.eq("all_queries") &
                           summary.evaluation_group.isin(reference.evaluation_group.unique())]
        mapping = formal_map if source_name == "formal_actual" else runtime_map
        keys = ["evaluation_group", "seed", "policy", "batch_size"]
        matched = selected.merge(reference, on=keys, validate="one_to_one", suffixes=("_computed", "_reference"))
        require(len(matched) == len(selected), f"{source_name}: historical summary coverage incomplete")
        for metric, original in mapping.items():
            computed_column = metric + "_computed" if metric in reference.columns else metric
            reference_column = original + "_reference" if original in selected.columns else original
            # Historical summaries suppress all system pair metrics by policy,
            # even in a small split where every candidate happened to be scored.
            # Compare full-pair baselines only; actual returned-list checks cover
            # the system. Our all-formal system pair metrics are also undefined.
            check = matched[matched.policy.ne("system_top3")] if metric.startswith(("pair_", "hard_pair_")) else matched
            computed = check[computed_column].to_numpy(float)
            frozen = check[reference_column].to_numpy(float)
            require(np.allclose(computed, frozen, rtol=0, atol=1e-10, equal_nan=True), f"Baseline summary differs: {source_name}/{metric}")
            finite = np.isfinite(computed) & np.isfinite(frozen)
            records.append({"source": source_name, "metric": metric, "reference_metric": original,
                            "condition_n": len(check), "finite_condition_n": int(finite.sum()),
                            "maximum_absolute_difference": float(np.abs(computed[finite] - frozen[finite]).max()) if finite.any() else np.nan,
                            "passed": True, "reference_sha256": sha(path)})
    pd.DataFrame(records).to_csv(out / "baseline_summary_crosscheck.csv", index=False)
    return {"status": "passed", "metric_check_n": len(records), "absolute_tolerance": 1e-10,
            "all_conditions_reproduced": True, "original_summaries_unmodified": True}


def write_readme(out, qa, summary):
    rows = summary[(summary.source.eq("gpt6_agent_blind")) & summary.query_subset.eq("all_queries")]
    main = rows[rows.evaluation_group.eq("all_formal")].iloc[0]
    text = f"""# Completed blinded GPT-6 Sol agent workflow: independent frozen-label evaluation

This is one completed Codex model-agent semantic screening workflow (requested model gpt-6-sol, medium reasoning). It is not a standalone API benchmark, a repeated single-prompt experiment, or an API cost/latency experiment. All 6,600 candidates were screened across 220 blinded 30-candidate pools in completed groups before this evaluator read gold. The input and output key/content/hash checks pass. The judge manifest declares gold_access=false; this declaration is reported as provenance, rather than treated as a general audit of model internals.

GPT binary candidate acceptance: TP={int(main.pair_tp)}, FP={int(main.pair_fp)}, FN={int(main.pair_fn)}, TN={int(main.pair_tn)}; precision={main.pair_precision_pct:.8f}%, recall={main.pair_recall_pct:.8f}%, F1={main.pair_f1_pct:.8f}%, accuracy={main.pair_accuracy_pct:.8f}%.

GPT actual Top3: {int(main.returned_n)} returned, {int(main.returned_tp_n)} true and {int(main.returned_fp_n)} false references; returned precision={main.returned_precision_pct:.8f}%, macro Recall@3={main.macro_recall_at3_pct:.8f}%, micro Recall@3={main.micro_recall_at3_pct:.8f}%, Hit@3={main.hit_at3_pct:.8f}%. Wrong-reference queries={int(main.wrong_reference_query_n)}/{int(main.query_n)} ({main.wrong_reference_query_rate_pct:.8f}%); genuine no-reference rejection={int(main.no_reference_rejected_query_n)}/{int(main.no_reference_query_n)} ({main.no_reference_pool_rejection_pct:.8f}%).

Definitions and boundaries:
- Pair P/R/F1/accuracy use all accepted-candidate binary decisions and the frozen labels. System full-pair metrics are blank if any candidate remains unobserved (-1); those candidates are never silently converted to negatives.
- Top3 metrics use each actual returned list, with no reranking or tuning. Returned precision pools returned references. Macro recall averages positive query pools; micro recall divides returned true references by all frozen positives. Hit@3 uses positive query pools. Wrong-reference rate uses every query pool. No-reference rejection uses only genuinely zero-positive pools, including any such pools in locked/external.
- Nonexact means the frozen input-only description+unit rule does not accept the pair; it is distinct from the graded label acceptable. Nonexact rescue counts queries with at least one nonexact positive and at least one such positive returned. No-exact-positive hit counts positive queries with no rule-positive candidate.
- Difficult pair metrics use only frozen difficulty==hard, matching the existing definition. The separately labeled hard_positive_queries Top3 view selects pools with at least one frozen hard positive but retains their full actual returned lists and full gold positives. No difficulty label affected inference.
- formal_actual uses original formal prediction files for fixed rule, all BGE, and stop_3, renamed system_top3. runtime_actual uses all actual batch sizes (1,16,64), preserving recorded BF16 differences. Comparisons are separately aggregated within source/batch over the three existing checkpoint seeds, with sample SD (ddof=1). The GPT workflow has one run and no measured SD. Seed=0 and batch_size=0 denote this single workflow, not a model seed or inference batch.
- All rates are percentages. No labels were rejudged, no thresholds tuned, no missing output guessed, and no candidate inference or new timings run. GPT token counts, measured timing, and monetary/API cost are unavailable; no cost or latency conclusion follows.

Files: comparison_per_seed.csv has exact counts and metrics; comparison_aggregate.csv has mean and sample SD; comparison_primary.csv is the all-formal formal_actual comparison; comparison_primary_display.csv formats its percentages; split_gold_counts.csv contains denominators; per_query.csv and blind_pair_predictions.csv support audit; all_pair_errors.csv contains every GPT pair error; sampled_pair_errors.csv uses a fixed descriptive sample; failure_examples.csv describes visible wording and frozen outcomes without claiming to know internal model reasoning; accepted_positive_not_returned.csv separates Top3 truncation from candidate rejection; baseline_summary_crosscheck.csv confirms independent baseline reproduction; qa_failure_checks.json records corruption detection; qa.json contains hashes and checks.

Blind prediction SHA-256: {qa['blind_integrity']['prediction_sha256']}
This hash was recorded by the independent evaluator. The completed judge output manifest did not predeclare a prediction hash.
"""
    (out / "README.md").write_text(text)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    project = Path(__file__).resolve().parents[1]
    parser.add_argument("--source", type=Path, default=project.parent / "rule_first_system_20261004/results/server")
    parser.add_argument("--runtime", type=Path, default=project / "results/runtime")
    parser.add_argument("--blind", type=Path, default=project / "blind_gpt6_sol")
    parser.add_argument("--mapping", type=Path, default=project / "results/gpt6_sol_blind/private_mapping.csv")
    parser.add_argument("--output", type=Path, default=project / "results/gpt6_sol_blind/evaluation")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    qa = {"status": "started", "created_utc": datetime.now(timezone.utc).isoformat(),
          "script_sha256": sha(Path(__file__)), "gold_for_evaluation_only": True,
          "python_executable": sys.executable, "python_version": sys.version,
          "new_inference_performed": False, "thresholds_retuned": False, "gold_rejudged": False,
          "token_counts_available": False, "measured_gpt_timing_available": False, "api_cost_available": False,
          "evaluation_scope": "One completed blinded GPT-6 Sol Codex agent screening workflow; frozen-label evaluation only",
          "hard_definition": "Frozen difficulty==hard pairs; Top3 difficult query view contains at least one hard positive",
          "system_pair_metrics": "Undefined whenever any candidate remains unobserved (-1)"}
    try:
        inputs, gpt, source_manifest = validate_blind(args.blind.resolve(), args.mapping.resolve(), args.source.resolve(), qa)
        formal = validate_formal(args.source.resolve(), inputs, qa)
        runtime = validate_runtime(args.source.resolve(), args.runtime.resolve(), qa)
        qa["all_prediction_validation_completed_before_gold_read"] = True
        qa["fail_closed_checks"] = failure_checks(args.blind.resolve(), args.mapping.resolve(), args.source.resolve())
        dump_json(out / "qa_failure_checks.json", qa["fail_closed_checks"])
        # The first label read is deliberately here, after every prediction check.
        label_path = args.source.resolve() / "labels.csv"
        require(sha(label_path) == source_manifest["labels_sha256"], "Frozen labels SHA mismatch")
        labels = pd.read_csv(label_path, keep_default_na=False)
        require(not labels.pair_id.duplicated().any() and labels.final_label.isin([0, 1]).all(), "Frozen labels invalid")
        require(labels.difficulty.isin(["easy", "hard"]).all(), "Unknown frozen difficulty")
        require(labels.final_relevance.isin(["exact", "acceptable", "related", "wrong"]).all(), "Unknown graded relevance")
        require(labels.final_label.eq(labels.final_relevance.isin(["exact", "acceptable"]).astype(int)).all(), "Gold label/grade disagree")
        require(set(inputs.pair_id).issubset(set(labels.pair_id)), "Formal label coverage incomplete")
        predictions = pd.concat([gpt, formal, runtime], ignore_index=True).merge(labels, on="pair_id", validate="many_to_one")
        require(predictions.loc[predictions.source.eq("gpt6_agent_blind"), "final_label"].sum() == 434, "Formal positives differ")
        queries = per_query(predictions)
        summary = summarize(predictions, queries)
        aggregate_frame = aggregate(summary)
        qa["baseline_summary_crosscheck"] = crosscheck_existing_summaries(summary, args.source.resolve(), args.runtime.resolve(), out)
        gpt_evaluated = predictions[predictions.source.eq("gpt6_agent_blind")].copy()
        qa["errors"] = error_outputs(gpt_evaluated, out)
        pairs_columns = ["query_key", "candidate_key", "pair_id", *QUERY_KEYS, "candidate_id", "prediction", "returned_rank",
                         "exact_match", "final_label", "final_relevance", "difficulty", "query_description", "candidate_description"]
        gpt_evaluated[pairs_columns].to_csv(out / "blind_pair_predictions.csv", index=False)
        queries.to_csv(out / "per_query.csv", index=False)
        summary.to_csv(out / "comparison_per_seed.csv", index=False)
        aggregate_frame.to_csv(out / "comparison_aggregate.csv", index=False)
        write_display_table(aggregate_frame, out)
        primary = aggregate_frame[aggregate_frame.source.isin(["gpt6_agent_blind", "formal_actual"]) &
                                  aggregate_frame.evaluation_group.eq("all_formal") & aggregate_frame.query_subset.eq("all_queries")]
        primary.to_csv(out / "comparison_primary.csv", index=False)
        gold = inputs.merge(labels, on="pair_id", validate="one_to_one")
        gold_queries = gpt_evaluated.groupby(QUERY_KEYS).agg(positive_n=("final_label", "sum"))
        counts = []
        for group, splits in GROUPS.items():
            part = gold[gold.evaluation_split.isin(splits)]
            pq = gold_queries[gold_queries.index.get_level_values("evaluation_split").isin(splits)]
            counts.append({"evaluation_group": group, "query_n": len(pq), "pair_n": len(part),
                           "positive_n": int(part.final_label.sum()), "negative_n": int(part.final_label.eq(0).sum()),
                           "positive_query_n": int(pq.positive_n.gt(0).sum()), "no_reference_query_n": int(pq.positive_n.eq(0).sum()),
                           "hard_pair_n": int(part.difficulty.eq("hard").sum()),
                           "hard_positive_n": int((part.difficulty.eq("hard") & part.final_label.eq(1)).sum())})
        pd.DataFrame(counts).to_csv(out / "split_gold_counts.csv", index=False)
        qa["frozen_labels_sha256"] = sha(label_path)
        qa["split_denominators"] = counts
        qa["seed_n"] = {"gpt6_agent_blind": 1, "formal_actual": 3, "runtime_actual": 3}
        qa["runtime_batches"] = [1, 16, 64]
        qa["rates"] = "Percentages; undefined denominators are blank/NaN"
        qa["all_formal_gpt_metrics"] = summary[summary.source.eq("gpt6_agent_blind") &
                                                 summary.evaluation_group.eq("all_formal") &
                                                 summary.query_subset.eq("all_queries")].iloc[0].to_dict()
        qa["status"] = "passed"
        write_readme(out, qa, summary)
        qa["output_hashes"] = {path.name: sha(path) for path in sorted(out.iterdir()) if path.is_file() and path.name != "qa.json"}
        dump_json(out / "qa.json", qa)
        print(json.dumps(json_safe({"status": "passed", "output": str(out), "gpt_all_formal": qa["all_formal_gpt_metrics"],
                                    "errors": qa["errors"]}), ensure_ascii=False))
    except Exception as error:
        qa["status"], qa["error"] = "failed", str(error)
        dump_json(out / "qa.json", qa)
        raise


if __name__ == "__main__":
    main()
