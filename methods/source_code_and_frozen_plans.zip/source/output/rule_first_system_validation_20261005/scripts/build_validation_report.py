#!/usr/bin/env python3
"""A report built only after all real runtime and policy checks pass."""
import argparse,json
from pathlib import Path
import pandas as pd
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Image

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--directory',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();p=a.directory/'results';new=p/'runtime_analysis'
    for f in [p/'supplemental_qa.json',p/'qa/system_policy_report.json',new/'runtime_validation_qa.json']:
        assert json.loads(f.read_text())['status']=='passed',f
    manifest=json.loads((p/'runtime/execution_manifest.json').read_text());assert manifest['status']=='complete'
    quality=pd.read_csv(p/'formal_summary_aggregate.csv');quality=quality.set_index('policy')
    per_seed=pd.read_csv(p/'formal_summary_per_seed.csv')
    no_exact_hits='、'.join(str(int(v)) for v in per_seed[per_seed.policy=='stop_3'].sort_values('seed').no_exact_positive_query_hit_n)
    ci=pd.read_csv(p/'formal_quality_paired_bootstrap.csv',dtype={'seed':str});ci=ci[ci.seed=='mean_seed']
    latency=pd.read_csv(p/'formal_latency_aggregate.csv').set_index('policy')
    lci=pd.read_csv(p/'formal_latency_paired_bootstrap.csv',dtype={'seed':str});lci=lci[lci.seed=='mean_seed']
    batch=pd.read_csv(new/'runtime_timing_seed_summary.csv')
    qnew=pd.read_csv(new/'runtime_quality_seed_summary.csv')
    for policy,old_policy in [('rule_only','rule_only'),('all_bge','all_bge'),('system_top3','stop_3')]:
        for bs in [1,16,64]:
            for metric in ['returned_precision_pct','macro_recall_at3_pct','hit_at3_pct']:
                z=qnew[(qnew.evaluation_group=='all_formal')&(qnew.policy==policy)&(qnew.batch_size==bs)&(qnew.metric==metric)]
                assert len(z)==1 and abs(float(z.iloc[0]['mean'])-float(quality.loc[old_policy,metric+'_mean']))<1e-9,(policy,bs,metric)
    def q(policy,metric):return float(quality.loc[policy,metric+'_mean'])
    def contrast(base,metric,frame=ci):
        row=frame[(frame.baseline==base)&(frame.metric==metric)];assert len(row)==1,(base,metric)
        row=row.iloc[0];return f'{row.estimate:+.2f}',f'[{row.ci95_low:+.2f}, {row.ci95_high:+.2f}]'
    def t(policy,bs,metric):
        z=batch[(batch.policy==policy)&(batch.batch_size==bs)&(batch.metric==metric)];assert len(z)==1
        return float(z.iloc[0]['mean'])
    pdfmetrics.registerFont(TTFont('ReportCJK','/System/Library/Fonts/Supplemental/Arial Unicode.ttf'))
    title=ParagraphStyle('title',fontName='ReportCJK',fontSize=21,leading=28,spaceAfter=12,textColor=colors.HexColor('#17364a'))
    head=ParagraphStyle('head',fontName='ReportCJK',fontSize=14,leading=21,spaceBefore=12,spaceAfter=7,textColor=colors.HexColor('#17364a'))
    body=ParagraphStyle('body',fontName='ReportCJK',fontSize=10,leading=17,spaceAfter=9,wordWrap='CJK')
    small=ParagraphStyle('small',parent=body,fontSize=8.3,leading=13,textColor=colors.HexColor('#5b6e78'))
    cell=ParagraphStyle('cell',parent=body,fontSize=9,leading=13,alignment=TA_CENTER)
    story=[]
    def para(s,style=body):story.append(Paragraph(s,style))
    def table(rows,widths):
        tab=Table([[Paragraph(str(x),cell) for x in r] for r in rows],colWidths=widths,hAlign='CENTER',repeatRows=1)
        tab.setStyle(TableStyle([('LINEABOVE',(0,0),(-1,0),1,colors.HexColor('#263e4c')),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#263e4c')),('LINEBELOW',(0,-1),(-1,-1),1,colors.HexColor('#263e4c')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eff4f7')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
        story.extend([tab,Spacer(1,9)])
    para('固定Top3系统：补充验证报告',title)
    para('2026-10-05 | 原模型、原阈值、原金标 | 新真实GPU批量复测与独立统计',small)
    para('此次验证的系统',head)
    para('最终方案固定为每个查询30个候选、至多3条参考，不采用10条扩展方向。规则根据非空规范化描述与计量单位是否同时相等直接接受候选；已有3条精确参考时直接返回，否则只对剩余候选调用专项微调BGE。结果先保留精确参考，再按模型分数补足至多3条，不强制凑满。')
    pic=a.directory/'figures/method_overview.png';w,h=PILImage.open(pic).size
    story.extend([Image(str(pic),width=483,height=483*h/w),Spacer(1,10)])
    para('可以成立的结论',head)
    para('在当前固定候选池和Top3协议下，规则优先系统相对全量微调BGE同时改善最终名单精确率、宏平均召回率和筛选效率。它将原先由模型重复判断的可靠精确参考保留下来，并在参考不足时使用模型补充。该结论不要求模型在所有样本上胜过规则，也不等同于组合普遍优于仅规则。')
    para('全部正式测试包含220个查询、6,600个候选对，其中434个兼容候选、57个无参考池。三个既有困难强化检查点分别使用原验证阈值9.1875、-1.453125、8.4375。本轮不重训、不改标签、不重新选择阈值，验证集只用于预热。纯输入模块只读推理字段，人工标签仅进入离线评价。',small)
    story.append(PageBreak())
    para('最终推荐质量与统计可靠性',title)
    rows=[['策略','精确率 (%)','宏Recall@3 (%)','Hit@3 (%)','正确 / 错误返回']]
    for policy,name in [('rule_only','仅规则'),('all_bge','全量微调BGE'),('stop_3','规则优先Top3系统')]:
        rows.append([name,f"{q(policy,'returned_precision_pct'):.2f}",f"{q(policy,'macro_recall_at3_pct'):.2f}",f"{q(policy,'hit_at3_pct'):.2f}",f"{q(policy,'returned_tp_n'):.2f} / {q(policy,'returned_fp_n'):.2f}"])
    table(rows,[120,85,100,70,108])
    para('以上为此前真实批上限64预测的三个检查点均值，配对统计使用同一组逐查询结果。新增三种批大小复测得到相同的三个名单质量指标。精确率只针对实际返回项；宏Recall@3先在有兼容候选的查询内计算召回，再对查询平均。Hit@3为有兼容候选的查询是否至少命中一条；候选对分类F1与这些推荐指标不同。',small)
    rows=[['系统相对全量BGE','差值 (百分点)','查询配对95%区间']]
    for metric,name in [('returned_precision_pct','返回精确率'),('macro_recall_at3_pct','宏Recall@3'),('hit_at3_pct','Hit@3'),('wrong_reference_query_rate_pct','错误参考查询率')]:
        estimate,bounds=contrast('all_bge',metric);rows.append([name,estimate,bounds])
    table(rows,[190,105,188])
    para('差值采用5,000次查询配对重采样，同一查询与三个检查点保持配对。返回精确率和宏Recall@3的区间高于零，错误参考查询率的区间低于零；Hit@3区间仍含零。区间以现有数据、标签和三个检查点为条件，不代表新的独立数据验证，也未作多重比较校正。',small)
    para('与仅规则比较仍存在代价',head)
    para('系统相对仅规则多返回平均1.33条正确参考，同时多返回7条错误参考。返回精确率下降1.69个百分点，95%区间[-3.06, -0.57]；宏Recall@3提高0.51个百分点，区间[0, 1.34]。因此，不能宣称组合在所有指标上优于规则，也不能将当前结果描述为已通过正式非劣检验。')
    para('原模型能力没有消失',head)
    para('先前真实服务器复现中，内部锁定集全量微调BGE的候选对F1为97.62%，规则为95.76%；困难子集F1分别为69.86%和0%。这说明模型提高了非精确兼容候选的识别能力，但最多3条输出会限制这部分识别改善转化为最终名单收益。')
    story.append(PageBreak())
    para('真实耗时与批量条件复测',title)
    rows=[['策略','平均逐查询筛选耗时 (ms)']]
    for policy,name in [('rule_only','仅规则'),('all_bge','全量微调BGE'),('stop_3','规则优先Top3系统')]:
        rows.append([name,f"{latency.loc[policy,'weighted_mean_latency_ms_mean']:.2f}"])
    table(rows,[260,223])
    para('逐查询耗时使用此前每查询3次真实请求的中位数，再按全部220个查询及三个检查点平均。系统由27.08ms降至14.56ms，相对全量BGE减少46.25%，配对95%区间[40.10%, 52.60%]。仅规则约1.51ms，系统仍显著更贵。',small)
    para('新增81次真实GPU批量测量',head)
    rows=[['批大小上限','全量BGE总耗时 (s)','系统总耗时 (s)','系统耗时减少 (%)']]
    for bs in [1,16,64]:
        rows.append([bs,f"{t('all_bge',bs,'seconds_median'):.2f}",f"{t('system_top3',bs,'seconds_median'):.2f}",f"{t('system_top3',bs,'wall_time_saving_pct'):.2f}"])
    table(rows,[95,134,120,134])
    para('新增测试对全部正式查询合并处理，三个检查点、三种策略、三种批上限、每条件3次，总计81次实测。表内先取同一检查点重复测时中位数，再取三个检查点均值。它是合并池的批量吞吐测试，不能当作单查询请求延迟。',small)
    para('相同RTX4090，BF16、最大序列长度256、TF32关闭；随机交错执行条件，记录每次测量。计时包含实际规则分流、序列化、分词、GPU推理与名单合并，排除检索、模型加载和CSV读写；全量BGE不承担它未使用的规则判断。模型与输入哈希重新核对，细微BF16跨批变化保留在独立差异表。')
    para('同一条件3次重复的预测与排名均一致。跨批大小时，系统返回名单完全一致；全量BGE最多1个查询的具体名单变化，但兼容和不兼容返回数不变，因此质量汇总一致。命令行系统另在服务器完整运行220个查询，名单、评分集合和未评分集合与新批上限64系统结果逐条一致。',small)
    para('全量BGE每次评分6,600对，系统评分3,063对，减少53.59%。评分量、批量吞吐、单查询耗时是三个独立指标。本实验没有测量货币成本、审核员时间或原始文件到候选池的端到端时间，不能用推理比例替代这些结论。')
    story.append(PageBreak())
    para('为什么机制成立，以及适用边界',title)
    table([['输入精确参考数','查询数量','实际系统处理'],['0',60,'全部候选进入模型'],['1',31,'保留精确项，评分剩余候选'],['2',13,'保留精确项，评分剩余候选'],['3',116,'直接返回，跳过模型']], [125,85,273])
    para('在116个已有三条精确参考的查询上，规则优先系统三个检查点均返回348条正确参考、0条错误参考；全量BGE平均返回344.67条正确参考、2.33条错误参考。在精确优先且最多返回3条的政策下，剩余模型候选不能改变该名单，所以跳过评分保持了未早停组合的名单。此性质以规则可靠接受和Top3预算为前提，而不是提前读取测试答案来分流。')
    para(f"规则不足三条的查询仍由模型补充，但不能夸大补救。没有精确参考的60个查询中，只有3个有兼容候选，按20260904/05/06顺序，模型命中{no_exact_hits}个；57个无参考池中，系统平均拒绝率为{q('stop_3','no_reference_pool_rejection_pct'):.2f}%。当前数据不足以证明稳定解决规则完全失败的真实查询，外部非精确参考也没有被补回。")
    para('规则优先方案是在已有实验结果基础上提出的补充验证，并复用原测试集。新的GPU复测提供了不同批量条件下的运行证据，不构成新独立数据上的准确率验证；未来仍需在另外留出的项目上验证规则可靠性和模型补救。',small)
    para('可运行实现已验收',head)
    para('纯输入模块完成9项边界与变形检查，包括空值、标点规范化、未命中规则必须进入模型、阈值排序、不凑满、三条早停不受剩余分数影响、行顺序不影响结果，以及人工标签字段访问隔离。三个检查点的原批处理和逐查询实际结果共6次、每次250个查询，在调用集合、预测及名单排名上均零差异复现。新增GPU结果另有独立哈希、掩码、名单排序、重复测时和跨批数值检查。')
    para('论文可以如何定位',head)
    para('可以定位为“规则优先的历史单位价格参考筛选系统”：数据集和专项微调用于工程兼容关系学习，输入可见的精确规则处理可靠参考，固定Top3预算下早停减少重复评分。结果分别呈现候选分类能力、最终推荐质量和实测推理开销，保留仅规则更便宜、更精确以及非精确查询补救有限的边界。当前证据支持比全量微调更有效率的筛选流程，尚不能把它称为普遍最优系统或已验证的人工审核收益。')
    para('交付包含可运行predict_top3.py、system_policy.py、完整新GPU预测及81次计时、配对统计、原始来源哈希与独立QA。默认最多返回3条，不提供10条方向；原论文未被本轮实验脚本覆盖。',small)
    def footer(c,doc):
        c.setFont('ReportCJK',8);c.setFillColor(colors.HexColor('#6c7e88'))
        c.drawString(42,25,'固定Top3系统补充验证 | 2026-10-05')
        c.drawRightString(A4[0]-42,25,str(doc.page))
    a.output.parent.mkdir(parents=True,exist_ok=True)
    doc=SimpleDocTemplate(str(a.output),pagesize=A4,rightMargin=56,leftMargin=56,topMargin=44,bottomMargin=44)
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print(json.dumps({'report':str(a.output)},ensure_ascii=False))

if __name__=='__main__':main()
