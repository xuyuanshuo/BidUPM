#!/usr/bin/env python3
"""Validation-only policy selection followed by a frozen saved-score evaluation.

This does not run a model, measure runtime, retrain, or read gold in routing.
The archived benchmark has already been studied; the freeze prevents selection
from this run's formal metrics but does not make that benchmark a new blind test.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from system_policy import exact_mask, normalize_unit, route as top3_route, apply_policy


SEEDS = (20260904, 20260905, 20260906)
FAMILIES = tuple({"family": f"cap{cap:02d}_unit{int(unit)}", "candidate_cap": cap,
                  "same_unit": unit} for cap in (3, 5, 10, 30) for unit in (False, True))
RISK_TARGET = 0.99
ORIGINAL_POLICIES = ("rule_only", "all_bge", "exact_rescue", "stop_1", "stop_2", "stop_3")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def groups(frame):
    return list(frame.groupby(["evaluation_split", "query_id"], sort=False).indices.values())


def gate(frame, family):
    """Uses only the explicit item fields, initial rank, and query grouping."""
    exact = exact_mask(frame)
    called = (~exact) & (frame.initial_rank.to_numpy(int) <= family["candidate_cap"])
    if family["same_unit"]:
        qu = frame.query_normalized_unit.map(normalize_unit).to_numpy()
        cu = frame.candidate_normalized_unit.map(normalize_unit).to_numpy()
        called &= (qu != "") & (qu == cu)
    for ix in groups(frame):
        if exact[ix].sum() >= 3:
            called[ix] = False
    return exact, called


def execute(frame, scores, threshold, *, mode="family", family=None, return_cap=3):
    """Label-free routing and selection with unknown on genuinely skipped rows."""
    n = len(frame)
    if mode == "all_bge":
        rule, called = np.zeros(n, bool), np.ones(n, bool)
    elif mode == "rule_only":
        rule, called = exact_mask(frame), np.zeros(n, bool)
    elif mode == "exact_rescue":
        rule = exact_mask(frame)
        called = ~rule
    elif mode.startswith("stop_"):
        rule = exact_mask(frame)
        called = ~rule
        for ix in groups(frame):
            if rule[ix].sum() >= int(mode.split("_")[1]):
                called[ix] = False
    else:
        rule, called = gate(frame, family)
    masked = np.where(called, scores, np.nan)
    if not np.isfinite(masked[called]).all():
        raise ValueError("A called pair has a missing score")
    semantic = called & (masked >= threshold)
    accepted = rule | semantic
    skipped = ~(rule | called)
    pred = accepted.astype(np.int8)
    if mode != "rule_only":
        pred[skipped] = -1
    ids = frame.candidate_id.to_numpy(str)
    rank = np.zeros(n, np.int16)
    for ix in groups(frame):
        rules = ix[rule[ix]]
        rules = rules[np.argsort(ids[rules], kind="stable")]
        model = ix[semantic[ix]]
        model = model[np.lexsort((ids[model], -masked[model]))]
        returned = np.r_[rules, model]
        if return_cap is not None:
            returned = returned[:return_cap]
        rank[returned] = np.arange(1, len(returned) + 1)
    return {"exact_match": exact_mask(frame), "rule_accept": rule,
            "model_called": called, "unscored": skipped if mode != "rule_only" else np.zeros(n, bool),
            "score": masked, "prediction": pred, "returned_rank": rank,
            "semantic_accept": semantic}


def ratio(a, b):
    return float(a / b) if b else None


def one_sided_zero_error_lower(success, total):
    """Binomial 95% lower bound only for all-success samples; descriptive only."""
    return float(0.05 ** (1 / total)) if total and success == total else None


def evaluate(frame, gold, result):
    positive = np.asarray(gold.final_label, int) == 1
    returned = result["returned_rank"] > 0
    semantic_returned = returned & ~result["rule_accept"]
    tp = int((returned & positive).sum())
    fp = int((returned & ~positive).sum())
    stp = int((semantic_returned & positive).sum())
    sfp = int((semantic_returned & ~positive).sum())
    called = result["model_called"]
    exact = result["exact_match"]
    rows = []
    for ix in groups(frame):
        g, r, s, e = positive[ix], returned[ix], semantic_returned[ix], exact[ix]
        count = int(g.sum())
        rows.append({"evaluation_split": frame.iloc[ix[0]].evaluation_split,
                     "query_id": frame.iloc[ix[0]].query_id,
                     "positive_n": count, "nonexact_positive_n": int((g & ~e).sum()),
                     "exact_candidate_n": int(e.sum()), "returned_n": int(r.sum()),
                     "returned_tp": int((r & g).sum()), "returned_fp": int((r & ~g).sum()),
                     "semantic_returned_n": int(s.sum()), "semantic_tp": int((s & g).sum()),
                     "semantic_fp": int((s & ~g).sum()),
                     "model_candidate_calls": int(called[ix].sum()),
                     "recall": ratio(int((r & g).sum()), count),
                     "hit": bool((r & g).any()) if count else None,
                     "empty": not bool(r.any()), "wrong": bool((r & ~g).any()),
                     "nonexact_positive_hit": bool((r & g & ~e).any()) if (g & ~e).any() else None})
    q = pd.DataFrame(rows)
    nonexact_n = int((positive & ~exact).sum())
    nonexact_tp = int((returned & positive & ~exact).sum())
    summary = {"candidate_n": len(frame), "query_n": len(q), "gold_positive_n": int(positive.sum()),
               "returned_n": tp + fp, "returned_tp": tp, "returned_fp": fp,
               "returned_precision": ratio(tp, tp + fp), "returned_micro_recall": ratio(tp, int(positive.sum())),
               "returned_f1": ratio(2 * tp, tp + fp + int(positive.sum())),
               "macro_recall": float(q.recall.dropna().mean()) if q.recall.notna().any() else None,
               "hit_returned": float(q.hit.dropna().mean()) if q.hit.notna().any() else None,
               "wrong_query_rate": float(q.wrong.mean()),
               "no_reference_query_n": int(q.positive_n.eq(0).sum()),
               "no_reference_rejection": float(q.loc[q.positive_n.eq(0), "empty"].mean()) if q.positive_n.eq(0).any() else None,
               "semantic_returned_n": stp + sfp, "semantic_tp": stp, "semantic_fp": sfp,
               "semantic_precision": ratio(stp, stp + sfp),
               "semantic_precision_zero_error_95pct_lower": one_sided_zero_error_lower(stp, stp + sfp),
               "nonexact_positive_n": nonexact_n, "nonexact_returned_tp": nonexact_tp,
               "nonexact_returned_recall": ratio(nonexact_tp, nonexact_n),
               "nonexact_positive_query_n": int(q.nonexact_positive_n.gt(0).sum()),
               "nonexact_positive_query_hit": float(q.nonexact_positive_hit.dropna().mean()) if q.nonexact_positive_hit.notna().any() else None,
               "model_candidate_calls": int(called.sum()), "model_candidate_fraction": float(called.mean()),
               "model_calls_mean_per_query": float(q.model_candidate_calls.mean()),
               "unscored_n": int(result["unscored"].sum()),
               "full_candidate_pair_metrics_available": not bool(result["unscored"].any())}
    # Classification scores are only defined when every row has a decision.
    if summary["full_candidate_pair_metrics_available"]:
        p = result["prediction"] == 1
        ptp, pfp, pfn = int((p & positive).sum()), int((p & ~positive).sum()), int((~p & positive).sum())
        summary.update(pair_tp=ptp, pair_fp=pfp, pair_fn=pfn,
                       pair_precision=ratio(ptp, ptp + pfp), pair_recall=ratio(ptp, ptp + pfn),
                       pair_f1=ratio(2 * ptp, 2 * ptp + pfp + pfn))
    return summary, q


def align_predictions(path, frame, policy):
    p = pd.read_csv(path)
    p = p.loc[p.policy.eq(policy)].set_index("pair_id")
    if not p.index.is_unique or set(p.index) != set(frame.pair_id):
        raise ValueError(f"Score ID mismatch: {path} {policy}")
    return p.loc[frame.pair_id].reset_index()


def summarize_groups(frame, gold, scores, result_specs, seed):
    rows, query_rows = [], []
    group_defs = {s: [s] for s in frame.evaluation_split.unique()}
    if frame.evaluation_split.ne("validation").any():
        group_defs.update(formal_combined=["locked", "external", "no_reference", "no_reference_reclassified"],
                          internal_combined=["locked", "no_reference", "no_reference_reclassified"])
    for spec in result_specs:
        full = execute(frame, scores, spec["threshold"], mode=spec["mode"],
                       family=spec.get("family"), return_cap=spec.get("return_cap", 3))
        for name, splits in group_defs.items():
            ix = np.flatnonzero(frame.evaluation_split.isin(splits).to_numpy())
            sub = frame.iloc[ix].reset_index(drop=True)
            gsub = gold.iloc[ix].reset_index(drop=True)
            sliced = {k: v[ix] for k, v in full.items()}
            metric, query = evaluate(sub, gsub, sliced)
            metric.update(seed=seed, policy=spec["name"], evaluation_group=name,
                          threshold=spec["threshold"], return_cap=spec.get("return_cap", 3))
            rows.append(metric)
            if name in frame.evaluation_split.unique():
                query["seed"], query["policy"] = seed, spec["name"]
                query_rows.extend(query.to_dict("records"))
    return rows, query_rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve()
    inputs_path, labels_path = source / "inputs.csv", source / "labels.csv"
    frame = pd.read_csv(inputs_path, keep_default_na=False)
    if frame.pair_id.duplicated().any() or (frame.groupby(["evaluation_split", "query_id"]).size() != 30).any():
        raise ValueError("Original 30-candidate pool contract violated")
    manifest = json.loads((source / "source_manifest.json").read_text())
    if sha(inputs_path) != manifest["inputs_sha256"] or sha(labels_path) != manifest["labels_sha256"]:
        raise ValueError("Original source integrity mismatch")
    script_hash = sha(__file__)
    plan = {"created_utc": datetime.now(timezone.utc).isoformat(), "script_sha256": script_hash,
            "routing_input_fields": ["evaluation_split", "query_id", "candidate_id", "initial_rank",
                                     "query_normalized_description", "candidate_normalized_description",
                                     "query_normalized_unit", "candidate_normalized_unit"],
            "gold_fields_forbidden_in_routing": ["final_label", "final_relevance", "difficulty"],
            "exact_rule": "nonempty canonical description equality and nonempty normalized unit equality",
            "candidate_families": list(FAMILIES), "semantic_grid": "all unique full-BGE validation scores plus finite below-min/above-max sentinels, separately per seed",
            "stop_rule": "score no nonexact candidate after >=3 exact candidates; otherwise score eligible fallback candidates",
            "return_policy": "up to3, exact by candidate_id first, then accepted semantic by score descending/id",
            "risk_target": RISK_TARGET,
            "selection_order": ["returned_precision >= target", "semantic precision >= target if semantic output exists",
                                "maximize validation returned_micro_recall", "minimize model_candidate_calls",
                                "maximize returned_precision", "maximize threshold", "family name ascending"],
            "include_rule_only_candidate": True,
            "formal_metrics_used_for_selection": False,
            "historical_test_exposure": "existing archived benchmark previously analyzed; this is development evidence, not a fresh blind test",
            "saved_score_replay_limit": "candidate-pair call counts only; no measured latency, GPU load, API requests, dollars, or end-to-end retrieval",
            "input_sha256": sha(inputs_path), "labels_sha256": sha(labels_path),
            "source_manifest_sha256": sha(source / "source_manifest.json")}
    plan_path = args.output / "predefined_policy_plan.json"
    save_json(plan_path, plan)
    # The first label read is filtered to validation. Formal gold is not kept.
    vframe = frame.loc[frame.evaluation_split.eq("validation")].reset_index(drop=True)
    vgold = pd.read_csv(labels_path).set_index("pair_id").loc[vframe.pair_id].reset_index()
    frozen_thresholds = {r["seed"]: r["threshold"] for r in manifest["runs"]}
    selected, grids, validation_summary, validation_queries = [], [], [], []
    for seed in SEEDS:
        vp_path = source / f"validation_predictions_seed_{seed}.csv"
        vp = align_predictions(vp_path, vframe, "all_bge")
        scores = vp.score.to_numpy(float)
        if not np.isfinite(scores).all():
            raise ValueError("Incomplete full validation scores")
        thresholds = np.r_[scores.min() - 1, np.unique(scores), scores.max() + 1]
        seed_grid = []
        for family in FAMILIES:
            for threshold in thresholds:
                result = execute(vframe, scores, float(threshold), family=family)
                metric, _ = evaluate(vframe, vgold, result)
                eligible = (metric["returned_precision"] is not None and metric["returned_precision"] >= RISK_TARGET
                            and (metric["semantic_returned_n"] == 0 or metric["semantic_precision"] >= RISK_TARGET))
                record = {"seed": seed, **family, "threshold": float(threshold), "eligible": bool(eligible), **metric}
                seed_grid.append(record)
        rr = execute(vframe, scores, float(thresholds[-1]), mode="rule_only")
        rm, _ = evaluate(vframe, vgold, rr)
        seed_grid.append({"seed": seed, "family": "rule_only", "candidate_cap": 0, "same_unit": False,
                          "threshold": float(thresholds[-1]),
                          "eligible": rm["returned_precision"] is not None and rm["returned_precision"] >= RISK_TARGET, **rm})
        eligible = [r for r in seed_grid if r["eligible"]]
        if not eligible:
            raise ValueError("No policy meets the predefined validation criterion; no formal evaluation should run")
        winner = sorted(eligible, key=lambda r: (-r["returned_micro_recall"], r["model_candidate_calls"],
                                                -r["returned_precision"], -r["threshold"], r["family"]))[0]
        selected.append({"seed": seed, "selected_family": winner["family"], "candidate_cap": winner["candidate_cap"],
                         "same_unit": winner["same_unit"], "threshold": winner["threshold"],
                         "validation_metrics": {k: winner[k] for k in rm},
                         "validation_prediction_sha256": sha(vp_path),
                         "validation_threshold_grid_n": len(thresholds), "validation_evaluated_policy_n": len(seed_grid)})
        grids.extend(seed_grid)
        specs = baseline_specs(frozen_thresholds[seed]) + [selected_spec(selected[-1])]
        sr, qr = summarize_groups(vframe, vgold, scores, specs, seed)
        validation_summary.extend(sr)
        validation_queries.extend(qr)
    pd.DataFrame(grids).to_csv(args.output / "validation_grid.csv", index=False)
    pd.DataFrame(validation_summary).to_csv(args.output / "validation_summary.csv", index=False)
    pd.DataFrame(validation_queries).to_csv(args.output / "validation_per_query.csv", index=False)
    freeze = {"frozen_utc": datetime.now(timezone.utc).isoformat(), "plan_sha256": sha(plan_path),
              "script_sha256": script_hash, "validation_grid_sha256": sha(args.output / "validation_grid.csv"),
              "selection_uses_validation_only": True, "selections": selected}
    freeze_path = args.output / "selected_policy_freeze.json"
    save_json(freeze_path, freeze)
    print("VALIDATION_SELECTION_FROZEN", json.dumps(selected, ensure_ascii=False), flush=True)
    # No new choices are permitted below this freeze. Load the formal scores and gold.
    fullgold = pd.read_csv(labels_path).set_index("pair_id").loc[frame.pair_id].reset_index()
    formalix = np.flatnonzero(frame.evaluation_split.ne("validation").to_numpy())
    formal = frame.iloc[formalix].reset_index(drop=True)
    gold = fullgold.iloc[formalix].reset_index(drop=True)
    formal_summary, formal_queries, reproduction, source_predictions = [], [], [], []
    for selection in selected:
        seed = selection["seed"]
        pred_path = source / f"predictions_seed_{seed}.csv"
        fullpred = align_predictions(pred_path, frame, "all_bge")
        fullscores = fullpred.score.to_numpy(float)
        source_predictions.append({"seed": seed, "path": str(pred_path), "sha256": sha(pred_path)})
        # Reproduce every archived original policy with its own archived scores.
        for policy in ORIGINAL_POLICIES:
            archived = align_predictions(pred_path, frame, policy)
            original = execute(frame, archived.score.to_numpy(float), frozen_thresholds[seed], mode=policy)
            comparisons = {col + "_mismatch_n": int((original[col].astype(int) != archived[col].to_numpy(int)).sum())
                           for col in ("exact_match", "rule_accept", "model_called", "prediction", "returned_rank")}
            # all_bge still carries the exact-match feature, but never accepts by rule.
            reproduction.append({"seed": seed, "policy": policy, **comparisons})
        # Independent new system_policy module reproduces original stop3 routing.
        ref = top3_route(frame)
        ours = execute(frame, fullscores, frozen_thresholds[seed], mode="stop_3")
        for name in ("exact_match", "rule_accept", "model_called", "unscored"):
            if not np.array_equal(ref[name], ours[name]):
                raise ValueError(f"system_policy route mismatch {name}")
        compiled = apply_policy(frame, fullscores, frozen_thresholds[seed])
        if not np.array_equal(compiled["returned_rank"], ours["returned_rank"]):
            raise ValueError("system_policy Top3 return mismatch")
        specs = baseline_specs(frozen_thresholds[seed]) + [selected_spec(selection)]
        rows, queries = summarize_groups(formal, gold, fullscores[formalix], specs, seed)
        formal_summary.extend(rows)
        formal_queries.extend(queries)
    rep = pd.DataFrame(reproduction)
    mismatch_cols = [c for c in rep if c.endswith("_mismatch_n")]
    if rep[mismatch_cols].to_numpy().sum():
        raise ValueError(f"Archived policy reproduction failed: {rep.to_dict('records')}")
    rep.to_csv(args.output / "original_policy_reproduction.csv", index=False)
    pd.DataFrame(formal_summary).to_csv(args.output / "formal_summary.csv", index=False)
    pd.DataFrame(formal_queries).to_csv(args.output / "formal_per_query.csv", index=False)
    # Aggregate only for reporting; no aggregate feeds selection.
    for stem in ("validation", "formal"):
        summary = pd.read_csv(args.output / f"{stem}_summary.csv")
        numeric = summary.select_dtypes(include="number").columns.difference(["seed", "threshold", "return_cap"])
        agg = summary.groupby(["evaluation_group", "policy"])[numeric].agg(["mean", "std", "min", "max"])
        agg.columns = ["_".join(c) for c in agg.columns]
        agg.reset_index().to_csv(args.output / f"{stem}_aggregate.csv", index=False)
    structural = construction_audit(frame, fullgold)
    pd.DataFrame(structural).to_csv(args.output / "benchmark_exact_structure.csv", index=False)
    qa = {"status": "passed", "script_sha256": script_hash, "selection_freeze_sha256": sha(freeze_path),
          "freeze_precedes_formal_evaluation_in_code": True, "original_policy_reproductions": len(rep),
          "original_policy_mismatch_total": int(rep[mismatch_cols].to_numpy().sum()),
          "system_policy_route_and_return_equal": True, "source_prediction_files": source_predictions,
          "timing_measured": False, "monetary_cost_measured": False, "model_run": False,
          "source_originals_modified": False,
          "metric_note": "Top3 returned F1 describes selected references; full pair F1 is absent with any unknown/unscored candidate",
          "precision_risk_note": "99% criterion is empirical, not a 99% guarantee; validation has only30 clustered query pools",
          "formal_exposure_note": plan["historical_test_exposure"]}
    save_json(args.output / "qa.json", qa)
    print("FORMAL_FROZEN_EVALUATION_COMPLETE", json.dumps(qa), flush=True)


def selected_spec(selection):
    if selection["selected_family"] == "rule_only":
        return {"name": "validation_selected", "mode": "rule_only", "threshold": selection["threshold"]}
    family = {"family": selection["selected_family"], "candidate_cap": selection["candidate_cap"],
              "same_unit": selection["same_unit"]}
    return {"name": "validation_selected", "mode": "family", "family": family,
            "threshold": selection["threshold"]}


def baseline_specs(threshold):
    specs = [{"name": "rule_only_top3", "mode": "rule_only", "threshold": threshold}]
    for mode in ("all_bge", "exact_rescue"):
        specs.extend([{"name": mode + "_published_top3", "mode": mode, "threshold": threshold},
                      {"name": mode + "_published_all", "mode": mode, "threshold": threshold, "return_cap": None}])
    specs.append({"name": "stop3_published_top3", "mode": "stop_3", "threshold": threshold})
    return specs


def construction_audit(frame, gold):
    exact = exact_mask(frame)
    positive = gold.final_label.to_numpy(int) == 1
    rows = []
    for split, ix in frame.groupby("evaluation_split", sort=False).indices.items():
        qix = groups(frame.iloc[ix].reset_index(drop=True))
        e, g = exact[ix], positive[ix]
        rows.append({"split": split, "candidate_n": len(ix), "query_n": len(qix),
                     "exact_candidate_n": int(e.sum()), "gold_positive_n": int(g.sum()),
                     "exact_gold_positive_n": int((e & g).sum()), "exact_gold_negative_n": int((e & ~g).sum()),
                     "nonexact_gold_positive_n": int((~e & g).sum()),
                     "exact_fraction_of_positives": ratio(int((e & g).sum()), int(g.sum())),
                     "queries_with_exact_n": sum(bool(e[j].any()) for j in qix),
                     "queries_with_atleast3_exact_n": sum(e[j].sum() >= 3 for j in qix),
                     "exact_initial_rank_max": int(frame.iloc[ix].loc[e, "initial_rank"].max()) if e.any() else None})
    return rows


if __name__ == "__main__":
    main()
