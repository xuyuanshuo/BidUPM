#!/usr/bin/env python3
"""Independent quality and pooled-throughput validation of actual GPU runs.

Gold labels are joined only after input-only masks and returned lists pass QA.
These measurements are full-pool throughput jobs, not individual-request
latencies. Loading and candidate retrieval are excluded; no money is estimated.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd

import system_policy


POLICIES = ["rule_only", "all_bge", "system_top3"]
QUERY_KEYS = ["evaluation_split", "query_id"]
MASKS = ["exact_match", "rule_accept", "model_called", "unscored"]
BASELINE = "all_bge"
SCOPE = ("Actual resident-model pooled throughput over all formal query pools. "
         "Includes routing, serialization, tokenization, inference, and merging; "
         "excludes model loading and candidate retrieval. Not request latency or monetary cost.")


def require(condition: bool, message: str) -> None:
    if not bool(condition):
        raise ValueError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def rate(numerator, denominator) -> float:
    return 100.0 * numerator / denominator if denominator else np.nan


def sd(values) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    return float(values.std(ddof=1)) if len(values) > 1 else np.nan


def boolean(series: pd.Series, name: str) -> np.ndarray:
    values = series.astype(str).str.lower()
    require(values.isin(["0", "1", "true", "false"]).all(), f"{name}: invalid boolean")
    return values.map({"0": False, "1": True, "false": False, "true": True}).to_numpy(bool)


def read_inputs(source: Path, runtime: Path, qa: dict) -> tuple[pd.DataFrame, dict, dict]:
    source_manifest = json.loads((source / "source_manifest.json").read_text())
    manifest = json.loads((runtime / "execution_manifest.json").read_text())
    require(manifest.get("status") == "complete", "GPU execution is not complete")
    require(manifest.get("labels_accessed") is False, "Runner did not declare label-blind inference")
    require(manifest.get("thresholds_retuned") is False, "Runtime run retuned thresholds")
    require(manifest.get("model_load_and_retrieval_included") is False, "Timing scope differs from planned measurement")
    require(list(manifest["policies"]) == POLICIES, "Unexpected runtime policies")
    require(sorted(map(int, manifest["batch_sizes"])) == [1, 16, 64], "Unexpected inference batch sizes")
    require(int(manifest["repeats"]) == 3, "Expected three measured repetitions")
    require(manifest["input_sha256"] == source_manifest["inputs_sha256"], "Runtime/source input hash mismatch")
    input_path = source / "inputs.csv"
    require(sha256(input_path) == source_manifest["inputs_sha256"], "Source inputs changed")
    inputs = pd.read_csv(input_path, dtype=str, keep_default_na=False)
    require(list(inputs.columns) == source_manifest["inference_input_contract"], "Input schema differs from frozen contract")
    require(not {"final_label", "final_relevance", "difficulty", "final_conflict_type"}.intersection(inputs.columns),
            "Inference inputs contain annotation fields")
    inputs = inputs[inputs.evaluation_split.ne("validation")].reset_index(drop=True)
    require(len(inputs) == int(manifest["pair_n"]), "Formal candidate-pair count differs")
    require(inputs[QUERY_KEYS].drop_duplicates().shape[0] == int(manifest["query_n"]), "Formal query-pool count differs")
    require(not inputs.pair_id.duplicated().any(), "Duplicate formal pair IDs")
    require(inputs.groupby(QUERY_KEYS).size().eq(30).all(), "Formal pools do not each have 30 candidates")
    require(not inputs.duplicated([*QUERY_KEYS, "candidate_id"]).any(), "Duplicate candidate in query pool")
    frozen_runs = {int(run["seed"]): run for run in source_manifest["runs"]}
    runtime_runs = {int(run["seed"]): run for run in manifest["source_runs"]}
    require(frozen_runs == runtime_runs, "Runtime checkpoints/threshold provenance differs from frozen source")
    completed = {int(run["seed"]): run for run in manifest["completed_runs"]}
    require(set(completed) == set(frozen_runs), "Runtime checkpoints incomplete")
    require(len(completed) == 3, "Expected all three checkpoints")
    module_hash = sha256(Path(system_policy.__file__))
    require(module_hash == manifest["policy_sha256"], "Policy module differs from executed module")
    runner_path = Path(__file__).with_name("run_runtime_validation.py")
    require(runner_path.is_file() and sha256(runner_path) == manifest["script_sha256"], "Runtime script differs from recorded executed script")
    qa["provenance"] = {"source_manifest_sha256": sha256(source / "source_manifest.json"),
                        "runtime_manifest_sha256": sha256(runtime / "execution_manifest.json"),
                        "inputs_sha256": sha256(input_path), "policy_sha256": module_hash,
                        "runtime_script_sha256": manifest["script_sha256"], "gpu": manifest.get("device"),
                        "torch": manifest.get("torch"), "precision": manifest.get("precision"),
                        "seeds": sorted(frozen_runs), "pair_n": len(inputs), "query_n": int(manifest["query_n"])}
    return inputs, source_manifest, manifest


def validate_predictions(runtime: Path, inputs: pd.DataFrame, source_manifest: dict,
                         manifest: dict, qa: dict) -> pd.DataFrame:
    exact = system_policy.exact_mask(inputs)
    system_route = system_policy.route(inputs)
    completed = {int(run["seed"]): run for run in manifest["completed_runs"]}
    records, pieces = [], []
    for run in source_manifest["runs"]:
        seed, threshold = int(run["seed"]), float(run["threshold"])
        require(float(completed[seed]["threshold"]) == threshold, f"seed {seed}: threshold changed")
        path = runtime / f"predictions_seed_{seed}.csv"
        require(sha256(path) == completed[seed]["prediction_sha256"], f"seed {seed}: prediction hash mismatch")
        raw = pd.read_csv(path, dtype={"pair_id": str, "query_id": str, "evaluation_split": str}, float_precision="round_trip")
        required = {"pair_id", *QUERY_KEYS, "seed", "policy", "batch_size", "threshold", *MASKS,
                    "score", "prediction", "returned_rank"}
        require(required.issubset(raw.columns), f"{path}: missing prediction fields")
        require(not {"final_label", "difficulty", "final_conflict_type"}.intersection(raw.columns), "Prediction export contains annotations")
        require(raw.seed.eq(seed).all() and raw.threshold.eq(threshold).all(), f"seed {seed}: frozen settings differ")
        require(raw.prediction.isin([-1, 0, 1]).all(), f"seed {seed}: invalid prediction state")
        require(raw.returned_rank.isin([0, 1, 2, 3]).all(), f"seed {seed}: invalid returned rank")
        require(not raw.duplicated(["policy", "batch_size", "pair_id"]).any(), f"seed {seed}: duplicate condition/pair")
        require(len(raw) == len(inputs) * len(POLICIES) * len(manifest["batch_sizes"]), f"seed {seed}: incomplete prediction rows")
        require(set(map(tuple, raw[["policy", "batch_size"]].drop_duplicates().to_numpy())) ==
                set(itertools.product(POLICIES, manifest["batch_sizes"])), f"seed {seed}: missing conditions")
        for (policy, batch_size), condition in raw.groupby(["policy", "batch_size"]):
            require(set(condition.pair_id) == set(inputs.pair_id), f"seed {seed}/{policy}/{batch_size}: pair IDs differ")
            condition = condition.set_index("pair_id").reindex(inputs.pair_id).reset_index()
            require(np.array_equal(condition[QUERY_KEYS].to_numpy(), inputs[QUERY_KEYS].to_numpy()),
                    f"seed {seed}/{policy}/{batch_size}: query metadata differs")
            masks = {name: boolean(condition[name], name) for name in MASKS}
            if policy == "rule_only":
                accepted, called, unknown = exact, np.zeros(len(inputs), bool), np.zeros(len(inputs), bool)
            elif policy == "all_bge":
                accepted, called, unknown = np.zeros(len(inputs), bool), np.ones(len(inputs), bool), np.zeros(len(inputs), bool)
            else:
                accepted, called, unknown = (system_route[name] for name in ["rule_accept", "model_called", "unscored"])
            for name, expected in [("exact_match", exact), ("rule_accept", accepted), ("model_called", called), ("unscored", unknown)]:
                require(np.array_equal(masks[name], expected), f"seed {seed}/{policy}/{batch_size}: {name} violates input-only gate")
                condition[name] = masks[name]
            scores = condition.score.to_numpy(float)
            require(np.isfinite(scores[called]).all(), f"seed {seed}/{policy}/{batch_size}: missing modeled scores")
            require(np.isnan(scores[~called]).all(), f"seed {seed}/{policy}/{batch_size}: uncalled scores were retained")
            expected_prediction = accepted.astype(int)
            expected_prediction[called] = (scores[called] >= threshold).astype(int)
            expected_prediction[unknown] = -1
            require(np.array_equal(condition.prediction.to_numpy(int), expected_prediction), f"seed {seed}/{policy}/{batch_size}: invalid threshold/unknown decisions")
            expected_rank = system_policy.rank_returned(inputs, accepted, scores, threshold)
            require(np.array_equal(condition.returned_rank.to_numpy(int), expected_rank), f"seed {seed}/{policy}/{batch_size}: invalid exact-priority Top3 ranking")
            require(condition.returned_rank.isin([0, 1, 2, 3]).all(), "Invalid return rank")
            returned = condition.returned_rank.gt(0)
            require(condition.loc[returned, "prediction"].eq(1).all(), "An unaccepted/unscored candidate was returned")
            require(condition.groupby(QUERY_KEYS).returned_rank.apply(lambda x: (x > 0).sum()).le(3).all(), "More than three references returned")
            condition["candidate_id"] = inputs.candidate_id.to_numpy()
            pieces.append(condition)
            records.append({"seed": seed, "policy": policy, "batch_size": int(batch_size), "pair_n": len(condition),
                            "model_pairs": int(called.sum()), "unknown_pairs": int(unknown.sum()),
                            "zero_model_queries": int(pd.Series(called).groupby([inputs.evaluation_split, inputs.query_id]).sum().eq(0).sum()),
                            "source_file_sha256": completed[seed]["prediction_sha256"], "input_only_gate_and_top3_passed": True})
    qa["prediction_conditions"] = records
    qa["predictions_validated_before_gold_join"] = True
    return pd.concat(pieces, ignore_index=True)


def join_gold(predictions: pd.DataFrame, source: Path, source_manifest: dict, qa: dict) -> pd.DataFrame:
    path = source / "labels.csv"
    require(sha256(path) == source_manifest["labels_sha256"], "Gold label source hash changed")
    labels = pd.read_csv(path, dtype={"pair_id": str}, keep_default_na=False)
    require(not labels.pair_id.duplicated().any(), "Duplicate gold pair ID")
    require(labels.final_label.isin([0, 1]).all(), "Nonbinary final gold label")
    require(set(predictions.pair_id).issubset(set(labels.pair_id)), "Formal predictions lack gold labels")
    qa["labels"] = {"labels_sha256": sha256(path), "use": "Independent evaluation after route/list verification only"}
    return predictions.merge(labels[["pair_id", "final_label"]], on="pair_id", how="left", validate="many_to_one")


def groups_for(predictions: pd.DataFrame) -> dict[str, list[str]]:
    groups = {split: [split] for split in sorted(predictions.evaluation_split.unique())}
    groups["all_formal"] = sorted(predictions.evaluation_split.unique())
    internal = [split for split in ["locked", "no_reference", "no_reference_reclassified"] if split in groups]
    if len(internal) > 1:
        groups["internal_combined"] = internal
    if {"locked", "no_reference"}.issubset(groups):
        groups["internal_locked_plus_original_noref"] = ["locked", "no_reference"]
    return groups


def per_query(predictions: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for key, part in predictions.groupby(["seed", "policy", "batch_size", *QUERY_KEYS]):
        seed, policy, batch_size, split, query_id = key
        returned = part.returned_rank.gt(0)
        gold = part.final_label.eq(1)
        tp, fp, positive = int((returned & gold).sum()), int((returned & ~gold).sum()), int(gold.sum())
        rows.append({"seed": seed, "policy": policy, "batch_size": batch_size, "evaluation_split": split,
                     "query_id": query_id, "candidate_n": len(part), "positive_n": positive,
                     "returned_tp": tp, "returned_fp": fp, "returned_n": tp + fp,
                     "hit": tp > 0, "recall_at3": tp / positive if positive else np.nan,
                     "any_wrong": fp > 0, "empty": tp + fp == 0, "model_pairs": int(part.model_called.sum())})
    return pd.DataFrame(rows)


def summarize_quality(predictions: pd.DataFrame, queries: pd.DataFrame, groups: dict) -> pd.DataFrame:
    rows = []
    for name, splits in groups.items():
        selected = predictions[predictions.evaluation_split.isin(splits)]
        qselected = queries[queries.evaluation_split.isin(splits)]
        for (seed, policy, batch_size), part in selected.groupby(["seed", "policy", "batch_size"]):
            q = qselected[(qselected.seed == seed) & qselected.policy.eq(policy) & qselected.batch_size.eq(batch_size)]
            positive_q, no_ref_q = q.positive_n.gt(0), q.positive_n.eq(0)
            tp, fp = int(q.returned_tp.sum()), int(q.returned_fp.sum())
            row = {"evaluation_group": name, "seed": seed, "policy": policy, "batch_size": batch_size,
                   "queries": len(q), "positive_queries": int(positive_q.sum()), "candidate_pairs": len(part),
                   "returned_tp": tp, "returned_fp": fp, "returned_precision_pct": rate(tp, tp + fp),
                   "macro_recall_at3_pct": 100 * q.loc[positive_q, "recall_at3"].mean(),
                   "hit_at3_pct": rate(q.loc[positive_q, "hit"].sum(), positive_q.sum()),
                   "wrong_reference_query_pct": 100 * q.any_wrong.mean(),
                   "no_reference_rejection_pct": rate(q.loc[no_ref_q, "empty"].sum(), no_ref_q.sum()),
                   "mean_returned_n": float(q.returned_n.mean()), "model_pairs": int(part.model_called.sum()),
                   "model_candidate_fraction_pct": rate(part.model_called.sum(), len(part)),
                   "full_pair_metrics_evaluated": policy != "system_top3"}
            if policy != "system_top3":
                require(part.prediction.isin([0, 1]).all(), "Unknown pair entered full pair metrics")
                gold, predicted = part.final_label.eq(1), part.prediction.eq(1)
                pair_tp, pair_fp = int((gold & predicted).sum()), int((~gold & predicted).sum())
                fn, tn = int((gold & ~predicted).sum()), int((~gold & ~predicted).sum())
                row.update({"pair_tp": pair_tp, "pair_fp": pair_fp, "pair_fn": fn, "pair_tn": tn,
                            "pair_precision_pct": rate(pair_tp, pair_tp + pair_fp),
                            "pair_recall_pct": rate(pair_tp, pair_tp + fn),
                            "pair_f1_pct": rate(2 * pair_tp, 2 * pair_tp + pair_fp + fn)})
            rows.append(row)
    return pd.DataFrame(rows)


def seed_aggregate(frame: pd.DataFrame, identifiers: list[str]) -> pd.DataFrame:
    metrics = [column for column in frame.select_dtypes(include="number").columns if column not in ["seed", "batch_size"]]
    rows = []
    for key, part in frame.groupby(identifiers):
        key = key if isinstance(key, tuple) else (key,)
        identity = dict(zip(identifiers, key))
        for metric in metrics:
            values = part[metric].dropna().to_numpy(float)
            rows.append({**identity, "metric": metric, "seed_n": len(part), "finite_seed_n": len(values),
                         "mean": float(values.mean()) if len(values) else np.nan, "sample_sd": sd(values)})
    return pd.DataFrame(rows)


def validate_timing(runtime: Path, predictions: pd.DataFrame, manifest: dict, qa: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    path = runtime / "timing.csv"
    require(sha256(path) == manifest["timing_sha256"], "Actual timing file hash mismatch")
    timing = pd.read_csv(path)
    fields = ["seed", "policy", "batch_size", "repeat", "pairs", "queries", "seconds", "model_pairs", "model_batches", "early_stopped_queries"]
    require(set(fields).issubset(timing.columns), "Incomplete timing columns")
    require(len(timing) == 81, "Expected exactly 81 real pooled-throughput measurements")
    require(np.isfinite(timing[[field for field in fields if field != "policy"]]).all().all(), "Nonfinite timing/count values")
    require(timing.seconds.gt(0).all(), "Nonpositive timing value")
    key = ["seed", "policy", "batch_size"]
    require(not timing.duplicated([*key, "repeat"]).any(), "Duplicate timing repetition")
    expected_conditions = set(itertools.product([int(run["seed"]) for run in manifest["source_runs"]], POLICIES, manifest["batch_sizes"]))
    require(set(map(tuple, timing[key].drop_duplicates().to_numpy())) == expected_conditions, "Incomplete timed conditions")
    count_rows = []
    for identity, part in predictions.groupby(key):
        seed, policy, batch_size = identity
        q_called = part.groupby(QUERY_KEYS).model_called.sum()
        q_rules = part.groupby(QUERY_KEYS).rule_accept.sum()
        count_rows.append({"seed": seed, "policy": policy, "batch_size": batch_size, "expected_pairs": len(part),
                           "expected_queries": len(q_called), "expected_model_pairs": int(part.model_called.sum()),
                           "expected_model_batches": int(np.ceil(part.model_called.sum() / batch_size)),
                           "expected_early_stopped_queries": int(q_rules.ge(3).sum()) if policy == "system_top3" else 0,
                           "zero_model_queries": int(q_called.eq(0).sum())})
    check = timing.merge(pd.DataFrame(count_rows), on=key, validate="many_to_one")
    for column in ["pairs", "queries", "model_pairs", "model_batches", "early_stopped_queries"]:
        require(check[column].eq(check[f"expected_{column}"]).all(), f"Actual timing {column} differs from prediction masks")
    for identity, part in timing.groupby(key):
        require(sorted(part.repeat.tolist()) == list(range(int(manifest["repeats"]))), f"{identity}: incomplete timing repeats")
        require(part[["pairs", "queries", "model_pairs", "model_batches", "early_stopped_queries"]].nunique().eq(1).all(),
                f"{identity}: scoring workload varies across repeats")
    consistency_parts, consistency_hashes = [], {}
    for run in manifest["source_runs"]:
        seed = int(run["seed"])
        cpath = runtime / f"repeat_consistency_seed_{seed}.csv"
        part = pd.read_csv(cpath)
        require(part.seed.eq(seed).all() and len(part) == 18, f"seed {seed}: incomplete repeat-consistency records")
        require(not part.duplicated(["policy", "batch_size", "repeat"]).any(), "Duplicate consistency row")
        required = set(itertools.product(POLICIES, manifest["batch_sizes"], [1, 2]))
        require(set(map(tuple, part[["policy", "batch_size", "repeat"]].to_numpy())) == required, "Missing consistency condition")
        for column in ["decision_difference_n", "rank_difference_n"]:
            require(part[column].between(0, int(manifest["pair_n"])).all(), "Invalid repeat difference count")
        consistency_parts.append(part)
        consistency_hashes[cpath.name] = sha256(cpath)
    consistency = pd.concat(consistency_parts, ignore_index=True)
    stable = consistency[["decision_difference_n", "rank_difference_n"]].eq(0).all().all()
    qa["timing_integrity"] = {"timing_sha256": sha256(path), "measurements": len(timing),
                              "all_work_counts_match_prediction_masks": True, "repeat_output_stable": bool(stable),
                              "repeat_consistency_hashes": consistency_hashes,
                              "repeat_consistency_provenance": "Locally hashed; upstream execution manifest does not separately declare these hashes."}
    if not stable:
        qa.setdefault("warnings", []).append("Repeated real inference changed decisions/ranks; quality tables use recorded repeat-0 predictions and do not quantify full repeat quality variation.")
    return check, consistency


def summarize_timing(timing: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (seed, policy, batch_size), part in timing.groupby(["seed", "policy", "batch_size"]):
        baseline = timing[(timing.seed == seed) & timing.policy.eq(BASELINE) & timing.batch_size.eq(batch_size)]
        wall = float(part.seconds.median())
        baseline_wall = float(baseline.seconds.median())
        rows.append({"seed": seed, "policy": policy, "batch_size": batch_size, "repeat_n": len(part),
                     "seconds_median": wall, "seconds_mean": float(part.seconds.mean()), "seconds_repeat_sample_sd": sd(part.seconds),
                     "seconds_min": float(part.seconds.min()), "seconds_max": float(part.seconds.max()),
                     "queries": int(part.queries.iloc[0]), "pairs": int(part.pairs.iloc[0]),
                     "model_pairs": int(part.model_pairs.iloc[0]), "model_batches": int(part.model_batches.iloc[0]),
                     "zero_model_queries": int(part.zero_model_queries.iloc[0]),
                     "zero_model_query_pct": rate(part.zero_model_queries.iloc[0], part.queries.iloc[0]),
                     "candidate_scoring_reduction_pct": 100 * (1 - part.model_pairs.iloc[0] / baseline.model_pairs.iloc[0]),
                     "model_batch_reduction_pct": 100 * (1 - part.model_batches.iloc[0] / baseline.model_batches.iloc[0]),
                     "wall_time_saving_pct": 100 * (1 - wall / baseline_wall), "wall_speedup_ratio": baseline_wall / wall,
                     "queries_per_second": part.queries.iloc[0] / wall,
                     "input_candidate_pairs_per_second": part.pairs.iloc[0] / wall,
                     "measurement_scope": "Full formal pooled throughput; not per-request latency"})
    return pd.DataFrame(rows)


def numerical_differences(predictions: pd.DataFrame, groups: dict) -> pd.DataFrame:
    rows = []
    seeds = sorted(predictions.seed.unique())
    batches = sorted(predictions.batch_size.unique())
    for name, splits in groups.items():
        selected = predictions[predictions.evaluation_split.isin(splits)]
        comparisons = [(policy, a, policy, b, "cross_batch") for policy in POLICIES for a, b in itertools.combinations(batches, 2)]
        comparisons += [("all_bge", bs, "system_top3", bs, "cross_policy") for bs in batches]
        for seed in seeds:
            for policy_a, batch_a, policy_b, batch_b, kind in comparisons:
                a = selected[(selected.seed == seed) & selected.policy.eq(policy_a) & selected.batch_size.eq(batch_a)].set_index("pair_id")
                b = selected[(selected.seed == seed) & selected.policy.eq(policy_b) & selected.batch_size.eq(batch_b)].set_index("pair_id").reindex(a.index)
                require(len(a) == len(b) and b.seed.notna().all(), "Unpaired numerical comparison")
                both_called = a.model_called & b.model_called
                delta = b.loc[both_called, "score"] - a.loc[both_called, "score"]
                decision_difference = a.prediction != b.prediction
                membership_difference = a.returned_rank.gt(0) != b.returned_rank.gt(0)
                rank_difference = a.returned_rank != b.returned_rank
                query_changed = a.loc[rank_difference, QUERY_KEYS].drop_duplicates().shape[0]
                gold = a.final_label.eq(1)
                row = {"evaluation_group": name, "seed": seed, "comparison_kind": kind, "policy_a": policy_a,
                       "batch_a": batch_a, "policy_b": policy_b, "batch_b": batch_b, "paired_candidates": len(a),
                       "scored_by_both_candidates": int(both_called.sum()),
                       "score_max_abs_difference": float(delta.abs().max()) if len(delta) else np.nan,
                       "score_mean_abs_difference": float(delta.abs().mean()) if len(delta) else np.nan,
                       "score_p95_abs_difference": float(delta.abs().quantile(.95)) if len(delta) else np.nan,
                       "model_call_mask_difference_n": int((a.model_called != b.model_called).sum()),
                       "threshold_decision_difference_on_common_scored_n": int((decision_difference & both_called).sum()),
                       "returned_membership_difference_n": int(membership_difference.sum()),
                       "returned_rank_difference_n": int(rank_difference.sum()), "returned_list_changed_query_n": int(query_changed),
                       "returned_tp_a": int((a.returned_rank.gt(0) & gold).sum()), "returned_tp_b": int((b.returned_rank.gt(0) & gold).sum()),
                       "returned_fp_a": int((a.returned_rank.gt(0) & ~gold).sum()), "returned_fp_b": int((b.returned_rank.gt(0) & ~gold).sum())}
                if kind == "cross_batch":
                    require(row["model_call_mask_difference_n"] == 0, "Batch size changed input-only routing")
                rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", required=True, type=Path)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    runtime, source, output = args.runtime.resolve(), args.source.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    qa = {"status": "started", "script_sha256": sha256(Path(__file__)), "scope": SCOPE,
          "labels_used_for_routing": False, "rates": "*_pct are percentages", "seed_sd": "Sample SD across existing checkpoints; timing SD also reflects measurement variability.",
          "system_pair_f1": "Not reported; early-stopped candidates remain unobserved (-1).",
          "bf16": "Every actual policy/batch uses its recorded GPU scores; numerical and return-list differences are explicitly retained."}
    try:
        inputs, source_manifest, manifest = read_inputs(source, runtime, qa)
        predictions = validate_predictions(runtime, inputs, source_manifest, manifest, qa)
        evaluated = join_gold(predictions, source, source_manifest, qa)
        groups = groups_for(evaluated)
        queries = per_query(evaluated)
        quality = summarize_quality(evaluated, queries, groups)
        timing, repeat_consistency = validate_timing(runtime, predictions, manifest, qa)
        timing_summary = summarize_timing(timing)
        differences = numerical_differences(evaluated, groups)
        outputs = {"runtime_per_query.csv": queries, "runtime_quality_per_seed.csv": quality,
                   "runtime_quality_seed_summary.csv": seed_aggregate(quality, ["evaluation_group", "policy", "batch_size"]),
                   "runtime_timing_per_seed.csv": timing_summary,
                   "runtime_timing_seed_summary.csv": seed_aggregate(timing_summary, ["policy", "batch_size"]),
                   "runtime_repeat_consistency.csv": repeat_consistency, "runtime_bf16_differences.csv": differences}
        for name, frame in outputs.items():
            frame.to_csv(output / name, index=False)
        qa["output_files"] = {name: {"rows": len(frame), "sha256": sha256(output / name)} for name, frame in outputs.items()}
        qa["evaluation_groups"] = groups
        qa["status"] = "passed"
        print(json.dumps({"status": "passed", "seeds": qa["provenance"]["seeds"], "measurements": len(timing),
                          "repeat_output_stable": qa["timing_integrity"]["repeat_output_stable"], "output_directory": str(output),
                          "scope": SCOPE}, ensure_ascii=False))
    except Exception as error:
        qa["status"] = "failed"
        qa["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "runtime_validation_qa.json").write_text(json.dumps(qa, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
