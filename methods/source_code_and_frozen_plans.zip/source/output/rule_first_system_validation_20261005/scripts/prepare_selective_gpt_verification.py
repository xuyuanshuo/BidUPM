"""Freeze a label-free, residual-only GPT diagnostic from existing BGE decisions.

This is post-hoc mechanism exploration on the old formal test, not independent
validation. Never use gold, quality statistics, model scores or prior GPT answers
in the verifier payload. All BGE-positive nonexact candidates are eligible, rather
than only the first three, so a rejected item can be replaced by another eligible
candidate. This experiment does not measure API money or latency.
"""
import hashlib
import json
from pathlib import Path

import pandas as pd


BASE = Path(__file__).resolve().parents[1]
DEST = BASE / 'blind_selective_gpt6_sol'
PRIVATE = BASE / 'results/selective_gpt6_sol'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    assert not DEST.exists(), 'Refusing to overwrite frozen blind input'
    original = BASE / 'blind_gpt6_sol/inputs/query_pools.jsonl'
    mapping_path = BASE / 'results/gpt6_sol_blind/private_mapping.csv'
    pools = [json.loads(x) for x in original.read_text().splitlines()]
    mp = pd.read_csv(mapping_path, dtype=str)
    assert len(mp) == 6600 and mp.pair_id.nunique() == 6600
    id_to_key = dict(zip(mp.pair_id, zip(mp.query_key, mp.candidate_key)))
    selected = set()
    source_hashes = {str(original.relative_to(BASE)):sha(original),
                     str(mapping_path.relative_to(BASE)):sha(mapping_path)}
    seed_selection = {}
    for seed in [20260904, 20260905, 20260906]:
        path = BASE / f'results/runtime/predictions_seed_{seed}.csv'
        d = pd.read_csv(path)
        d = d[(d.policy == 'system_top3') & (d.batch_size == 64)]
        assert len(d) == 6600 and d.pair_id.nunique() == 6600
        positive = d[(d.model_called == 1) & (d.prediction == 1) & (d.exact_match == 0)]
        ids = positive.pair_id.tolist()
        selected.update(ids)
        seed_selection[str(seed)] = ids
        source_hashes[str(path.relative_to(BASE))] = sha(path)
    by_query = {}
    for pair_id in selected:
        q, c = id_to_key[pair_id]
        by_query.setdefault(q, set()).add(c)
    payload = []
    for p in pools:
        q = p['query_key']
        if q not in by_query:
            continue
        candidates = [c for c in p['candidates'] if c['candidate_key'] in by_query[q]]
        assert len(candidates) == len(by_query[q])
        payload.append({'query_key':q, 'query':p['query'], 'candidates':candidates})
    assert sum(len(p['candidates']) for p in payload) == len(selected)
    DEST.joinpath('inputs').mkdir(parents=True)
    DEST.joinpath('outputs').mkdir()
    PRIVATE.mkdir(parents=True, exist_ok=True)
    out = DEST / 'inputs/query_pools.jsonl'
    out.write_text(''.join(json.dumps(p, ensure_ascii=False)+'\n' for p in payload))
    mp[mp.pair_id.isin(selected)].sort_values(['query_key','candidate_key']).to_csv(PRIVATE/'private_mapping.csv', index=False)
    manifest = {'status':'frozen_before_selective_judgment',
                'model':'gpt-6-sol','reasoning_effort':'medium',
                'design':'post-hoc residual-only verification; union of BGE-positive nonexact pairs from three frozen seeds; no known outcomes used for selection',
                'query_n':len(payload),'unique_candidate_pairs':len(selected),
                'seed_eligible_pair_ids':seed_selection,
                'input_sha256':sha(out),'source_sha256':source_hashes,
                'labels_read':False,'previous_gpt_predictions_read':False,
                'api_latency_and_cost_measured':False,
                'created_by_sha256':sha(Path(__file__)),
                'intended_policy':'Exact-first; eligible model-positive pair retained only when new verifier accepts it; preserve original BGE score ordering among accepted nonexact pairs; max3, no forced fill.'}
    (PRIVATE/'frozen_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    print(json.dumps({k:manifest[k] for k in ['status','query_n','unique_candidate_pairs','input_sha256']},ensure_ascii=False))


if __name__ == '__main__':
    main()
