"""Inventory original reference spans; never infer clauses, versions or gold."""
import hashlib
import json
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parents[1]
RAW = BASE / 'results/raw_alberta_import/raw_bid_items.csv'
OUT = BASE / 'results/engineering_evidence_inventory'
LANDING = 'https://www.alberta.ca/construction-contract-templates-and-specifications'
PUBLISHED = {
    'GCS': ('General Specifications and Specification Amendments for Highway and Bridge Construction', 'Edition16,2019', 'https://open.alberta.ca/publications/general-specifications-and-specification-amendments-for-highway-and-bridge-construction-edition-16'),
    'HCS': ('Standard Specifications for Highway Construction', 'Edition16,2019', 'https://open.alberta.ca/publications/standard-specifications-for-highway-construction-edition-16'),
    'BCS': ('Standard Specifications for Bridge Construction', 'Edition17,2020', 'https://open.alberta.ca/publications/standard-specifications-for-bridge-construction-edition-17'),
}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    before = sha(RAW)
    d = pd.read_csv(RAW).fillna('')
    assert len(d) == 135 and d.query_id.nunique() == 135
    rows, cards = [], []
    for record in d.to_dict('records'):
        spans = json.loads(record['removed_reference_spans'])
        item = int(record['item_number_metadata_only'])
        for i, span in enumerate(spans):
            text = span['text']
            family = next((k for k in PUBLISHED if k in text.upper()), '')
            if not family:
                family = 'Special Provisions' if 'special' in text.lower() else 'Project reference'
            public = PUBLISHED.get(family, ('', '', ''))
            rows.append({'query_id':record['query_id'], 'item_number':item,
                         'source_row':record['source_row'], 'source_cell':record['description_cell'],
                         'span_position':i, 'verbatim_reference':text, 'reference_family':family,
                         'extraction_rule':span['rule'], 'public_document_title_candidate':public[0],
                         'public_catalogue_edition_candidate':public[1],
                         'public_catalogue_url':public[2], 'official_landing_page':LANDING,
                         'applicable_contract_edition':'', 'actual_clause_text':'',
                         'reference_resolution':'not_resolved',
                         'manual_fetch_status':'catalogue_verified_body_fetch_403' if public[0] else 'project_document_not_provided'})
        cards.append({'query_id':record['query_id'], 'item_number':item,
                      'raw_description':record['description'], 'raw_unit':record['unit'],
                      'verbatim_reference_spans':[s['text'] for s in spans],
                      'source_cell':record['description_cell'], 'source_row':record['source_row'],
                      'engineering_action':None,'object':None,'material':None,
                      'size_or_range':None,'measurement_and_payment_scope':None,
                      'included_and_excluded_work':None,'contract_document_edition':None,
                      'scope':'Unfilled evidence-card prototype; no extracted semantic fields, gold judgments, or resolved clauses.'})
    r = pd.DataFrame(rows)
    assert len(r) == 189
    OUT.mkdir(parents=True, exist_ok=True)
    r.to_csv(OUT/'规范引用与证据缺口.csv', index=False, encoding='utf-8-sig')
    (OUT/'unfilled_query_evidence_cards.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in cards))
    aggregate = r.groupby('reference_family').agg(reference_spans=('query_id','size'),queries=('query_id','nunique')).reset_index()
    aggregate.to_csv(OUT/'reference_family_counts.csv',index=False)
    assert sha(RAW) == before
    summary = {'status':'passed','original_file_sha256':before,'raw_queries':135,
               'queries_with_reference':r.query_id.nunique(),'reference_spans':len(r),
               'unique_verbatim_reference_spans':r.verbatim_reference.nunique(),
               'semantic_fields_filled':0,'actual_clauses_retrieved':0,
               'contract_applicable_editions_verified':0,'labels_created':False,
               'official_catalogue_checked_on':'2026-10-05','official_catalogue_url':LANDING,
               'sources_unchanged':True,'script_sha256':sha(Path(__file__)),
               'output_sha256':{p.name:sha(p) for p in OUT.iterdir() if p.is_file() and p.name!='qa.json'}}
    (OUT/'qa.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    (OUT/'工程证据缺口说明.txt').write_text(
        '原始135个清单项的规范／项目引用已按原文定位整理，未改动来源，也未把模型判断写入金标。\n'
        f'含引用查询{r.query_id.nunique()}项，引用片段189处。这里只是引用清单，不是已解析施工规范。\n'
        '官方目录明确列出GCS/HCS第16版2019及BCS第17版2020；具体合同适用版本仍须由原合同确认。\n'
        f'官方目录：{LANDING}\n'
        '关联公开出版页可定位，但本轮获取正文返回403，没有条款内容可以加入模型。\n'
        'Special Provisions及BF项目引用必须从项目合同／图纸取得，不应由通用规范替代。\n'
        '报价目录也需要确认对应版本与计量支付范围；单靠查询一侧的条款不能证明两侧兼容。\n'
        '证据卡所有工程语义字段为空；不能把原文出现的引用编号当成已验证的规格相等。\n'
    )
    # Include the final note in the output hash inventory.
    summary['output_sha256'] = {p.name:sha(p) for p in OUT.iterdir() if p.is_file() and p.name!='qa.json'}
    (OUT/'qa.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps({k:summary[k] for k in ['status','raw_queries','queries_with_reference','reference_spans','actual_clauses_retrieved']},ensure_ascii=False))


if __name__ == '__main__':
    main()
