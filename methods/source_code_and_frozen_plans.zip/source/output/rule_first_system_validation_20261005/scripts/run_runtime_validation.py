#!/usr/bin/env python3
"""Frozen, label-blind runtime robustness for a deployed Top3 policy."""
import argparse,gc,hashlib,json,os,time
from pathlib import Path
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np
import pandas as pd
import torch
from transformers import AutoModelForSequenceClassification,AutoTokenizer
from system_policy import exact_mask,route,serialize,compose,rank_returned

POLICIES=('rule_only','all_bge','system_top3')
BATCH_SIZES=(1,16,64)
REPEATS=3

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def routing_for(frame,policy):
    if policy=='system_top3':return route(frame)
    n=len(frame)
    # Full-model baseline does not pay for a rule gate it does not use.
    exact=exact_mask(frame) if policy=='rule_only' else np.zeros(n,bool)
    accepted=exact if policy=='rule_only' else np.zeros(n,bool)
    called=np.zeros(n,bool) if policy=='rule_only' else np.ones(n,bool)
    return {'exact_match':exact,'rule_accept':accepted,'model_called':called,
            'unscored':np.zeros(n,bool),'called_indices':np.flatnonzero(called)}

@torch.inference_mode()
def execute(frame,policy,model,tokenizer,threshold,batch_size):
    torch.cuda.synchronize();t0=time.perf_counter()
    routing=routing_for(frame,policy);ix=routing['called_indices']
    sub=frame.iloc[ix]
    qt=serialize(sub,'query');ct=serialize(sub,'candidate')
    values=np.full(len(ix),np.nan,dtype=np.float64);batches=0
    for lo in range(0,len(ix),batch_size):
        enc=tokenizer(qt[lo:lo+batch_size],ct[lo:lo+batch_size],padding=True,
                      truncation=True,max_length=256,return_tensors='pt')
        enc={k:v.to('cuda') for k,v in enc.items()}
        with torch.autocast('cuda',dtype=torch.bfloat16):logits=model(**enc).logits.reshape(-1)
        values[lo:lo+batch_size]=logits.float().cpu().numpy();batches+=1
    if policy=='system_top3':
        result=compose(frame,routing,values,threshold)
    else:
        scores=np.full(len(frame),np.nan);scores[ix]=values
        prediction=routing['rule_accept'].astype(np.int8)
        prediction[ix]=(values>=threshold).astype(np.int8)
        result={**routing,'score':scores,'prediction':prediction,
                'returned_rank':rank_returned(frame,routing['rule_accept'],scores,threshold)}
    torch.cuda.synchronize();dt=time.perf_counter()-t0
    return result,{'seconds':dt,'model_pairs':len(ix),'model_batches':batches,
                  'early_stopped_queries':int(frame.assign(_exact=routing['rule_accept']).groupby('query_id')._exact.sum().ge(3).sum()) if policy=='system_top3' else 0}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    original=json.loads((a.source/'source_manifest.json').read_text())
    assert sha(a.source/'inputs.csv')==original['inputs_sha256']
    inputs=pd.read_csv(a.source/'inputs.csv',dtype=str,keep_default_na=False)
    assert inputs.columns.tolist()==original['inference_input_contract']
    frame=inputs[inputs.evaluation_split!='validation'].reset_index(drop=True)
    assert len(frame)==6600 and frame.query_id.nunique()==220
    assert frame.groupby('query_id').size().eq(30).all()
    diagnostic_exact=exact_mask(frame)
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False
    plan={'status':'running','policies':POLICIES,'batch_sizes':BATCH_SIZES,'repeats':REPEATS,
          'query_n':220,'pair_n':6600,'input_sha256':original['inputs_sha256'],
          'model_load_and_retrieval_included':False,'labels_accessed':False,'thresholds_retuned':False,
          'script_sha256':sha(__file__),'policy_sha256':sha(Path(__file__).with_name('system_policy.py')),
          'device':torch.cuda.get_device_name(0),'torch':torch.__version__,
          'timing':'full formal pooled batch; routing, preparation, tokenization, inference and merge; synchronized resident model',
          'precision':'BF16; TF32 false','max_length':256,'source_runs':original['runs'],'completed_runs':[]}
    plan['diagnostic_exact_feature']='Computed outside timers for CSV checks; rules/system still compute their actual gate inside timing. Full BGE has no unused rule gate.'
    (a.output/'execution_manifest.json').write_text(json.dumps(plan,indent=2))
    times=[]
    for run in original['runs']:
        seed=run['seed'];threshold=run['threshold'];cp=Path(run['checkpoint'])
        print(f'CHECKPOINT_VERIFY seed={seed}',flush=True)
        for name,expected in run['checkpoint_files'].items():assert sha(cp/name)==expected,(seed,name)
        print(f'LOAD seed={seed}',flush=True)
        torch.manual_seed(seed)
        tokenizer=AutoTokenizer.from_pretrained(cp,local_files_only=True)
        model=AutoModelForSequenceClassification.from_pretrained(cp,local_files_only=True).to('cuda').eval()
        warm=inputs[inputs.evaluation_split=='validation'].head(64).reset_index(drop=True)
        for bs in BATCH_SIZES:
            for _ in range(2):execute(warm,'all_bge',model,tokenizer,threshold,bs)
        rows=[];references={};repeat_consistency=[]
        for repeat in range(REPEATS):
            conditions=[(policy,bs) for bs in BATCH_SIZES for policy in POLICIES]
            order=np.random.default_rng(seed+repeat).permutation(len(conditions))
            for idx in order:
                policy,bs=conditions[idx]
                print(f'START seed={seed} policy={policy} batch={bs} repeat={repeat}',flush=True)
                result,timing=execute(frame,policy,model,tokenizer,threshold,bs)
                times.append({'seed':seed,'policy':policy,'batch_size':bs,'repeat':repeat,'pairs':len(frame),'queries':220,**timing})
                if repeat==0:
                    references[(policy,bs)]={key:result[key].copy() for key in ['prediction','returned_rank']}
                    out=frame[['pair_id','evaluation_split','query_id']].copy()
                    out['seed']=seed;out['policy']=policy;out['batch_size']=bs;out['threshold']=threshold
                    for key in ['exact_match','rule_accept','model_called','unscored','score','prediction','returned_rank']:
                        out[key]=result[key].astype(int) if key in ['exact_match','rule_accept','model_called','unscored'] else result[key]
                    out['exact_match']=diagnostic_exact.astype(int)
                    rows.append(out)
                else:
                    ref=references[(policy,bs)]
                    repeat_consistency.append({'seed':seed,'policy':policy,'batch_size':bs,'repeat':repeat,
                        'decision_difference_n':int((ref['prediction']!=result['prediction']).sum()),
                        'rank_difference_n':int((ref['returned_rank']!=result['returned_rank']).sum())})
                pd.DataFrame(times).to_csv(a.output/'timing.csv',index=False)
                print(f'FINISH seconds={timing["seconds"]:.4f} model_pairs={timing["model_pairs"]}',flush=True)
        pred=a.output/f'predictions_seed_{seed}.csv';pd.concat(rows,ignore_index=True).to_csv(pred,index=False)
        pd.DataFrame(repeat_consistency).to_csv(a.output/f'repeat_consistency_seed_{seed}.csv',index=False)
        plan['completed_runs'].append({'seed':seed,'prediction_sha256':sha(pred),'threshold':threshold})
        (a.output/'execution_manifest.json').write_text(json.dumps(plan,indent=2))
        del model,tokenizer;gc.collect();torch.cuda.empty_cache()
        print(f'SEED_COMPLETE {seed}',flush=True)
    assert len(times)==81
    plan['status']='complete';plan['timing_sha256']=sha(a.output/'timing.csv');plan['completed_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    (a.output/'execution_manifest.json').write_text(json.dumps(plan,indent=2))
    print('ALL_COMPLETE',flush=True)

if __name__=='__main__':main()
