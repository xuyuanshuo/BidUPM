#!/usr/bin/env python3
"""Actual label-blind GPU execution of fixed rule-first policies; no retraining."""
from __future__ import annotations
import argparse
import gc
import hashlib
import json
import os
import re
import time
from pathlib import Path

os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np
import pandas as pd
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

POLICIES = ('rule_only','all_bge','exact_rescue','stop_1','stop_2','stop_3')
SPLITS = ('validation','locked','external','no_reference','no_reference_reclassified')
TEXT_FIELDS = ('description','normalized_description','normalized_unit','category','spec_tokens')

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def norm(s): return ' '.join(str(s).strip().lower().split())

def canonical_description(s):
    # Preserve the server's original canonical_text rule: punctuation and
    # hyphen spacing are formatting differences, not new matching conditions.
    return ' '.join(re.sub(r'[^a-z0-9]+',' ',str(s or '').lower().replace('&',' and ')).split())

def exact_mask(frame):
    qd=frame.query_normalized_description.map(canonical_description).to_numpy()
    cd=frame.candidate_normalized_description.map(canonical_description).to_numpy()
    qu=frame.query_normalized_unit.map(norm).to_numpy()
    cu=frame.candidate_normalized_unit.map(norm).to_numpy()
    return (qd!='') & (qu!='') & (qd==cd) & (qu==cu)

def serialize(frame, side):
    values=[frame[f'{side}_{suffix}'].map(norm).tolist() for suffix in TEXT_FIELDS]
    return [f'Description: {d}. Normalized: {n}. Pay unit: {u}. Category: {c}. Specs: {s}.'
            for d,n,u,c,s in zip(*values)]

def route(frame, policy):
    if policy=='all_bge':
        return np.zeros(len(frame),bool), np.ones(len(frame),bool), np.zeros(len(frame),bool)
    exact=exact_mask(frame)
    called=np.zeros(len(frame),bool) if policy=='rule_only' else ~exact
    skipped=np.zeros(len(frame),bool)
    if policy.startswith('stop_'):
        k=int(policy.split('_')[1])
        counts=pd.Series(exact,index=frame.index).groupby(frame.query_id).transform('sum').to_numpy()
        skipped=(counts>=k) & ~exact
        called &= ~skipped
    return exact,called,skipped

def merge(frame, policy, accepted, scores, threshold):
    rank=np.zeros(len(frame),np.int16)
    for _,indices in frame.groupby('query_id',sort=False).indices.items():
        ids=frame.iloc[indices].candidate_id.to_numpy(str)
        rule=indices[accepted[indices]] if policy!='all_bge' else np.array([],int)
        if len(rule): rule=rule[np.argsort(frame.iloc[rule].candidate_id.to_numpy(str),kind='stable')]
        model=indices[np.isfinite(scores[indices]) & (scores[indices]>=threshold)]
        if len(model):
            order=np.lexsort((frame.iloc[model].candidate_id.to_numpy(str),-scores[model]))
            model=model[order]
        returned=np.r_[rule,model][:3]
        rank[returned]=np.arange(1,len(returned)+1)
    return rank

@torch.inference_mode()
def execute(frame, policy, model, tokenizer, threshold, batch_size=64):
    torch.cuda.synchronize()
    started=time.perf_counter()
    accepted,called,skipped=route(frame,policy)
    scores=np.full(len(frame),np.nan)
    ix=np.flatnonzero(called)
    sub=frame.iloc[ix]
    queries=serialize(sub,'query')
    candidates=serialize(sub,'candidate')
    gpu_ms=0.0
    batches=0
    for lo in range(0,len(sub),batch_size):
        enc=tokenizer(queries[lo:lo+batch_size],candidates[lo:lo+batch_size],padding=True,
                      truncation=True,max_length=256,return_tensors='pt')
        enc={k:v.to('cuda') for k,v in enc.items()}
        ev0=torch.cuda.Event(enable_timing=True); ev1=torch.cuda.Event(enable_timing=True)
        ev0.record()
        with torch.autocast('cuda',dtype=torch.bfloat16):
            logits=model(**enc).logits.reshape(-1)
        ev1.record()
        values=logits.float().cpu().numpy()
        ev1.synchronize(); gpu_ms+=ev0.elapsed_time(ev1)
        scores[ix[lo:lo+batch_size]]=values
        batches+=1
    pred=accepted.astype(np.int8)
    pred[called]=(scores[called]>=threshold).astype(np.int8)
    pred[skipped]=-1
    ranks=merge(frame,policy,accepted,scores,threshold)
    torch.cuda.synchronize()
    seconds=time.perf_counter()-started
    return {'score':scores,'prediction':pred,'returned_rank':ranks,'model_called':called,
            'rule_accept':accepted if policy!='all_bge' else None,'seconds':seconds,
            'gpu_forward_ms':gpu_ms,'model_pairs':int(called.sum()),'model_batches':batches,
            'skipped_pairs':int(skipped.sum())}

def prediction_rows(frame, result, seed, policy, threshold):
    out=frame[['pair_id']].copy()
    out['seed']=seed; out['policy']=policy; out['threshold']=threshold
    out['exact_match']=exact_mask(frame).astype(int)
    out['rule_accept']=out.exact_match if policy!='all_bge' else 0
    for k in ['model_called','score','prediction','returned_rank']:
        out[k]=result[k].astype(int) if k=='model_called' else result[k]
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--directory',type=Path,required=True)
    ap.add_argument('--batch-repeats',type=int,default=5)
    ap.add_argument('--query-repeats',type=int,default=3)
    args=ap.parse_args(); out=args.directory
    manifest=json.loads((out/'source_manifest.json').read_text())
    assert sha(out/'inputs.csv')==manifest['inputs_sha256']
    # This runner deliberately never opens labels.csv or any annotation field.
    inputs=pd.read_csv(out/'inputs.csv',dtype=str,keep_default_na=False)
    assert inputs.columns.tolist()==manifest['inference_input_contract']
    assert not inputs.pair_id.duplicated().any()
    assert inputs.groupby(['evaluation_split','query_id']).size().eq(30).all()
    assert not inputs.duplicated(['evaluation_split','query_id','candidate_id']).any()
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32=False
    timing_batch=[]; timing_query=[]; run_logs=[]; qa_rows=[]
    (out/'query_mode').mkdir(exist_ok=True)
    frozen={'policies':POLICIES,'batch_repeats':args.batch_repeats,'query_repeats':args.query_repeats,
            'script_sha256':sha(__file__),'input_sha256':sha(out/'inputs.csv'),
            'labels_accessed_by_runner':False,'retrieval_included_in_timing':False,
            'model_load_included_in_timing':False,'gate_label_access':False,
            'unit_rejection_gate':False,'merging':'exact priority, candidate ID ties; then BGE descending logit',
            'max_length':256,'batch_size':64,'dtype':'BF16 autocast',
            'timing':'resident model, CUDA synchronized, input serialization/gate/tokenization/merge included',
            'main_quality_mode':'batched candidate inference; query mode reported independently'}
    (out/'execution_plan.json').write_text(json.dumps(frozen,indent=2)+'\n')
    for run in manifest['runs']:
        seed=run['seed']; threshold=run['threshold']; checkpoint=run['checkpoint']
        print(f'LOAD seed={seed} threshold={threshold}',flush=True)
        torch.manual_seed(seed)
        t0=time.perf_counter()
        tokenizer=AutoTokenizer.from_pretrained(checkpoint,local_files_only=True)
        model=AutoModelForSequenceClassification.from_pretrained(checkpoint,local_files_only=True).to('cuda')
        model.eval(); load_seconds=time.perf_counter()-t0
        warm=inputs[inputs.evaluation_split=='validation'].head(64).reset_index(drop=True)
        for _ in range(3): execute(warm,'all_bge',model,tokenizer,threshold)
        seed_predictions=[]; query_predictions=[]; validation_done=False
        for split in SPLITS:
            frame=inputs[inputs.evaluation_split==split].reset_index(drop=True)
            first={}
            print(f'BATCH seed={seed} split={split} pairs={len(frame)}',flush=True)
            for repeat in range(args.batch_repeats):
                order=np.random.default_rng(seed+repeat+SPLITS.index(split)*100).permutation(POLICIES)
                for policy in order:
                    result=execute(frame,str(policy),model,tokenizer,threshold)
                    timing_batch.append({'seed':seed,'split':split,'policy':str(policy),'repeat':repeat,
                                         'pairs':len(frame),'queries':frame.query_id.nunique(),
                                         **{k:result[k] for k in ['seconds','gpu_forward_ms','model_pairs','model_batches','skipped_pairs']}})
                    if repeat==0:
                        first[str(policy)]=result
                        seed_predictions.append(prediction_rows(frame,result,seed,str(policy),threshold))
                    else:
                        reference=first[str(policy)]
                        assert np.array_equal(result['prediction'],reference['prediction'])
                        assert np.array_equal(result['returned_rank'],reference['returned_rank'])
            # Under fixed per-pair scores, stopping after three rule references
            # cannot change an exact-priority Top-3. Actual BF16 sub-batches may
            # differ numerically, so record those differences instead of hiding
            # them or aborting the experiment.
            accepted,called,_=route(frame,'stop_3')
            replay_scores=first['exact_rescue']['score'].copy()
            replay_scores[~called]=np.nan
            replay_rank=merge(frame,'stop_3',accepted,replay_scores,threshold)
            assert np.array_equal(replay_rank,first['exact_rescue']['returned_rank'])
            qa_rows.append({'seed':seed,'split':split,'policy':'stop_3_vs_exact_rescue',
                            'batch_query_prediction_disagreements':int((first['stop_3']['prediction'][called]!=first['exact_rescue']['prediction'][called]).sum()),
                            'batch_query_return_rank_disagreements':int((first['stop_3']['returned_rank']!=first['exact_rescue']['returned_rank']).sum())})
            if split=='validation':
                validation_done=True
                pd.concat(seed_predictions).to_csv(out/f'validation_predictions_seed_{seed}.csv',index=False)
                print(f'VALIDATION policies executed and frozen seed={seed}; no labels consumed',flush=True)
            assert validation_done
            print(f'QUERY seed={seed} split={split} queries={frame.query_id.nunique()}',flush=True)
            query_first={policy:[] for policy in POLICIES}
            for qid,group in frame.groupby('query_id',sort=True):
                group=group.reset_index(drop=True)
                for repeat in range(args.query_repeats):
                    order=np.random.default_rng(seed+repeat+int(hashlib.sha256(qid.encode()).hexdigest()[:6],16)).permutation(POLICIES)
                    for policy in order:
                        result=execute(group,str(policy),model,tokenizer,threshold)
                        timing_query.append({'seed':seed,'split':split,'query_id':qid,'policy':str(policy),'repeat':repeat,
                                             'pairs':len(group),**{k:result[k] for k in ['seconds','gpu_forward_ms','model_pairs','model_batches','skipped_pairs']}})
                        if repeat==0: query_first[str(policy)].append(prediction_rows(group,result,seed,str(policy),threshold))
            for policy in POLICIES:
                qpred=pd.concat(query_first[policy],ignore_index=True)
                query_predictions.append(qpred)
                bpred=prediction_rows(frame,first[policy],seed,policy,threshold).set_index('pair_id')
                qcomp=qpred.set_index('pair_id').loc[bpred.index]
                qa_rows.append({'seed':seed,'split':split,'policy':policy,
                                'batch_query_prediction_disagreements':int((bpred.prediction!=qcomp.prediction).sum()),
                                'batch_query_return_rank_disagreements':int((bpred.returned_rank!=qcomp.returned_rank).sum())})
            pd.DataFrame(timing_batch).to_csv(out/'timing_batch.csv',index=False)
            pd.DataFrame(timing_query).to_csv(out/'timing_query.csv',index=False)
            print(f'COMPLETE seed={seed} split={split}',flush=True)
        predfile=out/f'predictions_seed_{seed}.csv'
        pd.concat(seed_predictions,ignore_index=True).to_csv(predfile,index=False)
        qfile=out/'query_mode'/f'predictions_seed_{seed}.csv'
        pd.concat(query_predictions,ignore_index=True).to_csv(qfile,index=False)
        run_logs.append({'seed':seed,'threshold':threshold,'checkpoint':checkpoint,'load_seconds':load_seconds,
                         'prediction_sha256':sha(predfile),'query_prediction_sha256':sha(qfile),'status':'complete'})
        pd.DataFrame(qa_rows).to_csv(out/'batch_query_consistency.csv',index=False)
        (out/'execution_manifest.json').write_text(json.dumps({**frozen,'runs':run_logs,'status':'running',
                'torch':torch.__version__,'gpu':torch.cuda.get_device_name(0)},indent=2)+'\n')
        del model,tokenizer; gc.collect(); torch.cuda.empty_cache()
    (out/'execution_manifest.json').write_text(json.dumps({**frozen,'runs':run_logs,'status':'complete',
            'torch':torch.__version__,'gpu':torch.cuda.get_device_name(0),
            'completed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},indent=2)+'\n')
    print('ALL COMPLETE',flush=True)

if __name__=='__main__': main()
