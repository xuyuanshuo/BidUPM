#!/usr/bin/env python3
"""Plot the completed live-server three-checkpoint system experiment.

This figure compares final returned lists, never all-pair F1 for early-stop
policies. Timing is amortized batch-screening time per query, not request latency.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.text import Text
from matplotlib.ticker import LogLocator, NullFormatter, ScalarFormatter


POLICIES = ("rule_only", "all_bge", "stop_3")
GROUPS = ("locked", "external")
NAMES = {
    "rule_only": "Rule only",
    "all_bge": "All candidates → BGE",
    "stop_3": "Rule first + BGE\n(stop at ≥3 exact)",
}
COLORS = {"locked": "#25668B", "external": "#B36B29"}
MARKERS = {"rule_only": "o", "all_bge": "s", "stop_3": "D"}
METRICS = ("macro_recall_at3_pct", "returned_micro_precision_pct", "batch_ms_per_query")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def finite(value):
    return math.isfinite(float(value))


def get_record(rows, group, policy, metric):
    selected = [r for r in rows if r["evaluation_group"] == group
                and r["policy"] == policy and r["metric"] == metric]
    require(len(selected) == 1, f"Expected one {group}/{policy}/{metric} row")
    record = selected[0]
    require(int(record["seed_n"]) == 3 and int(record["finite_seed_n"]) == 3,
            f"Incomplete three-seed result: {group}/{policy}/{metric}")
    require(finite(record["mean"]) and finite(record["sample_sd"]),
            f"Nonfinite three-seed result: {group}/{policy}/{metric}")
    return float(record["mean"]), float(record["sample_sd"])


def load_data(directory):
    quality_path = directory / "summary_aggregate.csv"
    timing_path = directory / "timing_batch_seed_summary.csv"
    manifest_path = directory / "execution_manifest.json"
    source_path = directory / "source_manifest.json"
    for path in (quality_path, timing_path, manifest_path, source_path):
        require(path.is_file(), f"Final result not ready: {path}")
    manifest = json.loads(manifest_path.read_text())
    source = json.loads(source_path.read_text())
    require(manifest["status"] == "complete", "Server experiment is not complete")
    require(source["source"] == "live_server", "Figure requires live-server results")
    require(len(manifest["runs"]) == 3 and all(r["status"] == "complete" for r in manifest["runs"]),
            "All three checkpoint runs must be complete")
    seeds = sorted(int(r["seed"]) for r in manifest["runs"])
    require(len(set(seeds)) == 3, "Three distinct checkpoint seeds are required")
    quality = read_csv(quality_path)
    timing = read_csv(timing_path)
    values = {}
    for group in GROUPS:
        n_queries = int(source["queries_per_split"][group])
        values[group] = {}
        for policy in POLICIES:
            values[group][policy] = {
                metric: get_record(quality, group, policy, metric)
                for metric in METRICS[:2]
            }
            cohort_time, cohort_sd = get_record(timing, group, policy, "wall_seconds_median")
            values[group][policy]["batch_ms_per_query"] = (
                1000 * cohort_time / n_queries,
                1000 * cohort_sd / n_queries,
            )
            require(cohort_time > 0 and cohort_sd >= 0, "Invalid actual timing")
            for metric in METRICS[:2]:
                mean, sd = values[group][policy][metric]
                require(0 <= mean <= 100 and sd >= 0, "Invalid quality result")
        # Rule-only predictions do not depend on checkpoint seed.
        for metric in METRICS[:2]:
            require(values[group]["rule_only"][metric][1] < 1e-9,
                    "Rule-only quality unexpectedly depends on model seed")
    metadata = {
        "source": "live_server",
        "seeds": seeds,
        "policies": list(POLICIES),
        "groups": list(GROUPS),
        "query_counts": {g: source["queries_per_split"][g] for g in GROUPS},
        "quality_metrics": list(METRICS[:2]),
        "timing_definition": "For each seed, median total batch-screening seconds across repeats / query count; then checkpoint mean and sample SD in ms/query.",
        "timing_scope": "Resident model; routing, serialization, tokenization, inference and merge included. Candidate retrieval and model loading excluded.",
        "inference_batch_size": source["batch_size"],
        "gpu": source["gpu"],
        "full_pair_f1_plotted": False,
        "sources_sha256": {p.name: digest(p) for p in (quality_path, timing_path, manifest_path, source_path)},
        "plotted_values": values,
    }
    return values, metadata


def fmt(mean, sd, timing=False):
    if timing:
        decimals = 3 if mean < 1 else 2
        return f"{mean:.{decimals}f} ± {sd:.{decimals}f}"
    return f"{mean:.2f} ± {sd:.2f}"


def render(values, metadata, project, iteration):
    """Layout changes are intentional and recorded per inspected iteration."""
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.labelsize": 10, "axes.titlesize": 11,
        "xtick.labelsize": 9, "ytick.labelsize": 10,
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.spines.left": False,
    })
    configs = {
        1: dict(size=(11.7, 4.2), left=.20, right=.98, bottom=.19, top=.88,
                wspace=.37, annotations="above", subtitle=False),
        2: dict(size=(12.5, 4.8), left=.22, right=.985, bottom=.21, top=.89,
                wspace=.43, annotations="right_column", subtitle=True),
        3: dict(size=(12.5, 5.8), left=.205, right=.985, bottom=.25, top=.81,
                wspace=.48, annotations="above", subtitle=True),
    }
    cfg = configs[iteration]
    fig, axes = plt.subplots(1, 3, figsize=cfg["size"])
    fig.subplots_adjust(left=cfg["left"], right=cfg["right"], bottom=cfg["bottom"],
                        top=cfg["top"], wspace=cfg["wspace"])
    yy = {"locked": [5, 4, 3], "external": [1, 0, -1]}
    titles = ["(a) Reference coverage", "(b) Returned precision", "(c) Screening time"]
    labels = ["Macro Recall@3 (%)", "Micro precision (%)", "Batch screening (ms/query)"]
    for index, (ax, metric) in enumerate(zip(axes, METRICS)):
        ax.set_title(titles[index], loc="left", pad=13 if iteration == 3 else 15)
        ax.set_ylim(-1.65, 6.02)
        ax.set_xlabel(labels[index], labelpad=10)
        ax.tick_params(axis="y", left=False, length=0)
        ax.spines["bottom"].set_color("#99A4AC")
        ax.tick_params(axis="x", color="#99A4AC")
        ax.axhline(2.05, color="#D6DEE3", linewidth=.8, zorder=0)
        if index < 2:
            min_value = min(values[g][p][metric][0] - values[g][p][metric][1]
                            for g in GROUPS for p in POLICIES)
            low = min(94.0, math.floor(min_value - .6))
            ax.set_xlim(low, 101.7 if iteration == 3 else 101)
            ax.set_xticks(np.arange(math.ceil(low / 2) * 2, 101, 2))
            ax.grid(axis="x", color="#E8EDF1", linewidth=.8)
        else:
            low_value = min(values[g][p][metric][0] - values[g][p][metric][1]
                            for g in GROUPS for p in POLICIES)
            high_value = max(values[g][p][metric][0] + values[g][p][metric][1]
                             for g in GROUPS for p in POLICIES)
            require(low_value > 0, "Log timing axis cannot show nonpositive lower SD")
            ax.set_xscale("log")
            ax.set_xlim(low_value / (2.5 if iteration == 3 else 1.7), high_value * 1.7)
            lo, hi = ax.get_xlim()
            ax.set_xticks([10.0 ** power for power in range(math.ceil(math.log10(lo)),
                                                           math.floor(math.log10(hi)) + 1)])
            ax.xaxis.set_major_formatter(ScalarFormatter())
            ax.xaxis.set_minor_formatter(NullFormatter())
            ax.grid(axis="x", which="major", color="#E8EDF1", linewidth=.8)
        tick_positions = []
        tick_labels = []
        for group in GROUPS:
            color = COLORS[group]
            for policy, y in zip(POLICIES, yy[group]):
                mean, sd = values[group][policy][metric]
                ax.errorbar(mean, y, xerr=sd, fmt=MARKERS[policy], color=color,
                            markersize=6, linewidth=1.4, capsize=3.5, capthick=1.2,
                            markeredgewidth=1.0, zorder=3)
                value = fmt(mean, sd, timing=index == 2)
                if cfg["annotations"] == "above":
                    x = mean
                    if index < 2:
                        x = min(max(x, ax.get_xlim()[0] + 1.3), ax.get_xlim()[1] - 1.3)
                    else:
                        lo, hi = np.log10(ax.get_xlim())
                        label_position = min(max((math.log10(x) - lo) / (hi - lo), .18), .82)
                        x = 10 ** (lo + label_position * (hi - lo))
                    ax.annotate(value, (x, y), xytext=(0, 10),
                                textcoords="offset points", ha="center", va="bottom",
                                fontsize=8.7, color="#35424B", clip_on=False,
                                bbox=dict(facecolor="white", edgecolor="none", pad=.8))
                else:
                    ax.text(.98, y + .23, value, transform=ax.get_yaxis_transform(),
                            ha="right", va="bottom", fontsize=8.7, color="#35424B")
                tick_positions.append(y)
                tick_labels.append(NAMES[policy])
        ax.set_yticks(tick_positions)
        ax.set_yticklabels(tick_labels if index == 0 else [""] * len(tick_labels))
        if index == 0:
            for group, y in (("locked", 5.78), ("external", 1.78)):
                title = "Internal · NCDOT" if group == "locked" else "External · WSDOT"
                n = metadata["query_counts"][group]
                ax.text(-.06, y, f"{title}  (n={n})", transform=ax.get_yaxis_transform(),
                        ha="right", va="center", fontsize=10, fontweight="bold",
                        color=COLORS[group], clip_on=False)
    if cfg["subtitle"]:
        fig.text(.5, .965, "Final reference lists: quality and screening time",
                 ha="center", va="top", fontsize=12, fontweight="bold", color="#25323A")
    fig.text(cfg["left"], .105,
             "Points: mean ± sample SD across three checkpoint seeds. Every policy returns at most three references.",
             ha="left", va="center", fontsize=8.6, color="#46535B")
    fig.text(cfg["left"], .065,
             "Time: repeated batch-screening median per seed, divided by query count; resident model, "
             "given candidate pools. Log time axis.",
             ha="left", va="center", fontsize=8.3, color="#46535B")
    fig.text(cfg["left"], .032,
             "Includes routing, input preparation, inference and merging; excludes retrieval/model loading. "
             "Batch ms/query is not single-request latency.",
             ha="left", va="center", fontsize=8.3, color="#46535B")
    qa_dir = project / "qa" / f"figure_v{iteration}"
    qa_dir.mkdir(parents=True, exist_ok=True)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    canvas = fig.bbox
    boxes = []
    out_of_canvas = []
    for artist in fig.findobj(match=Text):
        if not artist.get_visible() or not artist.get_text().strip():
            continue
        box = artist.get_window_extent(renderer)
        record = {"text": artist.get_text(), "bounds": list(box.bounds)}
        boxes.append((artist.get_text(), box))
        if box.x0 < 0 or box.y0 < 0 or box.x1 > canvas.x1 or box.y1 > canvas.y1:
            out_of_canvas.append(record)
    overlaps = []
    for i, (label, box) in enumerate(boxes):
        for other_label, other_box in boxes[i + 1:]:
            intersection_width = min(box.x1, other_box.x1) - max(box.x0, other_box.x0)
            intersection_height = min(box.y1, other_box.y1) - max(box.y0, other_box.y0)
            if intersection_width > .5 and intersection_height > .5:
                overlaps.append([label, other_label])
    bounds_qa = {"canvas_size_pixels": [canvas.x1, canvas.y1],
                 "nonempty_text_items": len(boxes), "out_of_canvas_text": out_of_canvas,
                 "text_bbox_intersections": overlaps}
    (qa_dir / "text_bounds_check.json").write_text(json.dumps(bounds_qa, indent=2))
    if iteration == 3:
        require(not out_of_canvas, "Final layout has clipped text; inspect text_bounds_check.json")
        require(not overlaps, "Final layout has overlapping text; inspect text_bounds_check.json")
    png_path = qa_dir / "system_tradeoff.png"
    fig.savefig(png_path, dpi=220, facecolor="white")
    fig.savefig(qa_dir / "system_tradeoff.pdf", facecolor="white")
    (qa_dir / "source_and_layout.json").write_text(json.dumps(
        {**metadata, "iteration": iteration, "layout": cfg}, indent=2, ensure_ascii=False))
    if iteration == 3:
        figures = project / "figures"
        figures.mkdir(exist_ok=True)
        fig.savefig(figures / "system_tradeoff.pdf", facecolor="white")
        fig.savefig(figures / "system_tradeoff.png", dpi=220, facecolor="white")
        (figures / "system_tradeoff_metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False))
    plt.close(fig)
    return png_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path,
                        default=Path(__file__).resolve().parents[1] / "results" / "server")
    parser.add_argument("--iteration", type=int, choices=[1, 2, 3], required=True)
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    values, metadata = load_data(args.directory)
    path = render(values, metadata, project, args.iteration)
    print(path)


if __name__ == "__main__":
    main()
