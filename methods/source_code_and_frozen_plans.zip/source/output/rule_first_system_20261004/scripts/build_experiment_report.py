#!/usr/bin/env python3
"""Build a Chinese review report exclusively from completed server results."""
import argparse
import json
from pathlib import Path
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--directory',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();base=args.directory;p=base/'results/server'
    assert json.loads((p/'execution_manifest.json').read_text())['status']=='complete'
    for name in ['qa.json','timing_qa.json']:
        assert json.loads((p/name).read_text())['status']=='passed'
    quality=pd.read_csv(p/'summary_aggregate.csv')
    batch=pd.read_csv(p/'timing_batch_seed_summary.csv')
    query=pd.read_csv(p/'timing_query_seed_summary.csv')
    def value(frame,split,policy,metric,field='mean'):
        row=frame[(frame.evaluation_group==split)&(frame.policy==policy)&(frame.metric==metric)]
        assert len(row)==1,(split,policy,metric)
        return float(row.iloc[0][field])
    def q(split,policy,metric):return value(quality,split,policy,metric)
    def f(v):return f'{v:.2f}'
    def sd(split,policy,metric):return f'{q(split,policy,metric):.2f} ± {value(quality,split,policy,metric,"sample_sd"):.2f}'
    pdfmetrics.registerFont(TTFont('STSong-Light', '/System/Library/Fonts/Supplemental/Arial Unicode.ttf'))
    title=ParagraphStyle('title',fontName='STSong-Light',fontSize=22,leading=29,textColor=colors.HexColor('#17364a'),spaceAfter=12)
    head=ParagraphStyle('head',fontName='STSong-Light',fontSize=14,leading=21,textColor=colors.HexColor('#17364a'),spaceBefore=14,spaceAfter=7)
    body=ParagraphStyle('body',fontName='STSong-Light',fontSize=10.5,leading=18,spaceAfter=9,wordWrap='CJK',alignment=TA_LEFT)
    small=ParagraphStyle('small',parent=body,fontSize=8.5,leading=14,textColor=colors.HexColor('#596b76'))
    cell=ParagraphStyle('cell',fontName='STSong-Light',fontSize=9,leading=13,wordWrap='CJK',alignment=TA_CENTER)
    story=[]
    def para(s,style=body):story.append(Paragraph(s,style))
    def table(rows,widths):
        data=[[Paragraph(str(v),cell) for v in row] for row in rows]
        t=Table(data,colWidths=widths,hAlign='CENTER',repeatRows=1)
        t.setStyle(TableStyle([('LINEABOVE',(0,0),(-1,0),1,colors.HexColor('#263e4c')),
             ('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#263e4c')),
             ('LINEBELOW',(0,-1),(-1,-1),1,colors.HexColor('#263e4c')),
             ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eff4f7')),
             ('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),7),
             ('BOTTOMPADDING',(0,0),(-1,-1),7)]))
        story.append(t);story.append(Spacer(1,9))
    para('规则优先系统实验结果',title)
    para('2026-10-04  |  三个困难强化BGE检查点  |  真实服务器GPU实验',small)
    para('结论与适用范围',head)
    para('结果支持把规则优先、模型补充与查询级早停写成有实测依据的筛选流程。已有三条精确参考时停止模型评分，相对全部使用BGE明显减少了候选评分和筛选耗时。模型对内部非精确候选的判断有所帮助，但实际最终名单只多了一条正确参考。外部没有新增正确参考且出现新增错误，因此不能宣称组合方案普遍优于仅规则。')
    para('实验使用服务器原验证、内部锁定、外部、原无参考和重分类分区，共7,500个候选对、250个查询，每查询30个候选。三个检查点的种子为20260904、20260905、20260906；原验证阈值分别为9.1875、-1.453125、8.4375。本次没有重新训练模型，规则与推理脚本不读取人工标签、困难标记或人工冲突标签。')
    para('首先复现原模型结果',head)
    table([['配置','内部锁定F1 (%)','内部困难F1 (%)','外部F1 (%)'],
           ['仅精确规则',sd('locked','rule_only','f1_pct'),sd('locked','rule_only','hard_f1_pct'),sd('external','rule_only','f1_pct')],
           ['全部候选使用BGE',sd('locked','all_bge','f1_pct'),sd('locked','all_bge','hard_f1_pct'),sd('external','all_bge','f1_pct')],
           ['精确接受，其余BGE',sd('locked','exact_rescue','f1_pct'),sd('locked','exact_rescue','hard_f1_pct'),sd('external','exact_rescue','f1_pct')]],
          [120,121,121,121])
    para('全量BGE的内部与外部平均F1复现为97.62%和95.42%，与当前论文表格一致。未早停的组合内部F1为97.80%，外部仍为95.42%。早停策略对部分候选没有作兼容性判断，故不为它填入完整候选对F1。以上误差为三个检查点的样本标准差。',small)
    para('六个预先固定的策略',head)
    para('仅规则；全部BGE；精确规则接受后，其余进入BGE；以及已有至少1、2、3条精确参考时停止模型处理的三个策略。所有策略的结果均保留，没有按照测试成绩选择或修改阈值。精确规则沿用服务器原标点规范化定义，从描述与单位输入重新计算，逐条与原规则一致。')
    story.append(PageBreak())
    para('最终参考名单的实际质量',title)
    para('所有策略至多返回三条参考。组合先返回精确规则接受项，再由超过原阈值的BGE候选补足。规则结果不与模型logit混成一个分数。',body)
    rows=[['分区 / 配置','正确 / 错误返回','返回精确率 (%)','宏平均Recall@3 (%)','Hit@3 (%)']]
    for split,label in [('locked','内部锁定'),('external','外部')]:
        for policy,name in [('rule_only','仅规则'),('all_bge','全量BGE'),('stop_3','规则+BGE，三条早停')]:
            rows.append([label+' / '+name,f"{q(split,policy,'returned_tp_n'):.2f} / {q(split,policy,'returned_fp_n'):.2f}",
                         f(q(split,policy,'returned_micro_precision_pct')),f(q(split,policy,'macro_recall_at3_pct')),f(q(split,policy,'hit_at3_pct'))])
    table(rows,[150,85,83,91,74])
    para('表中计数及百分比为三个检查点的均值；无参考查询也纳入错误参考统计。宏平均Recall@3是在有正例的候选池内，每查询正确返回数除以该池全部正例数，再对查询平均。Hit@3表示有正例的查询是否至少返回一条正确参考。',small)
    para('候选对提升为何没有转化为同等名单提升',head)
    para('内部规则遗漏23个兼容候选，BGE每个种子均找回其中14个，但在规则优先且最多返回三条的政策下，最终每次只多出同一查询的一条非精确正确参考。正确返回从260条增加至261条，宏平均Recall@3从95.20%增加至95.70%。按查询配对重采样的95%区间为0至1.50个百分点，因此不能称为已经证明显著的最终推荐提升。')
    para('外部共有3个规则未识别的兼容候选，三个检查点均未找回。规则与组合均返回145条正确参考，组合新增错误条目分别为3、7、8条。返回精确率从规则的100%变为96.05% ± 1.70%；其相对规则的差值95%区间为-7.22至-1.27个百分点。')
    para('内部锁定集的100个有参考查询全部已有精确规则正例，不能充分检验模型首次解决规则完全失败查询的能力。外部仅有1个这样的正例查询，模型未命中。当前证据主要说明候选兼容性学习与筛选效率，非精确查询补救仍需要对应真实查询的独立评价。')
    story.append(PageBreak())
    para('实际计算量与筛选耗时',title)
    para('同一GPU、BF16、最大长度256、批大小上限64。每分区重复批处理5次，每查询重复3次，政策执行顺序随机化。计时含规则、序列化、分词、GPU推理、排序与合并，排除候选检索和模型加载。')
    rows=[['分区 / 配置','进入BGE (%)','批处理总耗时 (s)','平均逐查询耗时 (ms)']]
    for split,label in [('locked','内部锁定'),('external','外部')]:
        for policy,name in [('rule_only','仅规则'),('all_bge','全量BGE'),('exact_rescue','精确接受，其余BGE'),('stop_3','规则+BGE，三条早停')]:
            rows.append([label+' / '+name,f(q(split,policy,'model_candidate_fraction_pct')),
                         f(value(batch,split,policy,'wall_seconds_median')),
                         f(value(query,split,policy,'wall_ms_mean'))])
    table(rows,[174,89,106,114])
    para('批处理列为每个检查点重复测时的中位数，再取三检查点均值。逐查询列先取各查询三次请求的中位数，再对查询与检查点平均。批量摊销ms/query与单次请求延迟是不同口径，不能互换。',small)
    para('显著节省来自查询级早停',head)
    para(f"若只跳过精确正例，其余均进入模型，内部和外部候选评分仅减少8.67%与6.04%，逐查询平均耗时减少4.48%与2.42%。加入三条精确参考早停后，内部模型处理688/3,000对，外部处理1,175/2,400对，候选评分减少77.07%与51.04%。相对全量BGE，批处理耗时减少{value(batch,'locked','stop_3','wall_time_saving_pct'):.2f}%与{value(batch,'external','stop_3','wall_time_saving_pct'):.2f}%。")
    para(f"逐查询平均筛选耗时减少{value(query,'locked','stop_3','wall_mean_time_saving_pct'):.2f}%与{value(query,'external','stop_3','wall_mean_time_saving_pct'):.2f}%；对应配对查询重采样95%区间分别为61.56%-77.44%和32.68%-53.89%。这反映本硬件和本候选池下的推理开销，不能直接改写为等同比例的货币节省。原无参考分区没有精确接受项，三条早停仍需对全部候选评分，不能推广为所有查询都同幅度加速。")
    para('在固定分数下，已有三条精确接受项时，其余模型结果不会进入精确优先Top3。实际GPU实验中三条早停与未早停组合的全部名单也完全一致。不同批处理方式出现轻微BF16分数漂移，但主要结论经固定分数回放独立复核，质量汇总未改变。')
    story.append(PageBreak())
    para('结果图与论文修改建议',title)
    img=base/'figures/system_tradeoff.png'
    story.append(Image(str(img),width=483,height=483*1276/2750));story.append(Spacer(1,12))
    para('可以采用的论文主线',head)
    para('研究一个规则优先的历史参考筛选流程：精确规则处理已可确定的参考，规则不足三条时由专项微调BGE补充；已有三条精确参考则直接返回。分别评价候选兼容性与实际参考名单，并记录质量与推理开销的权衡。方法图需要展示发生在BGE之前的规则判断与早停出口，原BGE之后的LLM核验不能作为前置分流的证据。')
    para('可直接写入的实测结论',head)
    para('相对全量BGE，精确优先和三条早停保持了未早停组合的名单，减少模型评分量与筛选耗时。内部兼容候选识别有所改善，最终推荐只补充少量正确参考。WSDOT外部结果未显示非精确参考补救优势，简单规则在该集合上更稳健，应保留这一适用范围说明。')
    para('需要避免的结论',head)
    para('不要宣称组合系统普遍优于仅规则、显著提高最终推荐成功率，或已经证明降低工程造价与货币成本。不要将早停未评分的候选记成已识别的不兼容，也不要为早停政策填写完整分类F1。本实验是观察过旧测试结果之后追加的系统研究，1条和2条早停作为预设探索策略完整呈现，不能包装成独立验证选出的最佳默认配置。')
    para('交付与复核',head)
    para('实验包包含服务器来源哈希、逐对预测、逐查询实际名单、每次测时、查询配对重采样、三种检查点汇总、固定分数回放和全部脚本。数据与模型来自服务器，原论文正文、表格、模型权重及测试划分未被覆盖。复核文件qa.json和timing_qa.json均通过；模型载入日志与执行状态保留在原始结果中。',small)
    def footer(c,doc):
        c.setFont('STSong-Light',8);c.setFillColor(colors.HexColor('#6c7e88'))
        c.drawString(42,25,'规则优先系统实验 | 2026-10-04 | 服务器实测')
        c.drawRightString(A4[0]-42,25,str(doc.page))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    doc=SimpleDocTemplate(str(args.output),pagesize=A4,rightMargin=56,leftMargin=56,topMargin=44,bottomMargin=44)
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    compact=[]
    for split in ['locked','external','no_reference','internal_combined']:
        for policy in ['rule_only','all_bge','exact_rescue','stop_1','stop_2','stop_3']:
            compact.append({'分区':split,'策略':policy,'候选对F1_百分比':q(split,policy,'f1_pct'),
              '最终名单精确率_百分比':q(split,policy,'returned_micro_precision_pct'),
              '宏平均Recall_at3_百分比':q(split,policy,'macro_recall_at3_pct'),
              '正确返回_三检查点均值':q(split,policy,'returned_tp_n'),'错误返回_三检查点均值':q(split,policy,'returned_fp_n'),
              '模型候选评分减少_百分比':q(split,policy,'model_candidate_saving_pct'),
              '批处理耗时_秒':value(batch,split,policy,'wall_seconds_median'),
              '平均逐查询耗时_毫秒':value(query,split,policy,'wall_ms_mean')})
    pd.DataFrame(compact).to_csv(base/'核心结果汇总.csv',index=False,encoding='utf-8-sig')
    (base/'实验结论与论文修改建议.txt').write_text(
      '实验已全部完成：3检查点、6固定策略、5评价分区、5次批处理重复、每查询3次重复。\n\n'
      '可以把规则优先、精确优先合并、三条参考早停写成经过实测的筛选流程及推理开销权衡。\n'
      '不能声称组合方案普遍优于仅规则，或已经证明非精确跨机构推荐补救。\n\n'
      '内部：每模型恢复14/23个规则遗漏候选，但最终名单只多同一查询的一条正确参考，260→261；Recall@3增加0.50个百分点，95%区间[0,1.50]。\n'
      '外部：模型恢复0/3个规则遗漏兼容候选，145个正确返回不变，新增错误3/7/8条；最终名单精确率96.05±1.70%，规则100%。\n'
      '三条早停：实际最终名单与未早停组合完全相同；内部/外部评分减少77.07%/51.04%，批处理耗时减少75.74%/48.17%，平均逐查询耗时减少69.57%/43.33%。\n'
      '只有跳过精确正例而不做查询早停：内部/外部评分仅减少8.67%/6.04%，平均逐查询耗时减少4.48%/2.42%。\n\n'
      '方法新增BGE之前的精确规则判断与≥3参考直接输出；不足3条才评分其余候选。\n'
      '结果分别呈现候选兼容性、真实返回名单、推理开销，早停未评分样本不得记为兼容性负例。\n'
      '正文保留内部最终名单改善有限、外部规则更稳的限制。调用量、时间与金钱分开，当前没有货币成本估算。\n'
      '既有困难子集可以证明候选关系学习，不足以证明首次解决规则完全失败的查询；内部100个有参考查询均已有精确规则正例。\n'
      '所有脚本和数据来源哈希、原始真实预测及每次测时均附在实验包内。原论文尚未改写。\n',encoding='utf-8')
    print(json.dumps({'report':str(args.output),'pages_expected':4,'summary_csv':str(base/'核心结果汇总.csv')},ensure_ascii=False))

if __name__=='__main__':main()
