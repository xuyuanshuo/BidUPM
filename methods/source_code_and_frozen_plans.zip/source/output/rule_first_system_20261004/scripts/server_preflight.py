#!/usr/bin/env python3
"""Freeze server-owned evaluation inputs and checkpoints for a new routing study."""
import hashlib
import json
import platform
import sys
from pathlib import Path

import pandas as pd
import torch
import transformers

BASE = Path('experiment_runtime')
DATA = Path('experiment_environment/supplementary/data')
OUT = BASE / 'rule_first_20261004'
sys.path.insert(0, str(BASE / 'scripts'))
from local_experiment_utils import load_data

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    OUT.mkdir(exist_ok=True)
    train, _, frame, hashes = load_data(DATA)
    cols = ['pair_id', 'evaluation_split', 'query_id', 'candidate_id', 'initial_rank', 'retrieval_score']
    cols += [f'{side}_{suffix}' for side in ['query','candidate'] for suffix in
             ['description','normalized_description','normalized_unit','category','spec_tokens']]
    inputs = frame[cols].copy()
    labels = frame[['pair_id','final_label','final_relevance','difficulty']].copy()
    inputs.to_csv(OUT/'inputs.csv', index=False)
    labels.to_csv(OUT/'labels.csv', index=False)
    rows=[]
    for seed in [20260904,20260905,20260906]:
        run = BASE/'runs'/f'bge_hard_seed_{seed}'
        manifest=json.loads((run/'manifest.json').read_text())
        assert manifest['status']=='complete' and manifest['input_hashes']==hashes
        th=pd.read_csv(run/'validation_thresholds.csv',float_precision='round_trip')
        picked=th[(th.model=='bge_v2_m3_hard_hard_refined') & (th.policy=='f1_opt')]
        assert len(picked)==1
        cp=run/'checkpoint_hard_refined'
        assert cp.is_dir()
        rows.append({'seed':seed,'checkpoint':str(cp),'threshold':float(picked.iloc[0].threshold),
                     'original_run':str(run),'checkpoint_files':{p.name:sha(p) for p in cp.iterdir() if p.is_file()},
                     'manifest_sha256':sha(run/'manifest.json'),
                     'threshold_file_sha256':sha(run/'validation_thresholds.csv')})
    manifest={'source':'live_server','data_dir':str(DATA),'input_hashes':hashes,
              'inputs_sha256':sha(OUT/'inputs.csv'),'labels_sha256':sha(OUT/'labels.csv'),
              'script_sha256':sha(__file__),'rows':len(frame),
              'split_rows':frame.evaluation_split.value_counts().to_dict(),
              'queries_per_split':frame.groupby('evaluation_split').query_id.nunique().to_dict(),
              'candidates_per_query':frame.groupby(['evaluation_split','query_id']).size().value_counts().to_dict(),
              'training_rows':len(train),'training_performed':False,'runs':rows,
              'python':platform.python_version(),'torch':torch.__version__,'transformers':transformers.__version__,
              'gpu':torch.cuda.get_device_name(0),'precision':'CUDA BF16 autocast',
              'max_length':256,'batch_size':64,
              'inference_input_contract':cols,'label_contract':['pair_id','final_label','final_relevance','difficulty']}
    (OUT/'source_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:manifest[k] for k in ['rows','split_rows','queries_per_split','candidates_per_query','gpu']}),flush=True)

if __name__=='__main__': main()
