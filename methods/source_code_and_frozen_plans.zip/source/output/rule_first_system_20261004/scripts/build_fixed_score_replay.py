#!/usr/bin/env python3
"""Replay frozen routing policies using each checkpoint's real all-BGE scores.

No neural inference, training, threshold selection, or timing is performed.
Gold labels are copied byte-for-byte for a separate evaluator, never read to
construct predictions. Replay outputs are counterfactual policy predictions,
not replacements for the separately executed GPU policies or their timings.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path

import numpy as np
import pandas as pd


POLICIES = ["rule_only", "all_bge", "exact_rescue", "stop_1", "stop_2", "stop_3"]
QUERY_KEY = ["evaluation_split", "query_id"]


def require(condition: bool, message: str) -> None:
    if not bool(condition):
        raise ValueError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def norm(value: object) -> str:
    return " ".join(str(value).strip().lower().split())


def canonical_description(value: object) -> str:
    # Identical to the runner's input-only canonical_description.
    return " ".join(re.sub(r"[^a-z0-9]+", " ", str(value or "").lower().replace("&", " and ")).split())


def exact_mask(frame: pd.DataFrame) -> np.ndarray:
    qd = frame.query_normalized_description.map(canonical_description).to_numpy()
    cd = frame.candidate_normalized_description.map(canonical_description).to_numpy()
    qu = frame.query_normalized_unit.map(norm).to_numpy()
    cu = frame.candidate_normalized_unit.map(norm).to_numpy()
    return (qd != "") & (qu != "") & (qd == cd) & (qu == cu)


def replay(frame: pd.DataFrame, reference_scores: np.ndarray, threshold: float,
           seed: int, policy: str) -> pd.DataFrame:
    exact = exact_mask(frame)
    accepted = exact.copy() if policy != "all_bge" else np.zeros(len(frame), dtype=bool)
    called = np.ones(len(frame), dtype=bool) if policy == "all_bge" else ~exact
    skipped = np.zeros(len(frame), dtype=bool)
    if policy == "rule_only":
        called[:] = False
    elif policy.startswith("stop_"):
        minimum = int(policy.rsplit("_", 1)[1])
        counts = pd.Series(exact, index=frame.index).groupby(
            [frame.evaluation_split, frame.query_id]).transform("sum").to_numpy()
        skipped = (counts >= minimum) & ~exact
        called &= ~skipped
    scores = np.where(called, reference_scores, np.nan)
    prediction = accepted.astype(np.int8)
    prediction[called] = (scores[called] >= threshold).astype(np.int8)
    prediction[skipped] = -1
    rank = np.zeros(len(frame), dtype=np.int8)
    for _, indices in frame.groupby(QUERY_KEY, sort=False).indices.items():
        rules = indices[accepted[indices]]
        rules = rules[np.argsort(frame.iloc[rules].candidate_id.to_numpy(str), kind="stable")]
        model = indices[called[indices] & (scores[indices] >= threshold)]
        if len(model):
            ordering = np.lexsort((frame.iloc[model].candidate_id.to_numpy(str), -scores[model]))
            model = model[ordering]
        returned = np.r_[rules, model][:3]
        rank[returned] = np.arange(1, len(returned) + 1)
    out = frame[["pair_id"]].copy()
    out["seed"] = seed
    out["policy"] = policy
    out["threshold"] = threshold
    out["exact_match"] = exact.astype(int)
    out["rule_accept"] = accepted.astype(int)
    # Counterfactual required calls, not fresh actual GPU execution.
    out["model_called"] = called.astype(int)
    out["score"] = scores
    out["prediction"] = prediction
    out["returned_rank"] = rank
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", required=True, type=Path,
                        help="original complete GPU results directory")
    parser.add_argument("--output-directory", type=Path,
                        help="default: --directory/fixed_score_replay")
    parser.add_argument("--expected-candidates", type=int, default=30)
    args = parser.parse_args()
    directory = args.directory.resolve()
    output = (args.output_directory or directory / "fixed_score_replay").resolve()
    require(output != directory, "Replay must not overwrite the original GPU results directory")
    require(not output.is_relative_to(directory / "query_mode"), "Replay must not overwrite query-mode results")
    source_manifest_path = directory / "source_manifest.json"
    source_manifest = json.loads(source_manifest_path.read_text())
    inputs_path = directory / "inputs.csv"
    labels_path = directory / "labels.csv"
    require(sha256(inputs_path) == source_manifest["inputs_sha256"], "source input hash mismatch")
    require(sha256(labels_path) == source_manifest["labels_sha256"], "source label file hash mismatch")
    frame = pd.read_csv(inputs_path, dtype=str, keep_default_na=False)
    needed = {"pair_id", *QUERY_KEY, "candidate_id", "query_normalized_description", "candidate_normalized_description",
              "query_normalized_unit", "candidate_normalized_unit"}
    require(needed.issubset(frame.columns), "incomplete inference input fields")
    require(not {"final_label", "final_relevance", "difficulty"}.intersection(frame.columns), "inference input contains annotations")
    require(not frame.pair_id.duplicated().any(), "duplicate input pair ID")
    require(not frame.duplicated([*QUERY_KEY, "candidate_id"]).any(), "duplicate candidate within query pool")
    require(frame.groupby(QUERY_KEY).size().eq(args.expected_candidates).all(), "unexpected query-pool size")
    execution_path = directory / "execution_manifest.json"
    require(execution_path.is_file(), "Original execution_manifest.json is required for GPU-score provenance")
    execution = json.loads(execution_path.read_text())
    require(execution.get("status") == "complete", "Original GPU execution is not complete")
    require(execution.get("input_sha256") == source_manifest["inputs_sha256"], "GPU execution input hash mismatch")
    executed_runs = {int(run["seed"]): run for run in execution.get("runs", [])}
    seeds = sorted(int(run["seed"]) for run in source_manifest["runs"])
    require(set(seeds) == set(executed_runs), "GPU execution checkpoints are incomplete")
    output.mkdir(parents=True, exist_ok=True)
    require(not (output / "query_mode").exists(), "Replay output has stale query_mode data; use a fresh output directory")
    manifest = {"status": "started", "source": "replay of real all_bge scores", "inference_performed": False,
                "training_performed": False, "threshold_selection_performed": False, "timing_performed": False,
                "gold_labels_used_for_predictions": False, "gold_label_file_copied_for_independent_evaluation": True,
                "script_sha256": sha256(Path(__file__)), "original_results_directory": str(directory),
                "original_execution_manifest_sha256": sha256(execution_path), "original_source_manifest_sha256": sha256(source_manifest_path),
                "policies": POLICIES, "seeds": seeds,
                "score_contract": "Each policy uses the same checkpoint's original all_bge scores on called candidates; uncalled scores remain missing.",
                "model_called_meaning": "Counterfactual scoring requirement under the fixed routing policy; no fresh model call was executed by replay.",
                "comparison_scope": "Isolates routing and merge effects from BF16 subset-batch/padding variation. Original actual predictions and timings remain authoritative for execution behavior.",
                "copied_source_files": {}, "runs": []}
    try:
        for filename in ["inputs.csv", "labels.csv", "source_manifest.json"]:
            shutil.copyfile(directory / filename, output / filename)
            manifest["copied_source_files"][filename] = sha256(output / filename)
        shutil.copyfile(execution_path, output / "original_execution_manifest.json")
        for run in sorted(source_manifest["runs"], key=lambda row: int(row["seed"])):
            seed, threshold = int(run["seed"]), float(run["threshold"])
            path = directory / f"predictions_seed_{seed}.csv"
            require(path.is_file(), f"Missing original GPU predictions for seed {seed}")
            source_hash = sha256(path)
            require(source_hash == executed_runs[seed]["prediction_sha256"], f"Original GPU prediction hash mismatch for seed {seed}")
            source = pd.read_csv(path, dtype={"pair_id": str, "policy": str}, float_precision="round_trip")
            reference = source[source.policy.eq("all_bge")].copy()
            require(reference.seed.eq(seed).all(), f"Source checkpoint mismatch for seed {seed}")
            require(not reference.pair_id.duplicated().any() and set(reference.pair_id) == set(frame.pair_id),
                    f"Incomplete or duplicate all_bge scores for seed {seed}")
            require(reference.threshold.eq(threshold).all() and np.isfinite(threshold), f"Source threshold mismatch for seed {seed}")
            require(pd.to_numeric(reference.model_called).eq(1).all(), f"Source all_bge did not score all pairs for seed {seed}")
            reference = reference.set_index("pair_id").reindex(frame.pair_id)
            scores = reference.score.to_numpy(float)
            require(np.isfinite(scores).all(), f"Nonfinite real all_bge scores for seed {seed}")
            require(np.array_equal(reference.prediction.to_numpy(int), (scores >= threshold).astype(int)),
                    f"Source threshold decisions inconsistent for seed {seed}")
            policies = {policy: replay(frame, scores, threshold, seed, policy) for policy in POLICIES}
            require(np.array_equal(policies["stop_3"].returned_rank, policies["exact_rescue"].returned_rank),
                    f"Fixed-score stop_3/rescue ranking invariance failed for seed {seed}")
            require(np.array_equal(policies["all_bge"].returned_rank, reference.returned_rank.to_numpy(int)),
                    f"Replay failed to reproduce original all_bge ordering for seed {seed}")
            path_out = output / f"predictions_seed_{seed}.csv"
            pd.concat(policies.values(), ignore_index=True).to_csv(path_out, index=False)
            manifest["runs"].append({"seed": seed, "threshold": threshold, "rows": len(frame) * len(POLICIES),
                                     "source_all_bge_pair_n": len(reference), "source_prediction_sha256": source_hash,
                                     "replay_prediction_sha256": sha256(path_out),
                                     "fixed_score_stop_3_equals_exact_rescue_returned_ranks": True,
                                     "original_all_bge_predictions_and_order_reproduced": True})
        manifest["status"] = "complete"
        note = ("Fixed-score counterfactual replay; no model inference or timing was performed.\n"
                "All six policies reuse each checkpoint's original all_bge scores.\n"
                "model_called denotes the policy's hypothetical scoring requirement.\n"
                "This directory separates routing/merge effects from BF16 subset-batch differences.\n"
                "It does not replace original GPU predictions, measured latencies, or measured computing work.\n"
                "Labels were copied without parsing, solely for independent quality evaluation.\n")
        (output / "REPLAY_README.txt").write_text(note)
        print(json.dumps({"status": "complete", "seeds": seeds, "inference_performed": False,
                          "output_directory": str(output)}, ensure_ascii=False))
    except Exception as error:
        manifest["status"] = "failed"
        manifest["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "replay_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
