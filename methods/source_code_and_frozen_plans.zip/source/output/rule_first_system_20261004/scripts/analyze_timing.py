#!/usr/bin/env python3
"""Validate actual model-call masks and summarize candidate-screening timings.

This analysis never opens gold labels. Timings exclude candidate retrieval and
model loading. Candidate-pair reductions are not API, monetary-cost, or latency
reductions. Query bootstrap conditions on the measured repeat medians and the
existing checkpoints, rather than accounting for training or measurement noise.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


POLICIES = ["rule_only", "all_bge", "exact_rescue", "stop_1", "stop_2", "stop_3"]
BASELINE = "all_bge"
COUNT_FIELDS = ["pairs", "model_pairs", "model_batches", "skipped_pairs"]
SCOPE = ("Candidate-pool screening with a resident model; rule routing, input "
         "serialization, tokenization, model inference, and result merging included. "
         "Candidate retrieval and model loading excluded. No monetary-cost estimate.")


def require(condition: bool, message: str) -> None:
    if not bool(condition):
        raise ValueError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_saving(value: float, baseline: float) -> float:
    return 100.0 * (1.0 - value / baseline) if baseline > 0 else np.nan


def sample_sd(values) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    return float(values.std(ddof=1)) if len(values) > 1 else np.nan


def boolean(series: pd.Series, name: str) -> pd.Series:
    values = series.astype(str).str.lower()
    require(values.isin(["0", "1", "true", "false"]).all(), f"{name}: invalid boolean")
    return values.map({"0": False, "1": True, "false": False, "true": True})


def groups_for(inputs: pd.DataFrame) -> dict[str, list[str]]:
    groups = {split: [split] for split in sorted(inputs.evaluation_split.unique())}
    internal = [split for split in ["locked", "no_reference", "no_reference_reclassified"] if split in groups]
    if len(internal) > 1:
        groups["internal_combined"] = internal
    if {"locked", "no_reference"}.issubset(groups):
        groups["internal_locked_plus_original_noref"] = ["locked", "no_reference"]
    return groups


def load_prediction_routes(directory: Path, inputs: pd.DataFrame, seeds: list[int],
                           hashes: dict[str, str], mode: str) -> pd.DataFrame:
    pieces = []
    for seed in seeds:
        path = directory / f"predictions_seed_{seed}.csv"
        require(path.is_file(), f"Incomplete {mode} predictions: {path}")
        prediction = pd.read_csv(path, dtype={"pair_id": str, "policy": str}, keep_default_na=False)
        needed = {"pair_id", "seed", "policy", "model_called", "prediction"}
        require(needed.issubset(prediction.columns), f"{path}: missing route columns")
        require(prediction.seed.eq(seed).all(), f"{path}: seed mismatch")
        require(set(prediction.policy) == set(POLICIES), f"{path}: incomplete policies")
        require(not prediction.duplicated(["policy", "pair_id"]).any(), f"{path}: duplicate routes")
        for policy, part in prediction.groupby("policy"):
            require(set(part.pair_id) == set(inputs.pair_id), f"{path}/{policy}: incomplete input pairs")
        prediction["model_called"] = boolean(prediction.model_called, f"{path}:model_called")
        prediction["prediction"] = pd.to_numeric(prediction.prediction, errors="raise").astype(int)
        require(prediction.prediction.isin([-1, 0, 1]).all(), f"{path}: invalid prediction marker")
        require(~(prediction.model_called & prediction.prediction.eq(-1)).any(),
                f"{path}: model-called pair cannot be marked unobserved")
        prediction["skipped"] = prediction.prediction.eq(-1)
        require(prediction.loc[prediction.policy.eq(BASELINE), "model_called"].all(),
                f"{path}: all_bge did not score every candidate")
        require(~prediction.loc[prediction.policy.eq("rule_only"), "model_called"].any(),
                f"{path}: rule_only made a model call")
        require(~prediction.loc[~prediction.policy.str.startswith("stop_"), "skipped"].any(),
                f"{path}: non-stop policy has unobserved pairs")
        prediction = prediction[["pair_id", "seed", "policy", "model_called", "skipped"]].merge(
            inputs, on="pair_id", how="left", validate="many_to_one")
        pieces.append(prediction)
        hashes[f"{mode}/{path.name}"] = sha256(path)
    return pd.concat(pieces, ignore_index=True)


def load_and_validate(directory: Path, qa: dict) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    input_path = directory / "inputs.csv"
    manifest = json.loads((directory / "source_manifest.json").read_text())
    seeds = sorted(int(run["seed"]) for run in manifest["runs"])
    require(len(seeds) == len(set(seeds)), "duplicate checkpoint seeds")
    inputs = pd.read_csv(input_path, dtype=str, keep_default_na=False,
                         usecols=["pair_id", "evaluation_split", "query_id"])
    require(not inputs.pair_id.duplicated().any(), "duplicate input pair IDs")
    require(inputs[["pair_id", "evaluation_split", "query_id"]].ne("").all().all(), "empty input IDs")
    require(sha256(input_path) == manifest["inputs_sha256"], "source input hash mismatch")
    hashes = {"inputs.csv": sha256(input_path), "source_manifest.json": sha256(directory / "source_manifest.json")}
    plan_path = directory / "execution_plan.json"
    plan = json.loads(plan_path.read_text()) if plan_path.exists() else {}
    expected_repeats = {"batch": int(plan.get("batch_repeats", 5)), "query": int(plan.get("query_repeats", 3))}
    require(all(count >= 1 for count in expected_repeats.values()), "invalid timing repeat count")
    if plan_path.exists():
        hashes[plan_path.name] = sha256(plan_path)

    routes = load_prediction_routes(directory, inputs, seeds, hashes, "batch")
    query_routes = load_prediction_routes(directory / "query_mode", inputs, seeds, hashes, "query")
    route_key = ["seed", "policy", "pair_id"]
    comparison = routes.set_index(route_key)[["model_called", "skipped"]].sort_index()
    qcomparison = query_routes.set_index(route_key)[["model_called", "skipped"]].reindex(comparison.index)
    require(comparison.equals(qcomparison), "batch/query prediction call masks differ")

    timing_frames = {}
    for mode in ["batch", "query"]:
        path = directory / f"timing_{mode}.csv"
        frame = pd.read_csv(path, dtype={"split": str, "policy": str, "query_id": str})
        needed = {"seed", "split", "policy", "repeat", "seconds", "gpu_forward_ms", *COUNT_FIELDS}
        needed.add("queries" if mode == "batch" else "query_id")
        require(needed.issubset(frame.columns), f"{path}: missing timing columns {needed - set(frame.columns)}")
        require(set(frame.seed) == set(seeds), f"{mode}: incomplete checkpoint seeds")
        require(set(frame.policy) == set(POLICIES), f"{mode}: incomplete policies")
        require(set(frame.split) == set(inputs.evaluation_split), f"{mode}: incomplete splits")
        for column in ["seed", "repeat", "seconds", "gpu_forward_ms", *COUNT_FIELDS,
                       *(["queries"] if mode == "batch" else [])]:
            frame[column] = pd.to_numeric(frame[column], errors="raise")
            require(np.isfinite(frame[column]).all(), f"{mode}: nonfinite {column}")
        require(frame.seconds.gt(0).all() and frame.gpu_forward_ms.ge(0).all(), f"{mode}: invalid measured times")
        require(frame[COUNT_FIELDS].ge(0).all().all(), f"{mode}: negative work counts")
        for column in ["seed", "repeat", *COUNT_FIELDS, *(["queries"] if mode == "batch" else [])]:
            require(frame[column].eq(np.floor(frame[column])).all(), f"{mode}: fractional {column}")
            frame[column] = frame[column].astype(int)
        require(frame.model_pairs.le(frame.pairs).all(), f"{mode}: more model pairs than candidates")
        require((frame.model_pairs + frame.skipped_pairs).le(frame.pairs).all(), f"{mode}: overlapping work masks")
        require(frame.model_batches.le(frame.model_pairs).all(), f"{mode}: invalid batch count")
        require(frame.loc[frame.model_pairs.eq(0), "model_batches"].eq(0).all(), f"{mode}: empty inference has batches")
        require(frame.loc[frame.model_pairs.eq(0), "gpu_forward_ms"].eq(0).all(),
                f"{mode}: empty inference has GPU forward time")
        key = ["seed", "split", "policy"] + (["query_id"] if mode == "query" else [])
        require(not frame.duplicated([*key, "repeat"]).any(), f"{mode}: duplicate repeat")
        for identity, group in frame.groupby(key, sort=False):
            require(sorted(group.repeat.tolist()) == list(range(expected_repeats[mode])),
                    f"{mode}/{identity}: incomplete timing repeats")
            require(group[COUNT_FIELDS].nunique().eq(1).all(), f"{mode}/{identity}: work counts vary across repeats")

        chosen_routes = routes if mode == "batch" else query_routes
        grouping = ["seed", "evaluation_split", "policy"] + (["query_id"] if mode == "query" else [])
        expected = chosen_routes.groupby(grouping).agg(
            expected_pairs=("pair_id", "size"), expected_model_pairs=("model_called", "sum"),
            expected_skipped_pairs=("skipped", "sum"), expected_queries=("query_id", "nunique")).reset_index()
        expected = expected.rename(columns={"evaluation_split": "split"})
        expected_keys = set(map(tuple, expected[key].to_numpy()))
        observed_keys = set(map(tuple, frame[key].drop_duplicates().to_numpy()))
        require(expected_keys == observed_keys, f"{mode}: missing or unexpected timing groups")
        check = frame.merge(expected, on=key, how="left", validate="many_to_one")
        for observed, expected_column in [("pairs", "expected_pairs"), ("model_pairs", "expected_model_pairs"),
                                          ("skipped_pairs", "expected_skipped_pairs")]:
            require(check[observed].eq(check[expected_column]).all(), f"{mode}: {observed} disagrees with prediction masks")
        if mode == "batch":
            require(check.queries.eq(check.expected_queries).all(), "batch: query counts disagree with inputs")
        batch_size = int(plan.get("batch_size", 64))
        require(frame.model_batches.eq(np.ceil(frame.model_pairs / batch_size).astype(int)).all(),
                f"{mode}: batch count is not ceil(model_pairs/{batch_size})")
        timing_frames[mode] = frame
        hashes[path.name] = sha256(path)
    qa["integrity"] = {"status": "passed", "prediction_mask_checks": True, "labels_read": False,
                       "seeds": seeds, "policies": POLICIES, "expected_repeats": expected_repeats,
                       "batch_timing_rows": len(timing_frames["batch"]), "query_timing_rows": len(timing_frames["query"])}
    qa["source_hashes"] = hashes
    return timing_frames["batch"], timing_frames["query"], inputs, groups_for(inputs)


def batch_per_seed(batch: pd.DataFrame, groups: dict) -> pd.DataFrame:
    rows = []
    for name, splits in groups.items():
        selection = batch[batch.split.isin(splits)]
        # For combined groups these are sums of separately executed split jobs,
        # not an additional combined GPU execution.
        jobs = selection.groupby(["seed", "policy", "repeat"]).agg(
            seconds=("seconds", "sum"), gpu_forward_ms=("gpu_forward_ms", "sum"),
            pairs=("pairs", "sum"), queries=("queries", "sum"),
            model_pairs=("model_pairs", "sum"), model_batches=("model_batches", "sum"),
            skipped_pairs=("skipped_pairs", "sum")).reset_index()
        for (seed, policy), job in jobs.groupby(["seed", "policy"]):
            baseline = jobs[(jobs.seed == seed) & jobs.policy.eq(BASELINE)]
            require(len(baseline) == len(job), f"{name}/{seed}: unmatched baseline repeats")
            wall = job.seconds.to_numpy(float)
            gpu = job.gpu_forward_ms.to_numpy(float)
            base_wall = float(baseline.seconds.median())
            base_gpu = float(baseline.gpu_forward_ms.median())
            pairs, queries = int(job.pairs.iloc[0]), int(job.queries.iloc[0])
            modeled, batches, skipped = (int(job[column].iloc[0]) for column in ["model_pairs", "model_batches", "skipped_pairs"])
            baseline_modeled, baseline_batches = (int(baseline[column].iloc[0]) for column in ["model_pairs", "model_batches"])
            row = {"evaluation_group": name, "seed": int(seed), "policy": policy, "repeat_n": len(job),
                   "sum_of_separately_executed_splits": len(splits) > 1, "pairs": pairs, "queries": queries,
                   "model_pairs": modeled, "model_batches": batches, "skipped_pairs": skipped,
                   "model_candidate_fraction_pct": 100 * modeled / pairs,
                   "candidate_scoring_reduction_pct": safe_saving(modeled, baseline_modeled),
                   "model_batch_reduction_pct": safe_saving(batches, baseline_batches),
                   "wall_seconds_median": float(np.median(wall)), "wall_seconds_mean": float(np.mean(wall)),
                   "wall_seconds_repeat_sample_sd": sample_sd(wall),
                   "gpu_forward_ms_median": float(np.median(gpu)), "gpu_forward_ms_mean": float(np.mean(gpu)),
                   "gpu_forward_ms_repeat_sample_sd": sample_sd(gpu),
                   "wall_time_saving_pct": safe_saving(float(np.median(wall)), base_wall),
                   "gpu_forward_time_saving_pct": safe_saving(float(np.median(gpu)), base_gpu),
                   "wall_speedup_ratio": base_wall / float(np.median(wall)),
                   "candidate_pairs_per_second_median": float(np.median(pairs / wall)),
                   "queries_per_second_median": float(np.median(queries / wall))}
            rows.append(row)
    return pd.DataFrame(rows)


def query_per_query(query: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (seed, split, policy, query_id), part in query.groupby(["seed", "split", "policy", "query_id"]):
        row = {"seed": int(seed), "split": split, "policy": policy, "query_id": query_id, "repeat_n": len(part),
               "seconds_median": float(part.seconds.median()), "seconds_mean": float(part.seconds.mean()),
               "seconds_repeat_sample_sd": sample_sd(part.seconds),
               "gpu_forward_ms_median": float(part.gpu_forward_ms.median())}
        row.update({column: int(part[column].iloc[0]) for column in COUNT_FIELDS})
        row["zero_model_query"] = row["model_pairs"] == 0
        rows.append(row)
    return pd.DataFrame(rows)


def query_per_seed(per_query: pd.DataFrame, groups: dict) -> pd.DataFrame:
    rows = []
    for name, splits in groups.items():
        selected = per_query[per_query.split.isin(splits)]
        for (seed, policy), part in selected.groupby(["seed", "policy"]):
            baseline = selected[(selected.seed == seed) & selected.policy.eq(BASELINE)]
            latency = part.seconds_median.to_numpy(float) * 1000
            gpu = part.gpu_forward_ms_median.to_numpy(float)
            base_mean = float(baseline.seconds_median.mean()) * 1000
            base_gpu = float(baseline.gpu_forward_ms_median.mean())
            row = {"evaluation_group": name, "seed": int(seed), "policy": policy, "queries": len(part),
                   "wall_ms_p50": float(np.quantile(latency, .50)), "wall_ms_p95": float(np.quantile(latency, .95)),
                   "wall_ms_mean": float(np.mean(latency)), "wall_ms_query_sample_sd": sample_sd(latency),
                   "gpu_forward_ms_mean": float(np.mean(gpu)), "gpu_forward_ms_p50": float(np.quantile(gpu, .50)),
                   "gpu_forward_ms_p95": float(np.quantile(gpu, .95)),
                   "wall_mean_time_saving_pct": safe_saving(float(np.mean(latency)), base_mean),
                   "gpu_forward_mean_time_saving_pct": safe_saving(float(np.mean(gpu)), base_gpu),
                   "wall_mean_saved_ms": base_mean - float(np.mean(latency)),
                   "zero_model_query_n": int(part.zero_model_query.sum()),
                   "zero_model_query_pct": 100.0 * part.zero_model_query.mean(),
                   "mean_model_pairs_per_query": float(part.model_pairs.mean()),
                   "mean_model_batches_per_query": float(part.model_batches.mean()),
                   "model_candidate_fraction_pct": 100 * part.model_pairs.sum() / part.pairs.sum(),
                   "candidate_scoring_reduction_pct": safe_saving(float(part.model_pairs.sum()), float(baseline.model_pairs.sum())),
                   "model_batch_reduction_pct": safe_saving(float(part.model_batches.sum()), float(baseline.model_batches.sum()))}
            rows.append(row)
    return pd.DataFrame(rows)


def seed_summary(frame: pd.DataFrame) -> pd.DataFrame:
    metrics = [column for column in frame.select_dtypes(include="number").columns if column != "seed"]
    rows = []
    for (name, policy), part in frame.groupby(["evaluation_group", "policy"]):
        for metric in metrics:
            values = part[metric].dropna().to_numpy(float)
            rows.append({"evaluation_group": name, "policy": policy, "metric": metric, "seed_n": len(part),
                         "finite_seed_n": len(values), "mean": float(values.mean()) if len(values) else np.nan,
                         "sample_sd": sample_sd(values)})
    return pd.DataFrame(rows)


def paired_latency_bootstrap(per_query: pd.DataFrame, groups: dict, iterations: int, seed: int) -> pd.DataFrame:
    require(iterations >= 1, "bootstrap iterations must be positive")
    rng = np.random.default_rng(seed)
    seeds = sorted(per_query.seed.unique())
    rows = []
    for name, splits in groups.items():
        selected = per_query[per_query.split.isin(splits)]
        key_frame = selected[["split", "query_id"]].drop_duplicates().sort_values(["split", "query_id"])
        keys = pd.MultiIndex.from_frame(key_frame)
        draws = rng.integers(0, len(keys), size=(iterations, len(keys)))
        stats = {}
        points = {}
        for run_seed in seeds:
            baseline = selected[(selected.seed == run_seed) & selected.policy.eq(BASELINE)].set_index(["split", "query_id"]).reindex(keys)
            require(baseline.seconds_median.notna().all(), f"{name}/{run_seed}: missing baseline query")
            baseline_values = baseline.seconds_median.to_numpy(float)
            baseline_draw = baseline_values[draws].mean(axis=1)
            for policy in POLICIES:
                part = selected[(selected.seed == run_seed) & selected.policy.eq(policy)].set_index(["split", "query_id"]).reindex(keys)
                require(part.seconds_median.notna().all(), f"{name}/{run_seed}/{policy}: unmatched query")
                values = part.seconds_median.to_numpy(float)
                sampled_mean = values[draws].mean(axis=1)
                stats[(run_seed, policy)] = {"mean_latency_saving_pct": 100 * (1 - sampled_mean / baseline_draw),
                                             "mean_latency_saved_ms": 1000 * (baseline_draw - sampled_mean)}
                points[(run_seed, policy)] = {"mean_latency_saving_pct": safe_saving(float(values.mean()), float(baseline_values.mean())),
                                              "mean_latency_saved_ms": 1000 * float(baseline_values.mean() - values.mean())}
        for policy in POLICIES:
            for run_seed in [*seeds, "mean_seed"]:
                for metric in ["mean_latency_saving_pct", "mean_latency_saved_ms"]:
                    if run_seed == "mean_seed":
                        distribution = np.mean([stats[(s, policy)][metric] for s in seeds], axis=0)
                        point = float(np.mean([points[(s, policy)][metric] for s in seeds]))
                    else:
                        distribution = stats[(run_seed, policy)][metric]
                        point = points[(run_seed, policy)][metric]
                    low, high = np.quantile(distribution, [.025, .975])
                    rows.append({"evaluation_group": name, "seed": run_seed, "policy": policy, "baseline": BASELINE,
                                 "metric": metric, "estimate": point, "ci95_low": float(low), "ci95_high": float(high),
                                 "bootstrap_n": iterations, "query_n": len(keys), "paired_unit": "query_pool",
                                 "resampling": "same query draws across policies and existing seeds; repeat-median latency fixed"})
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", required=True, type=Path)
    parser.add_argument("--output-directory", type=Path)
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--bootstrap-seed", type=int, default=20261004)
    args = parser.parse_args()
    directory = args.directory.resolve()
    output = (args.output_directory or directory).resolve()
    output.mkdir(parents=True, exist_ok=True)
    qa = {"status": "started", "scope": SCOPE, "script_sha256": sha256(Path(__file__)),
          "definitions": {"saving_pct": "100*(1-policy_time/baseline_time); negative means slower.",
                          "batch_time": "Median, mean and sample SD of repeated split-job times; savings use medians.",
                          "combined_batch": "Sum matching repeat indices of independently executed split jobs; not a combined rerun.",
                          "query_time": "Take each query's repeated wall-time median, then summarize across queries.",
                          "seed_sample_sd": "Sample SD across existing checkpoints; includes measured execution variability.",
                          "bootstrap": "Paired query-pool percentile CI, conditional on repeat medians and existing checkpoints. Does not cover measurement, training, or label uncertainty.",
                          "zero_model_query": "Actual model_called count is zero; includes rule-only and empty-residual policies.",
                          "gpu_time": "CUDA forward-event time; wall time additionally includes routing/tokenization/transfers/merging."}}
    try:
        batch, query, inputs, groups = load_and_validate(directory, qa)
        per_batch = batch_per_seed(batch, groups)
        per_query = query_per_query(query)
        per_query_seed = query_per_seed(per_query, groups)
        outputs = {"timing_batch_per_seed.csv": per_batch,
                   "timing_batch_seed_summary.csv": seed_summary(per_batch),
                   "timing_query_per_query.csv": per_query,
                   "timing_query_per_seed.csv": per_query_seed,
                   "timing_query_seed_summary.csv": seed_summary(per_query_seed),
                   "timing_query_paired_bootstrap.csv": paired_latency_bootstrap(per_query, groups, args.bootstrap, args.bootstrap_seed)}
        for name, frame in outputs.items():
            frame.to_csv(output / name, index=False)
        qa["output_files"] = {name: {"rows": len(frame), "sha256": sha256(output / name)} for name, frame in outputs.items()}
        qa["evaluation_groups"] = groups
        qa["bootstrap"] = {"iterations": args.bootstrap, "random_seed": args.bootstrap_seed}
        qa["status"] = "passed"
        print(json.dumps({"status": "passed", "seeds": sorted(map(int, per_query.seed.unique())),
                          "query_pools": int(inputs.groupby(["evaluation_split", "query_id"]).ngroups),
                          "output_directory": str(output), "scope": SCOPE}, ensure_ascii=False))
    except Exception as error:
        qa["status"] = "failed"
        qa["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "timing_qa.json").write_text(json.dumps(qa, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
