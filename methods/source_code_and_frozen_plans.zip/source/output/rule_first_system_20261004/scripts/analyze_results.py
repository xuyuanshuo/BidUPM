#!/usr/bin/env python3
"""Independently validate and summarize the frozen rule-first routing experiment.

Only this evaluator joins gold labels to predictions. All rates are percentages.
Early-stopped pairs are unobserved (-1), never negative predictions. Query-level
evaluation uses the actual returned list, including empty lists. Confidence
intervals use paired query resampling, with the same draw across policies/seeds.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd


POLICIES = ["rule_only", "all_bge", "exact_rescue", "stop_1", "stop_2", "stop_3"]
FULL_POLICIES = {"rule_only", "all_bge", "exact_rescue"}
QUERY_KEY = ["evaluation_split", "query_id"]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not bool(condition):
        raise ValueError(message)


def require_columns(frame: pd.DataFrame, columns: list[str], name: str) -> None:
    missing = sorted(set(columns) - set(frame.columns))
    require(not missing, f"{name}: missing columns {missing}")


def percentage(numerator: float, denominator: float) -> float:
    return 100.0 * numerator / denominator if denominator else np.nan


def bool_column(series: pd.Series, name: str) -> pd.Series:
    if series.dtype == bool:
        return series
    strings = series.astype(str).str.lower()
    require(strings.isin(["0", "1", "true", "false"]).all(),
            f"{name}: expected 0/1 or true/false")
    return strings.map({"0": False, "1": True, "false": False, "true": True})


def exact_rule(frame: pd.DataFrame) -> pd.Series:
    def canonical_description(value: str) -> str:
        text = str(value or "").lower().replace("&", " and ")
        return " ".join(re.sub(r"[^a-z0-9]+", " ", text).split())

    def canonical_unit(value: str) -> str:
        return " ".join(str(value or "").lower().split())

    description_q = frame["query_normalized_description"].fillna("").map(canonical_description)
    description_c = frame["candidate_normalized_description"].fillna("").map(canonical_description)
    unit_q = frame["query_normalized_unit"].fillna("").map(canonical_unit)
    unit_c = frame["candidate_normalized_unit"].fillna("").map(canonical_unit)
    return ((description_q != "") & (unit_q != "") &
            (description_q == description_c) & (unit_q == unit_c))


def load_inputs(directory: Path, qa: dict, expected_candidates: int) -> pd.DataFrame:
    inputs_path, labels_path = directory / "inputs.csv", directory / "labels.csv"
    inputs = pd.read_csv(inputs_path, keep_default_na=False, float_precision="round_trip")
    labels = pd.read_csv(labels_path, keep_default_na=False, float_precision="round_trip")
    require_columns(inputs, ["pair_id", *QUERY_KEY, "candidate_id", "initial_rank",
                             "query_normalized_description", "candidate_normalized_description",
                             "query_normalized_unit", "candidate_normalized_unit"], "inputs")
    require_columns(labels, ["pair_id", "final_label", "final_relevance", "difficulty"], "labels")
    require(not {"final_label", "final_relevance", "difficulty"}.intersection(inputs.columns),
            "inputs contains gold-label or difficulty fields")
    for name, frame in [("inputs", inputs), ("labels", labels)]:
        require(frame.pair_id.ne("").all(), f"{name}: empty pair_id")
        require(not frame.pair_id.duplicated().any(), f"{name}: duplicated pair_id")
    require(set(inputs.pair_id) == set(labels.pair_id), "inputs/labels pair IDs differ")
    require(labels.final_label.isin([0, 1]).all(), "gold final_label is not binary")
    require(labels.final_relevance.isin(["exact", "acceptable", "related", "wrong"]).all(),
            "unknown final_relevance")
    require(labels.difficulty.isin(["easy", "hard"]).all(), "unknown difficulty")
    expected_label = labels.final_relevance.isin(["exact", "acceptable"]).astype(int)
    require((labels.final_label == expected_label).all(), "binary/graded gold labels disagree")
    data = inputs.merge(labels, on="pair_id", how="left", validate="one_to_one")
    require(data.query_id.ne("").all() and data.candidate_id.ne("").all(),
            "empty query or candidate ID")
    require(not data.duplicated([*QUERY_KEY, "candidate_id"]).any(),
            "duplicate candidate within a query pool")
    sizes = data.groupby(QUERY_KEY).size()
    require((sizes == expected_candidates).all(),
            f"candidate pool sizes are not uniformly {expected_candidates}: {sizes.value_counts().to_dict()}")
    for key, group in data.groupby(QUERY_KEY):
        require(sorted(group.initial_rank.astype(int)) == list(range(1, expected_candidates + 1)),
                f"{key}: initial_rank is not 1..{expected_candidates}")
    data["rule_accept_expected"] = exact_rule(data)
    data["nonexact"] = ~data.rule_accept_expected
    qa["source_integrity"] = {"inputs_sha256": sha256(inputs_path),
                              "labels_sha256": sha256(labels_path)}
    manifest_path = directory / "source_manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        for field in ["inputs_sha256", "labels_sha256"]:
            require(manifest.get(field) == qa["source_integrity"][field],
                    f"source_manifest {field} mismatch")
        qa["source_integrity"]["manifest_sha256"] = sha256(manifest_path)
    qa["inputs"] = {"pairs": len(data), "queries": len(sizes),
                    "split_pairs": data.evaluation_split.value_counts().to_dict(),
                    "split_queries": data.groupby("evaluation_split").query_id.nunique().to_dict(),
                    "candidates_per_query": expected_candidates,
                    "gold_positives": int(data.final_label.sum()),
                    "exact_rule_accepts": int(data.rule_accept_expected.sum()),
                    "difficulty_counts": data.difficulty.value_counts().to_dict()}
    return data


def expected_ranks(group: pd.DataFrame, policy: str) -> pd.Series:
    accepted = group[group.prediction == 1]
    if policy == "all_bge":
        ordered = accepted.sort_values(["score", "candidate_id"], ascending=[False, True])
    elif policy == "rule_only":
        ordered = accepted.sort_values("candidate_id")
    else:
        rules = accepted[accepted.rule_accept].sort_values("candidate_id")
        modeled = accepted[~accepted.rule_accept].sort_values(
            ["score", "candidate_id"], ascending=[False, True])
        ordered = pd.concat([rules, modeled])
    ranks = pd.Series(0, index=group.index, dtype=int)
    for rank, index in enumerate(ordered.head(3).index, 1):
        ranks.loc[index] = rank
    return ranks


def load_predictions(directory: Path, data: pd.DataFrame, qa: dict) -> pd.DataFrame:
    files = sorted(directory.glob("predictions_seed_*.csv"))
    require(bool(files), "no predictions_seed_*.csv files")
    manifest_path = directory / "source_manifest.json"
    thresholds = {}
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        thresholds = {int(row["seed"]): float(row["threshold"]) for row in manifest.get("runs", [])}
    frames = []
    records = []
    for path in files:
        match = re.fullmatch(r"predictions_seed_(\d+)\.csv", path.name)
        require(match is not None, f"unexpected prediction filename: {path.name}")
        seed = int(match.group(1))
        pred = pd.read_csv(path, float_precision="round_trip")
        require_columns(pred, ["pair_id", "seed", "policy", "threshold", "exact_match", "rule_accept",
                               "model_called", "score", "prediction", "returned_rank"], path.name)
        require((pred.seed == seed).all(), f"{path.name}: filename/seed mismatch")
        require(set(pred.policy) == set(POLICIES), f"{path.name}: missing/unexpected policies")
        require(not pred.duplicated(["policy", "pair_id"]).any(), f"{path.name}: duplicate policy/pair")
        require(len(pred) == len(data) * len(POLICIES), f"{path.name}: unexpected row count")
        for policy, group in pred.groupby("policy"):
            require(set(group.pair_id) == set(data.pair_id), f"{path.name}/{policy}: pair IDs differ")
        pred["rule_accept"] = bool_column(pred.rule_accept, f"{path.name}/rule_accept")
        pred["exact_match"] = bool_column(pred.exact_match, f"{path.name}/exact_match")
        pred["model_called"] = bool_column(pred.model_called, f"{path.name}/model_called")
        require(pred.prediction.isin([-1, 0, 1]).all(), f"{path.name}: invalid prediction")
        require(pred.returned_rank.isin([0, 1, 2, 3]).all(), f"{path.name}: invalid returned_rank")
        require(np.isfinite(pred.threshold).all() and pred.threshold.nunique() == 1,
                f"{path.name}: threshold must be finite and fixed across policies/pairs")
        threshold = float(pred.threshold.iloc[0])
        if seed in thresholds:
            require(threshold == thresholds[seed], f"{path.name}: frozen validation threshold mismatch")
        joined = pred.merge(data, on="pair_id", how="left", validate="many_to_one",
                            suffixes=("_prediction_input", ""))
        require((joined.exact_match == joined.rule_accept_expected).all(),
                f"{path.name}: exact_match does not match independently recomputed input-only feature")
        expected_rule_accept = joined.rule_accept_expected & joined.policy.ne("all_bge")
        require((joined.rule_accept == expected_rule_accept).all(),
                f"{path.name}: rule_accept does not match policy-specific direct rule acceptance")
        require(joined.loc[~joined.model_called, "score"].isna().all(),
                f"{path.name}: uncalled model has a recorded score")
        require(np.isfinite(joined.loc[joined.model_called, "score"]).all(),
                f"{path.name}: called model score is missing/nonfinite")
        for policy, policy_group in joined.groupby("policy"):
            for key, group in policy_group.groupby(QUERY_KEY):
                if policy == "all_bge":
                    expected_called = pd.Series(True, index=group.index)
                    expected_prediction = (group.score >= threshold).astype(int)
                elif policy == "rule_only":
                    expected_called = pd.Series(False, index=group.index)
                    expected_prediction = group.rule_accept.astype(int)
                else:
                    stop = policy.startswith("stop_") and int(group.rule_accept.sum()) >= int(policy[-1])
                    expected_called = ~group.rule_accept if not stop else pd.Series(False, index=group.index)
                    expected_prediction = group.rule_accept.astype(int)
                    if stop:
                        expected_prediction.loc[~group.rule_accept] = -1
                    else:
                        modeled = ~group.rule_accept
                        expected_prediction.loc[modeled] = (group.loc[modeled, "score"] >= threshold).astype(int)
                require((group.model_called == expected_called).all(),
                        f"{path.name}/{policy}/{key}: model_called violates routing policy")
                require((group.prediction == expected_prediction).all(),
                        f"{path.name}/{policy}/{key}: predictions violate frozen threshold/routing policy")
                ranks = expected_ranks(group, policy)
                require((group.returned_rank == ranks).all(),
                        f"{path.name}/{policy}/{key}: returned list violates documented ranking policy")
                positive_ranks = sorted(group.loc[group.returned_rank > 0, "returned_rank"])
                require(positive_ranks == list(range(1, len(positive_ranks) + 1)),
                        f"{path.name}/{policy}/{key}: ranks are not consecutive 1..K")
                require(len(positive_ranks) <= 3, f"{path.name}/{policy}/{key}: more than 3 returned")
                require(group.loc[group.returned_rank > 0, "prediction"].eq(1).all(),
                        f"{path.name}/{policy}/{key}: returned unaccepted/unscored pair")
        frames.append(joined)
        records.append({"file": path.name, "sha256": sha256(path), "seed": seed,
                        "rows": len(pred), "frozen_threshold": threshold})
        reference = joined[joined.policy == "all_bge"].set_index("pair_id")
        for policy in POLICIES:
            modeled = joined[(joined.policy == policy) & joined.model_called].set_index("pair_id")
            delta = modeled.score - reference.score.reindex(modeled.index)
            qa.setdefault("cross_policy_batch_score_differences", []).append({
                "seed": seed, "policy": policy, "model_called_n": len(modeled),
                "score_max_abs_difference": float(delta.abs().max()) if len(delta) else None,
                "score_mean_abs_difference": float(delta.abs().mean()) if len(delta) else None,
                "threshold_decision_difference_n": int((modeled.prediction !=
                    reference.prediction.reindex(modeled.index)).sum()),
                "note": "Separate BF16 policy batches may have small score differences; each policy is checked against its own score."})
    qa["prediction_files"] = records
    qa["invariants_passed"] = ["input/label IDs and source hashes", "30-candidate pool integrity",
                               "input-only exact rule independently recomputed",
                               "frozen thresholds and each policy's own model scores",
                               "model-call masks and missing uncalled scores",
                               "threshold decisions and early-stop unobserved states",
                               "policy-specific actual top-three ordering"]
    return pd.concat(frames, ignore_index=True)


def split_groups(data: pd.DataFrame) -> dict[str, list[str]]:
    groups = {name: [name] for name in sorted(data.evaluation_split.unique())}
    internal = [name for name in ["locked", "no_reference", "no_reference_reclassified"]
                if name in groups]
    if len(internal) > 1:
        groups["internal_combined"] = internal
    if {"locked", "no_reference"}.issubset(groups):
        groups["internal_locked_plus_original_noref"] = ["locked", "no_reference"]
    return groups


def pair_metrics(group: pd.DataFrame, prefix: str = "") -> dict:
    if len(group) == 0:
        return {prefix + name: np.nan for name in
                ["pair_n", "pair_gold_positive_n", "tp", "fp", "fn", "tn",
                 "precision_pct", "recall_pct", "f1_pct"]}
    truth, prediction = group.final_label.to_numpy(), group.prediction.to_numpy()
    require(np.isin(prediction, [0, 1]).all(), "unscored early-stop pairs cannot enter pair metrics")
    tp = int(((truth == 1) & (prediction == 1)).sum())
    fp = int(((truth == 0) & (prediction == 1)).sum())
    fn = int(((truth == 1) & (prediction == 0)).sum())
    tn = int(((truth == 0) & (prediction == 0)).sum())
    return {prefix + "pair_n": len(group), prefix + "pair_gold_positive_n": int(truth.sum()),
            prefix + "tp": tp, prefix + "fp": fp, prefix + "fn": fn, prefix + "tn": tn,
            prefix + "precision_pct": percentage(tp, tp + fp),
            prefix + "recall_pct": percentage(tp, tp + fn),
            prefix + "f1_pct": percentage(2 * tp, 2 * tp + fp + fn)}


def build_per_query(predictions: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (seed, policy, split, query), group in predictions.groupby(["seed", "policy", *QUERY_KEY]):
        gold = group.final_label.eq(1)
        returned = group.returned_rank.gt(0)
        nonexact_positive = gold & group.nonexact
        rule_positive = gold & group.exact_match
        row = {"seed": seed, "policy": policy, "evaluation_split": split, "query_id": query,
               "candidate_n": len(group), "positive_n": int(gold.sum()),
               "nonexact_positive_n": int(nonexact_positive.sum()),
               "acceptable_positive_n": int((gold & group.final_relevance.eq("acceptable")).sum()),
               "exact_match_n": int(group.exact_match.sum()),
               "rule_accept_n": int(group.rule_accept.sum()), "rule_positive_n": int(rule_positive.sum()),
               "returned_n": int(returned.sum()), "returned_tp": int((returned & gold).sum()),
               "returned_fp": int((returned & ~gold).sum()),
               "returned_nonexact_tp": int((returned & nonexact_positive).sum()),
               "returned_acceptable_tp": int((returned & gold & group.final_relevance.eq("acceptable")).sum()),
               "model_called_n": int(group.model_called.sum()),
               "unscored_n": int(group.prediction.eq(-1).sum()),
               "early_stopped": bool(policy.startswith("stop_") and
                                      int(group.rule_accept.sum()) >= int(policy[-1]))}
        row["has_positive"] = row["positive_n"] > 0
        row["has_nonexact_positive"] = row["nonexact_positive_n"] > 0
        row["no_exact_positive_query"] = row["has_positive"] and row["rule_positive_n"] == 0
        row["hit"] = row["returned_tp"] > 0
        row["any_wrong"] = row["returned_fp"] > 0
        row["pool_rejected"] = row["returned_n"] == 0
        row["recall_at3"] = row["returned_tp"] / row["positive_n"] if row["positive_n"] else np.nan
        row["nonexact_recall_at3"] = (row["returned_nonexact_tp"] / row["nonexact_positive_n"]
                                     if row["nonexact_positive_n"] else np.nan)
        rows.append(row)
    return pd.DataFrame(rows)


def query_metrics(group: pd.DataFrame) -> dict:
    positive = group.has_positive
    nonexact = group.has_nonexact_positive
    no_exact = group.no_exact_positive_query
    no_reference = ~positive
    output = group.returned_n.gt(0)
    called = group.model_called_n
    return {"query_n": len(group), "positive_query_n": int(positive.sum()),
            "no_reference_query_n": int(no_reference.sum()),
            "nonexact_positive_query_n": int(nonexact.sum()),
            "no_exact_positive_query_n": int(no_exact.sum()),
            "hit_at3_pct": percentage(group.loc[positive, "hit"].sum(), positive.sum()),
            "returned_micro_precision_pct": percentage(group.returned_tp.sum(), group.returned_n.sum()),
            "macro_recall_at3_pct": 100 * group.loc[positive, "recall_at3"].mean(),
            "returned_micro_recall_at3_pct": percentage(group.returned_tp.sum(), group.positive_n.sum()),
            "wrong_reference_query_rate_pct": percentage(group.any_wrong.sum(), len(group)),
            "wrong_given_output_query_rate_pct": percentage(group.loc[output, "any_wrong"].sum(), output.sum()),
            "average_returned_n": group.returned_n.mean(),
            "returned_tp_n": int(group.returned_tp.sum()), "returned_fp_n": int(group.returned_fp.sum()),
            "no_reference_pool_rejection_pct": percentage(group.loc[no_reference, "pool_rejected"].sum(), no_reference.sum()),
            "nonexact_positive_returned_n": int(group.returned_nonexact_tp.sum()),
            "nonexact_positive_returned_recall_pct": percentage(group.returned_nonexact_tp.sum(), group.nonexact_positive_n.sum()),
            "nonexact_positive_query_coverage_pct": percentage(group.loc[nonexact, "returned_nonexact_tp"].gt(0).sum(), nonexact.sum()),
            "no_exact_positive_query_hit_pct": percentage(group.loc[no_exact, "hit"].sum(), no_exact.sum()),
            "acceptable_positive_returned_n": int(group.returned_acceptable_tp.sum()),
            "acceptable_positive_returned_recall_pct": percentage(group.returned_acceptable_tp.sum(), group.acceptable_positive_n.sum()),
            "model_called_n": int(called.sum()),
            "model_candidate_fraction_pct": percentage(called.sum(), group.candidate_n.sum()),
            "model_candidate_saving_pct": 100 - percentage(called.sum(), group.candidate_n.sum()),
            "model_queries_fraction_pct": percentage(called.gt(0).sum(), len(group)),
            "model_calls_per_query_mean": called.mean(),
            "model_calls_per_query_median": called.median(),
            "model_calls_per_query_p95": called.quantile(.95),
            "model_calls_per_query_min": called.min(), "model_calls_per_query_max": called.max(),
            "early_stopped_query_n": int(group.early_stopped.sum()),
            "unscored_candidate_n": int(group.unscored_n.sum())}


def summarize(predictions: pd.DataFrame, per_query: pd.DataFrame, groups: dict) -> pd.DataFrame:
    rows = []
    for name, splits in groups.items():
        selection = predictions[predictions.evaluation_split.isin(splits)]
        queries = per_query[per_query.evaluation_split.isin(splits)]
        for (seed, policy), group in selection.groupby(["seed", "policy"]):
            query_group = queries[(queries.seed == seed) & (queries.policy == policy)]
            row = {"evaluation_group": name, "seed": seed, "policy": policy,
                   "threshold": group.threshold.iloc[0], "candidate_n": len(group),
                   "pair_metrics_evaluated": policy in FULL_POLICIES}
            if policy in FULL_POLICIES:
                row.update(pair_metrics(group))
                row.update(pair_metrics(group[group.difficulty == "hard"], "hard_"))
                row.update(pair_metrics(group[group.nonexact], "nonexact_"))
                row.update(pair_metrics(group[group.difficulty == "easy"], "easy_"))
            row.update(query_metrics(query_group))
            rows.append(row)
    return pd.DataFrame(rows)


def aggregate(summary: pd.DataFrame) -> pd.DataFrame:
    identifiers = {"evaluation_group", "seed", "policy", "pair_metrics_evaluated"}
    metrics = [column for column in summary.columns
               if column not in identifiers and pd.api.types.is_numeric_dtype(summary[column])]
    rows = []
    for (name, policy), group in summary.groupby(["evaluation_group", "policy"]):
        for metric in metrics:
            values = group[metric].dropna()
            rows.append({"evaluation_group": name, "policy": policy, "metric": metric,
                         "seed_n": len(group), "finite_seed_n": len(values),
                         "mean": values.mean() if len(values) else np.nan,
                         "sample_sd": values.std(ddof=1) if len(values) > 1 else np.nan,
                         "min": values.min() if len(values) else np.nan,
                         "max": values.max() if len(values) else np.nan})
    return pd.DataFrame(rows)


def complementarity(predictions: pd.DataFrame, groups: dict) -> pd.DataFrame:
    rows = []
    for name, splits in groups.items():
        selection = predictions[predictions.evaluation_split.isin(splits)]
        for seed, seed_frame in selection.groupby("seed"):
            model = seed_frame[seed_frame.policy == "all_bge"].set_index("pair_id")
            rule = seed_frame[seed_frame.policy == "rule_only"].set_index("pair_id")
            rescue = seed_frame[seed_frame.policy == "exact_rescue"].set_index("pair_id")
            gold = model.final_label.eq(1)
            misses = gold & ~model.exact_match
            found = misses & model.prediction.eq(1)
            nonexact_fp = ~gold & ~model.exact_match & model.prediction.eq(1)
            rule_rank = rule.returned_rank.reindex(model.index)
            rescue_rank = rescue.returned_rank.reindex(model.index)
            model_rank = model.returned_rank
            extra = rescue_rank.gt(0) & rule_rank.eq(0)
            row = {"evaluation_group": name, "seed": seed,
                   "positive_n": int(gold.sum()), "rule_missed_positive_n": int(misses.sum()),
                   "model_recovered_rule_missed_positive_n": int(found.sum()),
                   "model_recovered_rule_missed_positive_pct": percentage(found.sum(), misses.sum()),
                   "model_added_nonexact_fp_n": int(nonexact_fp.sum()),
                   "model_nonexact_accept_precision_pct": percentage(found.sum(), found.sum() + nonexact_fp.sum()),
                   "rule_positive_rejected_by_all_bge_n": int((gold & model.exact_match & model.prediction.eq(0)).sum()),
                   "rule_fp_n": int((~gold & model.exact_match).sum()),
                   "exact_rescue_rule_missed_positive_accepted_n": int((misses & rescue.prediction.reindex(model.index).eq(1)).sum()),
                   "exact_rescue_nonexact_fp_accepted_n": int((~gold & ~model.exact_match & rescue.prediction.reindex(model.index).eq(1)).sum()),
                   "all_bge_recovered_nonexact_positive_returned_n": int((found & model_rank.gt(0)).sum()),
                   "exact_rescue_nonexact_positive_returned_n": int((misses & rescue_rank.gt(0)).sum()),
                   "exact_rescue_additional_returned_tp_vs_rule_n": int((extra & gold).sum()),
                   "exact_rescue_additional_returned_fp_vs_rule_n": int((extra & ~gold).sum()),
                   "exact_rescue_rule_returned_tp_lost_n": int((rule_rank.gt(0) & rescue_rank.eq(0) & gold).sum()),
                   "model_rescue_queries_n": model.loc[found, QUERY_KEY].drop_duplicates().shape[0],
                   "exact_rescue_additional_correct_reference_queries_n": model.loc[extra & gold, QUERY_KEY].drop_duplicates().shape[0],
                   "exact_rescue_additional_wrong_reference_queries_n": model.loc[extra & ~gold, QUERY_KEY].drop_duplicates().shape[0]}
            rows.append(row)
    return pd.DataFrame(rows)


def safe_ratio(numerator: np.ndarray, denominator: np.ndarray) -> np.ndarray:
    out = np.full(np.shape(numerator), np.nan, dtype=float)
    np.divide(100 * numerator, denominator, out=out, where=denominator != 0)
    return out


def bootstrap_metric_values(group: pd.DataFrame, draws: np.ndarray) -> dict[str, np.ndarray]:
    def sampled(column: str) -> np.ndarray:
        return group[column].to_numpy(dtype=float)[draws]

    positives = sampled("has_positive")
    nonexact_positives = sampled("has_nonexact_positive")
    no_reference = 1 - positives
    output = sampled("returned_n") > 0
    return {
        "returned_micro_precision_pct": safe_ratio(sampled("returned_tp").sum(axis=1), sampled("returned_n").sum(axis=1)),
        "macro_recall_at3_pct": safe_ratio(np.nan_to_num(sampled("recall_at3")).sum(axis=1), positives.sum(axis=1)),
        "hit_at3_pct": safe_ratio((sampled("hit") * positives).sum(axis=1), positives.sum(axis=1)),
        "wrong_reference_query_rate_pct": 100 * sampled("any_wrong").mean(axis=1),
        "wrong_given_output_query_rate_pct": safe_ratio((sampled("any_wrong") * output).sum(axis=1), output.sum(axis=1)),
        "returned_micro_recall_at3_pct": safe_ratio(sampled("returned_tp").sum(axis=1), sampled("positive_n").sum(axis=1)),
        "nonexact_positive_returned_recall_pct": safe_ratio(sampled("returned_nonexact_tp").sum(axis=1), sampled("nonexact_positive_n").sum(axis=1)),
        "nonexact_positive_query_coverage_pct": safe_ratio(((sampled("returned_nonexact_tp") > 0) * nonexact_positives).sum(axis=1), nonexact_positives.sum(axis=1)),
        "no_reference_pool_rejection_pct": safe_ratio((sampled("pool_rejected") * no_reference).sum(axis=1), no_reference.sum(axis=1)),
        "average_returned_n": sampled("returned_n").mean(axis=1),
        "model_candidate_fraction_pct": safe_ratio(sampled("model_called_n").sum(axis=1), sampled("candidate_n").sum(axis=1)),
    }


def paired_bootstrap(per_query: pd.DataFrame, groups: dict, iterations: int, random_seed: int) -> pd.DataFrame:
    require(iterations >= 1, "bootstrap iterations must be positive")
    rng = np.random.default_rng(random_seed)
    rows = []
    seeds = sorted(per_query.seed.unique())
    for name, splits in groups.items():
        selection = per_query[per_query.evaluation_split.isin(splits)]
        query_keys = selection[QUERY_KEY].drop_duplicates().sort_values(QUERY_KEY)
        keys = pd.MultiIndex.from_frame(query_keys)
        draws = rng.integers(0, len(keys), size=(iterations, len(keys)))
        values, observed = {}, {}
        for seed in seeds:
            for policy in POLICIES:
                group = selection[(selection.seed == seed) & (selection.policy == policy)]
                group = group.set_index(QUERY_KEY).reindex(keys).reset_index()
                require(not group.seed.isna().any(), f"bootstrap unmatched query: {name}/{seed}/{policy}")
                values[(seed, policy)] = bootstrap_metric_values(group, draws)
                observed[(seed, policy)] = query_metrics(group)
        for policy_a, policy_b in itertools.combinations(POLICIES, 2):
            metrics = values[(seeds[0], policy_a)].keys()
            for seed in [*seeds, "mean_seed"]:
                for metric in metrics:
                    if seed == "mean_seed":
                        a_observed = np.array([observed[(s, policy_a)][metric] for s in seeds])
                        b_observed = np.array([observed[(s, policy_b)][metric] for s in seeds])
                        # Require all seed estimates finite, rather than changing the
                        # set of seeds when a resample has an undefined denominator.
                        delta_draws = np.mean(np.stack([values[(s, policy_b)][metric] -
                                                       values[(s, policy_a)][metric] for s in seeds]), axis=0)
                        point = np.mean(b_observed - a_observed)
                    else:
                        a_observed = observed[(seed, policy_a)][metric]
                        b_observed = observed[(seed, policy_b)][metric]
                        delta_draws = values[(seed, policy_b)][metric] - values[(seed, policy_a)][metric]
                        point = b_observed - a_observed
                    finite = delta_draws[np.isfinite(delta_draws)]
                    low, high = np.quantile(finite, [.025, .975]) if len(finite) else (np.nan, np.nan)
                    rows.append({"evaluation_group": name, "seed": seed, "policy_a": policy_a,
                                 "policy_b": policy_b, "metric": metric, "delta_b_minus_a": point,
                                 "delta_unit": "percentage_points" if metric.endswith("_pct") else "references_per_query",
                                 "ci95_low": low, "ci95_high": high,
                                 "bootstrap_n": iterations, "finite_bootstrap_n": len(finite),
                                 "query_n": len(keys), "paired_unit": "query_pool",
                                 "bootstrap_fraction_delta_gt_zero": float((finite > 0).mean()) if len(finite) else np.nan,
                                 "bootstrap_fraction_delta_lt_zero": float((finite < 0).mean()) if len(finite) else np.nan})
    return pd.DataFrame(rows)


def batch_query_consistency(batch_predictions: pd.DataFrame, query_predictions: pd.DataFrame,
                            groups: dict) -> pd.DataFrame:
    """Expose numerical/decision drift from batch64 versus per-query BF16 mode."""
    require(set(batch_predictions.seed) == set(query_predictions.seed),
            "batch/query-mode seeds differ")
    rows = []
    for name, splits in groups.items():
        batch = batch_predictions[batch_predictions.evaluation_split.isin(splits)]
        query = query_predictions[query_predictions.evaluation_split.isin(splits)]
        for (seed, policy), batch_group in batch.groupby(["seed", "policy"]):
            mode_group = query[(query.seed == seed) & (query.policy == policy)].set_index("pair_id")
            batch_group = batch_group.set_index("pair_id")
            require(set(batch_group.index) == set(mode_group.index),
                    f"batch/query-mode pair IDs differ: {name}/{seed}/{policy}")
            mode_group = mode_group.reindex(batch_group.index)
            require((batch_group.model_called == mode_group.model_called).all(),
                    f"batch/query-mode model-call masks differ: {name}/{seed}/{policy}")
            require((batch_group.threshold == mode_group.threshold).all(),
                    f"batch/query-mode frozen thresholds differ: {name}/{seed}/{policy}")
            called = batch_group.model_called & mode_group.model_called
            delta = mode_group.loc[called, "score"] - batch_group.loc[called, "score"]
            predictions_differ = batch_group.prediction != mode_group.prediction
            returned_membership_differ = batch_group.returned_rank.gt(0) != mode_group.returned_rank.gt(0)
            rank_differ = batch_group.returned_rank != mode_group.returned_rank
            changed_queries = batch_group.loc[rank_differ, QUERY_KEY].drop_duplicates()
            gold = batch_group.final_label.eq(1)
            rows.append({"evaluation_group": name, "seed": seed, "policy": policy,
                         "pair_n": len(batch_group), "model_called_intersection_n": int(called.sum()),
                         "score_max_abs_difference": float(delta.abs().max()) if len(delta) else np.nan,
                         "score_mean_abs_difference": float(delta.abs().mean()) if len(delta) else np.nan,
                         "score_p95_abs_difference": float(delta.abs().quantile(.95)) if len(delta) else np.nan,
                         "threshold_decision_difference_n": int((predictions_differ & called).sum()),
                         "positive_threshold_decision_difference_n": int((predictions_differ & called & gold).sum()),
                         "negative_threshold_decision_difference_n": int((predictions_differ & called & ~gold).sum()),
                         "returned_membership_difference_n": int(returned_membership_differ.sum()),
                         "returned_rank_difference_n": int(rank_differ.sum()),
                         "query_n": batch_group[QUERY_KEY].drop_duplicates().shape[0],
                         "returned_list_changed_query_n": len(changed_queries),
                         "batch_returned_tp_n": int((batch_group.returned_rank.gt(0) & gold).sum()),
                         "query_mode_returned_tp_n": int((mode_group.returned_rank.gt(0) & gold).sum()),
                         "batch_returned_fp_n": int((batch_group.returned_rank.gt(0) & ~gold).sum()),
                         "query_mode_returned_fp_n": int((mode_group.returned_rank.gt(0) & ~gold).sum())})
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", required=True, type=Path, help="directory containing frozen CSV inputs and predictions")
    parser.add_argument("--output-directory", type=Path, help="default: same as --directory")
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--bootstrap-seed", type=int, default=20261004)
    parser.add_argument("--expected-candidates", type=int, default=30)
    args = parser.parse_args()
    directory = args.directory.resolve()
    output = (args.output_directory or directory).resolve()
    output.mkdir(parents=True, exist_ok=True)
    qa = {"status": "started", "script_sha256": sha256(Path(__file__)),
          "metric_definitions": {
              "rates": "All *_pct values are percentages; bootstrap deltas use percentage points.",
              "pair_precision": "TP/(TP+FP); undefined if no pair accepted.",
              "pair_f1": "2TP/(2TP+FP+FN); zero if positives exist but no accepted pair.",
              "early_stop_pair_metrics": "No full-candidate pair metrics for stop policies; -1 remains unobserved.",
              "nonexact": "Does not satisfy input-only nonempty canonical description AND normalized-unit equality. Canonical description: lower, & to and, non-[a-z0-9] to spaces, collapse whitespace; unit: lower and collapse whitespace.",
              "exact_match": "Input-only exact feature, independently recomputed for every policy.",
              "rule_accept": "Actual direct rule acceptance: always false for all_bge, otherwise equal to exact_match.",
              "hard": "Frozen difficulty == hard; never used to route inference.",
              "hit_at3": "Returned >=1 positive among query pools that contain >=1 positive.",
              "macro_recall_at3": "Mean returned positives / all pool positives over positive query pools.",
              "returned_micro_precision": "Total returned positives / total returned items.",
              "wrong_reference_query_rate": "Query pools with >=1 returned negative / all query pools.",
              "wrong_given_output_query_rate": "Query pools with >=1 returned negative / nonempty-output query pools.",
              "no_reference_pool_rejection": "Empty output among actually all-negative pools, regardless of split name.",
              "nonexact_positive_query_coverage": "Returned >=1 nonexact positive among pools containing >=1 nonexact positive.",
              "no_exact_positive_query_hit": "Returned >=1 positive among positive pools without any rule-accepted gold positive.",
              "model_call": "One candidate-pair model scoring, not an API request or GPU batch.",
              "internal_combined": "locked + no_reference + no_reference_reclassified; each raw split is also shown.",
              "bootstrap": "Paired percentile CI by query-pool resampling; same draw across seeds/policies. Mean-seed CI conditions on existing seeds, not training-seed or label uncertainty.",
              "bootstrap_fraction": "Descriptive bootstrap sign fraction, not a formal p-value; CIs are not multiplicity adjusted."}}
    try:
        data = load_inputs(directory, qa, args.expected_candidates)
        predictions = load_predictions(directory, data, qa)
        groups = split_groups(data)
        queries = build_per_query(predictions)
        summary = summarize(predictions, queries, groups)
        aggregate_summary = aggregate(summary)
        complementary = complementarity(predictions, groups)
        bootstrap = paired_bootstrap(queries, groups, args.bootstrap, args.bootstrap_seed)
        outputs = {"summary_per_seed.csv": summary, "summary_aggregate.csv": aggregate_summary,
                   "complementarity.csv": complementary, "per_query.csv": queries,
                   "paired_bootstrap.csv": bootstrap}
        if (directory / "query_mode").is_dir():
            query_mode_qa = {}
            query_mode_predictions = load_predictions(directory / "query_mode", data, query_mode_qa)
            outputs["batch_query_consistency.csv"] = batch_query_consistency(
                predictions, query_mode_predictions, groups)
            qa["query_mode_validation"] = query_mode_qa
        for name, frame in outputs.items():
            frame.to_csv(output / name, index=False)
        qa["evaluation_groups"] = groups
        qa["bootstrap"] = {"iterations": args.bootstrap, "random_seed": args.bootstrap_seed,
                           "comparison_rows": len(bootstrap)}
        qa["output_files"] = {name: {"rows": len(frame), "sha256": sha256(output / name)}
                              for name, frame in outputs.items()}
        qa["status"] = "passed"
        print(json.dumps({"status": "passed", "seeds": sorted(map(int, predictions.seed.unique())),
                          "pairs": len(data), "policies": POLICIES,
                          "output_directory": str(output)}, ensure_ascii=False))
    except Exception as error:
        qa["status"] = "failed"
        qa["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (output / "qa.json").write_text(json.dumps(qa, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
