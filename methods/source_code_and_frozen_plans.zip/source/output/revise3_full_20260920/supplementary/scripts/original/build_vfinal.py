#!/usr/bin/env python3
"""Rebuild BidUPM-vFinal from raw public bid-item records.

This pipeline replaces the previous pair table instead of relabeling it.  It
enforces strict temporal retrieval, source-held-out external evaluation,
semantic query separation, deterministic provisional labels, and an explicit
double-review handoff.  No provisional label is described as human gold.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path
from typing import Iterable

import pandas as pd

from bidupm_vfinal_common import (
    PairFeatures,
    TemporalRetriever,
    canonical_text,
    canonical_unit,
    item_code_key,
    pair_semantic_key,
    provisional_judgment,
    semantic_key,
    token_metrics,
    tokens,
)


TARGET_QUERIES = {
    "train_standard": 100,
    "train_hard": 50,
    "validation": 30,
    "locked": 100,
    "no_reference": 40,
    "external": 80,
}
TOP_K = 30
FULL_K = 100


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-csv", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--alberta-xlsx", type=Path)
    parser.add_argument("--legacy-human-seed", type=Path)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def prepare_items(path: Path) -> pd.DataFrame:
    items = pd.read_csv(path, dtype=str, keep_default_na=False)
    required = {
        "item_id",
        "agency",
        "source_group_id",
        "source_file",
        "source_url",
        "letting_date",
        "contract_id",
        "description",
        "unit",
        "normalized_description",
        "normalized_unit",
        "category",
        "spec_tokens",
        "item_code",
        "quantity",
    }
    missing = sorted(required - set(items.columns))
    if missing:
        raise ValueError(f"Raw file is missing required columns: {missing}")
    items["_date"] = pd.to_datetime(items["letting_date"], errors="raise")
    items["query_semantic_key"] = [
        semantic_key(d, u)
        for d, u in zip(items["normalized_description"], items["normalized_unit"])
    ]
    items["_unit_key"] = items["normalized_unit"].map(canonical_unit)
    items["_item_code_key"] = items["item_code"].map(item_code_key)
    if items["item_id"].duplicated().any():
        raise ValueError("Raw item_id values are not unique")
    return items


def add_prior_exact_flag(items: pd.DataFrame) -> pd.DataFrame:
    out = items.copy()
    flags = pd.Series(False, index=out.index)
    for agency, agency_rows in out.groupby("agency"):
        seen_semantics: set[str] = set()
        for date in sorted(agency_rows["_date"].unique()):
            idx = agency_rows.index[agency_rows["_date"].eq(date)]
            current = out.loc[idx]
            sem_hit = current["query_semantic_key"].isin(seen_semantics)
            flags.loc[idx] = sem_hit
            seen_semantics.update(current["query_semantic_key"])
    out["has_prior_exact"] = flags.astype(int)
    return out


def row_to_query(row: pd.Series) -> dict[str, object]:
    return {
        "query_id": row["item_id"],
        "agency": row["agency"],
        "source_group_id": row["source_group_id"],
        "source_file": row["source_file"],
        "source_url": row["source_url"],
        "contract_id": row["contract_id"],
        "letting_date": row["letting_date"],
        "project_title": row.get("project_title", ""),
        "item_no": row.get("item_no", ""),
        "item_code": row["item_code"],
        "description": row["description"],
        "unit": row["unit"],
        "quantity": row["quantity"],
        "normalized_description": row["normalized_description"],
        "normalized_unit": row["normalized_unit"],
        "category": row["category"],
        "spec_tokens": row["spec_tokens"],
        "query_semantic_key": row["query_semantic_key"],
        "has_prior_exact": int(row["has_prior_exact"]),
    }


def features_from_row(row: pd.Series) -> PairFeatures:
    fields = PairFeatures.__dataclass_fields__
    values = {}
    integer_fields = {
        "unit_match",
        "category_match",
        "item_code_match",
        "exact_description",
        "action_conflict",
        "material_conflict",
        "dimension_conflict",
        "class_conflict",
        "type_conflict",
        "spec_conflict",
    }
    for name in fields:
        value = row[name]
        if name in integer_fields:
            values[name] = int(value)
        elif name == "conflict_type":
            values[name] = str(value)
        else:
            values[name] = float(value)
    return PairFeatures(**values)


def candidate_pool_profile(query: dict[str, object], pool: pd.DataFrame) -> dict[str, object]:
    judgments = [provisional_judgment(features_from_row(row)) for _, row in pool.iterrows()]
    top30 = judgments[:TOP_K]
    positive_ranks = [i + 1 for i, result in enumerate(top30) if result["proposed_label"] == 1]
    hard_negatives = sum(
        result["proposed_label"] == 0 and result["difficulty"] == "hard" for result in top30
    )
    proposed_positive_full = sum(result["proposed_label"] == 1 for result in judgments)
    ambiguous_full = sum(result["proposal_confidence"] == "low" for result in judgments)
    return {
        **query,
        "top30_proposed_positive": len(positive_ranks),
        "best_proposed_positive_rank": min(positive_ranks) if positive_ranks else 999,
        "top30_hard_negative": int(hard_negatives),
        "top100_proposed_positive": int(proposed_positive_full),
        "top100_ambiguous": int(ambiguous_full),
        "top_retrieval_score": float(pool.iloc[0]["retrieval_score"]) if len(pool) else 0.0,
    }


def balanced_candidates(frame: pd.DataFrame, maximum: int) -> pd.DataFrame:
    frame = frame.sort_values(
        ["category", "source_group_id", "query_semantic_key", "item_id"], kind="stable"
    )
    groups = {
        key: group.to_dict("records")
        for key, group in frame.groupby(frame["category"].replace("", "uncategorized"), sort=True)
    }
    selected = []
    while groups and len(selected) < maximum:
        for key in list(groups):
            if not groups[key]:
                del groups[key]
                continue
            selected.append(groups[key].pop(0))
            if len(selected) >= maximum:
                break
    return pd.DataFrame.from_records(selected)


def scan_profiles(
    frame: pd.DataFrame,
    retriever: TemporalRetriever,
    cache: dict[str, pd.DataFrame],
    maximum: int,
    *,
    excluded_item_ids: set[str] | None = None,
    excluded_source_groups: set[str] | None = None,
) -> pd.DataFrame:
    frame = frame.drop_duplicates("query_semantic_key", keep="first")
    frame = balanced_candidates(frame, maximum)
    profiles = []
    for _, row in frame.iterrows():
        query = row_to_query(row)
        pool = retriever.retrieve(
            query,
            FULL_K,
            excluded_item_ids=excluded_item_ids,
            excluded_source_groups=excluded_source_groups,
        )
        if len(pool) < FULL_K:
            continue
        cache[str(query["query_id"])] = pool
        profiles.append(candidate_pool_profile(query, pool))
    return pd.DataFrame.from_records(profiles)


def stratified_take(
    profiles: pd.DataFrame,
    count: int,
    *,
    sort_columns: list[str],
    ascending: list[bool],
    excluded_source_groups: set[str] | None = None,
    max_per_source_group: int = 12,
) -> pd.DataFrame:
    excluded_source_groups = excluded_source_groups or set()
    candidates = profiles[~profiles["source_group_id"].isin(excluded_source_groups)].copy()
    candidates = candidates.sort_values(sort_columns + ["query_id"], ascending=ascending + [True])
    category_queues = {
        key: group.to_dict("records")
        for key, group in candidates.groupby(candidates["category"].replace("", "uncategorized"), sort=True)
    }
    selected = []
    source_counts: Counter[str] = Counter()
    while category_queues and len(selected) < count:
        progressed = False
        for category in list(category_queues):
            queue = category_queues[category]
            while queue:
                row = queue.pop(0)
                source_group = str(row["source_group_id"])
                if source_counts[source_group] >= max_per_source_group:
                    continue
                selected.append(row)
                source_counts[source_group] += 1
                progressed = True
                break
            if not queue:
                del category_queues[category]
            if len(selected) >= count:
                break
        if not progressed:
            break
    result = pd.DataFrame.from_records(selected)
    if len(result) != count:
        raise RuntimeError(f"Could select only {len(result)} of required {count} queries")
    return result


def make_pair_rows(
    split: str,
    selected_queries: pd.DataFrame,
    cache: dict[str, pd.DataFrame],
    external_positive_ids: set[str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    pairs = []
    retrieval_rows = []
    prefix = {
        "train_standard": "TRS",
        "train_hard": "TRH",
        "validation": "VAL",
        "locked": "LOC",
        "no_reference": "NOR",
        "external": "EXT",
    }[split]
    pair_counter = 0
    for _, query in selected_queries.sort_values("query_id").iterrows():
        query_id = str(query["query_id"])
        pool = cache[query_id].copy()
        for _, candidate in pool.iterrows():
            features = features_from_row(candidate)
            judgment = provisional_judgment(features)
            retrieval_rows.append(
                {
                    "split": split,
                    "query_id": query_id,
                    "query_agency": query["agency"],
                    "query_source_group_id": query["source_group_id"],
                    "query_contract_id": query["contract_id"],
                    "query_letting_date": query["letting_date"],
                    "query_source_file": query["source_file"],
                    "query_semantic_key": query["query_semantic_key"],
                    **candidate.to_dict(),
                    **judgment,
                }
            )
        for _, candidate in pool.head(TOP_K).iterrows():
            pair_counter += 1
            features = features_from_row(candidate)
            judgment = provisional_judgment(features)
            is_training = split.startswith("train_")
            external_subtype = ""
            if split == "external":
                external_subtype = (
                    "positive_containing"
                    if query_id in external_positive_ids
                    else "no_reference_candidate"
                )
            pair_key = pair_semantic_key(
                query["normalized_description"],
                query["normalized_unit"],
                candidate["candidate_normalized_description"],
                candidate["candidate_normalized_unit"],
            )
            pairs.append(
                {
                    "pair_id": f"{prefix}{pair_counter:06d}",
                    "split": split,
                    "external_subtype": external_subtype,
                    "query_id": query_id,
                    "query_agency": query["agency"],
                    "query_source_group_id": query["source_group_id"],
                    "query_source_file": query["source_file"],
                    "query_source_url": query["source_url"],
                    "query_contract_id": query["contract_id"],
                    "query_letting_date": query["letting_date"],
                    "query_project_title": query["project_title"],
                    "query_item_no": query["item_no"],
                    "query_item_code": query["item_code"],
                    "query_description": query["description"],
                    "query_unit": query["unit"],
                    "query_quantity": query["quantity"],
                    "query_normalized_description": query["normalized_description"],
                    "query_normalized_unit": query["normalized_unit"],
                    "query_category": query["category"],
                    "query_spec_tokens": query["spec_tokens"],
                    "query_semantic_key": query["query_semantic_key"],
                    "candidate_id": candidate["candidate_item_id"],
                    "candidate_agency": candidate["candidate_agency"],
                    "candidate_source_group_id": candidate["candidate_source_group_id"],
                    "candidate_source_file": candidate["candidate_source_file"],
                    "candidate_source_url": candidate["candidate_source_url"],
                    "candidate_contract_id": candidate["candidate_contract_id"],
                    "candidate_letting_date": candidate["candidate_letting_date"],
                    "candidate_item_code": candidate["candidate_item_code"],
                    "candidate_description": candidate["candidate_description"],
                    "candidate_unit": candidate["candidate_unit"],
                    "candidate_quantity": candidate["candidate_quantity"],
                    "candidate_normalized_description": candidate[
                        "candidate_normalized_description"
                    ],
                    "candidate_normalized_unit": candidate["candidate_normalized_unit"],
                    "candidate_category": candidate["candidate_category"],
                    "candidate_spec_tokens": candidate["candidate_spec_tokens"],
                    "candidate_semantic_key": candidate["candidate_semantic_key"],
                    "pair_semantic_key": pair_key,
                    "initial_rank": int(candidate["rank"]),
                    "retrieval_score": float(candidate["retrieval_score"]),
                    **asdict(features),
                    **judgment,
                    "annotation_status": (
                        "weak_deterministic_training" if is_training else "pending_double_review"
                    ),
                    "annotation_source": (
                        "deterministic_high_precision_rules"
                        if is_training
                        else "provisional_rules_for_human_review"
                    ),
                    "training_label": (
                        int(judgment["proposed_label"])
                        if is_training and judgment["train_use"] == 1
                        else ""
                    ),
                    "annotator_a_label": "",
                    "annotator_a_relevance": "",
                    "annotator_a_conflict_type": "",
                    "annotator_a_note": "",
                    "annotator_b_label": "",
                    "annotator_b_relevance": "",
                    "annotator_b_conflict_type": "",
                    "annotator_b_note": "",
                    "adjudicator_label": "",
                    "adjudicator_relevance": "",
                    "adjudicator_conflict_type": "",
                    "adjudicator_note": "",
                    "final_label": "",
                    "final_relevance": "",
                    "final_conflict_type": "",
                }
            )
    return pd.DataFrame.from_records(pairs), pd.DataFrame.from_records(retrieval_rows)


def build_review_units(all_pairs: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    review_pairs = all_pairs[~all_pairs["split"].str.startswith("train_")].copy()
    review_pairs["review_unit_key"] = (
        review_pairs["split"] + "@@" + review_pairs["pair_semantic_key"]
    )
    keys = sorted(review_pairs["review_unit_key"].unique())
    key_to_id = {key: f"RU{idx:06d}" for idx, key in enumerate(keys, start=1)}
    review_pairs["review_unit_id"] = review_pairs["review_unit_key"].map(key_to_id)
    units = []
    for review_unit_id, group in review_pairs.groupby("review_unit_id", sort=True):
        row = group.sort_values(["query_id", "initial_rank", "candidate_id"]).iloc[0]
        units.append(
            {
                "review_unit_id": review_unit_id,
                "split": row["split"],
                "external_subtype": row["external_subtype"],
                "query_description": row["query_description"],
                "query_unit": row["query_unit"],
                "query_category": row["query_category"],
                "query_spec_tokens": row["query_spec_tokens"],
                "candidate_description": row["candidate_description"],
                "candidate_unit": row["candidate_unit"],
                "candidate_category": row["candidate_category"],
                "candidate_spec_tokens": row["candidate_spec_tokens"],
                "member_rows": len(group),
                "best_rank": int(pd.to_numeric(group["initial_rank"]).min()),
                "proposed_label": row["proposed_label"],
                "proposed_relevance": row["proposed_relevance"],
                "proposal_confidence": row["proposal_confidence"],
                "difficulty": row["difficulty"],
                "conflict_type": row["conflict_type"],
                "proposal_reason": row["proposal_reason"],
                "annotator_a_label": "",
                "annotator_a_relevance": "",
                "annotator_a_conflict_type": "",
                "annotator_a_note": "",
                "annotator_b_label": "",
                "annotator_b_relevance": "",
                "annotator_b_conflict_type": "",
                "annotator_b_note": "",
                "adjudicator_label": "",
                "adjudicator_relevance": "",
                "adjudicator_conflict_type": "",
                "adjudicator_note": "",
                "final_label": "",
                "final_relevance": "",
                "final_conflict_type": "",
            }
        )
    members = review_pairs[["review_unit_id", "pair_id", "split", "query_id", "candidate_id"]]
    return pd.DataFrame.from_records(units), members


def build_alberta(xlsx_path: Path, output_dir: Path) -> dict[str, object]:
    years = list(range(2019, 2027))
    rows = []
    for year in years:
        sheet = f"{year} UPA" + (" " if year == 2026 else "")
        raw = pd.read_excel(xlsx_path, sheet_name=sheet, header=None)
        for _, row in raw.iloc[4:].iterrows():
            code = str(row.iloc[1] if len(row) > 1 else "").strip()
            description = str(row.iloc[2] if len(row) > 2 else "").strip()
            unit = str(row.iloc[3] if len(row) > 3 else "").strip()
            if not code or code.lower() == "nan" or not description or description.lower() == "nan":
                continue
            if not any(ch.isalpha() for ch in code):
                continue
            rows.append(
                {
                    "agency": "Alberta Transportation and Economic Corridors",
                    "year": year,
                    "item_code": code,
                    "description": description,
                    "unit": unit,
                    "contract_count": row.iloc[4] if len(row) > 4 else "",
                    "amount": row.iloc[5] if len(row) > 5 else "",
                    "quantity": row.iloc[6] if len(row) > 6 else "",
                    "weighted_average_three_low_bids": row.iloc[7] if len(row) > 7 else "",
                    "normalized_description": canonical_text(description),
                    "normalized_unit": canonical_unit(unit),
                    "source_url": "https://www.alberta.ca/unit-prices-and-cost-adjustments",
                }
            )
    items = pd.DataFrame.from_records(rows)
    items.to_csv(output_dir / "alberta_unit_price_items_2019_2026.csv", index=False)
    history = items[items["year"].lt(2026)].copy()
    queries = items[items["year"].eq(2026)].drop_duplicates("item_code").copy()
    historical_codes = set(zip(history["item_code"], history["normalized_unit"]))
    queries = queries[
        [
            (code, unit) in historical_codes
            for code, unit in zip(queries["item_code"], queries["normalized_unit"])
        ]
    ].sort_values("item_code")
    pair_rows = []
    for query_index, (_, query) in enumerate(queries.iterrows(), start=1):
        candidates = history.copy()
        candidates["_code_match"] = candidates["item_code"].eq(query["item_code"]).astype(int)
        candidates["_unit_match"] = candidates["normalized_unit"].eq(
            query["normalized_unit"]
        ).astype(int)
        similarities = []
        q_tokens = tokens(query["normalized_description"])
        for value in candidates["normalized_description"]:
            jaccard, containment = token_metrics(q_tokens, tokens(value))
            similarities.append(jaccard + containment)
        candidates["_similarity"] = similarities
        candidates["_score"] = (
            100 * candidates["_code_match"] * candidates["_unit_match"]
            + 5 * candidates["_unit_match"]
            + candidates["_similarity"]
        )
        candidates = candidates.sort_values(
            ["_score", "year", "item_code"], ascending=[False, False, True]
        ).drop_duplicates(["year", "item_code", "normalized_unit"])
        for rank, (_, candidate) in enumerate(candidates.head(20).iterrows(), start=1):
            label = int(
                candidate["item_code"] == query["item_code"]
                and candidate["normalized_unit"] == query["normalized_unit"]
            )
            pair_rows.append(
                {
                    "pair_id": f"AB{query_index:04d}_{rank:02d}",
                    "query_id": f"AB2026_{query['item_code']}",
                    "query_year": 2026,
                    "query_item_code": query["item_code"],
                    "query_description": query["description"],
                    "query_unit": query["unit"],
                    "candidate_year": candidate["year"],
                    "candidate_item_code": candidate["item_code"],
                    "candidate_description": candidate["description"],
                    "candidate_unit": candidate["unit"],
                    "candidate_weighted_price": candidate[
                        "weighted_average_three_low_bids"
                    ],
                    "rank": rank,
                    "label": label,
                    "label_source": "official_item_code_and_compatible_unit",
                    "source_url": "https://www.alberta.ca/unit-prices-and-cost-adjustments",
                }
            )
    pairs = pd.DataFrame.from_records(pair_rows)
    pairs.to_csv(output_dir / "alberta_code_anchored_external_pairs.csv", index=False)
    return {
        "source_file": xlsx_path.name,
        "source_sha256": sha256(xlsx_path),
        "years": years,
        "parsed_rows": len(items),
        "2026_queries_with_historical_code_match": queries["item_code"].nunique(),
        "pair_rows": len(pairs),
    }


def process_legacy_seed(
    seed_path: Path,
    eval_pair_keys: set[str],
    output_path: Path,
) -> dict[str, int]:
    seed = pd.read_csv(seed_path, dtype=str, keep_default_na=False)
    seed["label_numeric"] = pd.to_numeric(seed["label"], errors="coerce")
    seed = seed[seed["label_numeric"].isin([0, 1])].copy()
    seed["pair_semantic_key"] = [
        pair_semantic_key(qd, qu, cd, cu)
        for qd, qu, cd, cu in zip(
            seed["normalized_bid_description"],
            seed["normalized_bid_unit"],
            seed["normalized_candidate_description"],
            seed["normalized_candidate_unit"],
        )
    ]
    conflicts = seed.groupby("pair_semantic_key")["label_numeric"].nunique()
    conflict_keys = set(conflicts[conflicts.gt(1)].index)
    clean = seed[~seed["pair_semantic_key"].isin(conflict_keys | eval_pair_keys)].copy()
    clean = clean.sort_values("gold_pair_id").drop_duplicates("pair_semantic_key")
    keep = [
        "gold_pair_id",
        "query_id",
        "candidate_id",
        "bid_description",
        "bid_unit",
        "candidate_description",
        "candidate_unit",
        "normalized_bid_description",
        "normalized_bid_unit",
        "normalized_candidate_description",
        "normalized_candidate_unit",
        "bid_category",
        "candidate_category",
        "bid_spec_tokens",
        "candidate_spec_tokens",
        "label_numeric",
        "relevance_level",
        "difficulty",
        "match_type",
        "reason",
        "annotation_status",
        "review_source",
        "pair_semantic_key",
    ]
    clean[keep].rename(columns={"label_numeric": "label"}).to_csv(output_path, index=False)
    return {
        "input_rows": len(seed),
        "conflicting_semantic_rows_removed": int(seed["pair_semantic_key"].isin(conflict_keys).sum()),
        "evaluation_overlap_rows_removed": int(seed["pair_semantic_key"].isin(eval_pair_keys).sum()),
        "deduplicated_training_rows": len(clean),
    }


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite existing output directory: {output}")
    for subdir in [
        "data",
        "queries",
        "pairs",
        "retrieval",
        "review",
        "provenance",
        "quality",
        "external_alberta",
    ]:
        (output / subdir).mkdir(parents=True, exist_ok=True)

    items = add_prior_exact_flag(prepare_items(args.raw_csv))
    raw_out = output / "data" / "all_bid_items_raw_normalized.csv"
    shutil.copy2(args.raw_csv, raw_out)
    ncdot = items[items["agency"].eq("NCDOT")].copy()
    wsdot = items[items["agency"].eq("WSDOT")].copy()
    ncdot_retriever = TemporalRetriever(items, "NCDOT")
    wsdot_retriever = TemporalRetriever(items, "WSDOT")
    cache: dict[str, pd.DataFrame] = {}

    # Reserve no-reference contracts before selecting the positive locked set.
    # Genuine no-exact candidates are sparse in the latest two lettings, so the
    # safety test draws from all post-baseline NCDOT lettings while preserving
    # the same strict historical-candidate rule.
    no_ref_frame = ncdot[
        ncdot["_date"].ge(pd.Timestamp("2025-09-16"))
        & ncdot["has_prior_exact"].eq(0)
    ]
    no_ref_profiles = scan_profiles(no_ref_frame, ncdot_retriever, cache, 320)
    no_ref_profiles = no_ref_profiles[
        no_ref_profiles["top100_proposed_positive"].eq(0)
    ]
    no_reference = stratified_take(
        no_ref_profiles,
        TARGET_QUERIES["no_reference"],
        sort_columns=["top_retrieval_score", "top100_ambiguous"],
        ascending=[True, True],
        max_per_source_group=10,
    )
    reserved_qkeys = set(no_reference["query_semantic_key"])
    reserved_source_groups = set(no_reference["source_group_id"])

    late_ncdot = ncdot[
        ncdot["_date"].ge(pd.Timestamp("2026-02-17"))
        & ~ncdot["source_group_id"].isin(reserved_source_groups)
        & ~ncdot["query_semantic_key"].isin(reserved_qkeys)
    ]
    locked_profiles = scan_profiles(
        late_ncdot[late_ncdot["has_prior_exact"].eq(1)], ncdot_retriever, cache, 260
    )
    locked_profiles = locked_profiles[locked_profiles["top30_proposed_positive"].gt(0)]
    locked = stratified_take(
        locked_profiles,
        TARGET_QUERIES["locked"],
        sort_columns=["top30_hard_negative", "best_proposed_positive_rank"],
        ascending=[False, True],
        max_per_source_group=12,
    )
    reserved_qkeys.update(locked["query_semantic_key"])
    reserved_source_groups.update(locked["source_group_id"])

    val_frame = ncdot[
        ncdot["_date"].between(pd.Timestamp("2026-01-20"), pd.Timestamp("2026-01-22"))
        & ncdot["has_prior_exact"].eq(1)
        & ~ncdot["query_semantic_key"].isin(reserved_qkeys)
        & ~ncdot["source_group_id"].isin(reserved_source_groups)
    ]
    validation_profiles = scan_profiles(val_frame, ncdot_retriever, cache, 180)
    validation_profiles = validation_profiles[
        validation_profiles["top30_proposed_positive"].gt(0)
    ]
    validation = stratified_take(
        validation_profiles,
        TARGET_QUERIES["validation"],
        sort_columns=["top30_hard_negative", "best_proposed_positive_rank"],
        ascending=[False, True],
        max_per_source_group=8,
    )
    reserved_qkeys.update(validation["query_semantic_key"])
    reserved_source_groups.update(validation["source_group_id"])

    held_out_internal = pd.concat(
        [validation, locked, no_reference], ignore_index=True
    )
    held_out_item_ids = set(held_out_internal["query_id"].astype(str))
    held_out_source_groups = set(held_out_internal["source_group_id"].astype(str))

    train_frame = ncdot[
        ncdot["_date"].between(pd.Timestamp("2025-09-16"), pd.Timestamp("2025-12-16"))
        & ncdot["has_prior_exact"].eq(1)
        & ~ncdot["query_semantic_key"].isin(reserved_qkeys)
        & ~ncdot["source_group_id"].isin(reserved_source_groups)
    ]
    train_profiles = scan_profiles(
        train_frame,
        ncdot_retriever,
        cache,
        360,
        excluded_item_ids=held_out_item_ids,
        excluded_source_groups=held_out_source_groups,
    )
    train_profiles = train_profiles[train_profiles["top30_proposed_positive"].gt(0)]
    train_hard = stratified_take(
        train_profiles,
        TARGET_QUERIES["train_hard"],
        sort_columns=["top30_hard_negative", "best_proposed_positive_rank"],
        ascending=[False, False],
        max_per_source_group=15,
    )
    train_standard_pool = train_profiles[
        ~train_profiles["query_id"].isin(train_hard["query_id"])
    ]
    train_standard = stratified_take(
        train_standard_pool,
        TARGET_QUERIES["train_standard"],
        sort_columns=["best_proposed_positive_rank", "top30_hard_negative"],
        ascending=[True, True],
        max_per_source_group=20,
    )

    # As with the internal safety split, reserve scarce no-reference WSDOT
    # sources first.  Selecting positives first consumed nearly all qualifying
    # no-reference source groups even though the underlying corpus was large.
    external_frame = wsdot[wsdot["_date"].ge(pd.Timestamp("2025-04-14"))]
    external_no_ref_frame = external_frame[
        external_frame["has_prior_exact"].eq(0)
    ]
    external_no_ref_profiles = scan_profiles(
        external_no_ref_frame, wsdot_retriever, cache, 240
    )
    external_no_ref_profiles = external_no_ref_profiles[
        external_no_ref_profiles["top100_proposed_positive"].eq(0)
    ]
    external_no_ref = stratified_take(
        external_no_ref_profiles,
        20,
        sort_columns=["top_retrieval_score", "top100_ambiguous"],
        ascending=[True, True],
        max_per_source_group=5,
    )
    external_reserved_qkeys = set(external_no_ref["query_semantic_key"])
    external_reserved_groups = set(external_no_ref["source_group_id"])
    external_positive_frame = external_frame[
        external_frame["has_prior_exact"].eq(1)
        & ~external_frame["query_semantic_key"].isin(external_reserved_qkeys)
        & ~external_frame["source_group_id"].isin(external_reserved_groups)
    ]
    external_positive_profiles = scan_profiles(
        external_positive_frame,
        wsdot_retriever,
        cache,
        300,
    )
    external_positive_profiles = external_positive_profiles[
        external_positive_profiles["top30_proposed_positive"].gt(0)
    ]
    external_positive = stratified_take(
        external_positive_profiles,
        60,
        sort_columns=["top30_hard_negative", "best_proposed_positive_rank"],
        ascending=[False, True],
        excluded_source_groups=external_reserved_groups,
        max_per_source_group=6,
    )
    external = pd.concat([external_positive, external_no_ref], ignore_index=True)
    external_positive_ids = set(external_positive["query_id"].astype(str))

    # Weak training rows may not contain any held-out evaluation query item or
    # source group.  Refresh only the training candidate pools after all
    # internal evaluation sources are frozen.
    for train_queries in [train_standard, train_hard]:
        for _, row in train_queries.iterrows():
            query = row.to_dict()
            refreshed = ncdot_retriever.retrieve(
                query,
                FULL_K,
                excluded_item_ids=held_out_item_ids,
                excluded_source_groups=held_out_source_groups,
            )
            if len(refreshed) != FULL_K:
                raise RuntimeError(
                    f"Training query {query['query_id']} has only {len(refreshed)} "
                    "candidates after evaluation-source exclusion"
                )
            profile = candidate_pool_profile(query, refreshed)
            if profile["top30_proposed_positive"] < 1:
                raise RuntimeError(
                    f"Training query {query['query_id']} lost all exact Top30 positives "
                    "after evaluation-source exclusion"
                )
            cache[str(query["query_id"])] = refreshed

    selected = {
        "train_standard": train_standard,
        "train_hard": train_hard,
        "validation": validation,
        "locked": locked,
        "no_reference": no_reference,
        "external": external,
    }
    pair_frames = []
    retrieval_frames = []
    for split, queries in selected.items():
        query_columns = [
            "query_id",
            "agency",
            "source_group_id",
            "source_file",
            "source_url",
            "contract_id",
            "letting_date",
            "project_title",
            "item_no",
            "item_code",
            "description",
            "unit",
            "quantity",
            "normalized_description",
            "normalized_unit",
            "category",
            "spec_tokens",
            "query_semantic_key",
            "has_prior_exact",
            "top30_proposed_positive",
            "best_proposed_positive_rank",
            "top30_hard_negative",
            "top100_proposed_positive",
            "top100_ambiguous",
        ]
        queries[query_columns].sort_values("query_id").to_csv(
            output / "queries" / f"{split}_queries.csv", index=False
        )
        pairs, retrieval = make_pair_rows(
            split, queries, cache, external_positive_ids
        )
        pairs.to_csv(output / "pairs" / f"{split}_pairs.csv", index=False)
        retrieval.to_csv(
            output / "retrieval" / f"{split}_top100_full_corpus.csv", index=False
        )
        pair_frames.append(pairs)
        retrieval_frames.append(retrieval)

    all_pairs = pd.concat(pair_frames, ignore_index=True)
    all_pairs.to_csv(output / "pairs" / "all_pairs.csv", index=False)
    review_units, review_members = build_review_units(all_pairs)
    review_units.to_csv(output / "review" / "evaluation_review_units.csv", index=False)
    review_members.to_csv(output / "review" / "evaluation_review_members.csv", index=False)
    train_review = all_pairs[
        all_pairs["split"].str.startswith("train_") & all_pairs["train_use"].eq(0)
    ]
    train_review.to_csv(output / "review" / "optional_training_review_queue.csv", index=False)

    source_manifest = (
        items.groupby(
            ["agency", "source_file", "source_url", "letting_date"], dropna=False
        )
        .agg(items=("item_id", "nunique"), source_groups=("source_group_id", "nunique"))
        .reset_index()
    )
    source_manifest.to_csv(output / "provenance" / "source_manifest.csv", index=False)
    split_manifest_rows = []
    for split, frame in all_pairs.groupby("split", sort=False):
        split_manifest_rows.append(
            {
                "split": split,
                "pairs": len(frame),
                "queries": frame["query_id"].nunique(),
                "query_agencies": ";".join(sorted(frame["query_agency"].unique())),
                "candidate_agencies": ";".join(sorted(frame["candidate_agency"].unique())),
                "proposed_positive": int(frame["proposed_label"].eq(1).sum()),
                "proposed_negative": int(frame["proposed_label"].eq(0).sum()),
                "usable_weak_training_rows": int(
                    (frame["training_label"].astype(str) != "").sum()
                ),
                "annotation_status": ";".join(sorted(frame["annotation_status"].unique())),
            }
        )
    pd.DataFrame(split_manifest_rows).to_csv(
        output / "provenance" / "split_manifest.csv", index=False
    )

    eval_pair_keys = set(
        all_pairs.loc[~all_pairs["split"].str.startswith("train_"), "pair_semantic_key"]
    )
    legacy_summary = None
    if args.legacy_human_seed:
        legacy_summary = process_legacy_seed(
            args.legacy_human_seed,
            eval_pair_keys,
            output / "data" / "legacy_human_seed_train_deduplicated.csv",
        )

    alberta_summary = None
    if args.alberta_xlsx:
        alberta_copy = output / "external_alberta" / args.alberta_xlsx.name
        shutil.copy2(args.alberta_xlsx, alberta_copy)
        alberta_summary = build_alberta(alberta_copy, output / "external_alberta")

    summary = {
        "dataset_name": "BidUPM-vFinal provisional rebuild",
        "created_from": str(args.raw_csv.resolve()),
        "raw_sha256": sha256(args.raw_csv),
        "raw_items": len(items),
        "core_pairs": len(all_pairs),
        "core_queries": all_pairs["query_id"].nunique(),
        "target_queries": TARGET_QUERIES,
        "top_k_labeled": TOP_K,
        "full_retrieval_k": FULL_K,
        "evaluation_review_units": len(review_units),
        "annotation_boundary": (
            "Training labels are deterministic weak labels. Validation, locked, "
            "no-reference, and external final labels remain blank until double review."
        ),
        "legacy_human_seed": legacy_summary,
        "alberta_external": alberta_summary,
    }
    (output / "quality" / "build_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
