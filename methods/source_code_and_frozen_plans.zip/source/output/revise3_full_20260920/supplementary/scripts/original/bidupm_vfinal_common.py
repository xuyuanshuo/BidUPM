#!/usr/bin/env python3
"""Shared deterministic utilities for the BidUPM-vFinal rebuild.

The functions in this module never create human labels.  They provide
reproducible normalization, retrieval, conflict features, and provisional
labels that are suitable for mining training data and preparing human review.
"""

from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Iterable, Mapping

import numpy as np
import pandas as pd


TOKEN_RE = re.compile(r"[a-z0-9]+")
DIMENSION_RE = re.compile(
    r"(?<![a-z0-9])(?:\d+(?:\.\d+)?|x+)\s*(?:in|inch|inches|ft|foot|feet|mm|cm|m)(?![a-z])"
)
QUALIFIER_PATTERNS = {
    "class": re.compile(r"\bclass\s+([a-z0-9-]+)\b"),
    "type": re.compile(r"\btype\s+([a-z0-9-]+)\b"),
}
GRADE_RE = re.compile(r"\bgrade\s+([a-z0-9-]+)\b")
PG_RE = re.compile(r"\bpg\s+(?:pg\s+)?([0-9]{2}[a-z]?)\s+([0-9]{2})\b")
SPEC_CODE_RE = re.compile(
    r"\bspec(?:ification)?\b\s*(?:no|number)?\s*([a-z0-9-]*[0-9][a-z0-9-]*)\b"
)
PLACEHOLDER_QUALIFIERS = {"x", "xx", "xxx", "type", "class"}

UNIT_ALIASES = {
    "ea": "each",
    "each": "each",
    "ls": "lump_sum",
    "l s": "lump_sum",
    "lump sum": "lump_sum",
    "lf": "linear_foot",
    "l f": "linear_foot",
    "linear foot": "linear_foot",
    "linear feet": "linear_foot",
    "ft": "linear_foot",
    "sf": "square_foot",
    "s f": "square_foot",
    "sqft": "square_foot",
    "square foot": "square_foot",
    "sy": "square_yard",
    "s y": "square_yard",
    "square yard": "square_yard",
    "cy": "cubic_yard",
    "c y": "cubic_yard",
    "cubic yard": "cubic_yard",
    "ton": "ton",
    "tonne": "tonne",
    "lb": "pound",
    "lbs": "pound",
    "pound": "pound",
    "kg": "kilogram",
    "hr": "hour",
    "hour": "hour",
    "day": "day",
    "acre": "acre",
    "hectare": "hectare",
    "metre": "metre",
    "meter": "metre",
    "square metre": "square_metre",
    "square meter": "square_metre",
    "cubic metre": "cubic_metre",
    "cubic meter": "cubic_metre",
}

ACTION_GROUPS = {
    "remove": {"remove", "removing", "removal", "dispose", "disposal", "demolish"},
    "install": {"install", "installation", "place", "placing", "construct", "construction", "erect"},
    "supply": {"supply", "furnish", "furnishing", "provide"},
    "repair": {"repair", "rehabilitate", "rehabilitation", "restore", "restoration"},
    "test": {"test", "testing", "inspect", "inspection"},
    "paint": {"paint", "painting", "marking", "stripe", "striping"},
    "excavate": {"excavate", "excavation", "undercut", "grading"},
    "haul": {"haul", "hauling", "transport"},
    "clean": {"clean", "cleaning", "flush", "flushing"},
}

MATERIAL_GROUPS = {
    "concrete": {"concrete", "conc", "cement", "rcp"},
    "asphalt": {"asphalt", "hma", "bituminous"},
    "steel": {"steel", "stl", "reinforcing", "reinf"},
    "aggregate": {"aggregate", "gravel", "stone", "rock", "riprap", "borrow"},
    "soil": {"soil", "earth", "topsoil", "subgrade"},
    "plastic": {"plastic", "polyethylene", "pvc", "hdpe"},
    "wood": {"wood", "timber", "lumber"},
    "paint": {"paint", "thermoplastic", "multipolymer", "epoxy"},
    "wire": {"wire", "chain", "mesh"},
}

STOP_TOKENS = {
    "and",
    "or",
    "of",
    "for",
    "the",
    "a",
    "an",
    "incl",
    "including",
    "item",
    "generic",
    "type",
    "class",
    "no",
}


def canonical_text(value: object) -> str:
    text = str(value or "").lower().replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def canonical_unit(value: object) -> str:
    raw = canonical_text(value).replace("_", " ")
    return UNIT_ALIASES.get(raw, raw.replace(" ", "_"))


def tokens(value: object) -> tuple[str, ...]:
    return tuple(t for t in TOKEN_RE.findall(canonical_text(value)) if t not in STOP_TOKENS)


def semantic_key(description: object, unit: object) -> str:
    return f"{canonical_text(description)}||{canonical_unit(unit)}"


def pair_semantic_key(
    query_description: object,
    query_unit: object,
    candidate_description: object,
    candidate_unit: object,
) -> str:
    return (
        f"{semantic_key(query_description, query_unit)}"
        f"@@{semantic_key(candidate_description, candidate_unit)}"
    )


def item_code_key(value: object) -> str:
    return re.sub(r"[^A-Z0-9]+", "", str(value or "").upper())


def token_metrics(query_tokens: Iterable[str], candidate_tokens: Iterable[str]) -> tuple[float, float]:
    q = set(query_tokens)
    c = set(candidate_tokens)
    if not q or not c:
        return 0.0, 0.0
    overlap = len(q & c)
    jaccard = overlap / len(q | c)
    containment = overlap / min(len(q), len(c))
    return jaccard, containment


def group_hits(token_set: set[str], groups: Mapping[str, set[str]]) -> set[str]:
    return {name for name, words in groups.items() if token_set & words}


def extract_dimensions(text: object) -> set[str]:
    normalized = canonical_text(text)
    return {m.group(0).replace(" ", "") for m in DIMENSION_RE.finditer(normalized)}


def extract_qualifiers(text: object, family: str) -> set[str]:
    normalized = canonical_text(text)
    if family in QUALIFIER_PATTERNS:
        return {
            match.group(1)
            for match in QUALIFIER_PATTERNS[family].finditer(normalized)
            if match.group(1) not in PLACEHOLDER_QUALIFIERS
        }
    if family != "spec":
        raise ValueError(f"Unknown qualifier family: {family}")

    values: set[str] = set()
    for match in GRADE_RE.finditer(normalized):
        value = match.group(1)
        # A grade is safe to compare only when it is an explicit code, not a
        # construction noun such as "grade beam".
        if any(char.isdigit() for char in value) or len(value) == 1:
            values.add(f"grade:{value}")
    for match in PG_RE.finditer(normalized):
        values.add(f"pg:{match.group(1)}-{match.group(2)}")
    for match in SPEC_CODE_RE.finditer(normalized):
        values.add(f"spec:{match.group(1)}")
    return values


@dataclass(frozen=True)
class PairFeatures:
    unit_match: int
    category_match: int
    item_code_match: int
    exact_description: int
    token_jaccard: float
    token_containment: float
    sequence_ratio: float
    action_conflict: int
    material_conflict: int
    dimension_conflict: int
    class_conflict: int
    type_conflict: int
    spec_conflict: int
    conflict_type: str


def pair_features(query: Mapping[str, object], candidate: Mapping[str, object]) -> PairFeatures:
    q_desc = query.get("normalized_description") or query.get("description") or ""
    c_desc = candidate.get("normalized_description") or candidate.get("description") or ""
    q_unit = canonical_unit(query.get("normalized_unit") or query.get("unit") or "")
    c_unit = canonical_unit(candidate.get("normalized_unit") or candidate.get("unit") or "")
    q_tokens = set(tokens(q_desc))
    c_tokens = set(tokens(c_desc))
    jaccard, containment = token_metrics(q_tokens, c_tokens)
    q_actions = group_hits(q_tokens, ACTION_GROUPS)
    c_actions = group_hits(c_tokens, ACTION_GROUPS)
    action_conflict = int(bool(q_actions and c_actions and q_actions.isdisjoint(c_actions)))
    q_materials = group_hits(q_tokens, MATERIAL_GROUPS)
    c_materials = group_hits(c_tokens, MATERIAL_GROUPS)
    material_conflict = int(bool(q_materials and c_materials and q_materials.isdisjoint(c_materials)))
    q_dims = extract_dimensions(q_desc)
    c_dims = extract_dimensions(c_desc)
    dimension_conflict = int(bool(q_dims and c_dims and q_dims.isdisjoint(c_dims)))
    q_classes = extract_qualifiers(q_desc, "class")
    c_classes = extract_qualifiers(c_desc, "class")
    class_conflict = int(bool(q_classes and c_classes and q_classes.isdisjoint(c_classes)))
    q_types = extract_qualifiers(q_desc, "type")
    c_types = extract_qualifiers(c_desc, "type")
    type_conflict = int(bool(q_types and c_types and q_types.isdisjoint(c_types)))
    q_specs = extract_qualifiers(q_desc, "spec")
    c_specs = extract_qualifiers(c_desc, "spec")
    spec_conflict = int(bool(q_specs and c_specs and q_specs.isdisjoint(c_specs)))
    unit_match = int(q_unit == c_unit and bool(q_unit))
    q_category = canonical_text(query.get("category") or "")
    c_category = canonical_text(candidate.get("category") or "")
    category_match = int(bool(q_category) and q_category == c_category)
    q_code = item_code_key(query.get("item_code") or "")
    c_code = item_code_key(candidate.get("item_code") or "")
    item_code_match = int(bool(q_code) and q_code == c_code)
    exact_description = int(canonical_text(q_desc) == canonical_text(c_desc) and bool(canonical_text(q_desc)))
    sequence_ratio = SequenceMatcher(None, canonical_text(q_desc), canonical_text(c_desc)).ratio()
    if not unit_match:
        conflict_type = "unit_conflict"
    elif action_conflict:
        conflict_type = "action_conflict"
    elif material_conflict:
        conflict_type = "material_conflict"
    elif class_conflict:
        conflict_type = "class_conflict"
    elif type_conflict:
        conflict_type = "type_conflict"
    elif spec_conflict:
        conflict_type = "spec_conflict"
    elif dimension_conflict:
        conflict_type = "dimension_conflict"
    else:
        conflict_type = "none"
    return PairFeatures(
        unit_match=unit_match,
        category_match=category_match,
        item_code_match=item_code_match,
        exact_description=exact_description,
        token_jaccard=jaccard,
        token_containment=containment,
        sequence_ratio=sequence_ratio,
        action_conflict=action_conflict,
        material_conflict=material_conflict,
        dimension_conflict=dimension_conflict,
        class_conflict=class_conflict,
        type_conflict=type_conflict,
        spec_conflict=spec_conflict,
        conflict_type=conflict_type,
    )


def provisional_judgment(features: PairFeatures) -> dict[str, object]:
    hard_conflict = bool(
        features.action_conflict
        or features.material_conflict
        or features.dimension_conflict
        or features.class_conflict
        or features.type_conflict
        or features.spec_conflict
    )
    # Automated labels must be a deterministic function of the textual model
    # input.  Agency item codes still help retrieval, but generic DOT codes can
    # be reused for materially different work and therefore cannot establish a
    # gold/weak-positive label by themselves.
    if features.unit_match and features.exact_description:
        return {
            "proposed_label": 1,
            "proposed_relevance": "exact",
            "proposal_confidence": "high",
            "difficulty": "easy",
            "sampling_role": "exact_positive",
            "train_use": 1,
            "proposal_reason": "Exact normalized description with compatible unit.",
        }
    if (
        features.unit_match
        and not hard_conflict
        and features.token_containment >= 0.75
        and features.token_jaccard >= 0.45
        and features.sequence_ratio >= 0.72
    ):
        return {
            "proposed_label": 1,
            "proposed_relevance": "acceptable",
            "proposal_confidence": "medium",
            "difficulty": "hard",
            "sampling_role": "acceptable_positive_candidate",
            "train_use": 0,
            "proposal_reason": "Strong compatible semantic overlap; human confirmation required.",
        }
    if not features.unit_match:
        return {
            "proposed_label": 0,
            "proposed_relevance": "wrong" if features.token_jaccard < 0.35 else "related",
            "proposal_confidence": "high",
            "difficulty": "hard" if features.token_jaccard >= 0.25 else "easy",
            "sampling_role": "unit_conflict_negative",
            "train_use": 1,
            "proposal_reason": "Incompatible pay units; unsafe as a unit-price reference.",
        }
    if hard_conflict:
        return {
            "proposed_label": 0,
            "proposed_relevance": "related",
            "proposal_confidence": "high",
            "difficulty": "hard",
            "sampling_role": "hard_conflict_negative",
            "train_use": 1,
            "proposal_reason": f"Explicit {features.conflict_type} despite lexical overlap.",
        }
    if features.token_jaccard <= 0.10 and features.sequence_ratio < 0.40:
        return {
            "proposed_label": 0,
            "proposed_relevance": "wrong",
            "proposal_confidence": "high",
            "difficulty": "easy",
            "sampling_role": "easy_negative",
            "train_use": 1,
            "proposal_reason": "Low semantic overlap after temporal retrieval.",
        }
    return {
        "proposed_label": 0,
        "proposed_relevance": "related",
        "proposal_confidence": "low",
        "difficulty": "hard",
        "sampling_role": "ambiguous_review",
        "train_use": 0,
        "proposal_reason": "Ambiguous near match; human confirmation required.",
    }


class TemporalRetriever:
    """Deterministic lexical retriever with strict date and provenance filters."""

    def __init__(self, items: pd.DataFrame, agency: str) -> None:
        self.items = items[items["agency"].eq(agency)].copy().reset_index(drop=True)
        self.items["_date"] = pd.to_datetime(self.items["letting_date"], errors="raise")
        self.items["_tokens"] = self.items["normalized_description"].map(tokens)
        self.items["_semantic_key"] = [
            semantic_key(d, u)
            for d, u in zip(self.items["normalized_description"], self.items["normalized_unit"])
        ]
        self.items["_unit_key"] = self.items["normalized_unit"].map(canonical_unit)
        self.items["_category_key"] = self.items["category"].map(canonical_text)
        self.items["_item_code_key"] = self.items["item_code"].map(item_code_key)
        self._dates = self.items["_date"].to_numpy(dtype="datetime64[ns]")
        self._contracts = self.items["contract_id"].astype(str).to_numpy()
        self._source_groups = self.items["source_group_id"].astype(str).to_numpy()
        self._unit_keys = self.items["_unit_key"].astype(str).to_numpy()
        self._category_keys = self.items["_category_key"].astype(str).to_numpy()
        self._semantic_keys = self.items["_semantic_key"].astype(str).to_numpy()
        self._item_code_keys = self.items["_item_code_key"].astype(str).to_numpy()
        self._item_ids = self.items["item_id"].astype(str).to_numpy()
        self.inverted: dict[str, list[int]] = defaultdict(list)
        self.code_index: dict[str, list[int]] = defaultdict(list)
        self.semantic_index: dict[str, list[int]] = defaultdict(list)
        df = Counter()
        for idx, row_tokens in enumerate(self.items["_tokens"]):
            for token in set(row_tokens):
                self.inverted[token].append(idx)
                df[token] += 1
            code = self._item_code_keys[idx]
            if code:
                self.code_index[code].append(idx)
            self.semantic_index[self._semantic_keys[idx]].append(idx)
        n = max(len(self.items), 1)
        self.idf = {token: math.log((n + 1) / (freq + 0.5)) + 1.0 for token, freq in df.items()}

    def _eligible(self, query: Mapping[str, object], idx: int) -> bool:
        q_date = np.datetime64(pd.Timestamp(query["letting_date"]), "ns")
        if self._dates[idx] >= q_date:
            return False
        if self._contracts[idx] == str(query["contract_id"]):
            return False
        if self._source_groups[idx] == str(query["source_group_id"]):
            return False
        return True

    def _eligible_mask(
        self,
        query: Mapping[str, object],
        excluded_item_ids: set[str] | None = None,
        excluded_source_groups: set[str] | None = None,
    ) -> np.ndarray:
        q_date = np.datetime64(pd.Timestamp(query["letting_date"]), "ns")
        mask = (
            (self._dates < q_date)
            & (self._contracts != str(query["contract_id"]))
            & (self._source_groups != str(query["source_group_id"]))
        )
        if excluded_item_ids:
            mask &= ~np.isin(self._item_ids, list(excluded_item_ids))
        if excluded_source_groups:
            mask &= ~np.isin(self._source_groups, list(excluded_source_groups))
        return mask

    def retrieve(
        self,
        query: Mapping[str, object],
        limit: int = 100,
        *,
        excluded_item_ids: set[str] | None = None,
        excluded_source_groups: set[str] | None = None,
    ) -> pd.DataFrame:
        q_tokens = tokens(query.get("normalized_description") or query.get("description") or "")
        q_token_set = set(q_tokens)
        q_unit = canonical_unit(query.get("normalized_unit") or query.get("unit") or "")
        q_category = canonical_text(query.get("category") or "")
        q_code = item_code_key(query.get("item_code") or "")
        q_semantic = semantic_key(
            query.get("normalized_description") or query.get("description") or "",
            query.get("normalized_unit") or query.get("unit") or "",
        )
        eligible = self._eligible_mask(query, excluded_item_ids, excluded_source_groups)
        candidate_scores: defaultdict[int, float] = defaultdict(float)
        for token in q_token_set:
            for idx in self.inverted.get(token, []):
                if eligible[idx]:
                    candidate_scores[idx] += self.idf.get(token, 1.0)
        if q_code:
            for idx in self.code_index.get(q_code, []):
                if eligible[idx]:
                    candidate_scores[idx] += 35.0
        for idx in self.semantic_index.get(q_semantic, []):
            if eligible[idx]:
                candidate_scores[idx] += 45.0
        if len(candidate_scores) < limit * 3:
            fallback_mask = eligible & (self._unit_keys == q_unit)
            if q_category:
                fallback_mask |= eligible & (self._category_keys == q_category)
            for idx in np.flatnonzero(fallback_mask):
                if idx not in candidate_scores:
                    candidate_scores[int(idx)] = 0.0
        scored: list[tuple[float, int, PairFeatures]] = []
        for idx, lexical in candidate_scores.items():
            candidate = self.items.iloc[idx].to_dict()
            feature = pair_features(query, candidate)
            score = lexical
            score += 5.0 * feature.sequence_ratio
            score += 4.0 * feature.token_jaccard
            score += 2.0 * feature.token_containment
            score += 3.0 * feature.unit_match
            score += 1.5 * feature.category_match
            score += 20.0 * feature.item_code_match
            score += 25.0 * feature.exact_description * feature.unit_match
            score -= 3.0 * feature.action_conflict
            score -= 3.0 * feature.material_conflict
            score -= 2.0 * feature.dimension_conflict
            score -= 3.0 * feature.class_conflict
            score -= 3.0 * feature.type_conflict
            score -= 3.0 * feature.spec_conflict
            scored.append((score, idx, feature))
        scored.sort(key=lambda x: (-x[0], str(self.items.iloc[x[1]]["item_id"])))

        selected: list[tuple[float, int, PairFeatures]] = []
        semantic_counts: Counter[str] = Counter()
        for row in scored:
            sem = self._semantic_keys[row[1]]
            if semantic_counts[sem] >= 3:
                continue
            selected.append(row)
            semantic_counts[sem] += 1
            if len(selected) >= limit:
                break
        if len(selected) < limit:
            selected_ids = {idx for _, idx, _ in selected}
            for row in scored:
                if row[1] in selected_ids:
                    continue
                selected.append(row)
                selected_ids.add(row[1])
                if len(selected) >= limit:
                    break
        records = []
        for rank, (score, idx, feature) in enumerate(selected[:limit], start=1):
            candidate = self.items.iloc[idx]
            records.append(
                {
                    "rank": rank,
                    "retrieval_score": round(float(score), 8),
                    "candidate_item_id": candidate["item_id"],
                    "candidate_semantic_key": candidate["_semantic_key"],
                    "candidate_letting_date": candidate["letting_date"],
                    "candidate_source_group_id": candidate["source_group_id"],
                    "candidate_contract_id": candidate["contract_id"],
                    "candidate_source_file": candidate["source_file"],
                    "candidate_agency": candidate["agency"],
                    "candidate_description": candidate["description"],
                    "candidate_unit": candidate["unit"],
                    "candidate_normalized_description": candidate["normalized_description"],
                    "candidate_normalized_unit": candidate["normalized_unit"],
                    "candidate_category": candidate["category"],
                    "candidate_spec_tokens": candidate["spec_tokens"],
                    "candidate_item_code": candidate["item_code"],
                    "candidate_quantity": candidate["quantity"],
                    "candidate_source_url": candidate["source_url"],
                    **feature.__dict__,
                }
            )
        return pd.DataFrame.from_records(records)
