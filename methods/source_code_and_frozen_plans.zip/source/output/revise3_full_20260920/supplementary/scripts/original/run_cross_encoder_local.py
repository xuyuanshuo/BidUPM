#!/usr/bin/env python3
"""Run zero-shot and locally fine-tuned open cross-encoder experiments."""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import math
import os
import random
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from huggingface_hub import model_info
from torch import nn
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    get_linear_schedule_with_warmup,
)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import (  # noqa: E402
    SEED,
    conflict_gate,
    evaluate_scores,
    f1_counts,
    item_text,
    load_data,
    select_threshold,
    write_json,
)


class PairDataset(Dataset):
    def __init__(self, frame: pd.DataFrame, variant: str = "full") -> None:
        self.queries = item_text(frame, "query", variant)
        self.candidates = item_text(frame, "candidate", variant)
        self.labels = frame["final_label"].to_numpy(dtype=np.float32)
        self.hard = frame["difficulty"].eq("hard").to_numpy(dtype=np.float32)

    def __len__(self) -> int:
        return len(self.labels)

    def __getitem__(self, index: int) -> tuple[str, str, float, float]:
        return (
            self.queries[index],
            self.candidates[index],
            float(self.labels[index]),
            float(self.hard[index]),
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--model", required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--train-batch-size", type=int, default=16)
    parser.add_argument("--max-length", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=2e-5)
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument(
        "--input-variant",
        choices=["full", "description_only", "no_unit", "no_category_specs"],
        default="full",
    )
    parser.add_argument(
        "--regimes",
        nargs="+",
        choices=["standard", "hard_refined"],
        default=["standard"],
    )
    parser.add_argument("--skip-zero-shot", action="store_true")
    parser.add_argument("--symmetric-train", action="store_true")
    parser.add_argument(
        "--device",
        choices=["auto", "cuda", "mps", "cpu"],
        default="auto",
    )
    parser.add_argument(
        "--amp-dtype",
        choices=["auto", "bf16", "fp16", "fp32"],
        default="auto",
    )
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_device(name: str) -> torch.device:
    if name == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        if torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    device = torch.device(name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    if device.type == "mps" and not torch.backends.mps.is_available():
        raise RuntimeError("MPS was requested but is unavailable")
    return device


def resolve_amp_dtype(device: torch.device, name: str) -> torch.dtype | None:
    if device.type != "cuda" or name == "fp32":
        return None
    if name in {"auto", "bf16"}:
        if torch.cuda.is_bf16_supported():
            return torch.bfloat16
        if name == "bf16":
            raise RuntimeError("BF16 was requested but is unsupported")
    return torch.float16


def autocast_context(device: torch.device, amp_dtype: torch.dtype | None):
    return torch.autocast(
        device_type=device.type,
        dtype=amp_dtype if amp_dtype is not None else torch.float32,
        enabled=amp_dtype is not None,
    )


def swapped_training_pairs(frame: pd.DataFrame) -> pd.DataFrame:
    swapped = frame.copy()
    suffixes = [
        "description",
        "normalized_description",
        "normalized_unit",
        "category",
        "spec_tokens",
    ]
    for suffix in suffixes:
        query = f"query_{suffix}"
        candidate = f"candidate_{suffix}"
        swapped[query] = frame[candidate].to_numpy()
        swapped[candidate] = frame[query].to_numpy()
    return pd.concat([frame, swapped], ignore_index=True)


def make_collate(tokenizer, max_length: int):
    def collate(batch: list[tuple[str, str, float, float]]) -> dict[str, torch.Tensor]:
        queries, candidates, labels, hard = zip(*batch)
        encoded = tokenizer(
            list(queries),
            list(candidates),
            padding=True,
            truncation=True,
            max_length=max_length,
            return_tensors="pt",
        )
        encoded["labels_local"] = torch.tensor(labels, dtype=torch.float32)
        encoded["hard_local"] = torch.tensor(hard, dtype=torch.float32)
        return encoded

    return collate


@torch.inference_mode()
def predict(
    model,
    tokenizer,
    frame: pd.DataFrame,
    device: torch.device,
    batch_size: int,
    max_length: int,
    variant: str = "full",
    amp_dtype: torch.dtype | None = None,
) -> tuple[np.ndarray, float]:
    model.eval()
    dataset = PairDataset(frame, variant)
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=device.type == "cuda",
        collate_fn=make_collate(tokenizer, max_length),
    )
    scores: list[np.ndarray] = []
    started = time.perf_counter()
    for batch in loader:
        batch.pop("labels_local")
        batch.pop("hard_local")
        encoded = {key: value.to(device) for key, value in batch.items()}
        with autocast_context(device, amp_dtype):
            logits = model(**encoded).logits.reshape(-1)
        scores.append(logits.float().cpu().numpy())
    elapsed = time.perf_counter() - started
    return np.concatenate(scores), elapsed


def validation_objective(
    validation: pd.DataFrame,
    scores: np.ndarray,
    regime: str,
) -> tuple[float, float, dict[str, float | int], dict[str, float | int]]:
    threshold, overall = select_threshold(
        validation["final_label"].to_numpy(dtype=int), scores, "f1_opt"
    )
    hard = validation["difficulty"].eq("hard").to_numpy()
    hard_metrics = f1_counts(
        validation.loc[hard, "final_label"].to_numpy(dtype=int), scores[hard], threshold
    )
    if regime == "hard_refined":
        objective = 0.60 * float(overall["pair_f1"]) + 0.40 * float(hard_metrics["pair_f1"])
    else:
        objective = float(overall["pair_f1"])
    return objective, threshold, overall, hard_metrics


def train_regime(
    args: argparse.Namespace,
    regime: str,
    train: pd.DataFrame,
    validation: pd.DataFrame,
    device: torch.device,
    amp_dtype: torch.dtype | None,
) -> tuple[Path, list[dict[str, object]], dict[str, float | int]]:
    set_seed(args.seed)
    tokenizer = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForSequenceClassification.from_pretrained(args.model).to(device)
    dataset = PairDataset(train, args.input_variant)
    generator = torch.Generator().manual_seed(args.seed)
    loader = DataLoader(
        dataset,
        batch_size=args.train_batch_size,
        shuffle=True,
        generator=generator,
        num_workers=0,
        pin_memory=device.type == "cuda",
        collate_fn=make_collate(tokenizer, args.max_length),
    )
    positives = max(int(train["final_label"].sum()), 1)
    negatives = max(len(train) - positives, 1)
    positive_weight = torch.tensor([negatives / positives], dtype=torch.float32, device=device)
    criterion = nn.BCEWithLogitsLoss(pos_weight=positive_weight, reduction="none")
    optimizer = AdamW(model.parameters(), lr=args.learning_rate, weight_decay=0.01)
    total_steps = len(loader) * args.epochs
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=max(1, round(total_steps * 0.10)),
        num_training_steps=total_steps,
    )
    checkpoint = args.output_dir / f"checkpoint_{regime}"
    if checkpoint.exists():
        shutil.rmtree(checkpoint)
    history: list[dict[str, object]] = []
    best: tuple[float, int] | None = None
    train_started = time.perf_counter()
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses: list[float] = []
        epoch_started = time.perf_counter()
        for batch in loader:
            labels = batch.pop("labels_local").to(device)
            hard = batch.pop("hard_local").to(device)
            encoded = {key: value.to(device) for key, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with autocast_context(device, amp_dtype):
                logits = model(**encoded).logits.reshape(-1)
                loss_values = criterion(logits.float(), labels)
            if regime == "hard_refined":
                hard_positive = hard * labels
                sample_weight = 1.0 + 2.0 * hard_positive
                loss_values = loss_values * sample_weight
            loss = loss_values.mean()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            losses.append(float(loss.detach().cpu()))
        validation_scores, validation_seconds = predict(
            model,
            tokenizer,
            validation,
            device,
            args.batch_size,
            args.max_length,
            args.input_variant,
            amp_dtype,
        )
        objective, threshold, overall, hard_metrics = validation_objective(
            validation, validation_scores, regime
        )
        history.append(
            {
                "regime": regime,
                "epoch": epoch,
                "train_loss": float(np.mean(losses)),
                "selection_objective": objective,
                "validation_threshold": threshold,
                "validation_pair_f1": overall["pair_f1"],
                "validation_pair_precision": overall["pair_precision"],
                "validation_pair_recall": overall["pair_recall"],
                "validation_hard_pair_f1": hard_metrics["pair_f1"],
                "epoch_seconds": time.perf_counter() - epoch_started,
                "validation_seconds": validation_seconds,
            }
        )
        key = (objective, -epoch)
        if best is None or key > (best[0], -best[1]):
            best = (objective, epoch)
            model.save_pretrained(checkpoint)
            tokenizer.save_pretrained(checkpoint)
    assert best is not None
    summary = {
        "regime": regime,
        "selected_epoch": best[1],
        "selected_validation_objective": best[0],
        "training_seconds": time.perf_counter() - train_started,
        "positive_class_weight": float(positive_weight.item()),
        "hard_positive_sample_weight": 3.0 if regime == "hard_refined" else 1.0,
    }
    del model
    if device.type == "mps":
        torch.mps.empty_cache()
    elif device.type == "cuda":
        torch.cuda.empty_cache()
    return checkpoint, history, summary


def main() -> None:
    args = parse_args()
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    set_seed(args.seed)
    _, train_source, evaluation, hashes = load_data(args.data_dir)
    train = swapped_training_pairs(train_source) if args.symmetric_train else train_source
    validation = evaluation[evaluation["evaluation_split"].eq("validation")].copy()
    device = resolve_device(args.device)
    amp_dtype = resolve_amp_dtype(device, args.amp_dtype)
    score_columns: dict[str, str] = {}
    timing: dict[str, float] = {}
    history_rows: list[dict[str, object]] = []
    training_summaries: list[dict[str, float | int]] = []
    total_started = time.perf_counter()

    if not args.skip_zero_shot:
        tokenizer = AutoTokenizer.from_pretrained(args.model)
        model = AutoModelForSequenceClassification.from_pretrained(args.model).to(device)
        scores, seconds = predict(
            model,
            tokenizer,
            evaluation,
            device,
            args.batch_size,
            args.max_length,
            args.input_variant,
            amp_dtype,
        )
        name = f"{args.label}_zero_shot"
        column = f"score_{name}"
        evaluation[column] = scores
        score_columns[name] = column
        gated_name = f"{name}_conflict_refined"
        gated_column = f"score_{gated_name}"
        evaluation[gated_column] = conflict_gate(evaluation, scores, strength=1.0)
        score_columns[gated_name] = gated_column
        timing[f"{name}_evaluation_seconds"] = seconds
        del model
        if device.type == "mps":
            torch.mps.empty_cache()
        elif device.type == "cuda":
            torch.cuda.empty_cache()

    for regime in args.regimes:
        checkpoint, history, training_summary = train_regime(
            args, regime, train, validation, device, amp_dtype
        )
        history_rows.extend(history)
        training_summaries.append(training_summary)
        tokenizer = AutoTokenizer.from_pretrained(checkpoint)
        model = AutoModelForSequenceClassification.from_pretrained(checkpoint).to(device)
        scores, seconds = predict(
            model,
            tokenizer,
            evaluation,
            device,
            args.batch_size,
            args.max_length,
            args.input_variant,
            amp_dtype,
        )
        name = f"{args.label}_{regime}"
        column = f"score_{name}"
        evaluation[column] = scores
        score_columns[name] = column
        gated_name = f"{name}_conflict_refined"
        gated_column = f"score_{gated_name}"
        evaluation[gated_column] = conflict_gate(evaluation, scores, strength=1.0)
        score_columns[gated_name] = gated_column
        timing[f"{name}_evaluation_seconds"] = seconds
        del model
        if device.type == "mps":
            torch.mps.empty_cache()
        elif device.type == "cuda":
            torch.cuda.empty_cache()

    _, metrics, _, _ = evaluate_scores(
        evaluation,
        score_columns,
        args.output_dir,
        bootstrap_samples=args.bootstrap,
        seed=args.seed,
    )
    pd.DataFrame(history_rows).to_csv(args.output_dir / "training_history.csv", index=False)
    keep = [
        "pair_id",
        "evaluation_split",
        "query_id",
        "candidate_id",
        "final_label",
        "final_relevance",
        "difficulty",
        "final_conflict_type",
        *score_columns.values(),
    ]
    evaluation[keep].to_csv(args.output_dir / "pair_scores.csv", index=False)
    try:
        revision = model_info(args.model).sha
    except Exception as exc:
        revision = f"unavailable: {type(exc).__name__}"
    manifest = {
        "status": "complete",
        "paper_eligible": True,
        "base_model": args.model,
        "base_model_revision": revision,
        "label": args.label,
        "device": str(device),
        "amp_dtype": str(amp_dtype) if amp_dtype is not None else "fp32",
        "gpu_name": torch.cuda.get_device_name(0) if device.type == "cuda" else None,
        "input_hashes": hashes,
        "training_source_rows_semantic_deduplicated": len(train_source),
        "training_effective_rows": len(train),
        "symmetric_training_augmentation": args.symmetric_train,
        "training_positive": int(train["final_label"].sum()),
        "training_hard_positive": int(
            (train["difficulty"].eq("hard") & train["final_label"].eq(1)).sum()
        ),
        "evaluation_rows": len(evaluation),
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "training_batch_size": args.train_batch_size,
        "max_length": args.max_length,
        "input_variant": args.input_variant,
        "learning_rate": args.learning_rate,
        "regimes": args.regimes,
        "training_summaries": training_summaries,
        "threshold_selection": "validation only",
        "checkpoint_selection": (
            "standard: validation pair F1; hard_refined: 0.60 validation pair F1 + "
            "0.40 validation hard-pair F1"
        ),
        "bootstrap_samples": args.bootstrap,
        "timing": timing,
        "total_runtime_seconds": time.perf_counter() - total_started,
        "packages": {
            name: importlib.metadata.version(name)
            for name in ["torch", "transformers"]
        },
        "seed": args.seed,
    }
    write_json(args.output_dir / "manifest.json", manifest)
    print(json.dumps(manifest, indent=2))
    print(
        metrics[(metrics["split"].eq("locked")) & (metrics["policy"].eq("f1_opt"))][
            ["model", "top1", "recall_at_5", "mrr", "ndcg_at_5_graded", "pair_f1", "hard_pair_f1"]
        ].to_string(index=False)
    )


if __name__ == "__main__":
    main()
