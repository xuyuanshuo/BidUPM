#!/usr/bin/env python3
"""Evaluate and LoRA-fine-tune Qwen3 rerankers on BidUPM-vFinal.

The scoring formulation follows the Qwen model card: each query/candidate pair is
presented as a yes/no judgment and the relevance score is logit(yes)-logit(no).
All thresholds and checkpoint choices are selected on validation only.
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import math
import os
import random
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from huggingface_hub import model_info
from peft import LoraConfig, PeftModel, TaskType, get_peft_model
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, get_linear_schedule_with_warmup

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import (  # noqa: E402
    SEED,
    conflict_gate,
    evaluate_scores,
    f1_counts,
    item_text,
    load_data,
    select_threshold,
    write_json,
)


DEFAULT_INSTRUCTION = (
    "Determine whether the historical bid item is a valid unit-price reference for "
    "the query bid item. Match the construction action, material, specification, "
    "type or class, scope, and pay unit."
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--model", default="Qwen/Qwen3-Reranker-0.6B")
    parser.add_argument("--label", required=True)
    parser.add_argument("--instruction", default=DEFAULT_INSTRUCTION)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--train-batch-size", type=int, default=8)
    parser.add_argument("--gradient-accumulation", type=int, default=2)
    parser.add_argument("--max-length", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    parser.add_argument("--warmup-ratio", type=float, default=0.10)
    parser.add_argument("--lora-rank", type=int, default=16)
    parser.add_argument("--lora-alpha", type=int, default=32)
    parser.add_argument("--lora-dropout", type=float, default=0.05)
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--skip-zero-shot", action="store_true")
    parser.add_argument("--zero-shot-only", action="store_true")
    parser.add_argument("--symmetric-train", action="store_true")
    parser.add_argument(
        "--regimes",
        nargs="+",
        choices=["standard", "hard_refined"],
        default=["standard"],
    )
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def swapped_training_pairs(frame: pd.DataFrame) -> pd.DataFrame:
    swapped = frame.copy()
    for suffix in [
        "description",
        "normalized_description",
        "normalized_unit",
        "category",
        "spec_tokens",
    ]:
        query = f"query_{suffix}"
        candidate = f"candidate_{suffix}"
        swapped[query] = frame[candidate].to_numpy()
        swapped[candidate] = frame[query].to_numpy()
    return pd.concat([frame, swapped], ignore_index=True)


class PairDataset(Dataset):
    def __init__(self, frame: pd.DataFrame) -> None:
        self.queries = item_text(frame, "query", "full")
        self.candidates = item_text(frame, "candidate", "full")
        self.labels = frame["final_label"].to_numpy(dtype=np.int64)
        self.hard = frame["difficulty"].eq("hard").to_numpy(dtype=np.float32)

    def __len__(self) -> int:
        return len(self.labels)

    def __getitem__(self, index: int) -> tuple[str, str, int, float]:
        return (
            self.queries[index],
            self.candidates[index],
            int(self.labels[index]),
            float(self.hard[index]),
        )


class QwenPairCollator:
    def __init__(self, tokenizer, max_length: int, instruction: str) -> None:
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.instruction = instruction
        self.prefix = (
            '<|im_start|>system\nJudge whether the Document meets the requirements '
            'based on the Query and the Instruct provided. Note that the answer can '
            'only be "yes" or "no".<|im_end|>\n<|im_start|>user\n'
        )
        self.suffix = "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
        self.prefix_ids = tokenizer.encode(self.prefix, add_special_tokens=False)
        self.suffix_ids = tokenizer.encode(self.suffix, add_special_tokens=False)
        self.content_length = max_length - len(self.prefix_ids) - len(self.suffix_ids)
        if self.content_length < 32:
            raise ValueError("max_length is too small for the Qwen reranker template")

    def __call__(self, batch: list[tuple[str, str, int, float]]) -> dict[str, torch.Tensor]:
        queries, candidates, labels, hard = zip(*batch)
        contents = [
            f"<Instruct>: {self.instruction}\n<Query>: {query}\n<Document>: {candidate}"
            for query, candidate in zip(queries, candidates)
        ]
        encoded = self.tokenizer(
            contents,
            add_special_tokens=False,
            padding=False,
            truncation=True,
            max_length=self.content_length,
        )
        input_ids = [
            self.prefix_ids + ids + self.suffix_ids for ids in encoded["input_ids"]
        ]
        padded = self.tokenizer.pad(
            {"input_ids": input_ids},
            padding=True,
            pad_to_multiple_of=8,
            return_tensors="pt",
        )
        padded["labels_local"] = torch.tensor(labels, dtype=torch.long)
        padded["hard_local"] = torch.tensor(hard, dtype=torch.float32)
        return padded


def load_base_model(model_name: str, device: torch.device):
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.bfloat16,
        low_cpu_mem_usage=True,
        attn_implementation="sdpa",
    )
    model.config.use_cache = False
    return model.to(device)


def label_token_ids(tokenizer) -> tuple[int, int]:
    no_id = tokenizer.convert_tokens_to_ids("no")
    yes_id = tokenizer.convert_tokens_to_ids("yes")
    if no_id is None or yes_id is None or no_id == tokenizer.unk_token_id or yes_id == tokenizer.unk_token_id:
        raise RuntimeError("Qwen tokenizer does not expose the expected yes/no tokens")
    return int(no_id), int(yes_id)


def pair_logits(model, batch: dict[str, torch.Tensor], no_id: int, yes_id: int) -> torch.Tensor:
    outputs = model(**batch)
    final = outputs.logits[:, -1, :]
    return torch.stack([final[:, no_id], final[:, yes_id]], dim=1)


@torch.inference_mode()
def predict(
    model,
    tokenizer,
    frame: pd.DataFrame,
    device: torch.device,
    batch_size: int,
    max_length: int,
    instruction: str,
) -> tuple[np.ndarray, float]:
    model.eval()
    collator = QwenPairCollator(tokenizer, max_length, instruction)
    loader = DataLoader(
        PairDataset(frame),
        batch_size=batch_size,
        shuffle=False,
        num_workers=2,
        pin_memory=True,
        collate_fn=collator,
    )
    no_id, yes_id = label_token_ids(tokenizer)
    scores: list[np.ndarray] = []
    started = time.perf_counter()
    for batch in loader:
        batch.pop("labels_local")
        batch.pop("hard_local")
        encoded = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
        with torch.autocast("cuda", dtype=torch.bfloat16):
            logits = pair_logits(model, encoded, no_id, yes_id)
        scores.append((logits[:, 1] - logits[:, 0]).float().cpu().numpy())
    return np.concatenate(scores), time.perf_counter() - started


def validation_objective(
    validation: pd.DataFrame,
    scores: np.ndarray,
    regime: str,
) -> tuple[float, float, dict[str, float | int], dict[str, float | int]]:
    threshold, overall = select_threshold(
        validation["final_label"].to_numpy(dtype=int), scores, "f1_opt"
    )
    hard = validation["difficulty"].eq("hard").to_numpy()
    hard_metrics = f1_counts(
        validation.loc[hard, "final_label"].to_numpy(dtype=int), scores[hard], threshold
    )
    if regime == "hard_refined":
        objective = 0.60 * float(overall["pair_f1"]) + 0.40 * float(hard_metrics["pair_f1"])
    else:
        objective = float(overall["pair_f1"])
    return objective, threshold, overall, hard_metrics


def make_lora_model(args: argparse.Namespace, device: torch.device):
    model = load_base_model(args.model, device)
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    model.enable_input_require_grads()
    config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=args.lora_rank,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        bias="none",
        target_modules=[
            "q_proj",
            "k_proj",
            "v_proj",
            "o_proj",
            "gate_proj",
            "up_proj",
            "down_proj",
        ],
    )
    return get_peft_model(model, config)


def train_regime(
    args: argparse.Namespace,
    regime: str,
    train: pd.DataFrame,
    validation: pd.DataFrame,
    tokenizer,
    device: torch.device,
) -> tuple[Path, list[dict[str, object]], dict[str, object]]:
    set_seed(args.seed)
    model = make_lora_model(args, device)
    collator = QwenPairCollator(tokenizer, args.max_length, args.instruction)
    generator = torch.Generator().manual_seed(args.seed)
    loader = DataLoader(
        PairDataset(train),
        batch_size=args.train_batch_size,
        shuffle=True,
        generator=generator,
        num_workers=2,
        pin_memory=True,
        collate_fn=collator,
    )
    positives = max(int(train["final_label"].sum()), 1)
    negatives = max(len(train) - positives, 1)
    class_weights = torch.tensor([1.0, negatives / positives], device=device)
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = AdamW(trainable, lr=args.learning_rate, weight_decay=args.weight_decay)
    updates_per_epoch = math.ceil(len(loader) / args.gradient_accumulation)
    total_updates = updates_per_epoch * args.epochs
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=max(1, round(total_updates * args.warmup_ratio)),
        num_training_steps=total_updates,
    )
    no_id, yes_id = label_token_ids(tokenizer)
    checkpoint = args.output_dir / f"checkpoint_{regime}"
    if checkpoint.exists():
        shutil.rmtree(checkpoint)
    history: list[dict[str, object]] = []
    best: tuple[float, int] | None = None
    train_started = time.perf_counter()
    for epoch in range(1, args.epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        losses: list[float] = []
        epoch_started = time.perf_counter()
        for step, batch in enumerate(loader, start=1):
            labels = batch.pop("labels_local").to(device, non_blocking=True)
            hard = batch.pop("hard_local").to(device, non_blocking=True)
            encoded = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            with torch.autocast("cuda", dtype=torch.bfloat16):
                logits = pair_logits(model, encoded, no_id, yes_id)
                loss_values = F.cross_entropy(
                    logits.float(), labels, weight=class_weights, reduction="none"
                )
                if regime == "hard_refined":
                    loss_values = loss_values * (1.0 + 2.0 * hard * labels.float())
                loss = loss_values.mean() / args.gradient_accumulation
            loss.backward()
            losses.append(float(loss.detach().cpu()) * args.gradient_accumulation)
            if step % args.gradient_accumulation == 0 or step == len(loader):
                torch.nn.utils.clip_grad_norm_(trainable, 1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)

        validation_scores, validation_seconds = predict(
            model,
            tokenizer,
            validation,
            device,
            args.batch_size,
            args.max_length,
            args.instruction,
        )
        objective, threshold, overall, hard_metrics = validation_objective(
            validation, validation_scores, regime
        )
        history.append(
            {
                "regime": regime,
                "epoch": epoch,
                "train_loss": float(np.mean(losses)),
                "selection_objective": objective,
                "validation_threshold": threshold,
                "validation_pair_f1": overall["pair_f1"],
                "validation_pair_precision": overall["pair_precision"],
                "validation_pair_recall": overall["pair_recall"],
                "validation_hard_pair_f1": hard_metrics["pair_f1"],
                "epoch_seconds": time.perf_counter() - epoch_started,
                "validation_seconds": validation_seconds,
            }
        )
        key = (objective, -epoch)
        if best is None or key > (best[0], -best[1]):
            best = (objective, epoch)
            model.save_pretrained(checkpoint)
            tokenizer.save_pretrained(checkpoint)

    assert best is not None
    trainable_parameters = sum(parameter.numel() for parameter in trainable)
    summary: dict[str, object] = {
        "regime": regime,
        "selected_epoch": best[1],
        "selected_validation_objective": best[0],
        "training_seconds": time.perf_counter() - train_started,
        "positive_class_weight": float(class_weights[1].item()),
        "hard_positive_sample_weight": 3.0 if regime == "hard_refined" else 1.0,
        "trainable_parameters": trainable_parameters,
        "total_parameters": sum(parameter.numel() for parameter in model.parameters()),
    }
    del model
    torch.cuda.empty_cache()
    return checkpoint, history, summary


def load_adapter(args: argparse.Namespace, checkpoint: Path, device: torch.device):
    base = load_base_model(args.model, device)
    model = PeftModel.from_pretrained(base, checkpoint)
    return model.to(device)


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("Qwen reranker training requires CUDA")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    torch.backends.cuda.matmul.allow_tf32 = True
    args.output_dir.mkdir(parents=True, exist_ok=True)
    set_seed(args.seed)
    _, train_source, evaluation, hashes = load_data(args.data_dir)
    train = swapped_training_pairs(train_source) if args.symmetric_train else train_source
    validation = evaluation[evaluation["evaluation_split"].eq("validation")].copy()
    device = torch.device("cuda")
    tokenizer = AutoTokenizer.from_pretrained(args.model, padding_side="left")
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    score_columns: dict[str, str] = {}
    timing: dict[str, float] = {}
    history_rows: list[dict[str, object]] = []
    training_summaries: list[dict[str, object]] = []
    total_started = time.perf_counter()

    if not args.skip_zero_shot:
        model = load_base_model(args.model, device)
        scores, seconds = predict(
            model,
            tokenizer,
            evaluation,
            device,
            args.batch_size,
            args.max_length,
            args.instruction,
        )
        name = f"{args.label}_zero_shot"
        column = f"score_{name}"
        evaluation[column] = scores
        score_columns[name] = column
        gated_name = f"{name}_conflict_refined"
        gated_column = f"score_{gated_name}"
        evaluation[gated_column] = conflict_gate(evaluation, scores, strength=1.0)
        score_columns[gated_name] = gated_column
        timing[f"{name}_evaluation_seconds"] = seconds
        del model
        torch.cuda.empty_cache()

    if not args.zero_shot_only:
        for regime in args.regimes:
            checkpoint, history, summary = train_regime(
                args, regime, train, validation, tokenizer, device
            )
            history_rows.extend(history)
            training_summaries.append(summary)
            model = load_adapter(args, checkpoint, device)
            scores, seconds = predict(
                model,
                tokenizer,
                evaluation,
                device,
                args.batch_size,
                args.max_length,
                args.instruction,
            )
            name = f"{args.label}_{regime}"
            column = f"score_{name}"
            evaluation[column] = scores
            score_columns[name] = column
            gated_name = f"{name}_conflict_refined"
            gated_column = f"score_{gated_name}"
            evaluation[gated_column] = conflict_gate(evaluation, scores, strength=1.0)
            score_columns[gated_name] = gated_column
            timing[f"{name}_evaluation_seconds"] = seconds
            del model
            torch.cuda.empty_cache()

    _, metrics, _, _ = evaluate_scores(
        evaluation,
        score_columns,
        args.output_dir,
        bootstrap_samples=args.bootstrap,
        seed=args.seed,
    )
    pd.DataFrame(history_rows).to_csv(args.output_dir / "training_history.csv", index=False)
    keep = [
        "pair_id",
        "evaluation_split",
        "query_id",
        "candidate_id",
        "final_label",
        "final_relevance",
        "difficulty",
        "final_conflict_type",
        *score_columns.values(),
    ]
    evaluation[keep].to_csv(args.output_dir / "pair_scores.csv", index=False)
    try:
        revision = model_info(args.model).sha
    except Exception as exc:
        revision = f"unavailable: {type(exc).__name__}"
    manifest = {
        "status": "complete",
        "paper_eligible": True,
        "base_model": args.model,
        "base_model_revision": revision,
        "label": args.label,
        "device": "cuda",
        "gpu_name": torch.cuda.get_device_name(0),
        "gpu_memory_bytes": torch.cuda.get_device_properties(0).total_memory,
        "dtype": "bfloat16",
        "instruction": args.instruction,
        "score_definition": "next-token logit(yes) minus logit(no)",
        "input_hashes": hashes,
        "training_source_rows_semantic_deduplicated": len(train_source),
        "training_effective_rows": len(train),
        "symmetric_training_augmentation": args.symmetric_train,
        "evaluation_rows": len(evaluation),
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "training_batch_size": args.train_batch_size,
        "gradient_accumulation": args.gradient_accumulation,
        "max_length": args.max_length,
        "learning_rate": args.learning_rate,
        "lora_rank": args.lora_rank,
        "lora_alpha": args.lora_alpha,
        "lora_dropout": args.lora_dropout,
        "regimes": [] if args.zero_shot_only else args.regimes,
        "training_summaries": training_summaries,
        "threshold_selection": "validation only",
        "checkpoint_selection": (
            "standard: validation pair F1; hard_refined: 0.60 validation pair F1 + "
            "0.40 validation hard-pair F1"
        ),
        "bootstrap_samples": args.bootstrap,
        "timing": timing,
        "total_runtime_seconds": time.perf_counter() - total_started,
        "packages": {
            name: importlib.metadata.version(name)
            for name in ["torch", "transformers", "peft"]
        },
        "seed": args.seed,
    }
    write_json(args.output_dir / "manifest.json", manifest)
    print(json.dumps(manifest, indent=2))
    print(
        metrics[(metrics["split"].eq("locked")) & (metrics["policy"].eq("f1_opt"))][
            ["model", "top1", "recall_at_5", "mrr", "ndcg_at_5_graded", "pair_f1", "hard_pair_f1"]
        ].to_string(index=False)
    )


if __name__ == "__main__":
    main()
