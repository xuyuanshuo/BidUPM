#!/usr/bin/env python3
"""Export leakage-safe query/candidate JSONL for domain reranker training."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("build_dir", type=Path)
    parser.add_argument("--final-pairs", type=Path)
    parser.add_argument("--output-dir", type=Path)
    return parser.parse_args()


def text(description: object, unit: object) -> str:
    return f"{str(description).strip()} [PAY UNIT: {str(unit).strip()}]"


def write_jsonl(path: Path, records: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def read_jsonl(path: Path) -> list[dict[str, object]]:
    records = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                records.append(json.loads(line))
    return records


def core_record(row: pd.Series, label_column: str, source: str, weight: float) -> dict[str, object]:
    return {
        "pair_id": row["pair_id"],
        "query_id": row["query_id"],
        "candidate_id": row["candidate_id"],
        "query": text(row["query_description"], row["query_unit"]),
        "candidate": text(row["candidate_description"], row["candidate_unit"]),
        "label": int(row[label_column]),
        "sample_weight": weight,
        "source": source,
        "split": row["split"],
        "pair_semantic_key": row["pair_semantic_key"],
        "difficulty": row["difficulty"],
        "conflict_type": row["final_conflict_type"] or row["conflict_type"] or "none",
    }


def main() -> None:
    args = parse_args()
    build = args.build_dir.resolve()
    output = (args.output_dir or (build / "reranker_ready")).resolve()
    output.mkdir(parents=True, exist_ok=True)
    base = pd.read_csv(build / "pairs" / "all_pairs.csv", dtype=str, keep_default_na=False)
    reviewed_path = build / "training_review_resolved" / "train_human_reviewed.jsonl"
    reviewed_records = read_jsonl(reviewed_path) if reviewed_path.exists() else []
    reviewed_keys = {str(record["pair_semantic_key"]) for record in reviewed_records}
    if len(reviewed_keys) != len(reviewed_records):
        raise RuntimeError("Human-reviewed training JSONL contains duplicate semantic pairs")
    write_jsonl(output / "train_human_reviewed.jsonl", reviewed_records)

    weak = base[
        base["split"].str.startswith("train_")
        & base["train_use"].eq("1")
        & base["training_label"].isin(["0", "1"])
    ].copy()
    weak = weak.sort_values(["pair_semantic_key", "pair_id"]).drop_duplicates("pair_semantic_key")
    weak_overlap_removed = int(weak["pair_semantic_key"].isin(reviewed_keys).sum())
    weak = weak[~weak["pair_semantic_key"].isin(reviewed_keys)].copy()
    weak_records = [core_record(row, "training_label", "core_deterministic_weak", 1.0) for _, row in weak.iterrows()]
    write_jsonl(output / "train_core_weak.jsonl", weak_records)

    legacy_path = build / "data" / "legacy_human_seed_train_deduplicated.csv"
    legacy_records: list[dict[str, object]] = []
    legacy_overlap_removed = 0
    if legacy_path.exists():
        legacy = pd.read_csv(legacy_path, dtype=str, keep_default_na=False)
        higher_priority_keys = reviewed_keys | set(weak["pair_semantic_key"])
        legacy_overlap_removed = int(legacy["pair_semantic_key"].isin(higher_priority_keys).sum())
        legacy = legacy[~legacy["pair_semantic_key"].isin(higher_priority_keys)].copy()
        for _, row in legacy.iterrows():
            legacy_records.append(
                {
                    "pair_id": row["gold_pair_id"],
                    "query_id": row["query_id"],
                    "candidate_id": row["candidate_id"],
                    "query": text(row["bid_description"], row["bid_unit"]),
                    "candidate": text(row["candidate_description"], row["candidate_unit"]),
                    "label": int(float(row["label"])),
                    "sample_weight": 0.5,
                    "source": "legacy_confirmed_seed_unverified_double_review",
                    "split": "auxiliary_train_only",
                    "pair_semantic_key": row["pair_semantic_key"],
                    "difficulty": row["difficulty"],
                    "conflict_type": "none",
                }
            )
    write_jsonl(output / "train_legacy_auxiliary.jsonl", legacy_records)
    combined_records = reviewed_records + weak_records + legacy_records
    combined_keys = [str(record["pair_semantic_key"]) for record in combined_records]
    if len(combined_keys) != len(set(combined_keys)):
        raise RuntimeError("Combined training export contains duplicate semantic pairs")
    write_jsonl(output / "train_combined.jsonl", combined_records)

    final_path = args.final_pairs or (build / "finalized" / "pairs" / "all_pairs_final.csv")
    evaluation_ready = False
    evaluation_counts: dict[str, int] = {}
    if final_path.exists():
        final = pd.read_csv(final_path, dtype=str, keep_default_na=False)
        evaluation = final[~final["split"].str.startswith("train_")].copy()
        evaluation_ready = evaluation["final_label"].isin(["0", "1"]).all()
        if evaluation_ready:
            train_keys = {record["pair_semantic_key"] for record in combined_records}
            overlap = set(evaluation["pair_semantic_key"]) & train_keys
            if overlap:
                raise RuntimeError(f"Refusing export: {len(overlap)} semantic pairs overlap train and evaluation")
            for split, group in evaluation.groupby("split", sort=False):
                records = [core_record(row, "final_label", "human_final", 1.0) for _, row in group.iterrows()]
                write_jsonl(output / f"{split}_human_final.jsonl", records)
                evaluation_counts[split] = len(records)

    model_config = {
        "recommended_primary": {
            "model": "BAAI/bge-reranker-v2-m3",
            "model_card": "https://huggingface.co/BAAI/bge-reranker-v2-m3",
            "role": "open reproducible cross-encoder reranker baseline and domain fine-tuning",
        },
        "optional_lora": {
            "model": "Qwen/Qwen3-Reranker-0.6B",
            "model_card": "https://huggingface.co/Qwen/Qwen3-Reranker-0.6B",
            "role": "parameter-efficient domain reranker if GPU budget permits",
        },
        "input": "query description + pay unit; candidate description + pay unit",
        "output": "single compatibility score",
        "safety_gate": "separate deterministic/learned conflict and abstention layer",
        "selection_policy": {
            "hyperparameters_and_thresholds": "validation only",
            "locked_internal": "one frozen run",
            "no_reference": "separate safety metrics",
            "external": "one frozen WSDOT run",
        },
    }
    (output / "model_and_freeze_config.json").write_text(
        json.dumps(model_config, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    manifest = {
        "human_reviewed_training_ready": bool(reviewed_records),
        "human_reviewed_training_rows": len(reviewed_records),
        "human_reviewed_training_positive": sum(int(record["label"]) == 1 for record in reviewed_records),
        "human_reviewed_training_negative": sum(int(record["label"]) == 0 for record in reviewed_records),
        "core_weak_rows": len(weak_records),
        "core_weak_positive": sum(record["label"] == 1 for record in weak_records),
        "core_weak_negative": sum(record["label"] == 0 for record in weak_records),
        "core_weak_overlap_with_human_review_removed": weak_overlap_removed,
        "legacy_auxiliary_rows": len(legacy_records),
        "legacy_overlap_with_core_removed": legacy_overlap_removed,
        "legacy_weight": 0.5,
        "combined_training_rows": len(combined_records),
        "evaluation_ready": bool(evaluation_ready),
        "evaluation_counts": evaluation_counts,
        "claim_boundary": (
            "Legacy labels are auxiliary and are not described as double-reviewed gold. "
            "Locked/no-reference/external JSONL files are exported only after final human labels exist."
        ),
    }
    (output / "export_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
