#!/usr/bin/env python3
"""Independent structural and leakage audit for a BidUPM-vFinal build.

This script deliberately recomputes invariants from exported CSV files.  It
does not treat provisional rules as ground truth and it does not require human
labels to be complete.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

import pandas as pd

from bidupm_vfinal_common import pair_features, pair_semantic_key, provisional_judgment


EXPECTED_QUERIES = {
    "train_standard": 100,
    "train_hard": 50,
    "validation": 30,
    "locked": 100,
    "no_reference": 40,
    "external": 80,
}
INTERNAL_SPLITS = [
    "train_standard",
    "train_hard",
    "validation",
    "locked",
    "no_reference",
]
EVALUATION_SPLITS = ["validation", "locked", "no_reference", "external"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("build_dir", type=Path)
    return parser.parse_args()


class Audit:
    def __init__(self) -> None:
        self.rows: list[dict[str, object]] = []

    def check(
        self,
        name: str,
        passed: bool,
        observed: object,
        expected: object,
        severity: str = "error",
    ) -> None:
        self.rows.append(
            {
                "check": name,
                "status": "PASS" if passed else "FAIL",
                "severity": severity,
                "observed": observed,
                "expected": expected,
            }
        )

    @property
    def errors(self) -> list[dict[str, object]]:
        return [r for r in self.rows if r["status"] == "FAIL" and r["severity"] == "error"]


def blank_count(series: pd.Series) -> int:
    return int(series.fillna("").astype(str).str.strip().eq("").sum())


def semantic_dup_max(frame: pd.DataFrame) -> int:
    if frame.empty:
        return 0
    counts = frame.groupby(["query_id", "candidate_semantic_key"]).size()
    return int(counts.max())


def main() -> None:
    args = parse_args()
    build = args.build_dir.resolve()
    quality = build / "quality"
    quality.mkdir(parents=True, exist_ok=True)
    audit = Audit()

    required = [
        build / "pairs" / "all_pairs.csv",
        build / "review" / "evaluation_review_units.csv",
        build / "review" / "evaluation_review_members.csv",
    ]
    for split in EXPECTED_QUERIES:
        required.extend(
            [
                build / "queries" / f"{split}_queries.csv",
                build / "pairs" / f"{split}_pairs.csv",
                build / "retrieval" / f"{split}_top100_full_corpus.csv",
            ]
        )
    missing = [str(path) for path in required if not path.exists()]
    audit.check("required exported files", not missing, missing, [])
    if missing:
        write_reports(quality, audit)
        raise SystemExit(1)

    pairs = pd.read_csv(build / "pairs" / "all_pairs.csv", dtype=str, keep_default_na=False)
    pairs["initial_rank"] = pd.to_numeric(pairs["initial_rank"], errors="raise")
    pair_splits = set(pairs["split"])
    audit.check("split names", pair_splits == set(EXPECTED_QUERIES), sorted(pair_splits), sorted(EXPECTED_QUERIES))
    audit.check("core pair count", len(pairs) == 12_000, len(pairs), 12_000)
    audit.check("core query count", pairs["query_id"].nunique() == 400, pairs["query_id"].nunique(), 400)
    audit.check("pair_id globally unique", pairs["pair_id"].is_unique, int(pairs["pair_id"].duplicated().sum()), 0)

    feature_columns = [
        "unit_match",
        "category_match",
        "item_code_match",
        "exact_description",
        "action_conflict",
        "material_conflict",
        "dimension_conflict",
        "class_conflict",
        "type_conflict",
        "spec_conflict",
        "conflict_type",
    ]
    missing_features = sorted(set(feature_columns) - set(pairs.columns))
    audit.check("all deterministic feature columns exported", not missing_features, missing_features, [])
    if not missing_features:
        recomputed = []
        for row in pairs.to_dict("records"):
            query = {
                "normalized_description": row["query_normalized_description"],
                "normalized_unit": row["query_normalized_unit"],
                "category": row["query_category"],
                "item_code": row["query_item_code"],
            }
            candidate = {
                "normalized_description": row["candidate_normalized_description"],
                "normalized_unit": row["candidate_normalized_unit"],
                "category": row["candidate_category"],
                "item_code": row["candidate_item_code"],
            }
            recomputed.append(pair_features(query, candidate))
        for column in feature_columns:
            if column == "conflict_type":
                observed = pairs[column].astype(str).tolist()
                expected = [feature.conflict_type for feature in recomputed]
            else:
                observed = pd.to_numeric(pairs[column], errors="coerce").tolist()
                expected = [getattr(feature, column) for feature in recomputed]
            mismatches = sum(left != right for left, right in zip(observed, expected))
            audit.check(f"deterministic feature recomputes: {column}", mismatches == 0, mismatches, 0)

    provenance_columns = [
        "query_id",
        "query_agency",
        "query_source_group_id",
        "query_source_file",
        "query_source_url",
        "query_contract_id",
        "query_letting_date",
        "candidate_id",
        "candidate_agency",
        "candidate_source_group_id",
        "candidate_source_file",
        "candidate_source_url",
        "candidate_contract_id",
        "candidate_letting_date",
    ]
    provenance_blanks = {column: blank_count(pairs[column]) for column in provenance_columns}
    provenance_blanks = {column: count for column, count in provenance_blanks.items() if count}
    audit.check("critical provenance fields are complete", not provenance_blanks, provenance_blanks, {})

    query_frames: dict[str, pd.DataFrame] = {}
    retrieval_frames: dict[str, pd.DataFrame] = {}
    pair_frames: dict[str, pd.DataFrame] = {}
    for split, expected_queries in EXPECTED_QUERIES.items():
        query = pd.read_csv(build / "queries" / f"{split}_queries.csv", dtype=str, keep_default_na=False)
        pair = pairs[pairs["split"].eq(split)].copy()
        retrieval = pd.read_csv(
            build / "retrieval" / f"{split}_top100_full_corpus.csv",
            dtype=str,
            keep_default_na=False,
        )
        retrieval["rank"] = pd.to_numeric(retrieval["rank"], errors="raise")
        query_frames[split] = query
        pair_frames[split] = pair
        retrieval_frames[split] = retrieval
        counts = pair.groupby("query_id").size()
        retrieval_counts = retrieval.groupby("query_id").size()
        ranks_ok = pair.groupby("query_id")["initial_rank"].apply(
            lambda s: sorted(s.tolist()) == list(range(1, 31))
        ).all()
        retrieval_ranks_ok = retrieval.groupby("query_id")["rank"].apply(
            lambda s: sorted(s.tolist()) == list(range(1, 101))
        ).all()
        audit.check(f"{split}: query count", query["query_id"].nunique() == expected_queries, query["query_id"].nunique(), expected_queries)
        audit.check(
            f"{split}: query semantic keys unique within split",
            query["query_semantic_key"].is_unique,
            int(query["query_semantic_key"].duplicated().sum()),
            0,
        )
        audit.check(f"{split}: pair count", len(pair) == expected_queries * 30, len(pair), expected_queries * 30)
        audit.check(f"{split}: exactly 30 candidates/query", len(counts) == expected_queries and counts.eq(30).all(), counts.value_counts().to_dict(), {30: expected_queries})
        audit.check(f"{split}: pair ranks 1..30", bool(ranks_ok), bool(ranks_ok), True)
        audit.check(f"{split}: exactly 100 full-corpus candidates/query", len(retrieval_counts) == expected_queries and retrieval_counts.eq(100).all(), retrieval_counts.value_counts().to_dict(), {100: expected_queries})
        audit.check(f"{split}: retrieval ranks 1..100", bool(retrieval_ranks_ok), bool(retrieval_ranks_ok), True)

        top30 = retrieval[retrieval["rank"].le(30)][["query_id", "rank", "candidate_item_id"]].copy()
        exported = pair[["query_id", "initial_rank", "candidate_id"]].rename(
            columns={"initial_rank": "rank", "candidate_id": "candidate_item_id"}
        )
        same_top30 = top30.sort_values(["query_id", "rank"]).reset_index(drop=True).equals(
            exported.sort_values(["query_id", "rank"]).reset_index(drop=True)
        )
        audit.check(f"{split}: labeled Top30 equals full-corpus ranks 1..30", same_top30, same_top30, True)
        max_dup = semantic_dup_max(retrieval[retrieval["rank"].le(30)])
        audit.check(f"{split}: semantic duplicates capped in Top30", max_dup <= 3, max_dup, "<=3", severity="warning")

    exact_query_sets = {split: set(frame["query_id"]) for split, frame in query_frames.items()}
    qkey_sets = {split: set(frame["query_semantic_key"]) for split, frame in query_frames.items()}
    group_sets = {split: set(frame["source_group_id"]) for split, frame in query_frames.items()}
    contract_sets = {split: set(frame["contract_id"]) for split, frame in query_frames.items()}
    for i, left in enumerate(EXPECTED_QUERIES):
        for right in list(EXPECTED_QUERIES)[i + 1 :]:
            audit.check(
                f"query IDs disjoint: {left} vs {right}",
                not (exact_query_sets[left] & exact_query_sets[right]),
                len(exact_query_sets[left] & exact_query_sets[right]),
                0,
            )
            # Semantic overlap across agencies is part of transfer testing, not
            # leakage.  Within the internal NCDOT protocol it is forbidden.
            if left in INTERNAL_SPLITS and right in INTERNAL_SPLITS:
                audit.check(
                    f"query semantic keys disjoint: {left} vs {right}",
                    not (qkey_sets[left] & qkey_sets[right]),
                    len(qkey_sets[left] & qkey_sets[right]),
                    0,
                )
            # train_standard and train_hard are two samplers over one training
            # domain; all evaluation query sources remain isolated from them.
            both_training = left.startswith("train_") and right.startswith("train_")
            if not both_training:
                audit.check(
                    f"query source groups disjoint: {left} vs {right}",
                    not (group_sets[left] & group_sets[right]),
                    len(group_sets[left] & group_sets[right]),
                    0,
                )
                audit.check(
                    f"query contracts disjoint: {left} vs {right}",
                    not (contract_sets[left] & contract_sets[right]),
                    len(contract_sets[left] & contract_sets[right]),
                    0,
                )

    q_dates = pd.to_datetime(pairs["query_letting_date"], errors="coerce")
    c_dates = pd.to_datetime(pairs["candidate_letting_date"], errors="coerce")
    invalid_dates = int(q_dates.isna().sum() + c_dates.isna().sum())
    future = int((c_dates >= q_dates).sum())
    audit.check("all pair dates parse", invalid_dates == 0, invalid_dates, 0)
    audit.check("strict temporal freeze: candidate date < query date", future == 0, future, 0)
    same_contract = int(pairs["query_contract_id"].eq(pairs["candidate_contract_id"]).sum())
    same_group = int(pairs["query_source_group_id"].eq(pairs["candidate_source_group_id"]).sum())
    audit.check("same-contract candidates excluded", same_contract == 0, same_contract, 0)
    audit.check("same-source-group candidates excluded", same_group == 0, same_group, 0)

    internal = pairs[pairs["split"].isin(INTERNAL_SPLITS)]
    external = pairs[pairs["split"].eq("external")]
    audit.check("internal queries are NCDOT only", set(internal["query_agency"]) == {"NCDOT"}, sorted(internal["query_agency"].unique()), ["NCDOT"])
    audit.check("internal candidates are NCDOT only", set(internal["candidate_agency"]) == {"NCDOT"}, sorted(internal["candidate_agency"].unique()), ["NCDOT"])
    audit.check("external queries are WSDOT only", set(external["query_agency"]) == {"WSDOT"}, sorted(external["query_agency"].unique()), ["WSDOT"])
    audit.check("external candidates are WSDOT only", set(external["candidate_agency"]) == {"WSDOT"}, sorted(external["candidate_agency"].unique()), ["WSDOT"])

    train = pairs[pairs["split"].str.startswith("train_")]
    eval_pairs = pairs[pairs["split"].isin(EVALUATION_SPLITS)]
    train_pair_keys = set(train["pair_semantic_key"])
    eval_pair_keys = set(eval_pairs["pair_semantic_key"])
    audit.check("no train/evaluation semantic pair overlap", not (train_pair_keys & eval_pair_keys), len(train_pair_keys & eval_pair_keys), 0)
    model_key = pd.Series(
        [
            pair_semantic_key(qd, qu, cd, cu)
            for qd, qu, cd, cu in zip(
                pairs["query_normalized_description"],
                pairs["query_normalized_unit"],
                pairs["candidate_normalized_description"],
                pairs["candidate_normalized_unit"],
            )
        ],
        index=pairs.index,
    )
    audit.check("stored semantic pair key recomputes exactly", model_key.eq(pairs["pair_semantic_key"]).all(), int((model_key != pairs["pair_semantic_key"]).sum()), 0)
    proposed_conflicts = pairs.groupby("pair_semantic_key")["proposed_label"].nunique()
    audit.check("no contradictory provisional labels for same semantic pair", int(proposed_conflicts.gt(1).sum()) == 0, int(proposed_conflicts.gt(1).sum()), 0)

    eval_query_ids = set(pd.concat([query_frames[s]["query_id"] for s in EVALUATION_SPLITS]))
    train_candidate_hits = set(train["candidate_id"]) & eval_query_ids
    audit.check("evaluation query items absent from training candidates", not train_candidate_hits, len(train_candidate_hits), 0)
    held_out_internal_groups = set(
        pd.concat([query_frames[s]["source_group_id"] for s in ["validation", "locked", "no_reference"]])
    )
    train_group_hits = set(train["candidate_source_group_id"]) & held_out_internal_groups
    audit.check("held-out internal query sources absent from weak training candidates", not train_group_hits, len(train_group_hits), 0)

    for split in ["no_reference", "external"]:
        retrieval = retrieval_frames[split]
        query_lookup = query_frames[split].set_index("query_id").to_dict("index")
        if split == "external":
            no_ref_ids = set(query_frames[split].loc[
                ~query_frames[split]["query_id"].isin(
                    pair_frames[split].loc[pair_frames[split]["external_subtype"].eq("positive_containing"), "query_id"]
                ),
                "query_id",
            ])
            subset = retrieval[retrieval["query_id"].isin(no_ref_ids)]
        else:
            subset = retrieval
        exact_unsafe = subset["exact_description"].astype(str).eq("1") & subset["unit_match"].astype(str).eq("1")
        code_only = (
            subset["item_code_match"].astype(str).eq("1")
            & subset["unit_match"].astype(str).eq("1")
            & ~exact_unsafe
        )
        audit.check(f"{split}: no-reference Top100 contains no exact-description anchor", int(exact_unsafe.sum()) == 0, int(exact_unsafe.sum()), 0)
        deterministic_positive = 0
        for row in subset.to_dict("records"):
            query_row = query_lookup[row["query_id"]]
            deterministic_positive += int(
                provisional_judgment(
                    pair_features(
                        {
                            "normalized_description": query_row["normalized_description"],
                            "normalized_unit": query_row["normalized_unit"],
                            "category": query_row["category"],
                            "item_code": query_row["item_code"],
                        },
                        {
                            "normalized_description": row["candidate_normalized_description"],
                            "normalized_unit": row["candidate_normalized_unit"],
                            "category": row["candidate_category"],
                            "item_code": row["candidate_item_code"],
                        },
                    )
                )["proposed_label"]
                == 1
            )
        audit.check(
            f"{split}: no-reference Top100 contains no deterministic proposed positive",
            deterministic_positive == 0,
            deterministic_positive,
            0,
        )
        audit.check(
            f"{split}: code-only hits reported for human review",
            True,
            int(code_only.sum()),
            "diagnostic only; agency codes are not automatic labels",
            severity="warning",
        )

    ext_counts = external.groupby("external_subtype")["query_id"].nunique().to_dict()
    expected_external = {"no_reference_candidate": 20, "positive_containing": 60}
    audit.check("external subtype composition", ext_counts == expected_external, ext_counts, expected_external)

    final_blank = sum(blank_count(eval_pairs[col]) for col in ["final_label", "final_relevance", "final_conflict_type"])
    expected_blank = len(eval_pairs) * 3
    audit.check("evaluation final fields remain human-only", final_blank == expected_blank, final_blank, expected_blank)
    audit.check("evaluation status pending double review", set(eval_pairs["annotation_status"]) == {"pending_double_review"}, sorted(eval_pairs["annotation_status"].unique()), ["pending_double_review"])
    train_bad_labels = train.loc[train["train_use"].astype(str).eq("1"), "training_label"].astype(str).str.strip().eq("").sum()
    train_ambiguous_labeled = train.loc[~train["train_use"].astype(str).eq("1"), "training_label"].astype(str).str.strip().ne("").sum()
    audit.check("all selected weak-training rows have labels", int(train_bad_labels) == 0, int(train_bad_labels), 0)
    audit.check("ambiguous training rows are not auto-labeled", int(train_ambiguous_labeled) == 0, int(train_ambiguous_labeled), 0)

    units = pd.read_csv(build / "review" / "evaluation_review_units.csv", dtype=str, keep_default_na=False)
    members = pd.read_csv(build / "review" / "evaluation_review_members.csv", dtype=str, keep_default_na=False)
    eval_ids = set(eval_pairs["pair_id"])
    audit.check("review unit IDs unique", units["review_unit_id"].is_unique, int(units["review_unit_id"].duplicated().sum()), 0)
    audit.check("review member pair coverage exact", set(members["pair_id"]) == eval_ids and len(members) == len(eval_pairs), {"members": len(members), "unique": members["pair_id"].nunique()}, {"members": len(eval_pairs), "unique": len(eval_pairs)})
    audit.check("all member unit IDs resolve", set(members["review_unit_id"]).issubset(set(units["review_unit_id"])), len(set(members["review_unit_id"]) - set(units["review_unit_id"])), 0)

    standard_hard = pair_frames["train_standard"]["difficulty"].eq("hard").mean()
    hard_hard = pair_frames["train_hard"]["difficulty"].eq("hard").mean()
    audit.check("train_hard is measurably harder than train_standard", hard_hard >= standard_hard + 0.05, {"train_standard": round(float(standard_hard), 4), "train_hard": round(float(hard_hard), 4)}, "train_hard >= train_standard + 0.05", severity="warning")

    write_reports(quality, audit)
    print(json.dumps({"checks": len(audit.rows), "errors": len(audit.errors)}, indent=2))
    if audit.errors:
        raise SystemExit(1)


def write_reports(quality: Path, audit: Audit) -> None:
    payload = {
        "checks": audit.rows,
        "error_count": len(audit.errors),
        "status": "PASS" if not audit.errors else "FAIL",
    }
    (quality / "independent_audit.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    frame = pd.DataFrame(audit.rows)
    frame.to_csv(quality / "independent_audit.csv", index=False)
    lines = ["# BidUPM-vFinal Independent Audit", "", f"Overall: **{payload['status']}**", ""]
    if not frame.empty:
        for _, row in frame.iterrows():
            lines.append(
                f"- {row['status']} [{row['severity']}] {row['check']}: "
                f"observed `{row['observed']}`, expected `{row['expected']}`"
            )
    (quality / "independent_audit.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
