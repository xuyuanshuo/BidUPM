from pathlib import Path
import sys,csv,json,statistics,hashlib
sys.path.insert(0,str(Path('tmp/revise3_deps').resolve()))
from tokenizers import Tokenizer
b=Path('original_project/outputs/bidupm_server_results_20260905/extracted_evidence/data/FINAL_DATASET_READY')
tok=Tokenizer.from_file('tmp/revise3_bge_tokenizer.json');tok.no_truncation();tok.no_padding()
def norm(v):return ' '.join(v.strip().lower().split())
def txt(r,s):
 a=[norm(r[s+'_'+k]) for k in ['description','normalized_description','normalized_unit','category','spec_tokens']]
 return f'Description: {a[0]}. Normalized: {a[1]}. Pay unit: {a[2]}. Category: {a[3]}. Specs: {a[4]}.'
allr=list(csv.DictReader((b/'pairs/all_pairs_vfinal_12092.csv').open()))
train=list(csv.DictReader((b/'training/training_pairs_semantic_deduplicated.csv').open()))
sets={'training_distinct':train}
for split in ['validation','locked','no_reference','external']:
 sets[split]=[r for r in allr if r['split_final']==split]
output={}
for split,rs in sets.items():
 lens=sorted(len(tok.encode(txt(r,'query'),txt(r,'candidate')).ids) for r in rs)
 n=len(lens)
 def q(v):return lens[round((n-1)*v)]
 output[split]={'rows':n,'p50':q(.5),'p95':q(.95),'p99':q(.99),'max':max(lens),'over_256':sum(x>256 for x in lens),'over_256_fraction':sum(x>256 for x in lens)/n}
result={'model':'BAAI/bge-reranker-v2-m3','revision':'953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e','tokenizer_sha256':hashlib.sha256(Path('tmp/revise3_bge_tokenizer.json').read_bytes()).hexdigest(),'method':'Full serialized query/candidate pairs including tokenizer special tokens; no padding or truncation during audit. Runtime max_length=256 uses tokenizer longest-first pair truncation.','splits':output}
Path('tmp/revise3_token_lengths.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
