#!/usr/bin/env python3
"""Build manuscript-facing S1--S3 tables from frozen result exports."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


TABLES = {
    "S1_complete_split_metrics.csv": (
        "scores/consolidated/all_models/metrics.csv",
        "scores/classical/metrics.csv",
        ("split", "model", "policy"),
    ),
    "S2_safety_outcomes.csv": (
        "scores/consolidated/all_models/safety_metrics.csv",
        "scores/classical/safety_metrics.csv",
        ("split", "model", "policy"),
    ),
    "S3_validation_selected_thresholds.csv": (
        "scores/consolidated/all_models/validation_thresholds.csv",
        "scores/classical/validation_thresholds.csv",
        ("model", "policy"),
    ),
}


def read(path: Path):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--package-root", type=Path, default=Path(__file__).resolve().parents[2]
    )
    args = parser.parse_args()
    root = args.package_root.resolve()
    for table_name, (consolidated_name, classical_name, key_fields) in TABLES.items():
        fields, rows = read(root / consolidated_name)
        classical_fields, classical_rows = read(root / classical_name)
        if fields != classical_fields:
            raise RuntimeError(f"Column mismatch for {table_name}")
        additions = [
            row
            for row in classical_rows
            if row["model"] == "feature_full" and row["policy"] == "f1_opt"
        ]
        if not additions:
            raise RuntimeError(f"No feature_full/f1_opt rows found for {table_name}")
        existing_keys = {tuple(row[field] for field in key_fields) for row in rows}
        additions = [
            row
            for row in additions
            if tuple(row[field] for field in key_fields) not in existing_keys
        ]
        insert_at = max(
            (index for index, row in enumerate(rows) if row["model"] == "tfidf"),
            default=-1,
        ) + 1
        output_rows = rows[:insert_at] + additions + rows[insert_at:]
        output_keys = [tuple(row[field] for field in key_fields) for row in output_rows]
        if len(output_keys) != len(set(output_keys)):
            raise RuntimeError(f"Duplicate rows in {table_name}")
        destination = root / "tables" / table_name
        with destination.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(output_rows)
        print(f"{destination}: {len(output_rows)} rows")


if __name__ == "__main__":
    main()
