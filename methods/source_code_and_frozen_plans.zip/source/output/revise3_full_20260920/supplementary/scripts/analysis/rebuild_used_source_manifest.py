#!/usr/bin/env python3
import csv,json,collections
from datetime import datetime
DATA='original_project/outputs/bidupm_server_results_20260905/extracted_evidence/data/FINAL_DATASET_READY'
OUT='research_workspace/tmp'
pairs=list(csv.DictReader(open(DATA+'/pairs/all_pairs_vfinal_12092.csv',newline='')))
orig=list(csv.DictReader(open(DATA+'/provenance/source_manifest.csv',newline='')))
acc={}
for r in pairs:
 for side in ('query','candidate'):
  agency=r[f'{side}_agency'];f=r[f'{side}_source_file'];key=(agency,f)
  a=acc.setdefault(key,{'agency':agency,'source_file':f,'query_rows':0,'candidate_rows':0,'query_item_ids':set(),'candidate_item_ids':set(),'dates':set(),'contracts':set(),'source_groups':set(),'urls':set()})
  a[f'{side}_rows']+=1;a[f'{side}_item_ids'].add(r[f'{side}_id'])
  for dest,col in [('dates',f'{side}_letting_date'),('contracts',f'{side}_contract_id'),('source_groups',f'{side}_source_group_id'),('urls',f'{side}_source_url')]:
   v=r.get(col,'').strip()
   if v:a[dest].add(v)
rows=[]
for key,a in sorted(acc.items()):
 dates=sorted(a['dates'])
 rows.append({'agency':a['agency'],'source_file':a['source_file'],'used_as_query':int(a['query_rows']>0),'used_as_candidate':int(a['candidate_rows']>0),'query_pair_rows':a['query_rows'],'candidate_pair_rows':a['candidate_rows'],'distinct_query_items':len(a['query_item_ids']),'distinct_candidate_items':len(a['candidate_item_ids']),'letting_date_min':dates[0] if dates else '','letting_date_max':dates[-1] if dates else '','distinct_contracts':len(a['contracts']),'contract_ids':';'.join(sorted(a['contracts'])),'distinct_source_groups':len(a['source_groups']),'source_group_ids':';'.join(sorted(a['source_groups'])),'source_urls':';'.join(sorted(a['urls']))})
with open(OUT+'/revise3_used_source_manifest.csv','w',newline='') as h:
 w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
M={(r['agency'],r['source_file']) for r in orig};U=set(acc)
summary={'status':'read-only reconstruction from both query and candidate provenance fields in all_pairs_vfinal_12092.csv','pair_rows':len(pairs),'reconstructed_files':len(U),'original_source_manifest_rows':len(orig),'original_source_manifest_unique_agency_file':len(M),'used_files_present_in_original_manifest':len(U&M),'used_files_missing_from_original_manifest':len(U-M),'original_manifest_files_not_used_in_pairs':len(M-U),'by_agency':{},'outputs':{'used_source_manifest':OUT+'/revise3_used_source_manifest.csv'}}
for agency in sorted({a for a,f in M|U}):
 summary['by_agency'][agency]={'reconstructed_used_files':sum(a==agency for a,f in U),'original_manifest_unique_files':sum(a==agency for a,f in M),'used_present_in_original':sum(a==agency for a,f in U&M),'used_missing_from_original':sum(a==agency for a,f in U-M),'original_not_used_in_pairs':sum(a==agency for a,f in M-U)}
summary['used_missing_file_keys']=[{'agency':a,'source_file':f} for a,f in sorted(U-M)]
summary['original_unused_file_keys']=[{'agency':a,'source_file':f} for a,f in sorted(M-U)]
json.dump(summary,open(OUT+'/revise3_source_completeness_audit.json','w'),indent=2,ensure_ascii=False)
print(json.dumps(summary,indent=2,ensure_ascii=False))
