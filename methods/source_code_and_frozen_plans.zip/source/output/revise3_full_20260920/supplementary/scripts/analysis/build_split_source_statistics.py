#!/usr/bin/env python3
"""Build descriptive source/contract/time/category counts from frozen pair rows."""

from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path


SPLIT_ORDER = [
    "train_standard",
    "train_hard",
    "train_hard_supplement",
    "train_excluded_eval_semantic_overlap",
    "validation",
    "locked",
    "no_reference",
    "no_reference_reclassified_positive",
    "external",
]


def arguments() -> argparse.Namespace:
    package_default = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, default=package_default)
    parser.add_argument("--output-dir", type=Path, default=None)
    return parser.parse_args()


def joined(values) -> str:
    return ";".join(sorted(value for value in values if value))


def date_range(values) -> tuple[str, str]:
    dates = sorted(value for value in values if value)
    return (dates[0], dates[-1]) if dates else ("", "")


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = arguments()
    package_root = args.package_root.resolve()
    output_dir = args.output_dir.resolve() if args.output_dir else package_root / "data/provenance"
    canonical = package_root / "data/canonical/all_pairs_vfinal_12092.csv"
    with canonical.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))

    grouped = defaultdict(list)
    for row in rows:
        grouped[row["split_final"]].append(row)

    summary_rows = []
    for split in SPLIT_ORDER:
        split_rows = grouped.get(split, [])
        query_dates = {row["query_letting_date"] for row in split_rows}
        candidate_dates = {row["candidate_letting_date"] for row in split_rows}
        all_dates = query_dates | candidate_dates
        q_min, q_max = date_range(query_dates)
        c_min, c_max = date_range(candidate_dates)
        a_min, a_max = date_range(all_dates)
        positives = sum(row["final_label"] == "1" for row in split_rows)
        hard_positives = sum(
            row["final_label"] == "1" and row["difficulty"] == "hard" for row in split_rows
        )
        summary_rows.append(
            {
                "split": split,
                "pair_rows": len(split_rows),
                "positive_rows": positives,
                "negative_rows": len(split_rows) - positives,
                "hard_positive_rows": hard_positives,
                "hard_negative_rows": sum(
                    row["final_label"] == "0" and row["difficulty"] == "hard"
                    for row in split_rows
                ),
                "query_ids": len({row["query_id"] for row in split_rows}),
                "candidate_ids": len({row["candidate_id"] for row in split_rows}),
                "agencies": joined(
                    {row["query_agency"] for row in split_rows}
                    | {row["candidate_agency"] for row in split_rows}
                ),
                "query_source_files": len({row["query_source_file"] for row in split_rows}),
                "candidate_source_files": len(
                    {row["candidate_source_file"] for row in split_rows}
                ),
                "all_source_files": len(
                    {row["query_source_file"] for row in split_rows}
                    | {row["candidate_source_file"] for row in split_rows}
                ),
                "query_source_groups": len(
                    {row["query_source_group_id"] for row in split_rows}
                ),
                "candidate_source_groups": len(
                    {row["candidate_source_group_id"] for row in split_rows}
                ),
                "all_source_groups": len(
                    {row["query_source_group_id"] for row in split_rows}
                    | {row["candidate_source_group_id"] for row in split_rows}
                ),
                "query_contracts": len({row["query_contract_id"] for row in split_rows}),
                "candidate_contracts": len(
                    {row["candidate_contract_id"] for row in split_rows}
                ),
                "all_contracts": len(
                    {row["query_contract_id"] for row in split_rows}
                    | {row["candidate_contract_id"] for row in split_rows}
                ),
                "query_date_min": q_min,
                "query_date_max": q_max,
                "candidate_date_min": c_min,
                "candidate_date_max": c_max,
                "all_date_min": a_min,
                "all_date_max": a_max,
                "query_categories": len(
                    {row["query_category"] for row in split_rows if row["query_category"]}
                ),
                "candidate_categories": len(
                    {row["candidate_category"] for row in split_rows if row["candidate_category"]}
                ),
            }
        )

    summary_fields = list(summary_rows[0])
    write_csv(output_dir / "split_source_contract_summary.csv", summary_fields, summary_rows)

    source_group_map = defaultdict(list)
    date_map = defaultdict(list)
    year_category_map = defaultdict(list)
    for row in rows:
        split = row["split_final"]
        for side in ("query", "candidate"):
            source_group_map[
                (
                    split,
                    side,
                    row[f"{side}_agency"],
                    row[f"{side}_source_group_id"],
                )
            ].append(row)
            date = row[f"{side}_letting_date"]
            date_map[(split, side, row[f"{side}_agency"], date)].append(row)
            year = date[:4] if date else ""
            year_category_map[
                (split, side, row[f"{side}_agency"], year, row[f"{side}_category"] or "[blank]")
            ].append(row)

    split_rank = {name: index for index, name in enumerate(SPLIT_ORDER)}
    source_group_rows = []
    for key, group_rows in sorted(
        source_group_map.items(), key=lambda item: (split_rank.get(item[0][0], 999), item[0][1:])
    ):
        split, side, agency, source_group = key
        dates = {row[f"{side}_letting_date"] for row in group_rows}
        date_min, date_max = date_range(dates)
        source_group_rows.append(
            {
                "split": split,
                "side": side,
                "agency": agency,
                "source_group_id": source_group,
                "pair_occurrences": len(group_rows),
                "unique_item_ids": len({row[f"{side}_id"] for row in group_rows}),
                "source_files": len({row[f"{side}_source_file"] for row in group_rows}),
                "contracts": len({row[f"{side}_contract_id"] for row in group_rows}),
                "letting_date_min": date_min,
                "letting_date_max": date_max,
            }
        )
    write_csv(
        output_dir / "split_source_group_counts.csv",
        list(source_group_rows[0]),
        source_group_rows,
    )

    date_rows = []
    for key, group_rows in sorted(
        date_map.items(), key=lambda item: (split_rank.get(item[0][0], 999), item[0][1:])
    ):
        split, side, agency, date = key
        date_rows.append(
            {
                "split": split,
                "side": side,
                "agency": agency,
                "letting_date": date,
                "pair_occurrences": len(group_rows),
                "unique_item_ids": len({row[f"{side}_id"] for row in group_rows}),
                "source_files": len({row[f"{side}_source_file"] for row in group_rows}),
                "source_groups": len({row[f"{side}_source_group_id"] for row in group_rows}),
                "contracts": len({row[f"{side}_contract_id"] for row in group_rows}),
            }
        )
    write_csv(output_dir / "split_letting_date_counts.csv", list(date_rows[0]), date_rows)

    year_category_rows = []
    for key, group_rows in sorted(
        year_category_map.items(),
        key=lambda item: (split_rank.get(item[0][0], 999), item[0][1:]),
    ):
        split, side, agency, year, category = key
        year_category_rows.append(
            {
                "split": split,
                "side": side,
                "agency": agency,
                "year": year,
                "category": category,
                "pair_occurrences": len(group_rows),
                "unique_item_ids": len({row[f"{side}_id"] for row in group_rows}),
                "source_files": len({row[f"{side}_source_file"] for row in group_rows}),
                "source_groups": len({row[f"{side}_source_group_id"] for row in group_rows}),
                "contracts": len({row[f"{side}_contract_id"] for row in group_rows}),
            }
        )
    write_csv(
        output_dir / "split_year_category_counts.csv",
        list(year_category_rows[0]),
        year_category_rows,
    )

    print(output_dir / "split_source_contract_summary.csv")
    print(output_dir / "split_source_group_counts.csv")
    print(output_dir / "split_letting_date_counts.csv")
    print(output_dir / "split_year_category_counts.csv")


if __name__ == "__main__":
    main()
