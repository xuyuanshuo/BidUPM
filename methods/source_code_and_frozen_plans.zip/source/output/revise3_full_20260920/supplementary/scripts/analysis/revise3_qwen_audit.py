from pathlib import Path
import json,urllib.request,hashlib,csv,sys,concurrent.futures,ast
sys.path.insert(0,str(Path('tmp/revise3_deps').resolve()))
from tokenizers import Tokenizer
models={'qwen06':('Qwen/Qwen3-Reranker-0.6B','e61197ed45024b0ed8a2d74b80b4d909f1255473'),'qwen4':('Qwen/Qwen3-Reranker-4B','22e683669bc0f0bd69640a1354a6d0aebcfeede5'),'verifier':('Qwen/Qwen3-4B-Instruct-2507','cdbee75f17c01a7cc42f958dc650907174af0554')}
def fetch(x):
 key,(repo,rev)=x
 p=Path('tmp')/('revise3_'+key+'_tokenizer.json')
 if not p.exists():p.write_bytes(urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/tokenizer.json',timeout=60).read())
 cfg=json.load(urllib.request.urlopen(f'https://huggingface.co/{repo}/resolve/{rev}/tokenizer_config.json',timeout=60))
 return key,p,cfg
files=list(concurrent.futures.ThreadPoolExecutor(3).map(fetch,models.items()))
b=Path('original_project/outputs/bidupm_server_results_20260905/extracted_evidence')
allr=list(csv.DictReader((b/'data/FINAL_DATASET_READY/pairs/all_pairs_vfinal_12092.csv').open()))
train=list(csv.DictReader((b/'data/FINAL_DATASET_READY/training/training_pairs_semantic_deduplicated.csv').open()))
sets={'training_distinct':train}
for split in ['validation','locked','no_reference','external']:sets[split]=[r for r in allr if r['split_final']==split]
def txt(r,s):
 vals=[' '.join(r[s+'_'+k].lower().split()) for k in ['description','normalized_description','normalized_unit','category','spec_tokens']]
 return f'Description: {vals[0]}. Normalized: {vals[1]}. Pay unit: {vals[2]}. Category: {vals[3]}. Specs: {vals[4]}.'
mod=ast.parse((b/'scripts/run_qwen_reranker.py').read_text())
inst=next(ast.literal_eval(n.value) for n in mod.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DEFAULT_INSTRUCTION' for t in n.targets))
prefix='<|im_start|>system\nJudge whether the Document meets the requirements based on the Query and the Instruct provided. Note that the answer can only be "yes" or "no".<|im_end|>\n<|im_start|>user\n'
suffix='<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n'
modv=ast.parse((b/'scripts/run_open_llm_verifier.py').read_text())
system=next(ast.literal_eval(n.value) for n in modv.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SYSTEM_PROMPT' for t in n.targets))
output={}
for key,path,cfg in files:
 tok=Tokenizer.from_file(str(path));tok.no_truncation();tok.no_padding()
 enc=lambda s:tok.encode(s,add_special_tokens=False).ids
 stats={}
 for split,rs in sets.items():
  if key=='verifier' and split=='training_distinct':continue
  lengths=[];tails=[]
  for r in rs:
   q,c=txt(r,'query'),txt(r,'candidate')
   if key=='verifier':
    from jinja2 import Environment
    user=f'Query bid item:\n{q}\n\nHistorical candidate:\n{c}\n\nCan this candidate safely serve as a unit-price reference for the query?'
    prompt=Environment(trim_blocks=True, lstrip_blocks=True).from_string(cfg['chat_template']).render(messages=[{'role':'system','content':system},{'role':'user','content':user}],add_generation_prompt=True,enable_thinking=False,tools=None,bos_token=cfg.get('bos_token'),eos_token=cfg.get('eos_token'))
    ids=enc(prompt);lengths.append(len(ids))
    if len(ids)>256:tails.append(tok.decode(ids[256:]))
   else:
    content=f'<Instruct>: {inst}\n<Query>: {q}\n<Document>: {c}'
    ids=enc(content);available=256-len(enc(prefix))-len(enc(suffix));lengths.append(len(ids)+256-available)
    if len(ids)>available:tails.append(tok.decode(ids[available:]))
  lengths.sort();n=len(lengths)
  stats[split]={'rows':n,'p50':lengths[round((n-1)*.5)],'p95':lengths[round((n-1)*.95)],'max':max(lengths),'over_256':sum(x>256 for x in lengths),'over_256_fraction':sum(x>256 for x in lengths)/n,'truncated_tails_examples':tails[:3]}
 output[key]={'repo':models[key][0],'revision':models[key][1],'tokenizer_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'truncation_side':cfg.get('truncation_side','right(default)'),'splits':stats}
Path('tmp/revise3_qwen_token_lengths.json').write_text(json.dumps(output,indent=2))
print(json.dumps(output,indent=2))
