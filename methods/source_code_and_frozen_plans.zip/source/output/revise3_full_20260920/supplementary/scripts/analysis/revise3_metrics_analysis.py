import csv,json,collections,os
ROOT='original_project/outputs/bidupm_server_results_20260905/extracted_evidence'
SCORES=ROOT+'/consolidated_final/all_model_pair_scores.csv'
THR=ROOT+'/consolidated_final/all_models/validation_thresholds.csv'
OUT='research_workspace/tmp'
DATA=ROOT+'/data/FINAL_DATASET_READY'
rows=list(csv.DictReader(open(SCORES,newline='')))
th={r['model']:float(r['threshold']) for r in csv.DictReader(open(THR,newline='')) if r['policy']=='f1_opt'}
CLASSICAL='original_project/outputs/bidupm_final_local_experiments_20260904/classical'
feature_scores={r['pair_id']:r['score_feature_full'] for r in csv.DictReader(open(CLASSICAL+'/pair_scores.csv',newline=''))}
feature_threshold=next(float(r['threshold']) for r in csv.DictReader(open(CLASSICAL+'/validation_thresholds.csv',newline='')) if r['model']=='feature_full' and r['policy']=='f1_opt')
for r in rows:
 r['score_feature_full']=feature_scores[r['pair_id']]
models={
 'tfidf':('score_tfidf',th['tfidf']),
 'feature_full':('score_feature_full',feature_threshold),
 'bge_zero':('score_bge_v2_m3_zero_shot',th['bge_v2_m3_zero_shot']),
 'bge_s1':('score_bge_v2_m3_seed_20260904',th['bge_v2_m3_seed_20260904']),
 'bge_s2':('score_bge_v2_m3_seed_20260905',th['bge_v2_m3_seed_20260905']),
 'bge_s3':('score_bge_v2_m3_seed_20260906',th['bge_v2_m3_seed_20260906']),
 'bge_hard':('score_bge_v2_m3_hard_refined',th['bge_v2_m3_hard_refined']),
 'route20':('score_routing_fixed_20pct',0.5),
}
# attach full text data by pair
raw={}
for f in ['evaluation/locked_pairs.csv','evaluation/external_mixed_pairs.csv','evaluation/no_reference_top30_pairs.csv','evaluation/no_reference_reclassified_positive_pairs.csv']:
 for r in csv.DictReader(open(DATA+'/'+f,newline='')): raw[r['pair_id']]=r

def pred(r,m):
 c,t=models[m];return float(r[c])>=t

def metrics(rr,m):
 tp=tn=fp=fn=hp_tp=hp_fn=hn_fp=hn_tn=0
 for r in rr:
  y=int(r['final_label']);p=pred(r,m);hard=r['difficulty'].lower()=='hard'
  tp+=y and p; tn+=(not y) and (not p); fp+=(not y) and p; fn+=y and (not p)
  if hard and y:hp_tp+=p;hp_fn+=not p
  if hard and not y:hn_fp+=p;hn_tn+=not p
 qs=collections.defaultdict(list)
 for r in rr:qs[r['query_id']].append(r)
 posq=[v for v in qs.values() if any(int(x['final_label']) for x in v)]
 noq=[v for v in qs.values() if not any(int(x['final_label']) for x in v)]
 q_any_accept=sum(any(pred(x,m) for x in v) for v in qs.values())
 q_valid_output=sum(any(pred(x,m) and int(x['final_label']) for x in v) for v in posq)
 q_invalid_accept=sum(any(pred(x,m) and not int(x['final_label']) for x in v) for v in qs.values())
 q_false_abstain=sum(not any(pred(x,m) for x in v) for v in posq)
 q_unsafe_no_ref=sum(any(pred(x,m) for x in v) for v in noq)
 return dict(rows=len(rr),positive=sum(int(x['final_label']) for x in rr),tp=tp,tn=tn,fp=fp,fn=fn,hard_positive=hp_tp+hp_fn,hard_positive_tp=hp_tp,hard_positive_fn=hp_fn,hard_positive_recall=(hp_tp/(hp_tp+hp_fn) if hp_tp+hp_fn else None),hard_negative=hn_fp+hn_tn,hard_negative_fp=hn_fp,hard_negative_fp_rate=(hn_fp/(hn_fp+hn_tn) if hn_fp+hn_tn else None),queries=len(qs),positive_queries=len(posq),no_reference_queries=len(noq),queries_any_accepted=q_any_accept,positive_queries_with_valid_output=q_valid_output,positive_query_coverage=(q_valid_output/len(posq) if posq else None),queries_with_any_invalid_accept=q_invalid_accept,positive_queries_false_abstain=q_false_abstain,no_reference_queries_unsafe=q_unsafe_no_ref)
summary={}
for split in ['locked','external','no_reference']:
 rr=[r for r in rows if r['evaluation_split']==split]
 summary[split]={m:metrics(rr,m) for m in models}
json.dump(summary,open(OUT+'/revise3_metrics_summary.json','w'),indent=2)

# pairwise change rows locked and external: seeds and standard/hard/route/tfidf/zero
fields=['pair_id','evaluation_split','query_id','candidate_id','final_label','final_relevance','difficulty','final_conflict_type','query_description','candidate_description','query_unit','candidate_unit']
out=[]
for r in rows:
 if r['evaluation_split'] not in ['locked','external']:continue
 x={k:r.get(k,'') for k in fields[:8]}; x.update({k:raw.get(r['pair_id'],{}).get(k,'') for k in fields[8:]})
 for m in models:x['pred_'+m]=int(pred(r,m))
 x['s1_corrected_tfidf']=int(int(r['final_label'])==1 and pred(r,'bge_s1') and not pred(r,'tfidf'))
 x['hard_corrected_s1']=int(pred(r,'bge_hard')==int(r['final_label']) and pred(r,'bge_s1')!=int(r['final_label']))
 x['hard_broke_s1']=int(pred(r,'bge_hard')!=int(r['final_label']) and pred(r,'bge_s1')==int(r['final_label']))
 x['route_changed_s1']=int(pred(r,'route20')!=pred(r,'bge_s1'))
 x['route_corrected_s1']=int(pred(r,'route20')==int(r['final_label']) and pred(r,'bge_s1')!=int(r['final_label']))
 x['route_broke_s1']=int(pred(r,'route20')!=int(r['final_label']) and pred(r,'bge_s1')==int(r['final_label']))
 out.append(x)
with open(OUT+'/revise3_pairwise_changes.csv','w',newline='') as h:
 w=csv.DictWriter(h,fieldnames=list(out[0]));w.writeheader();w.writerows(out)

# all hard-focused locked errors with text/scores/preds
errs=[]
for r in rows:
 if r['evaluation_split']=='locked' and pred(r,'bge_hard')!=int(r['final_label']):
  x=next(x for x in out if x['pair_id']==r['pair_id'])
  for m,(c,t) in models.items():x['score_'+m]=r[c];x['threshold_'+m]=t
  errs.append(x)
with open(OUT+'/revise3_hardfocused_locked_14_errors.csv','w',newline='') as h:
 w=csv.DictWriter(h,fieldnames=list(errs[0]));w.writeheader();w.writerows(errs)

# seed flips and pipeline changes aggregate
change={}
for split in ['locked','external']:
 rr=[r for r in rows if r['evaluation_split']==split]
 change[split]={}
 for a,b in [('s1','s2'),('s1','s3'),('s2','s3'),('bge_s1','bge_hard'),('bge_hard','route20'),('bge_s1','route20')]:
  aa='bge_'+a if a in ['s1','s2','s3'] else a;bb='bge_'+b if b in ['s1','s2','s3'] else b
  change[split][a+'__'+b]={'flips':sum(pred(r,aa)!=pred(r,bb) for r in rr),'positive_flips':sum(int(r['final_label']) and pred(r,aa)!=pred(r,bb) for r in rr),'negative_flips':sum(not int(r['final_label']) and pred(r,aa)!=pred(r,bb) for r in rr),'a_wrong_b_right':sum(pred(r,aa)!=int(r['final_label']) and pred(r,bb)==int(r['final_label']) for r in rr),'a_right_b_wrong':sum(pred(r,aa)==int(r['final_label']) and pred(r,bb)!=int(r['final_label']) for r in rr)}
json.dump(change,open(OUT+'/revise3_prediction_changes.json','w'),indent=2)
print(json.dumps(summary,indent=2));print(json.dumps(change,indent=2));print('hard errors',len(errs))
