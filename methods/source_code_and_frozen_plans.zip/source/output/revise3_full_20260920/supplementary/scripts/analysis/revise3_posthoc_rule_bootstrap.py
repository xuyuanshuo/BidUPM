import csv,json,collections,os
import numpy as np
ROOT='original_project/outputs/bidupm_server_results_20260905/extracted_evidence'
DATA=ROOT+'/data/FINAL_DATASET_READY'
OUT='research_workspace/tmp'
CLASSICAL='original_project/outputs/bidupm_final_local_experiments_20260904/classical'
rows=list(csv.DictReader(open(ROOT+'/consolidated_final/all_model_pair_scores.csv',newline='')))
byid={r['pair_id']:r for r in rows}
raw={}
for f in ['evaluation/validation_pairs.csv','evaluation/locked_pairs.csv','evaluation/external_mixed_pairs.csv','evaluation/no_reference_top30_pairs.csv','evaluation/no_reference_reclassified_positive_pairs.csv']:
 for r in csv.DictReader(open(DATA+'/'+f,newline='')):raw[r['pair_id']]=r
fs={r['pair_id']:float(r['score_feature_full']) for r in csv.DictReader(open(CLASSICAL+'/pair_scores.csv',newline=''))}
th={r['model']:float(r['threshold']) for r in csv.DictReader(open(ROOT+'/consolidated_final/all_models/validation_thresholds.csv',newline='')) if r['policy']=='f1_opt'}
feature_th=next(float(r['threshold']) for r in csv.DictReader(open(CLASSICAL+'/validation_thresholds.csv',newline='')) if r['model']=='feature_full' and r['policy']=='f1_opt')
models={'tfidf':('score_tfidf',th['tfidf']),'bge_zero':('score_bge_v2_m3_zero_shot',th['bge_v2_m3_zero_shot']),'bge_s1':('score_bge_v2_m3_seed_20260904',th['bge_v2_m3_seed_20260904']),'bge_hard':('score_bge_v2_m3_hard_refined',th['bge_v2_m3_hard_refined']),'feature_full':('FEATURE',feature_th),'posthoc_exact_and_unit':('RULE',1.0)}
def score(r,m):
 if m=='feature_full':return fs[r['pair_id']]
 if m=='posthoc_exact_and_unit':
  z=raw[r['pair_id']];return float(int(float(z['exact_description'])==1 and float(z['unit_match'])==1))
 return float(r[models[m][0]])
def pred(r,m):return score(r,m)>=models[m][1]
def summarize(rr,m):
 tp=fp=fn=tn=0;qs=collections.defaultdict(list)
 for r in rr:
  y=int(r['final_label']);p=pred(r,m);tp+=y and p;fp+=(not y) and p;fn+=y and not p;tn+=(not y) and not p;qs[r['query_id']].append(r)
 posq=[v for v in qs.values() if any(int(x['final_label']) for x in v)];noq=[v for v in qs.values() if not any(int(x['final_label']) for x in v)]
 hp=[r for r in rr if r['difficulty'].lower()=='hard' and int(r['final_label'])];hn=[r for r in rr if r['difficulty'].lower()=='hard' and not int(r['final_label'])]
 return {'rows':len(rr),'tp':tp,'fp':fp,'fn':fn,'tn':tn,'f1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0,'hard_positive_rows':len(hp),'hard_positive_tp':sum(pred(r,m) for r in hp),'hard_positive_recall':sum(pred(r,m) for r in hp)/len(hp) if hp else None,'hard_negative_rows':len(hn),'hard_negative_fp':sum(pred(r,m) for r in hn),'positive_queries':len(posq),'positive_queries_with_valid_accept':sum(any(pred(x,m) and int(x['final_label']) for x in v) for v in posq),'queries_with_invalid_accept':sum(any(pred(x,m) and not int(x['final_label']) for x in v) for v in qs.values()),'no_reference_queries':len(noq),'unsafe_no_reference_queries':sum(any(pred(x,m) for x in v) for v in noq)}
summary={}
for split in ['locked','external','no_reference']:
 rr=[r for r in rows if r['evaluation_split']==split]
 summary[split]={m:summarize(rr,m) for m in models}
json.dump({'analysis_status':'post_hoc_exploration; no threshold fitting and no model training','rule_definition':'predict compatible iff stored observable exact_description == 1 and unit_match == 1; fixed threshold 1.0','summary':summary},open(OUT+'/revise3_posthoc_exact_unit_rule.json','w'),indent=2)
flat=[]
for s,ms in summary.items():
 for m,d in ms.items():flat.append({'split':s,'model':m,**d})
with open(OUT+'/revise3_posthoc_exact_unit_rule.csv','w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
# Query cluster bootstrap, exactly mirroring consolidated query resampling/F1 aggregation.
locked=[r for r in rows if r['evaluation_split']=='locked'];qids=sorted({r['query_id'] for r in locked});groups={q:[r for r in locked if r['query_id']==q] for q in qids}
def cnt(q,m):
 tp=fp=fn=0
 for r in groups[q]:
  y=int(r['final_label']);p=pred(r,m);tp+=y and p;fp+=(not y) and p;fn+=y and not p
 return tp,fp,fn
counts={m:np.array([cnt(q,m) for q in qids],float) for m in models}
rng=np.random.default_rng(20260904);draws=rng.integers(0,len(qids),size=(10000,len(qids)))
def f1(c):
 x=c[draws].sum(axis=1);return 2*x[:,0]/np.maximum(2*x[:,0]+x[:,1]+x[:,2],1)
def obs(c):
 x=c.sum(axis=0);return 2*x[0]/max(2*x[0]+x[1]+x[2],1)
b=[]
for comp in ['tfidf','feature_full','posthoc_exact_and_unit']:
 d=f1(counts['bge_s1'])-f1(counts[comp]);p=min(1,2*min(float((d<=0).mean()),float((d>=0).mean())))
 b.append({'reference':'bge_s1','comparison':comp,'queries':100,'observed_difference':obs(counts['bge_s1'])-obs(counts[comp]),'bootstrap_mean_difference':float(d.mean()),'ci_low':float(np.quantile(d,.025)),'ci_high':float(np.quantile(d,.975)),'p_two_sided':p,'bootstrap_samples':10000,'seed':20260904})
with open(OUT+'/revise3_s1_feature_rule_bootstrap.csv','w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(b[0]));w.writeheader();w.writerows(b)
json.dump(b,open(OUT+'/revise3_s1_feature_rule_bootstrap.json','w'),indent=2)
# Relationship-level aggregation, within split and unordered semantic pair. Mean stored score, original threshold.
rel={}
for split in ['locked','external']:
 rr=[r for r in rows if r['evaluation_split']==split]
 groups=collections.defaultdict(list)
 for r in rr:groups[raw[r['pair_id']]['unordered_pair_key']].append(r)
 mixed_label=sum(len({x['final_label'] for x in g})>1 for g in groups.values());mixed_diff=sum(len({x['difficulty'] for x in g})>1 for g in groups.values())
 rel[split]={'definition':'group rows within this split by unordered_pair_key; assign the common gold label and difficulty; average row scores; apply the original row-level threshold','relationships':len(groups),'mixed_label_groups':mixed_label,'mixed_difficulty_groups':mixed_diff,'models':{}}
 for m in models:
  hp=hn=hp_tp=hn_fp=0
  for key,g in groups.items():
   ys={int(x['final_label']) for x in g};ds={x['difficulty'].lower() for x in g}
   if len(ys)!=1 or len(ds)!=1:continue
   hard=next(iter(ds))=='hard';y=next(iter(ys));p=np.mean([score(x,m) for x in g])>=models[m][1]
   if hard and y:hp+=1;hp_tp+=p
   if hard and not y:hn+=1;hn_fp+=p
  rel[split]['models'][m]={'hard_positive_relationships':hp,'hard_positive_tp':int(hp_tp),'hard_positive_recall':float(hp_tp/hp) if hp else None,'hard_negative_relationships':hn,'hard_negative_fp':int(hn_fp),'hard_negative_fp_rate':float(hn_fp/hn) if hn else None}
json.dump(rel,open(OUT+'/revise3_relationship_aggregated_hard_metrics.json','w'),indent=2)
print(json.dumps({'rule':summary,'bootstrap':b,'relationship':rel},indent=2))
