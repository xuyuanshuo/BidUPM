#!/usr/bin/env python3
import csv,json,math
import numpy as np
ROOT='original_project/outputs/bidupm_server_results_20260905/extracted_evidence'
DATA=ROOT+'/data/FINAL_DATASET_READY'
OUT='research_workspace/tmp/revise3_routing_selected_2x2.json'
rows=list(csv.DictReader(open(ROOT+'/consolidated_final/all_model_pair_scores.csv',newline='')))
raw={}
for f in ['evaluation/validation_pairs.csv','evaluation/locked_pairs.csv','evaluation/external_mixed_pairs.csv','evaluation/no_reference_top30_pairs.csv','evaluation/no_reference_reclassified_positive_pairs.csv']:
 for r in csv.DictReader(open(DATA+'/'+f,newline='')):raw[r['pair_id']]=r
local_thr=-1.8046875;expert_thr=12.75;cutoff=-0.7556422569027611
val=np.array([r['evaluation_split']=='validation' for r in rows])
ls=np.array([float(r['score_bge_v2_m3_seed_20260904']) for r in rows])
validation_margin=ls[val]-local_thr
scale=max(float(np.median(np.abs(validation_margin))),1e-6)
flags=['action_conflict','material_conflict','dimension_conflict','class_conflict','type_conflict','spec_conflict']
priority=[]
for r,l in zip(rows,ls):
 z=raw[r['pair_id']]; conflict=max(float(z[c]) for c in flags);unit_mismatch=1-float(z['unit_match']);priority.append(-abs((l-local_thr)/scale)+.35*conflict+.35*unit_mismatch)
priority=np.array(priority);routed=priority>=cutoff
out={'policy':{'local_raw_threshold_selected_on_validation':local_thr,'independent_verifier_raw_threshold_selected_on_validation':expert_thr,'priority_scale_median_absolute_validation_margin':scale,'priority_cutoff_from_20pct_validation_budget':cutoff,'route_rule':'priority >= cutoff','fusion':'positive_rescue = max(robust local probability, robust verifier probability); final threshold 0.5'},'splits':{}}
for split in ['locked','external']:
 idx=np.array([r['evaluation_split']==split for r in rows]);sel=idx&routed
 cell={'local_correct_verifier_correct':0,'local_correct_verifier_wrong':0,'local_wrong_verifier_correct':0,'local_wrong_verifier_wrong':0}
 transitions={'local_correct_fusion_correct':0,'local_correct_fusion_wrong':0,'local_wrong_fusion_correct':0,'local_wrong_fusion_wrong':0,'local_pred_0_to_fusion_1':0,'local_pred_1_to_fusion_0':0,'fusion_prediction_unchanged':0,'expert_pred_0_to_fusion_1':0,'expert_pred_1_to_fusion_0':0,'fusion_correct_when_both_local_and_verifier_wrong':0}
 for i,r in enumerate(rows):
  if not sel[i]:continue
  y=int(r['final_label']);lp=float(r['score_bge_v2_m3_seed_20260904'])>=local_thr; ep=float(r['score_open_llm_verifier'])>=expert_thr;fp=float(r['score_routing_fixed_20pct'])>=.5
  lc=lp==y;ec=ep==y;fc=fp==y
  cell[('local_correct_' if lc else 'local_wrong_')+('verifier_correct' if ec else 'verifier_wrong')]+=1
  transitions[('local_correct_' if lc else 'local_wrong_')+('fusion_correct' if fc else 'fusion_wrong')]+=1
  if lp==fp:transitions['fusion_prediction_unchanged']+=1
  elif not lp and fp:transitions['local_pred_0_to_fusion_1']+=1
  else:transitions['local_pred_1_to_fusion_0']+=1
  if ep!=fp:
   transitions['expert_pred_0_to_fusion_1' if (not ep and fp) else 'expert_pred_1_to_fusion_0']+=1
  if (not lc) and (not ec) and fc:transitions['fusion_correct_when_both_local_and_verifier_wrong']+=1
 out['splits'][split]={'rows':int(idx.sum()),'routed_rows':int(sel.sum()),'routed_fraction':float(sel.sum()/idx.sum()),'selected_correctness_2x2':cell,'fusion_vs_local_on_selected':transitions,'selected_local_errors':cell['local_wrong_verifier_correct']+cell['local_wrong_verifier_wrong'],'selected_verifier_correct_on_local_errors':cell['local_wrong_verifier_correct'],'selected_verifier_wrong_on_local_correct':cell['local_correct_verifier_wrong']}
json.dump(out,open(OUT,'w'),indent=2);print(json.dumps(out,indent=2))
