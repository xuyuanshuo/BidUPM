#!/usr/bin/env python3
"""Document the TF-IDF floating-point boundary across two retained exports."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def threshold(path: Path) -> float:
    rows = read_rows(path)
    return float(
        next(
            row["threshold"]
            for row in rows
            if row["model"] == "tfidf" and row["policy"] == "f1_opt"
        )
    )


def metric(path: Path, split: str) -> dict[str, str]:
    return next(
        row
        for row in read_rows(path)
        if row["model"] == "tfidf"
        and row["policy"] == "f1_opt"
        and row["split"] == split
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--package-root", type=Path, default=Path(__file__).resolve().parents[2]
    )
    parser.add_argument("--output-dir", type=Path, default=None)
    args = parser.parse_args()
    root = args.package_root.resolve()
    output_dir = args.output_dir.resolve() if args.output_dir else root / "analysis_outputs"
    output_dir.mkdir(parents=True, exist_ok=True)

    classical_root = root / "scores/classical"
    consolidated_root = root / "scores/consolidated"
    classical_rows = read_rows(classical_root / "pair_scores.csv")
    consolidated_rows = read_rows(consolidated_root / "all_model_pair_scores.csv")
    consolidated_by_id = {row["pair_id"]: row for row in consolidated_rows}
    classical_threshold = threshold(classical_root / "validation_thresholds.csv")
    consolidated_threshold = threshold(
        consolidated_root / "all_models/validation_thresholds.csv"
    )

    changed_score_rows = 0
    maximum_difference = 0.0
    flipped = []
    for row in classical_rows:
        other = consolidated_by_id[row["pair_id"]]
        score_classical = float(row["score_tfidf"])
        score_consolidated = float(other["score_tfidf"])
        difference = abs(score_classical - score_consolidated)
        if difference:
            changed_score_rows += 1
            maximum_difference = max(maximum_difference, difference)
        prediction_classical = int(score_classical >= classical_threshold)
        prediction_consolidated = int(score_consolidated >= consolidated_threshold)
        if row["evaluation_split"] == "locked" and prediction_classical != prediction_consolidated:
            flipped.append(
                {
                    "pair_id": row["pair_id"],
                    "query_id": row["query_id"],
                    "candidate_id": row["candidate_id"],
                    "final_label": row["final_label"],
                    "difficulty": row["difficulty"],
                    "classical_score": row["score_tfidf"],
                    "classical_threshold": format(classical_threshold, ".17g"),
                    "classical_prediction": prediction_classical,
                    "consolidated_score": other["score_tfidf"],
                    "consolidated_threshold": format(consolidated_threshold, ".17g"),
                    "consolidated_prediction": prediction_consolidated,
                }
            )

    csv_path = output_dir / "tfidf_export_precision_boundary_audit.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(flipped[0]))
        writer.writeheader()
        writer.writerows(flipped)

    classical_locked = metric(classical_root / "metrics.csv", "locked")
    consolidated_locked = metric(
        consolidated_root / "all_models/metrics.csv", "locked"
    )
    result = {
        "scope": "floating-point serialization sensitivity; no gold labels changed",
        "paper_authoritative_source": "scores/consolidated/all_models",
        "retained_original_source": "scores/classical",
        "pair_score_rows": len(classical_rows),
        "pair_score_rows_with_nonzero_float_difference": changed_score_rows,
        "maximum_absolute_score_difference": maximum_difference,
        "classical_threshold": classical_threshold,
        "consolidated_threshold": consolidated_threshold,
        "locked_prediction_flips": len(flipped),
        "flipped_pair_ids": [row["pair_id"] for row in flipped],
        "classical_locked": {
            key: classical_locked[key]
            for key in ("tp", "tn", "fp", "fn", "pair_precision", "pair_recall", "pair_f1")
        },
        "consolidated_locked": {
            key: consolidated_locked[key]
            for key in ("tp", "tn", "fp", "fn", "pair_precision", "pair_recall", "pair_f1")
        },
        "interpretation": (
            "The paper and S1--S3 use the consolidated export consistently. The original "
            "classical export is retained for provenance and must not be substituted silently "
            "for paper metrics at this numerical boundary."
        ),
    }
    json_path = output_dir / "tfidf_export_precision_boundary_audit.json"
    json_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(csv_path)
    print(json_path)


if __name__ == "__main__":
    main()
