#!/usr/bin/env python3
from pathlib import Path
import shutil, json, csv, hashlib, os
WS=Path('research_workspace')
DEST=WS/'output/revise3_full_20260920/supplementary'
DATA=Path('original_project/outputs/bidupm_server_results_20260905/extracted_evidence/data/FINAL_DATASET_READY')
EVID=Path('original_project/outputs/bidupm_server_results_20260905/extracted_evidence')
CLASS=Path('original_project/outputs/bidupm_final_local_experiments_20260904/classical')
BUILD=Path('original_project/BidUPM_vFinal_rebuild_20260816/scripts')
TMP=WS/'tmp'
for d in ['tables','data/canonical','data/training','data/evaluation','data/annotation/source_submissions','data/provenance','scores/consolidated','scores/classical','configs/run_manifests','scripts/original','scripts/analysis','analysis_outputs']:
 (DEST/d).mkdir(parents=True,exist_ok=True)
def cp(src,rel):
 src=Path(src); dst=DEST/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
# Manuscript-facing supplementary tables.
cp(EVID/'consolidated_final/all_models/metrics.csv','tables/S1_complete_split_metrics.csv')
cp(EVID/'consolidated_final/all_models/safety_metrics.csv','tables/S2_safety_outcomes.csv')
cp(EVID/'consolidated_final/all_models/validation_thresholds.csv','tables/S3_validation_selected_thresholds.csv')
# Canonical, frozen data and double-human annotation records.
for f in ['pairs/all_pairs_vfinal_12092.csv','pairs/hard_positive_supplement_92.csv']:
 cp(DATA/f,'data/canonical/'+Path(f).name)
cp(DATA/'BidUPM_vFinal_数据修复终稿.xlsx','data/canonical/BidUPM_vFinal_数据修复终稿.xlsx')
for f in ['training/training_pairs_all_rows.csv','training/training_pairs_semantic_deduplicated.csv','training/reranker_train_human_labeled_plus_hard.jsonl']:
 cp(DATA/f,'data/training/'+Path(f).name)
for name in ['validation_pairs.csv','locked_pairs.csv','external_mixed_pairs.csv','no_reference_top30_pairs.csv','no_reference_reclassified_positive_pairs.csv']:
 cp(DATA/'evaluation'/name,'data/evaluation/'+name)
for name in ['all_review_units_vfinal.csv','all_review_members_vfinal.csv','final_adjudication_964.csv','hard_positive_final_92.csv','hard_positive_two_pass_review_history.csv']:
 cp(DATA/'review'/name,'data/annotation/'+name)
for f in sorted((DATA/'provenance/source_submissions').glob('*.xlsx')):
 if not f.name.startswith('._'): cp(f,'data/annotation/source_submissions/'+f.name)
for name in ['split_manifest.csv','source_manifest.csv']:
 cp(DATA/'provenance'/name,'data/provenance/'+name)
for name in ['annotation_summary.json','split_summary.csv','dataset_audit.json','dataset_audit.csv','dataset_audit.md','no_reference_protocol.json','core_label_corrections.csv','training_rows_excluded_for_eval_overlap.csv','workbook_verification.ndjson']:
 cp(DATA/'quality'/name,'data/provenance/'+name)
cp(DATA/'manifest.json','configs/dataset_manifest.json')
cp(DATA/'README.md','data/DATASET_README_original.md')
cp(TMP/'revise3_used_source_manifest.csv','data/provenance/used_source_manifest_42_files.csv')
cp(TMP/'revise3_source_completeness_audit.json','data/provenance/source_completeness_audit.json')
# Consolidated and classical predictions/results.
for src in (EVID/'consolidated_final').rglob('*'):
 if src.is_file() and not src.name.startswith('._'):
  cp(src,'scores/consolidated/'+str(src.relative_to(EVID/'consolidated_final')))
for src in CLASS.glob('*'):
 if src.is_file() and not src.name.startswith('._'):
  cp(src,'scores/classical/'+src.name)
# Run configurations and compact per-run histories/metrics. Deliberately omit checkpoints and duplicate pair-score files.
for run in sorted((EVID/'results').iterdir()):
 if not run.is_dir(): continue
 for name in ['manifest.json','training_history.csv','metrics.csv','safety_metrics.csv','validation_thresholds.csv','runtime.json']:
  if (run/name).exists():cp(run/name,f'configs/run_manifests/{run.name}/{name}')
# Original reproducibility scripts.
orig_scripts=[
 EVID/'scripts/local_experiment_utils.py',EVID/'scripts/run_classical_local.py',EVID/'scripts/run_embedding_local.py',EVID/'scripts/run_cross_encoder_local.py',EVID/'scripts/run_qwen_reranker.py',EVID/'scripts/run_open_llm_verifier.py',EVID/'scripts/consolidate_server_results.py',EVID/'scripts/consolidate_local_results.py',EVID/'scripts/audit_server_results.py',
 BUILD/'build_vfinal.py',BUILD/'bidupm_vfinal_common.py',BUILD/'audit_vfinal.py',BUILD/'prepare_domain_reranker_data.py']
for f in orig_scripts:
 if f.exists():cp(f,'scripts/original/'+f.name)
# Focused audit scripts and outputs.
analysis_scripts=['revise3_metrics_analysis.py','revise3_posthoc_rule_bootstrap.py','revise3_routing_2x2.py','rebuild_used_source_manifest.py']
for name in analysis_scripts:
 if (TMP/name).exists():cp(TMP/name,'scripts/analysis/'+name)
analysis_outputs=['revise3_metrics_summary.json','revise3_metrics_summary.csv','revise3_pairwise_changes.csv','revise3_prediction_changes.json','revise3_seed_positive_flips.csv','revise3_hardfocused_locked_14_errors.csv','revise3_posthoc_exact_unit_rule.json','revise3_posthoc_exact_unit_rule.csv','revise3_s1_feature_rule_bootstrap.csv','revise3_s1_feature_rule_bootstrap.json','revise3_relationship_aggregated_hard_metrics.json','revise3_metric_method_audit.json','revise3_routing_selected_2x2.json','revise3_source_manifest_pair_audit.csv','revise3_source_manifest_pair_audit.json']
for name in analysis_outputs:
 if (TMP/name).exists():cp(TMP/name,'analysis_outputs/'+name)
print('staged',DEST)
