#!/usr/bin/env python3
"""Recompute key frozen metrics and routing diagnostics from this package only."""
from __future__ import annotations
import argparse,csv,json,math,statistics
from pathlib import Path

def read_csv(path):
    with path.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def div(a,b):return a/b if b else 0.0
def summarize(rows, score_getter, threshold):
    tp=tn=fp=fn=htp=htn=hfp=hfn=0; queries={}
    for r in rows:
        y=int(r['final_label']); p=score_getter(r)>=threshold; hard=r['difficulty'].lower()=='hard'
        tp+=bool(y and p);tn+=bool((not y) and (not p));fp+=bool((not y) and p);fn+=bool(y and (not p))
        if hard:
            htp+=bool(y and p);htn+=bool((not y) and (not p));hfp+=bool((not y) and p);hfn+=bool(y and (not p))
        queries.setdefault(r['query_id'],[]).append((y,p))
    posq=[v for v in queries.values() if any(y for y,p in v)]; noq=[v for v in queries.values() if not any(y for y,p in v)]
    return {'rows':len(rows),'tp':tp,'tn':tn,'fp':fp,'fn':fn,'precision':div(tp,tp+fp),'recall':div(tp,tp+fn),'f1':div(2*tp,2*tp+fp+fn),'hard_tp':htp,'hard_tn':htn,'hard_fp':hfp,'hard_fn':hfn,'hard_f1':div(2*htp,2*htp+hfp+hfn),'queries':len(queries),'positive_queries':len(posq),'positive_queries_with_valid_accept':sum(any(y and p for y,p in v) for v in posq),'no_reference_queries':len(noq),'unsafe_no_reference_queries':sum(any(p for y,p in v) for v in noq)}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path);args=ap.parse_args();root=args.package_root.resolve();out=args.output or root/'analysis_outputs/recomputed_key_metrics.json'
    scores=read_csv(root/'scores/consolidated/all_model_pair_scores.csv'); byid={r['pair_id']:r for r in scores}
    raw=[]; data_files={}
    for name in ['validation_pairs.csv','locked_pairs.csv','external_mixed_pairs.csv','no_reference_top30_pairs.csv','no_reference_reclassified_positive_pairs.csv']:
        data_files[name]=read_csv(root/'data/evaluation'/name);raw.extend(data_files[name])
    rawid={r['pair_id']:r for r in raw}
    class_rows=read_csv(root/'scores/classical/pair_scores.csv');classid={r['pair_id']:r for r in class_rows}
    th={r['model']:float(r['threshold']) for r in read_csv(root/'tables/S3_validation_selected_thresholds.csv') if r['policy']=='f1_opt'}
    cth={r['model']:float(r['threshold']) for r in read_csv(root/'scores/classical/validation_thresholds.csv') if r['policy']=='f1_opt'}
    models={
      'tfidf':(lambda r:float(byid[r['pair_id']]['score_tfidf']),th['tfidf']),
      'bge_zero':(lambda r:float(byid[r['pair_id']]['score_bge_v2_m3_zero_shot']),th['bge_v2_m3_zero_shot']),
      'bge_standard_s1':(lambda r:float(byid[r['pair_id']]['score_bge_v2_m3_seed_20260904']),th['bge_v2_m3_seed_20260904']),
      'bge_standard_s2':(lambda r:float(byid[r['pair_id']]['score_bge_v2_m3_seed_20260905']),th['bge_v2_m3_seed_20260905']),
      'bge_standard_s3':(lambda r:float(byid[r['pair_id']]['score_bge_v2_m3_seed_20260906']),th['bge_v2_m3_seed_20260906']),
      'bge_score_ensemble':(lambda r:float(byid[r['pair_id']]['score_bge_v2_m3_three_seed_mean']),th['bge_v2_m3_three_seed_mean']),
      'bge_hard_focused':(lambda r:float(byid[r['pair_id']]['score_bge_v2_m3_hard_refined']),th['bge_v2_m3_hard_refined']),
      'supervised_feature_full':(lambda r:float(classid[r['pair_id']]['score_feature_full']),cth['feature_full']),
      'posthoc_exact_and_unit':(lambda r:float(int(float(r['exact_description'])==1 and float(r['unit_match'])==1)),1.0),
    }
    split_rows={'locked':data_files['locked_pairs.csv'],'external':data_files['external_mixed_pairs.csv'],'no_reference':[r for r in data_files['no_reference_top30_pairs.csv'] if r['pair_id'].startswith('NOR') and r['split_final']=='no_reference']}
    result={'package_root':str(root),'threshold_policy':'original validation-selected f1_opt; posthoc rule has fixed threshold 1 and no tuning','metrics':{s:{m:summarize(rr,*cfg) for m,cfg in models.items()} for s,rr in split_rows.items()}}
    # Rebuild the reported fixed routing mask and selected-sample correctness table.
    policy=json.load(open(root/'scores/consolidated/routing_policy.json'))['fixed_policy'];local_thr=th['bge_v2_m3_seed_20260904'];expert_thr=th['open_llm_verifier'];val=data_files['validation_pairs.csv'];scale=max(statistics.median(abs(float(byid[r['pair_id']]['score_bge_v2_m3_seed_20260904'])-local_thr) for r in val),1e-6);flags=['action_conflict','material_conflict','dimension_conflict','class_conflict','type_conflict','spec_conflict']
    route={}
    for split in ['locked','external']:
        cell={'local_correct_verifier_correct':0,'local_correct_verifier_wrong':0,'local_wrong_verifier_correct':0,'local_wrong_verifier_wrong':0};trans={'local_wrong_fusion_correct':0,'local_correct_fusion_wrong':0,'fusion_unchanged':0};n=0
        for r in split_rows[split]:
            pid=r['pair_id'];ls=float(byid[pid]['score_bge_v2_m3_seed_20260904']);priority=-abs((ls-local_thr)/scale)+.35*max(float(r[x]) for x in flags)+.35*(1-float(r['unit_match']))
            if priority<policy['priority_cutoff']:continue
            n+=1;y=int(r['final_label']);lp=ls>=local_thr;ep=float(byid[pid]['score_open_llm_verifier'])>=expert_thr;fp=float(byid[pid]['score_routing_fixed_20pct'])>=policy['validation_threshold'];lc=lp==y;ec=ep==y;fc=fp==y;cell[('local_correct_' if lc else 'local_wrong_')+('verifier_correct' if ec else 'verifier_wrong')]+=1
            if (not lc) and fc:trans['local_wrong_fusion_correct']+=1
            if lc and not fc:trans['local_correct_fusion_wrong']+=1
            if lp==fp:trans['fusion_unchanged']+=1
        route[split]={'routed_rows':n,'correctness_2x2':cell,'fusion_changes':trans}
    result['routing_fixed_20pct']=route
    # Frozen audit assertions protect against accidental file mixing.
    expected={('locked','bge_standard_s1'):(274,8,9),('locked','bge_hard_focused'):(274,5,9),('external','bge_hard_focused'):(145,0,3)}
    for (s,m),v in expected.items():
        got=result['metrics'][s][m];assert (got['tp'],got['fp'],got['fn'])==v,(s,m,got,v)
    assert route['locked']['routed_rows']==584 and route['external']['routed_rows']==1103
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8');print(out)
if __name__=='__main__':main()
