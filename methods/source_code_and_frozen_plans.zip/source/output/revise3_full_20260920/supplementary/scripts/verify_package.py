#!/usr/bin/env python3
import argparse,csv,hashlib
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parents[1]);args=ap.parse_args();root=args.package_root.resolve();manifest=root/'MANIFEST_SHA256.csv';bad=[];n=0
with manifest.open(newline='',encoding='utf-8') as f:
 for r in csv.DictReader(f):
  p=root/r['relative_path'];n+=1
  if not p.is_file():bad.append((r['relative_path'],'missing'));continue
  h=hashlib.sha256()
  with p.open('rb') as x:
   for b in iter(lambda:x.read(1024*1024),b''):h.update(b)
  if h.hexdigest()!=r['sha256']:bad.append((r['relative_path'],'hash mismatch'))
print(f'checked={n} failures={len(bad)}')
for x in bad:print(*x)
raise SystemExit(1 if bad else 0)
