# Token 长度审计复现

`run_token_audit.py` 使用补充包中的冻结配对、原实验脚本中的完整提示词，以及四个固定 revision 的 tokenizer，复算 BGE、两种 Qwen reranker 和 verifier 的完整输入长度。它不下载模型权重，不训练模型，也不修改任何标签或预测。

## 依赖

建议在独立虚拟环境中安装：

```bash
python3 -m pip install -r scripts/token_audit/requirements.txt
```

核心复算依赖是 `tokenizers` 和 `jinja2`；`certifi` 为 Python 网络下载提供 CA 证书。下载使用 Python 标准库，不依赖 Hugging Face Hub 客户端。

## 首次联网下载

首次运行需要访问 `https://huggingface.co`，只下载以下固定 revision 的 `tokenizer.json`，Qwen 模型还会下载 `tokenizer_config.json`：

- `BAAI/bge-reranker-v2-m3` @ `953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e`
- `Qwen/Qwen3-Reranker-0.6B` @ `e61197ed45024b0ed8a2d74b80b4d909f1255473`
- `Qwen/Qwen3-Reranker-4B` @ `22e683669bc0f0bd69640a1354a6d0aebcfeede5`
- `Qwen/Qwen3-4B-Instruct-2507` @ `cdbee75f17c01a7cc42f958dc650907174af0554`

默认缓存位于 `~/.cache/bidupm_token_audit/`。下载完成后可在同一缓存上离线重复运行。可用 `--cache-dir` 指定已有或新的 tokenizer 缓存位置。

## 运行

在补充包根目录运行：

```bash
python3 scripts/token_audit/run_token_audit.py --package-root . --output-dir /tmp/bidupm_token_audit
```

冻结输出位于 `analysis_outputs/token_audit/`。复算结果应显示所有审计输入的 `over_256=0`；BGE 全部分割最大长度为 151，Qwen reranker 最大长度为 232，verifier 最大长度为 223。冻结 JSON 同时记录 tokenizer SHA-256，可用于确认下载文件一致。

`scripts/analysis/revise3_token_audit.py` 和 `scripts/analysis/revise3_qwen_audit.py` 是本次审计时使用的原始工作脚本副本，保留了原工作区路径，仅用于过程追溯；可移植复算入口是本目录的 `run_token_audit.py`。
