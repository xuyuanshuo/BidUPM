#!/usr/bin/env python3
"""Recompute the frozen BGE/Qwen token-length audits from package data.

The script downloads only tokenizer metadata/files at pinned revisions.  It does
not download model weights and does not alter labels or model predictions.
"""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import ssl
import urllib.request
from pathlib import Path

import certifi
from jinja2 import Environment
from tokenizers import Tokenizer


MODELS = {
    "bge": (
        "BAAI/bge-reranker-v2-m3",
        "953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e",
    ),
    "qwen06": (
        "Qwen/Qwen3-Reranker-0.6B",
        "e61197ed45024b0ed8a2d74b80b4d909f1255473",
    ),
    "qwen4": (
        "Qwen/Qwen3-Reranker-4B",
        "22e683669bc0f0bd69640a1354a6d0aebcfeede5",
    ),
    "verifier": (
        "Qwen/Qwen3-4B-Instruct-2507",
        "cdbee75f17c01a7cc42f958dc650907174af0554",
    ),
}


def arguments() -> argparse.Namespace:
    package_default = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, default=package_default)
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=Path.home() / ".cache" / "bidupm_token_audit",
        help="Tokenizer-only cache; model weights are never downloaded.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Default: <package-root>/analysis_outputs/token_audit/recomputed",
    )
    return parser.parse_args()


def constant_from_script(path: Path, name: str) -> str:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if any(isinstance(target, ast.Name) and target.id == name for target in targets):
            return ast.literal_eval(node.value)
    raise RuntimeError(f"Cannot find {name} in {path}")


def fetch(repo: str, revision: str, filename: str, destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        url = f"https://huggingface.co/{repo}/resolve/{revision}/{filename}"
        context = ssl.create_default_context(cafile=certifi.where())
        with urllib.request.urlopen(url, timeout=120, context=context) as response:
            destination.write_bytes(response.read())
    return destination


def load_tokenizer_files(cache_dir: Path):
    files = {}
    for key, (repo, revision) in MODELS.items():
        model_dir = cache_dir / key
        tokenizer_path = fetch(repo, revision, "tokenizer.json", model_dir / "tokenizer.json")
        config = None
        if key != "bge":
            config_path = fetch(
                repo, revision, "tokenizer_config.json", model_dir / "tokenizer_config.json"
            )
            config = json.loads(config_path.read_text(encoding="utf-8"))
        files[key] = (tokenizer_path, config)
    return files


def normalized(value: str) -> str:
    return " ".join((value or "").strip().lower().split())


def item_text(row: dict[str, str], side: str) -> str:
    fields = [
        normalized(row[f"{side}_{key}"])
        for key in (
            "description",
            "normalized_description",
            "normalized_unit",
            "category",
            "spec_tokens",
        )
    ]
    return (
        f"Description: {fields[0]}. Normalized: {fields[1]}. "
        f"Pay unit: {fields[2]}. Category: {fields[3]}. Specs: {fields[4]}."
    )


def percentile(sorted_values: list[int], quantile: float) -> int:
    return sorted_values[round((len(sorted_values) - 1) * quantile)]


def summarize(lengths: list[int], include_p99: bool) -> dict[str, object]:
    values = sorted(lengths)
    output: dict[str, object] = {
        "rows": len(values),
        "p50": percentile(values, 0.50),
        "p95": percentile(values, 0.95),
    }
    if include_p99:
        output["p99"] = percentile(values, 0.99)
    output.update(
        {
            "max": max(values),
            "over_256": sum(value > 256 for value in values),
            "over_256_fraction": sum(value > 256 for value in values) / len(values),
        }
    )
    return output


def load_splits(package_root: Path):
    canonical = package_root / "data/canonical/all_pairs_vfinal_12092.csv"
    training = package_root / "data/training/training_pairs_semantic_deduplicated.csv"
    with canonical.open(newline="", encoding="utf-8-sig") as handle:
        all_rows = list(csv.DictReader(handle))
    with training.open(newline="", encoding="utf-8-sig") as handle:
        train_rows = list(csv.DictReader(handle))
    splits = {"training_distinct": train_rows}
    for split in ("validation", "locked", "no_reference", "external"):
        splits[split] = [row for row in all_rows if row["split_final"] == split]
    return splits


def audit_bge(tokenizer_path: Path, splits) -> dict[str, object]:
    tokenizer = Tokenizer.from_file(str(tokenizer_path))
    tokenizer.no_padding()
    tokenizer.no_truncation()
    output = {}
    for split, rows in splits.items():
        lengths = [
            len(tokenizer.encode(item_text(row, "query"), item_text(row, "candidate")).ids)
            for row in rows
        ]
        output[split] = summarize(lengths, include_p99=True)
    return {
        "model": MODELS["bge"][0],
        "revision": MODELS["bge"][1],
        "tokenizer_sha256": hashlib.sha256(tokenizer_path.read_bytes()).hexdigest(),
        "method": (
            "Full serialized query/candidate pairs including tokenizer special tokens; "
            "no padding or truncation during audit. Runtime max_length=256 uses tokenizer "
            "longest-first pair truncation."
        ),
        "splits": output,
    }


def audit_qwen(
    key: str,
    tokenizer_path: Path,
    config: dict[str, object],
    splits,
    instruction: str,
    verifier_system: str,
) -> dict[str, object]:
    tokenizer = Tokenizer.from_file(str(tokenizer_path))
    tokenizer.no_padding()
    tokenizer.no_truncation()

    def encode(text: str) -> list[int]:
        return tokenizer.encode(text, add_special_tokens=False).ids

    prefix = (
        '<|im_start|>system\nJudge whether the Document meets the requirements based on '
        'the Query and the Instruct provided. Note that the answer can only be "yes" or '
        '"no".<|im_end|>\n<|im_start|>user\n'
    )
    suffix = "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
    split_output = {}
    for split, rows in splits.items():
        if key == "verifier" and split == "training_distinct":
            continue
        lengths = []
        truncated_tails = []
        for row in rows:
            query = item_text(row, "query")
            candidate = item_text(row, "candidate")
            if key == "verifier":
                user = (
                    f"Query bid item:\n{query}\n\nHistorical candidate:\n{candidate}\n\n"
                    "Can this candidate safely serve as a unit-price reference for the query?"
                )
                prompt = Environment(trim_blocks=True, lstrip_blocks=True).from_string(
                    config["chat_template"]
                ).render(
                    messages=[
                        {"role": "system", "content": verifier_system},
                        {"role": "user", "content": user},
                    ],
                    add_generation_prompt=True,
                    enable_thinking=False,
                    tools=None,
                    bos_token=config.get("bos_token"),
                    eos_token=config.get("eos_token"),
                )
                ids = encode(prompt)
                lengths.append(len(ids))
                if len(ids) > 256:
                    truncated_tails.append(tokenizer.decode(ids[256:]))
            else:
                content = (
                    f"<Instruct>: {instruction}\n<Query>: {query}\n<Document>: {candidate}"
                )
                ids = encode(content)
                available = 256 - len(encode(prefix)) - len(encode(suffix))
                lengths.append(len(ids) + 256 - available)
                if len(ids) > available:
                    truncated_tails.append(tokenizer.decode(ids[available:]))
        stats = summarize(lengths, include_p99=False)
        stats["truncated_tails_examples"] = truncated_tails[:3]
        split_output[split] = stats
    return {
        "repo": MODELS[key][0],
        "revision": MODELS[key][1],
        "tokenizer_sha256": hashlib.sha256(tokenizer_path.read_bytes()).hexdigest(),
        "truncation_side": config.get("truncation_side", "right(default)"),
        "splits": split_output,
    }


def main() -> None:
    args = arguments()
    package_root = args.package_root.resolve()
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir
        else package_root / "analysis_outputs/token_audit/recomputed"
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    files = load_tokenizer_files(args.cache_dir.expanduser().resolve())
    splits = load_splits(package_root)

    original_scripts = package_root / "scripts/original"
    instruction = constant_from_script(original_scripts / "run_qwen_reranker.py", "DEFAULT_INSTRUCTION")
    verifier_system = constant_from_script(
        original_scripts / "run_open_llm_verifier.py", "SYSTEM_PROMPT"
    )

    bge = audit_bge(files["bge"][0], splits)
    qwen = {
        key: audit_qwen(
            key,
            files[key][0],
            files[key][1],
            splits,
            instruction,
            verifier_system,
        )
        for key in ("qwen06", "qwen4", "verifier")
    }
    bge_path = output_dir / "revise3_token_lengths.json"
    qwen_path = output_dir / "revise3_qwen_token_lengths.json"
    bge_path.write_text(json.dumps(bge, indent=2) + "\n", encoding="utf-8")
    qwen_path.write_text(json.dumps(qwen, indent=2) + "\n", encoding="utf-8")
    print(bge_path)
    print(qwen_path)


if __name__ == "__main__":
    main()
