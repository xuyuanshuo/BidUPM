# 运行环境摘要

冻结 server reranker 与 prompt-verifier 运行记录对应：

- Python 3
- PyTorch 2.8.0
- CUDA 12.8
- Transformers 4.57.6
- PEFT 0.20.0
- GPU: NVIDIA GeForce RTX 4090
- neural evaluation dtype: bfloat16

本地 embedding 基线记录对应：

- Sentence-Transformers 3.4.1
- Apple MPS backend

传统基线和包内快速核验脚本只需常规 Python；`scripts/run_package_analysis.py` 仅使用标准库。逐次实际设置以 `configs/run_manifests/<run>/manifest.json` 为准。

独立 token 长度审计入口 `scripts/token_audit/run_token_audit.py` 需要 `tokenizers>=0.23,<0.24`、`jinja2>=3.1,<4` 与 `certifi>=2025.0`。首次复算仅联网下载固定 revision 的 tokenizer 文件；不需要 PyTorch、Transformers 或模型权重。
