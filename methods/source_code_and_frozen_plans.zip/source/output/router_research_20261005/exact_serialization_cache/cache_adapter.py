"""Frozen exact-input score-cache design. CPU-only; contains no model loader.

The callback defines a new canonical scoring regime unless its batch context is
part of the namespace. Never assume BF16 pair-only caching preserves an earlier
batch-dependent run. Acceptance thresholds deliberately stay outside score keys.
"""
from __future__ import annotations

from collections.abc import Callable, Sequence
import hashlib
import json
import math
from dataclasses import dataclass


def canonical_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha256_json(value: object) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def serialized_pair_key(query: str, candidate: str) -> str:
    """Length-safe ordered pair: no concatenation ambiguity or fuzzy matching."""
    return sha256_json([query, candidate])


@dataclass(frozen=True)
class CacheNamespace:
    model_name: str
    checkpoint_manifest_sha256: str
    tokenizer_manifest_sha256: str
    input_variant: str
    serializer_sha256: str
    model_configuration: dict
    runtime_configuration: dict
    scoring_regime: str

    def identity(self) -> dict:
        data = dict(self.__dict__)
        if not all(data[k] for k in (
            "model_name", "checkpoint_manifest_sha256", "tokenizer_manifest_sha256",
            "input_variant", "serializer_sha256", "scoring_regime",
        )):
            raise ValueError("Every model/checkpoint/tokenizer/input/serializer/regime identity is required")
        for k in ("checkpoint_manifest_sha256", "tokenizer_manifest_sha256", "serializer_sha256"):
            if len(data[k]) != 64 or any(c not in "0123456789abcdef" for c in data[k]):
                raise ValueError("Identity hashes must be lowercase SHA256 hex")
        if not self.model_configuration or not self.runtime_configuration:
            raise ValueError("Frozen model and runtime configurations are required")
        forbidden = {"threshold", "acceptance_threshold", "decision_threshold"}
        if forbidden.intersection(self.model_configuration) or forbidden.intersection(self.runtime_configuration):
            raise ValueError("Acceptance thresholds belong to decision logic, outside the score cache")
        canonical_json(data)
        return data


def score_key(namespace: CacheNamespace, query: str, candidate: str,
              numerical_context: dict | None = None) -> str:
    return sha256_json({"schema": "exact-score-cache-v1", "namespace": namespace.identity(),
                        "ordered_serialized_pair": [query, candidate],
                        "numerical_context": numerical_context})


def unique_pairs_and_inverse(pairs: Sequence[tuple[str, str]]) -> tuple[list[tuple[str, str]], list[int]]:
    # Dictionary equality uses the original strings, so SHA256 collisions cannot
    # silently merge different serialized pairs during in-memory deduplication.
    positions: dict[tuple[str, str], int] = {}
    unique: list[tuple[str, str]] = []
    inverse: list[int] = []
    for pair in pairs:
        if pair not in positions:
            positions[pair] = len(unique)
            unique.append(pair)
        inverse.append(positions[pair])
    return unique, inverse


def design_score_and_scatter(pairs: Sequence[tuple[str, str]], namespace: CacheNamespace,
                             cache: dict, score_unique: Callable,
                             numerical_context: dict | None = None) -> list[float]:
    """Executable adapter specification, not an executed GPU acceleration result.

    A production scorer MUST score every pair separately at fixed token length.
    This changed regime must pass real-GPU agreement checks before deployment.
    Cache records retain original strings as a collision/integrity check.
    """
    if namespace.scoring_regime != "canonical_single_pair_v1":
        raise ValueError("Pair-only adapter requires the explicit canonical single-pair scoring regime")
    if namespace.runtime_configuration.get("batch_size") != 1 or namespace.runtime_configuration.get("padding") != "max_length":
        raise ValueError("Pair-only adapter requires batch size 1 and fixed max-length padding")
    unique, inverse = unique_pairs_and_inverse(pairs)
    keys = [score_key(namespace, q, c, numerical_context) for q, c in unique]
    misses = [i for i, key in enumerate(keys) if key not in cache]
    if misses:
        scores = list(score_unique([unique[i] for i in misses]))
        if len(scores) != len(misses):
            raise ValueError("Scorer returned an incorrect output count")
        staged = []
        for i, value in zip(misses, scores):
            value = float(value)
            if not math.isfinite(value):
                raise ValueError("Never cache nonfinite or missing model scores")
            staged.append((keys[i], {"pair": list(unique[i]), "score": value}))
        cache.update(staged)
    restored = []
    for i, key in enumerate(keys):
        record = cache[key]
        if record["pair"] != list(unique[i]) or not math.isfinite(float(record["score"])):
            raise ValueError("Cache collision or corrupt cache record")
        restored.append(float(record["score"]))
    return [restored[i] for i in inverse]


def strict_batch_replay(pairs: Sequence[tuple[str, str]], namespace: CacheNamespace,
                        cache: dict, score_full_batch: Callable,
                        tensor_context: dict) -> list[float]:
    """Cache whole original-batch executions, preserving row and tensor context.

    A miss scores the complete original batch. It never deduplicates within a
    batch or constructs a shorter miss batch. This provides a conservative
    replay cache, with different reuse opportunities from the pair census.
    """
    if namespace.scoring_regime != "strict_original_batch_context_v1":
        raise ValueError("Strict replay requires its explicit scoring regime")
    required = {"model_input_tensors_sha256", "input_ids_sha256", "attention_mask_sha256", "tensor_shapes", "padding_policy"}
    if not required <= set(tensor_context):
        raise ValueError("Strict cache needs effective tokenizer tensor identity and shape context")
    context = {"ordered_batch_pairs": [list(pair) for pair in pairs], "tensor_context": tensor_context}
    keys = [score_key(namespace, q, c, {**context, "row_position": i}) for i, (q, c) in enumerate(pairs)]
    if not all(key in cache for key in keys):
        scores = list(score_full_batch(list(pairs)))
        if len(scores) != len(pairs) or not all(math.isfinite(float(v)) for v in scores):
            raise ValueError("Invalid full-batch score output")
        cache.update((key, {"pair": list(pair), "score": float(score)})
                     for key, pair, score in zip(keys, pairs, scores))
    result = []
    for key, pair in zip(keys, pairs):
        record = cache[key]
        if record["pair"] != list(pair) or not math.isfinite(float(record["score"])):
            raise ValueError("Cache collision or corrupt cache record")
        result.append(float(record["score"]))
    return result


def threshold_decisions(scores: Sequence[float], threshold: float) -> list[int]:
    threshold = float(threshold)
    if not math.isfinite(threshold):
        raise ValueError("Threshold must be finite")
    return [int(float(score) >= threshold) for score in scores]
