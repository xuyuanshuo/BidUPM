#!/usr/bin/env python3
"""CPU-only static plus synthetic audit; no labels, SSH, torch or real GPU."""
import ast,hashlib,importlib.util,json,tempfile,time
from pathlib import Path
from types import SimpleNamespace
from collections import Counter
import numpy as np,pandas as pd

HERE=Path(__file__).resolve().parent
WORK=HERE.parents[2]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    runner=HERE/'run_canonical_bucket_cache_gpu.py';planpath=HERE/'canonical_bucket_gpu_plan.json';plan=json.loads(planpath.read_text());source=runner.read_text();tree=ast.parse(source);m=load('cache_runner_audit',runner)
    checks=[]
    def check(ok,name):
        assert bool(ok),name
        checks.append(name)
    check(sha(runner)==plan['file_sha256']['runner'],'runner matches frozen SHA')
    args=SimpleNamespace(frozen_plan=planpath,policy=WORK/'output/rule_first_system_validation_20261005/scripts/system_policy.py',gate_dir=HERE.parent/'generic_unit_gate',source=WORK/'output/rule_first_system_20261004/results/server',supplement=WORK/'output/paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs',output=HERE/'independent_review_never_created')
    sm,frozen,frames,policy,gate,cpu=m.prepare_inputs(args)
    check(not args.output.exists(),'CPU preflight creates no actual output directory')
    check(cpu['new_gpu_inference_executed'] is False and cpu['labels_read'] is False,'CPU preflight has no model or labels')
    check(m.BATCH==plan['batch_size']==64 and m.BUCKET_WIDTH==plan['bucket_width']==32 and m.MAX_LENGTH==plan['max_length']==256,'fixed scoring shape contract')
    check(len(m.CONDITIONS)==4 and tuple(plan['conditions'])==m.CONDITIONS,'four frozen conditions')
    grid={(ds,int(run['seed']),condition,repeat) for ds in frames for run in sm['runs'] for condition in m.CONDITIONS for repeat in range(3 if ds=='main220' else 1)}
    check(len(grid)==plan['planned_timing_rows']==60,'60 timing grid')
    check({int(r['seed']):float(r['threshold']) for r in sm['runs']}==m.THRESHOLDS,'all three inherited thresholds')
    check(sum(len(f)*4*(3 if name=='main220' else 1)*3 for name,f in frames.items())==1056420,'complete prediction/mapping row count expectation')
    check(3*(3*2+2*4)+2*3*2==54,'expected complete cache/repeat agreement rows')
    check([m.bucket_length(n) for n in [1,32,33,64,65,255,256]]==[32,32,64,64,96,256,256],'fixed 32-token bucket boundaries')
    pairs=[('a','b'),('a','b'),('b','a'),('c','d')];u,inverse,reps=m.stable_unique_pairs(pairs)
    check(u==[('a','b'),('b','a'),('c','d')] and inverse.tolist()==[0,0,1,2] and reps.tolist()==[0,2,3],'stable exact ordered pair inverse and representatives')
    check(m.cache_key('namespace',('a','b'),32)!=m.cache_key('namespace',('b','a'),32),'cache key binds ordered pair')
    check(m.cache_key('namespace',('a','b'),32)!=m.cache_key('namespace',('a','b'),64),'cache key binds fixed tensor bucket')
    check(m.cache_key('namespace',('a','b'),32)!=m.cache_key('other',('a','b'),32),'cache key binds model/runtime namespace')
    check("'namespace_file': namespace_path.name" in source and "'namespace_file_sha256': sha(namespace_path)" in source,'namespace output records filename and byte SHA as well as semantic digest')
    records=[]
    for name,f in frames.items():
        p=list(zip(policy.serialize(f,'query'),policy.serialize(f,'candidate')));exact=policy.exact_mask(f);dimension=np.asarray(gate.dimension_conflict_mask(f),bool);called=~exact&~dimension
        check(not np.any(exact&dimension),name+' exact and dimension never overlap')
        check(f.pair_id.nunique()==len(f),name+' complete unique pair IDs')
        if name!='challenge600':check(not f[['evaluation_split','query_id','candidate_id']].duplicated().any(),name+' unique original query candidate metadata')
        else:check('query_id' not in f,name+' has no invented query pool')
        records.append({'dataset':name,'rows':len(f),'full_real_model_rows':len(p),'full_unique_serialized_keys':len(set(p)),'exact_accept':int(exact.sum()),'dimension_reject':int(dimension.sum()),'gated_model_required_pairs':int(called.sum()),'gated_unique_serialized_keys':len({p[i] for i in np.flatnonzero(called)})})
    # Execute only core nested Python algorithms with a fake row-independent
    # scalar scorer. No run_gpu, model import, nvidia-smi or CUDA allocation.
    outer=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_gpu')
    names={'score_features','position_probe','execute','compare'}
    functions=[n for n in ast.walk(outer) if isinstance(n,ast.FunctionDef) and n.name in names]
    check(len(functions)==4,'all four synthetic-audited core algorithms extracted')
    ns=dict(m.__dict__);calls=[]
    def fake_score_fixed_batch(model,tokenizer,features,bucket):
        check(len(features)==64 and bucket%32==0 and 32<=bucket<=256 and all(len(x['input_ids'])<=bucket for x in features),'synthetic model sees full fixed64 bucket tensor')
        calls.append((len(features),bucket))
        return np.asarray([sum(x['input_ids'])/16 for x in features],np.float32)
    class FakeTokenizer:
        def __call__(self,q,c,**kwargs):return {'input_ids':[list((a+'|'+b).encode())[:256] for a,b in zip(q,c)]}
    tok=FakeTokenizer();ns['score_fixed_batch']=fake_score_fixed_batch;ns['torch']=SimpleNamespace(cuda=SimpleNamespace(synchronize=lambda:None));ns['policy']=policy;ns['gate']=gate
    exec(compile(ast.fix_missing_locations(ast.Module(body=functions,type_ignores=[])),str(runner),'exec'),ns)
    rows=[]
    for i,desc in enumerate(['work a','different work','work b','work b','work c','work c','work b']):
        r={'pair_id':str(i),'evaluation_split':'synthetic','query_id':'q','candidate_id':str(i)}
        for side,d,unit in [('query','work a','m'),('candidate',desc,'kg' if i==1 else 'm')]:
            r.update({f'{side}_description':d,f'{side}_normalized_description':d,f'{side}_normalized_unit':unit,f'{side}_category':'',''+f'{side}_spec_tokens':''})
        rows.append(r)
    f=pd.DataFrame(rows);dummy=m.encode_pairs(tok,[m.DUMMY_PAIR])[0][0];out={};stats={}
    for condition in m.CONDITIONS:out[condition],stats[condition],mapping=ns['execute'](None,tok,1.,f,condition,'synthetic_namespace',dummy);check(len(mapping)==len(f),'synthetic every original row mapped: '+condition)
    check(stats['full_nocache']['actual_real_model_rows']==7,'full baseline actually scores every occurrence')
    check(stats['full_exact_cache']['actual_real_model_rows']==4,'cold full cache scores four unique inputs')
    check(stats['exact_dimension_nocache']['actual_real_model_rows']==5,'gated no-cache scores every unresolved occurrence')
    check(stats['exact_dimension_exact_cache']['actual_real_model_rows']==2,'gated cache dedup only exact unresolved strings')
    for prefix in ['full','exact_dimension']:check(ns['compare'](out[prefix+'_nocache'],out[prefix+'_exact_cache'])['strict_cache_equivalence_pass'],'synthetic scores decisions ranks equivalence: '+prefix)
    changed={k:v.copy() for k,v in out['full_exact_cache'].items()};changed['score'][2]+=1.
    check(not ns['compare'](out['full_nocache'],changed)['strict_cache_equivalence_pass'],'any bitwise score mismatch prevents strict pass even if decision/rank retained')
    with tempfile.TemporaryDirectory(prefix='cache_static_synthetic_') as tmp:
        ns['args']=SimpleNamespace(output=Path(tmp));probe=ns['position_probe'](None,tok,1.,'synthetic',f,20260904,dummy)
        check(probe['unique_keys_probed']==4 and probe['strict_equivalence_probe_pass'],'unique-input fixed-position permutation round trip')
    expected_sha=sha(runner);check(expected_sha==plan['file_sha256']['runner'],'runner unchanged during audit')
    out={'all_passed':True,'checks_passed':len(checks),'checks':checks,'gpu_used':False,'ssh_used':False,'labels_read':False,'actual_outputs_read':False,'runner_sha256':expected_sha,'plan_sha256':sha(planpath),'cli_sha256':sha(HERE/'CANONICAL_GPU_CLI.txt'),'input_only_counts':records,'planned_timing_rows':60,'expected_prediction_and_mapping_rows_each':1056420,'expected_agreement_rows':54,'findings':['No execution-blocking schema/mask/inverse/full-nocache/bitwise/ranking/timing bug found.','Author fixed previously notified namespace output auditability: both raw-file SHA and canonical semantic namespace digest now preserved.'],'limitations':['Synthetic scorer tests mapping and branching only, not actual BF16 numerical invariance or runtime speed.','One fixed permutation is not a general proof of every batch composition; all actual full/cache rows must independently agree before claiming strict equivalence.','Canonical64/bucket numerical regime is new; no claim about archived normal-batch scores or quality before actual inference and later frozen-reference evaluation.']}
    (HERE/'independent_canonical_runner_cpu_qa.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checks_passed':len(checks),'runner_sha256':expected_sha,'labels_read':False,'gpu_used':False,'ssh_used':False,'input_only_counts':records},ensure_ascii=False))

if __name__=='__main__':main()
