"""CPU-only exact serialization census/audit from explicit label-free allowlists."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
from pathlib import Path
from collections import Counter, defaultdict
import csv
import numpy as np
import pandas as pd

from cache_adapter import canonical_json, serialized_pair_key

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
POLICY_PATH = ROOT / 'output/rule_first_system_validation_20261005/scripts/system_policy.py'
GATE_PATH = ROOT / 'output/router_research_20261005/generic_unit_gate/generic_unit_gate.py'
SOURCES = {
    'server_nonvalidation_6600': ROOT / 'output/rule_first_system_20261004/results/server/inputs.csv',
    'challenge600': ROOT / 'output/paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_challenge600.csv',
    'alberta_scope_core': ROOT / 'output/paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_alberta_scope_core.csv',
}
MODEL_FIELDS = [f'{side}_{field}' for side in ('query', 'candidate')
                for field in ('description', 'normalized_description', 'normalized_unit', 'category', 'spec_tokens')]
METADATA_FIELDS = ['pair_id', 'evaluation_split', 'query_id', 'candidate_id', 'source_year']


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


policy = load_module('frozen_cache_policy', POLICY_PATH)
gate = load_module('frozen_cache_generic_gate', GATE_PATH)


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def safe_read(path, allowed):
    with path.open(newline='') as handle:
        fields = next(csv.reader(handle))
    return pd.read_csv(path, usecols=[c for c in allowed if c in fields], dtype=str, keep_default_na=False)


def counts_summary(name, stage, pairs, query_texts, candidate_texts):
    counts = Counter(pairs)
    n = len(pairs)
    unique = len(counts)
    histogram = Counter(counts.values())
    return {
        'corpus': name, 'stage': stage, 'rows': n,
        'unique_serialized_pair_keys': unique,
        'duplicate_excess_rows': n - unique,
        'duplicate_excess_fraction': (n - unique) / n if n else 0.0,
        'rows_in_repeated_pair_groups': sum(v for v in counts.values() if v > 1),
        'repeated_pair_groups': sum(v > 1 for v in counts.values()),
        'maximum_pair_multiplicity': max(counts.values(), default=0),
        'unique_query_serializations': len(set(query_texts)),
        'unique_candidate_serializations': len(set(candidate_texts)),
        'unique_serialized_items_across_both_sides': len(set(query_texts) | set(candidate_texts)),
        'item_occurrences': n * 2,
        'item_duplicate_excess_fraction': (1 - len(set(query_texts) | set(candidate_texts)) / (2 * n)) if n else 0.0,
        'pair_multiplicity_histogram': dict(sorted(histogram.items())),
    }


frames, pairs_by_corpus, serialized = {}, {}, {}
inputs_manifest, census, duplicate_examples = [], [], []
combined_stages = defaultdict(list)
stage_masks = {}
for name, path in SOURCES.items():
    frame = safe_read(path, MODEL_FIELDS + METADATA_FIELDS)
    original_rows = len(frame)
    if name == 'server_nonvalidation_6600':
        frame = frame.loc[frame['evaluation_split'].ne('validation')].reset_index(drop=True)
    if name == 'alberta_scope_core':
        for side in ('query', 'candidate'):
            frame[f'{side}_description'] = frame[f'{side}_normalized_description']
    assert len(frame) == {'server_nonvalidation_6600': 6600, 'challenge600': 600, 'alberta_scope_core': 67635}[name]
    assert not frame['pair_id'].duplicated().any()
    q = policy.serialize(frame, 'query')
    c = policy.serialize(frame, 'candidate')
    pairs = list(zip(q, c))
    exact = policy.exact_mask(frame)
    conflict = np.asarray(gate.dimension_conflict_mask(frame), dtype=bool)
    assert not np.any(exact & conflict)
    masks = {'full_pool': np.ones(len(frame), dtype=bool),
             'after_pairwise_exact': ~exact,
             'after_pairwise_exact_and_generic_dimension_gate': ~exact & ~conflict}
    frames[name] = frame
    pairs_by_corpus[name] = pairs
    serialized[name] = {'query': q, 'candidate': c}
    stage_masks[name] = masks
    inputs_manifest.append({'corpus': name, 'path': str(path.relative_to(ROOT)),
                           'sha256': file_hash(path), 'source_rows': original_rows, 'analyzed_rows': len(frame),
                           'model_fields': MODEL_FIELDS, 'metadata_fields_used_only_for_alignment': [f for f in METADATA_FIELDS if f in frame],
                           'input_variant': 'scope_core_description_equals_normalized' if name == 'alberta_scope_core' else 'frozen_five_field_original',
                           'pairwise_exact_rows': int(exact.sum()), 'generic_conflict_rows_in_full_pool': int(conflict.sum()),
                           'generic_rejected_after_exact': int((~exact & conflict).sum()),
                           'query_pool_early_stop_used': False})
    for stage, mask in masks.items():
        indices = np.flatnonzero(mask)
        selected = [pairs[i] for i in indices]
        row = counts_summary(name, stage, selected, [q[i] for i in indices], [c[i] for i in indices])
        census.append(row)
        combined_stages[stage].extend(selected)
        groups = defaultdict(list)
        for i in indices:
            groups[pairs[i]].append(int(i))
        top = sorted(((pair, members) for pair, members in groups.items() if len(members) > 1),
                     key=lambda entry: (-len(entry[1]), serialized_pair_key(*entry[0])))[:5]
        for pair, members in top:
            duplicate_examples.append({'corpus': name, 'stage': stage,
                                       'serialized_pair_sha256': serialized_pair_key(*pair),
                                       'multiplicity': len(members), 'query_serialization': pair[0],
                                       'candidate_serialization': pair[1],
                                       'input_row_positions_zero_based': members[:12]})
for stage, pairs in combined_stages.items():
    census.append(counts_summary('all_three_input_sets_text_union', stage, pairs, [p[0] for p in pairs], [p[1] for p in pairs]))

# A pooled text union describes overlap, not guaranteed cross-variant/cache reuse.
write_json('input_hashes.json', {'policy_sha256': file_hash(POLICY_PATH),
                               'generic_unit_gate_sha256': file_hash(GATE_PATH),
                               'ontology_sha256': gate.ontology_sha256(),
                               'inputs': inputs_manifest,
                               'labels_read': False, 'gpu_or_ssh_used': False,
                               'cache_content_key': 'SHA256(canonical JSON ordered [query serialization, candidate serialization])',
                               'production_key_requires_model_namespace': True})
write_json('census.json', census)
flat_fields = [k for k in census[0] if k != 'pair_multiplicity_histogram']
with (OUT / 'census.csv').open('w', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=flat_fields)
    writer.writeheader()
    writer.writerows({k: row[k] for k in flat_fields} for row in census)
write_json('duplicate_examples_label_free.json', duplicate_examples)


def numeric(value):
    try:
        result = float(value)
        return result if np.isfinite(result) else None
    except (TypeError, ValueError):
        return None


prediction_files = []
for seed in (20260904, 20260905, 20260906):
    prediction_files.append(('server_nonvalidation_6600', ROOT / f'output/router_research_20261005/gpu_unit_gate/unit_gate_gpu/predictions_seed_{seed}.csv'))
    prediction_files.append(('alberta_scope_core', ROOT / f'output/rule_first_system_validation_20261005/results/raw_alberta_scope_core/predictions_scope_core_seed_{seed}.csv'))

audit, audit_examples, prediction_manifest = [], [], []
for name, path in prediction_files:
    frame = safe_read(path, ['pair_id', 'seed', 'policy', 'variant', 'threshold', 'score', 'prediction', 'bge_called'])
    lookup = dict(zip(frames[name]['pair_id'], pairs_by_corpus[name]))
    observed_pair_ids = set(frame['pair_id'])
    if not observed_pair_ids <= set(lookup):
        raise ValueError('Unmatched input pair IDs in authorized prediction file')
    if name == 'server_nonvalidation_6600':
        groupings = [(policy_name, sub) for policy_name, sub in frame.groupby('policy', sort=False)]
        groupings.append(('across_policies_same_seed', frame))
    else:
        groupings = [(variant, sub) for variant, sub in frame.groupby('variant', sort=False)]
    groupings = [(condition, stage, sub.loc[sub['pair_id'].isin(set(frames[name].loc[mask, 'pair_id']))])
                 for condition, sub in groupings for stage, mask in stage_masks[name].items()]
    prediction_manifest.append({'path': str(path.relative_to(ROOT)), 'sha256': file_hash(path),
                                'rows': len(frame), 'columns_accessed': list(frame.columns)})
    for condition, stage, sub in groupings:
        observations = defaultdict(list)
        skipped = 0
        for row in sub.to_dict('records'):
            value = numeric(row.get('score'))
            if value is None or ('bge_called' in row and row['bge_called'] != '1'):
                skipped += 1
                continue
            threshold = numeric(row['threshold'])
            if threshold is None:
                raise ValueError('Missing frozen threshold in a scored prediction row')
            pair = lookup[row['pair_id']]
            observations[pair].append({'score': value, 'threshold': threshold,
                                       'score_decision': int(value >= threshold), 'policy_or_variant': row.get('policy', row.get('variant', ''))})
        repeated = {pair: rows for pair, rows in observations.items() if len(rows) > 1}
        score_drift = {pair: rows for pair, rows in repeated.items() if len({row['score'] for row in rows}) > 1}
        decision_drift = {pair: rows for pair, rows in repeated.items() if len({row['score_decision'] for row in rows}) > 1}
        spreads = [max(r['score'] for r in rows) - min(r['score'] for r in rows) for rows in repeated.values()]
        thresholds = sorted({row['threshold'] for rows in observations.values() for row in rows})
        if len(thresholds) != 1:
            raise ValueError('Comparison mixed acceptance thresholds')
        seed = int(sub['seed'].iloc[0])
        audit.append({'corpus': name, 'seed_checkpoint_identity': seed, 'condition': condition, 'stage': stage,
                      'input_variant': 'scope_core' if name == 'alberta_scope_core' else 'frozen_five_field_original',
                      'frozen_threshold': thresholds[0], 'scored_rows': sum(len(r) for r in observations.values()),
                      'unscored_or_missing_rows_excluded': skipped,
                      'unique_serialized_pair_keys_scored': len(observations), 'repeated_scored_key_groups': len(repeated),
                      'score_drift_key_groups': len(score_drift), 'score_decision_drift_key_groups': len(decision_drift),
                      'maximum_score_range': max(spreads, default=0.0),
                      'score_drift_observation_rows': sum(len(r) for r in score_drift.values()),
                      'decision_drift_observation_rows': sum(len(r) for r in decision_drift.values()),
                      'different_seed_scores_never_compared': True})
        combined = {**score_drift, **decision_drift}
        for pair, rows in sorted(combined.items(), key=lambda entry: (
            -int(entry[0] in decision_drift),
            -(max(r['score'] for r in entry[1]) - min(r['score'] for r in entry[1])), serialized_pair_key(*entry[0])))[:5]:
            unique_obs = sorted({(r['score'], r['threshold'], r['score_decision'], r['policy_or_variant']) for r in rows})
            audit_examples.append({'corpus': name, 'seed_checkpoint_identity': seed, 'condition': condition, 'stage': stage,
                                   'serialized_pair_sha256': serialized_pair_key(*pair),
                                   'query_serialization': pair[0], 'candidate_serialization': pair[1],
                                   'observation_count': len(rows), 'score_decision_drift': pair in decision_drift,
                                   'unique_score_threshold_decision_contexts': unique_obs})

write_json('prediction_input_hashes.json', prediction_manifest)
write_json('existing_gpu_score_audit.json', audit)
write_json('score_drift_examples_label_free.json', audit_examples)
with (OUT / 'existing_gpu_score_audit.csv').open('w', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=list(audit[0]))
    writer.writeheader()
    writer.writerows(audit)
print(json.dumps({'census': [{k:v for k,v in r.items() if k in {'corpus','stage','rows','unique_serialized_pair_keys','duplicate_excess_fraction'}} for r in census],
                  'existing_prediction_audit': audit}, ensure_ascii=False, indent=2))
