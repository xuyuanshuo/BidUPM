#!/usr/bin/env python3
"""Independent tiny synthetic-only checks of frozen canonical CPU evaluator."""
import importlib.util
import json
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('frozen_cache_eval_fixture_qa', HERE / 'evaluate_canonical_actual_cpu.py')
e = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)
checks = []


def record(name, callback, reject=False):
    try:
        callback()
    except AssertionError as error:
        if not reject:
            raise
        checks.append({'name': name, 'pass': True, 'rejection': str(error)})
    else:
        if reject:
            raise AssertionError('Invalid fixture accepted: ' + name)
        checks.append({'name': name, 'pass': True})


pairs = [('qA', 'cA'), ('qB', 'cB'), ('qA', 'cA'), ('qC', 'cC')]
frame = pd.DataFrame({'pair_id': ['p0', 'p1', 'p2', 'p3']})
values = [2.0, 3.0, 2.0, 4.0]
block = pd.DataFrame({'pair_id': frame.pair_id, 'threshold': 1.0, 'score': values,
                      'exact_match': 0, 'dimension_rejected': 0})
called = np.ones(4, dtype=bool)
namespace_digest = 'synthetic-namespace'


def mapping(condition):
    cached = condition.endswith('_exact_cache')
    unique, inverse, first = e.first_unique(pairs)
    if not cached:
        inverse, first = np.arange(4), np.arange(4)
    rows = []
    for i, pair in enumerate(pairs):
        j = int(inverse[i])
        rows.append({'pair_id': frame.at[i, 'pair_id'], 'condition': condition, 'repeat': '0',
                     'threshold': '1.0', 'input_row_position': i, 'bucket_length': 32,
                     'representative_input_row': int(first[j]), 'model_row_index': j,
                     'model_batch_id': 0, 'model_batch_position': j,
                     'serialized_pair_sha256': e.object_hash(list(pair)),
                     'cache_key_sha256': e.cache_key(namespace_digest, pair, 32)})
    return pd.DataFrame(rows)


full = mapping('full_nocache')
cached = mapping('full_exact_cache')
for condition, raw in [('full_nocache', full), ('full_exact_cache', cached)]:
    record('valid_' + condition + '_mapping', lambda condition=condition, raw=raw:
           e.verify_mapping(raw, block, frame, pairs, called, namespace_digest, condition, 0))
badmap = cached.copy()
badmap.loc[2, 'representative_input_row'] = 0.5
record('fractional_representative_rejected', lambda:
       e.verify_mapping(badmap, block, frame, pairs, called, namespace_digest, 'full_exact_cache', 0), True)

unique, _, first = e.first_unique(pairs)
probes = []
for position, (pair, row) in enumerate(zip(unique, first)):
    value = values[int(row)]
    bits = int(e.score_bits([value])[0])
    probes.append({'dataset': 'synthetic', 'seed': 123, 'threshold': 1.0,
                   'serialized_pair_sha256': e.object_hash(list(pair)),
                   'representative_input_row': int(row), 'input_multiplicity': pairs.count(pair),
                   'original_position': position, 'permuted_position': (position + 31) % 64,
                   'bucket_length': 32, 'probe_batch_id': 0,
                   'score_original': value, 'score_permuted': value,
                   'score_original_bits_u32': bits, 'score_permuted_bits_u32': bits,
                   'score_bitwise_equal': 'True', 'decision_original': 1, 'decision_permuted': 1})
probe = pd.DataFrame(probes)
summary = {'unique_keys_probed': 3, 'probe_model_batches': 2, 'probe_padded_gpu_rows': 128,
           'score_bitwise_difference_keys': 0, 'decision_difference_keys': 0,
           'strict_equivalence_probe_pass': True}
maps = {('full_nocache', 0): full, ('full_exact_cache', 0): cached}
with tempfile.TemporaryDirectory(prefix='canonical-independent-synthetic-') as temporary:
    path = Path(temporary) / 'synthetic_probe.csv'

    def runprobe(data):
        data.to_csv(path, index=False)
        return e.verify_probe(path, summary, 'synthetic', 123, frame, pairs, 1.0, maps)

    record('valid_shift31_inverse_and_unique_layout', lambda: runprobe(probe))
    wronglayout = probe.copy()
    wronglayout.loc[2, 'original_position'] = 3
    wronglayout.loc[2, 'permuted_position'] = 34
    record('original_layout_not_full_occurrence_layout', lambda: runprobe(wronglayout), True)
    wrongshift = probe.copy()
    wrongshift.loc[0, 'permuted_position'] = 32
    record('wrong_shift_inverse_rejected', lambda: runprobe(wrongshift), True)
    wrongbits = probe.copy()
    wrongbits.loc[0, 'score_original_bits_u32'] += 1
    record('original_score_bytes_recomputed', lambda: runprobe(wrongbits), True)
    wrongbatch = probe.copy()
    wrongbatch.loc[0, 'probe_batch_id'] = 1
    record('wrong_probe_batch_rejected', lambda: runprobe(wrongbatch), True)

source = {'checkpoint_files': {'config.json': 'c', 'model.safetensors': 'm', 'tokenizer.json': 't'}, 'seed': 123}
execution = {'torch_version': 'synthetic-torch', 'transformers_version': 'synthetic-transformers',
             'cuda_version': 'synthetic-cuda', 'gpu': 'synthetic-gpu',
             'gpu_uuid_driver_records': [{'uuid': 'synthetic-uuid', 'driver': 'synthetic-driver'}]}
frozen = {'file_sha256': {'policy': 'synthetic-policy'}}
namespace = {'scoring_regime': 'canonical_bucket_batch64_v1',
             'checkpoint_manifest_sha256': e.object_hash(source['checkpoint_files']),
             'tokenizer_manifest_sha256': e.object_hash({'tokenizer.json': 't'}),
             'serializer_sha256': 'synthetic-policy', 'input_variant': 'frozen_five_field_original',
             'model_configuration': {'max_length': 256, 'truncation': True, 'evaluation_mode': True,
                                     'dummy_pair': ['', ''], 'architecture_config_sha256': 'c'},
             'runtime_configuration': {'batch_size': 64, 'bucket_width': 32, 'padding': 'fixed_bucket_max_length',
                                       'precision': 'BF16 autocast', 'tf32_matmul': False, 'tf32_cudnn': False,
                                       'torch': execution['torch_version'], 'transformers': execution['transformers_version'],
                                       'cuda': execution['cuda_version'], 'gpu': execution['gpu'],
                                       'gpu_uuid_driver_records': execution['gpu_uuid_driver_records'],
                                       'random_seed': 123, 'threads': 8}}
record('valid_runtime_namespace', lambda: e.verify_namespace(namespace, 'main220', source, frozen, execution))
for field, bad in [('gpu_uuid_driver_records', [{'uuid': 'wrong', 'driver': 'synthetic-driver'}]),
                   ('random_seed', 124)]:
    badnamespace = json.loads(json.dumps(namespace))
    badnamespace['runtime_configuration'][field] = bad
    record(field + '_mismatch_rejected', lambda badnamespace=badnamespace:
           e.verify_namespace(badnamespace, 'main220', source, frozen, execution), True)

report = {'status': 'PASS', 'synthetic_only': True, 'actual_results_read': False,
          'real_reference_values_read': False, 'GPU_used': False, 'SSH_used': False,
          'frozen_evaluator_sha256': e.sha(HERE / 'evaluate_canonical_actual_cpu.py'),
          'check_count': len(checks), 'checks': checks}
e.dump(HERE / 'independent_canonical_evaluator_fixture_qa.json', report)
print(json.dumps({'status': 'PASS', 'check_count': len(checks)}))
