#!/usr/bin/env python3
"""Prospective canonical BF16 bucket-cache experiment; no labels or training.

Default/--check-inputs is CPU-only and never imports torch/transformers. Real
execution needs --execute-gpu, verified frozen files, a free GPU, and a new output
directory. Batch64 + fixed bucket length + dummy padding is a NEW numerical
regime; this program never claims archived normal-batch scores are unchanged.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import fcntl
import gc
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
import numpy as np
import pandas as pd

BATCH = 64
MAX_LENGTH = 256
BUCKET_WIDTH = 32
SEEDS = (20260904, 20260905, 20260906)
THRESHOLDS = {20260904: 9.1875, 20260905: -1.453125, 20260906: 8.4375}
CONDITIONS = ('full_nocache', 'full_exact_cache', 'exact_dimension_nocache', 'exact_dimension_exact_cache')
ITEM = [f'{side}_{field}' for side in ('query', 'candidate')
        for field in ('description', 'normalized_description', 'normalized_unit', 'category', 'spec_tokens')]
META = ['pair_id', 'evaluation_split', 'query_id', 'candidate_id', 'source_year']
FORBIDDEN = {'label', 'labels', 'final_label', 'provisional_label', 'gold_label', 'reference_label',
             'final_relevance', 'difficulty', 'final_conflict_type', 'reference', 'references',
             'query_reference', 'candidate_reference', 'query_unit_price', 'candidate_unit_price', 'price'}
REMOTE_ROOT = Path('experiment_runtime')
DUMMY_PAIR = ('', '')


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def cjson(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def object_hash(value):
    return hashlib.sha256(cjson(value).encode('utf-8')).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def bucket_length(token_n):
    require(0 < token_n <= MAX_LENGTH, 'Unexpected truncated token length')
    return min(MAX_LENGTH, max(BUCKET_WIDTH, ((token_n + BUCKET_WIDTH - 1) // BUCKET_WIDTH) * BUCKET_WIDTH))


def prepare_inputs(args):
    frozen = json.loads(args.frozen_plan.read_text())
    require(frozen['schema'] == 'canonical-bucket-cache-gpu-plan-v1', 'Unexpected frozen plan')
    for name, path in {'runner': Path(__file__), 'policy': args.policy,
                       'generic_gate': args.gate_dir / 'generic_unit_gate.py',
                       'ontology': args.gate_dir / 'unit_dimension_ontology.json'}.items():
        require(sha(path) == frozen['file_sha256'][name], f'Frozen implementation changed: {name}')
    source_manifest_path = args.source / 'source_manifest.json'
    require(sha(source_manifest_path) == frozen['source_manifest_sha256'], 'Source manifest differs')
    source = json.loads(source_manifest_path.read_text())
    require([int(run['seed']) for run in source['runs']] == list(SEEDS), 'Frozen checkpoint list differs')
    for run in source['runs']:
        seed = int(run['seed'])
        require(float(run['threshold']) == THRESHOLDS[seed], 'Frozen threshold differs; no retuning permitted')
        require(run['checkpoint_files'] and 'model.safetensors' in run['checkpoint_files'], 'Missing checkpoint hashes')
    policy = load_module('canonical_cache_system_policy', args.policy)
    gate = load_module('canonical_cache_generic_gate', args.gate_dir / 'generic_unit_gate.py')
    paths = {'main220': args.source / 'inputs.csv',
             'challenge600': args.supplement / 'model_inputs_challenge600.csv',
             'alberta_scope_core': args.supplement / 'model_inputs_alberta_scope_core.csv'}
    frames = {}
    for dataset, path in paths.items():
        require(sha(path) == frozen['input_sha256'][dataset], f'Frozen input hash differs: {dataset}')
        with path.open(newline='') as handle:
            columns = next(csv.reader(handle))
        require(not FORBIDDEN.intersection(columns), f'Forbidden input column: {dataset}')
        require(set(['pair_id', *ITEM]) <= set(columns), f'Missing five-field input: {dataset}')
        frame = pd.read_csv(path, usecols=[field for field in META + ITEM if field in columns],
                            dtype=str, keep_default_na=False)
        if dataset == 'main220':
            require(sha(path) == source['inputs_sha256'], 'Main input differs from frozen source manifest')
            frame = frame.loc[frame['evaluation_split'].ne('validation')].reset_index(drop=True)
        if dataset == 'alberta_scope_core':
            for side in ('query', 'candidate'):
                frame[f'{side}_description'] = frame[f'{side}_normalized_description']
        require(len(frame) == {'main220': 6600, 'challenge600': 600, 'alberta_scope_core': 67635}[dataset],
                f'Unexpected complete dataset size: {dataset}')
        require(not frame['pair_id'].duplicated().any(), f'Duplicate input pair ID: {dataset}')
        if dataset != 'challenge600':
            require(set(['evaluation_split', 'query_id', 'candidate_id']) <= set(frame), 'Missing ranking metadata')
        frames[dataset] = frame.reset_index(drop=True)
    cpu_plan = {'status': 'cpu_input_preflight_pass', 'new_gpu_inference_executed': False,
                'labels_read': False, 'training_performed': False, 'thresholds_retuned': False,
                'rows': {dataset: len(frame) for dataset, frame in frames.items()},
                'input_sha256': frozen['input_sha256'], 'conditions': CONDITIONS,
                'main_repeats': 3, 'supplementary_repeats': 1, 'planned_timing_rows': 60,
                'batch_size': BATCH, 'bucket_width': BUCKET_WIDTH, 'max_length': MAX_LENGTH,
                'dummy_pair': list(DUMMY_PAIR), 'new_canonical_scoring_regime': True,
                'source_manifest_sha256': frozen['source_manifest_sha256'],
                'row_position_probe': frozen['row_position_probe'],
                'model_fairness': 'same system optimization is available to all model baselines'}
    return source, frozen, frames, policy, gate, cpu_plan


def require_idle_gpu():
    # Called before importing torch or allocating a CUDA context. No automatic
    # wait/start behavior: the owner places this job after the existing queue.
    result = subprocess.run(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'],
                            capture_output=True, text=True, check=True)
    pids = [int(line.strip()) for line in result.stdout.splitlines() if line.strip().isdigit()]
    require(not pids, f'GPU busy with compute PIDs {pids}; refusing concurrent execution')
    memory = subprocess.run(['nvidia-smi', '--query-gpu=memory.used', '--format=csv,noheader,nounits'],
                            capture_output=True, text=True, check=True)
    values = [int(line.strip()) for line in memory.stdout.splitlines() if line.strip().isdigit()]
    require(values and max(values) <= 512, f'GPU is not empty (MiB={values}); refusing execution')
    identity = subprocess.run(['nvidia-smi', '--query-gpu=uuid,driver_version', '--format=csv,noheader'],
                              capture_output=True, text=True, check=True)
    return identity.stdout.strip().splitlines()


def encode_pairs(tokenizer, pairs):
    if not pairs:
        return [], []
    encoded = tokenizer([p[0] for p in pairs], [p[1] for p in pairs], padding=False,
                        truncation=True, max_length=MAX_LENGTH)
    features = [{name: encoded[name][i] for name in encoded} for i in range(len(pairs))]
    lengths = [bucket_length(len(row['input_ids'])) for row in features]
    return features, lengths


def stable_unique_pairs(pairs):
    positions, unique, inverse, representatives = {}, [], [], []
    for i, pair in enumerate(pairs):
        if pair not in positions:
            positions[pair] = len(unique)
            unique.append(pair)
            representatives.append(i)
        inverse.append(positions[pair])
    return unique, np.asarray(inverse, dtype=np.int64), np.asarray(representatives, dtype=np.int64)


def cache_key(namespace_digest, pair, bucket):
    # Namespace binds all model/runtime details except the acceptance threshold.
    return object_hash({'schema': 'canonical-bucket-score-v1', 'namespace': namespace_digest,
                        'ordered_serialized_pair': list(pair), 'fixed_bucket_length': int(bucket)})


def finite_bits(values):
    return np.asarray(values, dtype=np.float32).view(np.uint32)


def run_gpu(args, source, frozen, frames, policy, gate, cpu_plan):
    require(not args.output.exists(), 'Refusing existing output directory; choose a fresh directory')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    lock_path = args.output.parent / 'canonical_bucket_gpu.lock'
    with lock_path.open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ValueError('Another canonical bucket job owns the serial GPU lock') from exc
        gpu_identities = require_idle_gpu()
        os.environ.setdefault('HF_HUB_OFFLINE', '1')
        os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
        os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')
        import torch
        import transformers
        from transformers import AutoTokenizer, AutoModelForSequenceClassification
        require(torch.cuda.is_available() and torch.cuda.is_bf16_supported(), 'Actual BF16 CUDA GPU required')
        torch.set_num_threads(8)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        args.output.mkdir()
        manifest = {**cpu_plan, 'status': 'running', 'new_gpu_inference_executed': True,
                    'created_utc': datetime.now(timezone.utc).isoformat(),
                    'torch_version': torch.__version__, 'transformers_version': transformers.__version__,
                    'cuda_version': torch.version.cuda, 'gpu': torch.cuda.get_device_name(0),
                    'gpu_uuid_driver_records': gpu_identities,
                    'precision': 'BF16 autocast; TF32 disabled; model.eval; threads8',
                    'runner_sha256': sha(__file__), 'frozen_plan_sha256': sha(args.frozen_plan),
                    'shared_policy_sha256': sha(args.policy), 'ontology_sha256': gate.ontology_sha256(),
                    'timing': 'synchronized resident-model end-to-end gate/serialize/dedup/tokenize/bucket/pad/GPU/cache/scatter/threshold/rank; excludes CSV input/checkpoint load/probe/warmup/output file writing; cache starts empty each repeat',
                    'legacy_equivalence_claim': False, 'strict_cache_equivalence_pass': True,
                    'completed_runs': [], 'probes': [], 'model_loads': []}
        times, agreements = [], []
        dump(args.output / 'execution_manifest.json', manifest)

        @torch.inference_mode()
        def score_fixed_batch(model, tokenizer, batch_features, bucket):
            require(len(batch_features) == BATCH, 'Every model batch must have exactly 64 rows')
            require(all(len(row['input_ids']) <= bucket for row in batch_features), 'Feature exceeds fixed bucket length')
            padded = tokenizer.pad(batch_features, padding='max_length', max_length=bucket, return_tensors='pt')
            require(tuple(padded['input_ids'].shape) == (BATCH, bucket), 'Unexpected model input shape')
            padded = {name: tensor.to('cuda') for name, tensor in padded.items()}
            with torch.autocast('cuda', dtype=torch.bfloat16):
                logits = model(**padded).logits
            require(logits.numel() == BATCH, 'Expected one scalar BGE logit per pair')
            values = logits.reshape(-1).float().cpu().numpy().astype(np.float32, copy=False)
            require(np.isfinite(values).all(), 'Nonfinite model logits including dummy rows')
            return values

        def score_features(model, tokenizer, features, lengths, dummy):
            scores = np.full(len(features), np.nan, dtype=np.float32)
            batch_ids = np.full(len(features), -1, dtype=np.int64)
            positions = np.full(len(features), -1, dtype=np.int64)
            batch_n = 0
            for bucket in range(BUCKET_WIDTH, MAX_LENGTH + 1, BUCKET_WIDTH):
                indices = [i for i, length in enumerate(lengths) if length == bucket]
                for lo in range(0, len(indices), BATCH):
                    real = indices[lo:lo + BATCH]
                    batch = [features[i] for i in real] + [dummy] * (BATCH - len(real))
                    values = score_fixed_batch(model, tokenizer, batch, bucket)
                    scores[real] = values[:len(real)]
                    batch_ids[real] = batch_n
                    positions[real] = np.arange(len(real))
                    batch_n += 1
            require(np.isfinite(scores).all(), 'Invalid real-pair scores')
            return scores, batch_ids, positions, batch_n

        def position_probe(model, tokenizer, threshold, dataset, frame, seed, dummy):
            # All unique keys are covered, including keys with only one occurrence.
            pairs = list(zip(policy.serialize(frame, 'query'), policy.serialize(frame, 'candidate')))
            counts = Counter(pairs)
            unique, _, representatives = stable_unique_pairs(pairs)
            features, lengths = encode_pairs(tokenizer, unique)
            records, batch_n = [], 0
            torch.cuda.synchronize()
            started = time.perf_counter()
            for bucket in range(BUCKET_WIDTH, MAX_LENGTH + 1, BUCKET_WIDTH):
                indices = [i for i, length in enumerate(lengths) if length == bucket]
                for lo in range(0, len(indices), BATCH):
                    real = indices[lo:lo + BATCH]
                    batch = [features[i] for i in real] + [dummy] * (BATCH - len(real))
                    first = score_fixed_batch(model, tokenizer, batch, bucket)
                    # Shift by 31 in a 64-row batch: every real key changes position.
                    permutation = np.roll(np.arange(BATCH), 31)
                    second_permuted = score_fixed_batch(model, tokenizer, [batch[i] for i in permutation], bucket)
                    second = np.empty(BATCH, dtype=np.float32)
                    second[permutation] = second_permuted
                    original_to_permuted = np.argsort(permutation)
                    for position, i in enumerate(real):
                        a, b = float(first[position]), float(second[position])
                        records.append({'dataset': dataset, 'seed': seed, 'threshold': threshold,
                                        'serialized_pair_sha256': object_hash(list(unique[i])),
                                        'representative_input_row': int(representatives[i]),
                                        'input_multiplicity': counts[unique[i]], 'bucket_length': bucket,
                                        'probe_batch_id': batch_n, 'original_position': position,
                                        'permuted_position': int(original_to_permuted[position]),
                                        'score_original': a, 'score_permuted': b,
                                        'score_original_bits_u32': int(finite_bits([a])[0]),
                                        'score_permuted_bits_u32': int(finite_bits([b])[0]),
                                        'score_bitwise_equal': bool(finite_bits([a])[0] == finite_bits([b])[0]),
                                        'decision_original': int(a >= threshold), 'decision_permuted': int(b >= threshold)})
                    batch_n += 1
            torch.cuda.synchronize()
            elapsed = time.perf_counter() - started
            table = pd.DataFrame(records)
            path = args.output / f'position_probe_{dataset}_seed_{seed}.csv.gz'
            table.to_csv(path, index=False, compression='gzip')
            bit_diff = int((~table['score_bitwise_equal']).sum())
            decision_diff = int(table['decision_original'].ne(table['decision_permuted']).sum())
            summary = {'dataset': dataset, 'seed': seed, 'unique_keys_probed': len(unique),
                       'probe_model_batches': batch_n * 2, 'probe_padded_gpu_rows': batch_n * 2 * BATCH,
                       'score_bitwise_difference_keys': bit_diff, 'decision_difference_keys': decision_diff,
                       'strict_equivalence_probe_pass': bit_diff == 0 and decision_diff == 0,
                       'probe_inference_seconds_excluding_preparation_and_file_output': elapsed,
                       'output': path.name, 'sha256': sha(path),
                       'coverage_limitation': 'one deterministic 31-position cyclic permutation per unique key; end-to-end full-v-cache checks also test changed batch composition'}
            return summary

        def execute(model, tokenizer, threshold, frame, condition, namespace_digest, dummy):
            torch.cuda.synchronize()
            started = time.perf_counter()
            n = len(frame)
            gated = condition.startswith('exact_dimension_')
            cached = condition.endswith('_exact_cache')
            exact = policy.exact_mask(frame) if gated else np.zeros(n, dtype=bool)
            conflict = np.asarray(gate.dimension_conflict_mask(frame), dtype=bool) if gated else np.zeros(n, dtype=bool)
            require(not np.any(exact & conflict), 'Exact acceptance overlaps dimensional rejection')
            rejected = ~exact & conflict
            called = ~exact & ~rejected
            ix = np.flatnonzero(called)
            sub = frame.iloc[ix]
            pairs = list(zip(policy.serialize(sub, 'query'), policy.serialize(sub, 'candidate')))
            if cached:
                chosen, inverse, representatives = stable_unique_pairs(pairs)
            else:
                chosen = pairs
                inverse = np.arange(len(pairs), dtype=np.int64)
                representatives = inverse.copy()
            features, lengths = encode_pairs(tokenizer, chosen)
            chosen_keys = [cache_key(namespace_digest, pair, bucket) for pair, bucket in zip(chosen, lengths)] if cached else None
            chosen_scores, batch_ids, batch_positions, batch_n = score_features(model, tokenizer, features, lengths, dummy)
            if cached:
                cache = {}
                for key, pair, value in zip(chosen_keys, chosen, chosen_scores):
                    require(key not in cache, 'Hash collision across distinct serialized pairs')
                    cache[key] = (pair, float(value))
                restored = []
                for j, i in enumerate(inverse):
                    pair, score = cache[chosen_keys[i]]
                    require(pair == chosen[i] == pairs[j] and math.isfinite(score), 'Invalid cache restoration')
                    restored.append(score)
                values = np.asarray(restored, dtype=np.float32)
            else:
                values = chosen_scores
            scores = np.full(n, np.nan, dtype=np.float64)
            scores[ix] = values
            prediction = (exact | (called & (scores >= threshold))).astype(np.int8)
            ranks = policy.rank_returned(frame, exact, scores, threshold) if 'query_id' in frame else np.zeros(n, dtype=np.int8)
            torch.cuda.synchronize()
            seconds = time.perf_counter() - started
            # Reporting hashes/unique-counts for the noncache condition are outside
            # timing so the baseline does not pay for an unused cache operation.
            if chosen_keys is None:
                chosen_keys = [cache_key(namespace_digest, pair, bucket) for pair, bucket in zip(chosen, lengths)]
            mapping = frame[[field for field in META if field in frame]].copy()
            mapping['input_row_position'] = np.arange(n)
            mapping['serialized_pair_sha256'] = ''
            mapping['cache_key_sha256'] = ''
            for column in ('bucket_length', 'representative_input_row', 'model_row_index', 'model_batch_id', 'model_batch_position'):
                mapping[column] = -1
            for j, row_index in enumerate(ix):
                i = int(inverse[j])
                mapping.at[row_index, 'serialized_pair_sha256'] = object_hash(list(pairs[j]))
                mapping.at[row_index, 'cache_key_sha256'] = chosen_keys[i]
                mapping.at[row_index, 'bucket_length'] = lengths[i]
                mapping.at[row_index, 'representative_input_row'] = int(ix[representatives[i]])
                mapping.at[row_index, 'model_row_index'] = i
                mapping.at[row_index, 'model_batch_id'] = int(batch_ids[i])
                mapping.at[row_index, 'model_batch_position'] = int(batch_positions[i])
            stats = {'seconds': seconds, 'model_required_pairs': int(called.sum()),
                     'unique_serialized_pair_keys': len(set(pairs)), 'actual_real_model_rows': len(chosen),
                     'actual_model_batches': batch_n, 'actual_padded_gpu_rows': batch_n * BATCH,
                     'dummy_model_rows': batch_n * BATCH - len(chosen),
                     'cache_reused_pair_occurrences': len(pairs) - len(chosen),
                     'exact_accepted_pairs': int(exact.sum()), 'dimension_rejected_pairs': int(rejected.sum()),
                     'cache_initial_state': 'empty', 'top3_applicable': 'query_id' in frame}
            values = {'score': scores, 'prediction': prediction, 'returned_rank': ranks,
                      'exact_match': exact.astype(np.int8), 'dimension_rejected': rejected.astype(np.int8),
                      'model_called': called.astype(np.int8)}
            return values, stats, mapping

        def compare(reference, cached):
            mask = reference['model_called'].astype(bool)
            require(np.array_equal(mask, cached['model_called'].astype(bool)), 'Comparison mixed routing masks')
            bits_a = finite_bits(reference['score'][mask])
            bits_b = finite_bits(cached['score'][mask])
            bit_diff = int((bits_a != bits_b).sum())
            decision_diff = int((reference['prediction'] != cached['prediction']).sum())
            rank_diff = int((reference['returned_rank'] != cached['returned_rank']).sum())
            score_range = float(np.max(np.abs(reference['score'][mask] - cached['score'][mask]))) if mask.any() else 0.0
            return {'score_bitwise_difference_rows': bit_diff, 'decision_difference_rows': decision_diff,
                    'returned_rank_difference_rows': rank_diff, 'maximum_absolute_score_difference': score_range,
                    'strict_cache_equivalence_pass': bit_diff == 0 and decision_diff == 0 and rank_diff == 0}

        for run in source['runs']:
            seed, threshold, checkpoint = int(run['seed']), float(run['threshold']), Path(run['checkpoint'])
            for name, expected in run['checkpoint_files'].items():
                require(sha(checkpoint / name) == expected, f'Checkpoint changed: {seed}/{name}')
            torch.manual_seed(seed)
            torch.cuda.synchronize()
            load_started = time.perf_counter()
            tokenizer = AutoTokenizer.from_pretrained(checkpoint, local_files_only=True)
            model = AutoModelForSequenceClassification.from_pretrained(checkpoint, local_files_only=True).to('cuda').eval()
            torch.cuda.synchronize()
            manifest['model_loads'].append({'seed': seed, 'seconds': time.perf_counter() - load_started,
                                             'checkpoint_files_verified': True})
            dummy_features, _ = encode_pairs(tokenizer, [DUMMY_PAIR])
            dummy = dummy_features[0]
            require(len(dummy['input_ids']) <= BUCKET_WIDTH, 'Fixed dummy input is longer than the smallest bucket')
            # All eight fixed tensor shapes warmed twice; no validation rows used.
            for bucket in range(BUCKET_WIDTH, MAX_LENGTH + 1, BUCKET_WIDTH):
                for _ in range(2):
                    score_fixed_batch(model, tokenizer, [dummy] * BATCH, bucket)
            for dataset, frame in frames.items():
                variant = 'scope_core_description_equals_normalized' if dataset == 'alberta_scope_core' else 'frozen_five_field_original'
                tokenizer_hashes = {name: value for name, value in run['checkpoint_files'].items()
                                    if name not in ('config.json', 'model.safetensors')}
                namespace = {'model_family': 'BGE AutoModelForSequenceClassification',
                             'checkpoint_manifest_sha256': object_hash(run['checkpoint_files']),
                             'tokenizer_manifest_sha256': object_hash(tokenizer_hashes),
                             'serializer_sha256': sha(args.policy), 'input_variant': variant,
                             'scoring_regime': 'canonical_bucket_batch64_v1',
                             'model_configuration': {'architecture_config_sha256': run['checkpoint_files']['config.json'],
                                                     'evaluation_mode': True, 'score_extraction': 'one raw scalar logit, no sigmoid',
                                                     'max_length': MAX_LENGTH, 'truncation': True,
                                                     'prompt_or_instruction': None, 'dummy_pair': list(DUMMY_PAIR)},
                             'runtime_configuration': {'batch_size': BATCH, 'padding': 'fixed_bucket_max_length',
                                                       'bucket_width': BUCKET_WIDTH, 'precision': 'BF16 autocast',
                                                       'torch': torch.__version__, 'transformers': transformers.__version__,
                                                       'cuda': torch.version.cuda, 'gpu': torch.cuda.get_device_name(0),
                                                       'gpu_uuid_driver_records': gpu_identities,
                                                       'gpu_capability': torch.cuda.get_device_capability(0),
                                                       'tf32_matmul': False, 'tf32_cudnn': False, 'threads': 8,
                                                       'random_seed': seed, 'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                                                       'cudnn_version': torch.backends.cudnn.version(),
                                                       'cudnn_deterministic': torch.backends.cudnn.deterministic,
                                                       'cudnn_benchmark': torch.backends.cudnn.benchmark,
                                                       'float32_matmul_precision': torch.get_float32_matmul_precision(),
                                                       'cublas_workspace_config': os.environ.get('CUBLAS_WORKSPACE_CONFIG'),
                                                       'attention_backend': getattr(model.config, '_attn_implementation', None)}}
                namespace_digest = object_hash(namespace)
                namespace_path = args.output / f'cache_namespace_{dataset}_seed_{seed}.json'
                dump(namespace_path, namespace)
                probe = position_probe(model, tokenizer, threshold, dataset, frame, seed, dummy)
                manifest['probes'].append(probe)
                manifest['strict_cache_equivalence_pass'] &= probe['strict_equivalence_probe_pass']
                if not probe['strict_equivalence_probe_pass']:
                    manifest['strict_cache_equivalence_failure'] = 'Same serialized key under different row positions was not bitwise invariant; results retained, no gold-based representative selection'
                    print('STRICT_CACHE_EQUIVALENCE_FAILED_PROBE', dataset, seed, flush=True)
                dump(args.output / 'execution_manifest.json', manifest)
                outputs, maps = [], []
                references = {}
                for repeat in range(3 if dataset == 'main220' else 1):
                    results = {}
                    for condition in np.random.default_rng(seed + repeat).permutation(CONDITIONS).tolist():
                        values, stats, mapping = execute(model, tokenizer, threshold, frame, condition, namespace_digest, dummy)
                        times.append({'dataset': dataset, 'seed': seed, 'threshold': threshold, 'condition': condition,
                                      'repeat': repeat, 'rows': len(frame), **stats})
                        results[condition] = values
                        out = frame[[field for field in META if field in frame]].copy()
                        for table in (out, mapping):
                            table['dataset'], table['seed'], table['condition'], table['repeat'] = dataset, seed, condition, repeat
                            table['threshold'] = threshold
                        for name, value in values.items():
                            out[name] = value
                        outputs.append(out)
                        maps.append(mapping)
                        if condition in references:
                            agreements.append({'dataset': dataset, 'seed': seed, 'repeat': repeat,
                                               'comparison': f'repeat0_vs_repeat{repeat}_{condition}',
                                               **compare(references[condition], values)})
                        else:
                            references[condition] = {name: value.copy() for name, value in values.items()}
                        pd.DataFrame(times).to_csv(args.output / 'timing.csv', index=False)
                        print('FINISH', dataset, seed, condition, repeat, round(stats['seconds'], 4),
                              'real_rows', stats['actual_real_model_rows'], 'batches', stats['actual_model_batches'], flush=True)
                    for mode in ('full', 'exact_dimension'):
                        result = compare(results[f'{mode}_nocache'], results[f'{mode}_exact_cache'])
                        agreements.append({'dataset': dataset, 'seed': seed, 'repeat': repeat,
                                           'comparison': f'{mode}_nocache_vs_exact_cache', **result})
                        manifest['strict_cache_equivalence_pass'] &= result['strict_cache_equivalence_pass']
                        if not result['strict_cache_equivalence_pass']:
                            manifest['strict_cache_equivalence_failure'] = 'Canonical complete-row scoring and exact-cache scoring differed; outputs retained, no gold-based mapping changes'
                    dump(args.output / 'execution_manifest.json', manifest)
                predictions_path = args.output / f'predictions_{dataset}_seed_{seed}.csv.gz'
                mapping_path = args.output / f'cache_mapping_{dataset}_seed_{seed}.csv.gz'
                predictions = pd.concat(outputs, ignore_index=True)
                mappings = pd.concat(maps, ignore_index=True)
                repeats = 3 if dataset == 'main220' else 1
                expected_rows = len(frame) * len(CONDITIONS) * repeats
                require(len(predictions) == len(mappings) == expected_rows, 'Incomplete row outputs or cache mappings')
                for table in (predictions, mappings):
                    groups = table.groupby(['condition', 'repeat'], sort=False).size()
                    require(len(groups) == len(CONDITIONS) * repeats and groups.eq(len(frame)).all(),
                            'Incomplete repeat/condition row coverage')
                predictions.to_csv(predictions_path, index=False, compression='gzip')
                mappings.to_csv(mapping_path, index=False, compression='gzip')
                pd.DataFrame(agreements).to_csv(args.output / 'canonical_agreement.csv', index=False)
                manifest['completed_runs'].append({'dataset': dataset, 'seed': seed, 'threshold': threshold,
                                                    'namespace_sha256': namespace_digest,
                                                    'namespace_file': namespace_path.name, 'namespace_file_sha256': sha(namespace_path),
                                                    'predictions': predictions_path.name, 'predictions_sha256': sha(predictions_path),
                                                    'cache_mapping': mapping_path.name, 'cache_mapping_sha256': sha(mapping_path)})
                dump(args.output / 'execution_manifest.json', manifest)
            del model, tokenizer
            gc.collect()
            torch.cuda.empty_cache()
        require(len(times) == 60 and len(manifest['completed_runs']) == 9, 'Incomplete full input experiment')
        # Any repeat mismatch is also a failed strict equivalence claim.
        manifest['strict_cache_equivalence_pass'] &= all(row['strict_cache_equivalence_pass'] for row in agreements)
        manifest['status'] = 'complete_equivalence_pass' if manifest['strict_cache_equivalence_pass'] else 'complete_strict_equivalence_failed'
        manifest['completed_utc'] = datetime.now(timezone.utc).isoformat()
        manifest['timing_sha256'] = sha(args.output / 'timing.csv')
        manifest['agreement_sha256'] = sha(args.output / 'canonical_agreement.csv')
        dump(args.output / 'execution_manifest.json', manifest)
        print('ALL_COMPLETE', manifest['status'], flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--supplement', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--policy', type=Path, default=REMOTE_ROOT / 'system_validation_20261005/scripts/system_policy.py')
    parser.add_argument('--gate-dir', type=Path, default=Path(__file__).resolve().parent.parent / 'generic_unit_gate')
    parser.add_argument('--frozen-plan', type=Path, default=Path(__file__).with_name('canonical_bucket_gpu_plan.json'))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--check-inputs', action='store_true')
    mode.add_argument('--execute-gpu', action='store_true')
    args = parser.parse_args()
    source, frozen, frames, policy, gate, cpu_plan = prepare_inputs(args)
    if not args.execute_gpu:
        print(json.dumps(cpu_plan, ensure_ascii=False, indent=2))
        return
    run_gpu(args, source, frozen, frames, policy, gate, cpu_plan)


if __name__ == '__main__':
    main()
