#!/usr/bin/env python3
"""Independent CPU audit of completed canonical bucket/cache output.

Never imports torch, starts a model/GPU/SSH, downloads data, or changes sources.
Reference values are read only with --evaluate-labels AND a complete prelabel
integrity PASS. Numerical cache failures are preserved as experimental results.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
import tempfile

sys.dont_write_bytecode = True
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
GENERIC = HERE.parent / 'generic_unit_gate'
ROWS = {'main220': 6600, 'challenge600': 600, 'alberta_scope_core': 67635}
SEEDS = (20260904, 20260905, 20260906)
CONDITIONS = ('full_nocache', 'full_exact_cache', 'exact_dimension_nocache', 'exact_dimension_exact_cache')
META = ['pair_id', 'evaluation_split', 'query_id', 'candidate_id', 'source_year']
ITEM = [f'{side}_{field}' for side in ('query', 'candidate')
        for field in ('description', 'normalized_description', 'normalized_unit', 'category', 'spec_tokens')]
MASKS = ('prediction', 'exact_match', 'dimension_rejected', 'model_called')
MAP_INTS = ('input_row_position', 'bucket_length', 'representative_input_row', 'model_row_index', 'model_batch_id', 'model_batch_position')
FORBIDDEN_PRELABEL = {'label', 'labels', 'final_label', 'provisional_label', 'reference_label', 'reference_uncertain', 'difficulty', 'generation_rule'}
REPEATS = {'main220': 3, 'challenge600': 1, 'alberta_scope_core': 1}


def require(condition, message):
    if not bool(condition):
        raise AssertionError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def object_hash(value):
    text = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def inspect_csv(path):
    columns = pd.read_csv(path, nrows=0).columns
    require(not FORBIDDEN_PRELABEL.intersection(columns), f'Answer column in prelabel artifact: {path.name}')
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def scores(column):
    return np.asarray([float(v) if str(v).strip() else np.nan for v in column], dtype=np.float64)


def score_bits(column):
    return np.asarray(column, dtype=np.float32).view(np.uint32)


def binary(frame, field):
    require(frame[field].isin(['0', '1']).all(), f'Nonbinary output: {field}')
    return frame[field].astype(int).to_numpy(bool)


def comparison(a, b):
    mask = a['model_called'].to_numpy(bool)
    require(np.array_equal(mask, b['model_called'].to_numpy(bool)), 'Different scoring masks in numerical comparison')
    left = a['score'].to_numpy(float)[mask]
    right = b['score'].to_numpy(float)[mask]
    bits = int((score_bits(left) != score_bits(right)).sum())
    decisions = int(a.prediction.ne(b.prediction).sum())
    ranks = int(a.returned_rank.ne(b.returned_rank).sum())
    return {'score_bitwise_difference_rows': bits, 'decision_difference_rows': decisions,
            'returned_rank_difference_rows': ranks,
            'maximum_absolute_score_difference': float(np.max(np.abs(left - right))) if len(left) else 0.0,
            'strict_cache_equivalence_pass': bits == 0 and decisions == 0 and ranks == 0}


def changed_rows(a, b, identity):
    require(a.pair_id.tolist() == b.pair_id.tolist(), 'Change report pair ordering differs')
    called = a.model_called.to_numpy(bool)
    bit_changed = np.zeros(len(a), bool)
    bit_changed[called] = score_bits(a.score.to_numpy(float)[called]) != score_bits(b.score.to_numpy(float)[called])
    decision_changed = a.prediction.ne(b.prediction).to_numpy()
    rank_changed = a.returned_rank.ne(b.returned_rank).to_numpy()
    mask = bit_changed | decision_changed | rank_changed
    table = b.loc[mask, [field for field in META if field in b]].copy()
    table['input_row_position'] = np.flatnonzero(mask)
    for field, value in identity.items():
        table[field] = value
    for field in ('score', 'prediction', 'returned_rank'):
        table['baseline_' + field] = a.loc[mask, field].to_numpy()
        table[field] = b.loc[mask, field].to_numpy()
    table['score_bitwise_changed'] = bit_changed[mask]
    table['decision_changed'] = decision_changed[mask]
    table['returned_rank_changed'] = rank_changed[mask]
    return table


def cache_key(namespace_digest, pair, bucket):
    return object_hash({'schema': 'canonical-bucket-score-v1', 'namespace': namespace_digest,
                        'ordered_serialized_pair': list(pair), 'fixed_bucket_length': int(bucket)})


def first_unique(pairs):
    positions, unique, inverse, first = {}, [], [], []
    for i, pair in enumerate(pairs):
        if pair not in positions:
            positions[pair] = len(unique)
            unique.append(pair)
            first.append(i)
        inverse.append(positions[pair])
    return unique, np.asarray(inverse, dtype=int), np.asarray(first, dtype=int)


def verify_namespace(namespace, dataset, source_run, frozen, execution):
    require(namespace['scoring_regime'] == 'canonical_bucket_batch64_v1', 'Wrong numerical regime')
    require(namespace['checkpoint_manifest_sha256'] == object_hash(source_run['checkpoint_files']), 'Checkpoint namespace differs')
    tokenizer_files = {name: digest for name, digest in source_run['checkpoint_files'].items()
                       if name not in ('config.json', 'model.safetensors')}
    require(namespace['tokenizer_manifest_sha256'] == object_hash(tokenizer_files), 'Tokenizer namespace differs')
    require(namespace['serializer_sha256'] == frozen['file_sha256']['policy'], 'Serializer namespace differs')
    variant = 'scope_core_description_equals_normalized' if dataset == 'alberta_scope_core' else 'frozen_five_field_original'
    require(namespace['input_variant'] == variant, 'Input variant namespace differs')
    model, runtime = namespace['model_configuration'], namespace['runtime_configuration']
    require(not any('threshold' in key.lower() for part in (namespace, model, runtime) for key in part), 'Threshold entered numeric score namespace')
    require(model['max_length'] == 256 and model['truncation'] is True and model['evaluation_mode'] is True,
            'Model preprocessing/evaluation namespace differs')
    require(model['dummy_pair'] == ['', ''] and model['architecture_config_sha256'] == source_run['checkpoint_files']['config.json'],
            'Dummy/model configuration namespace differs')
    require(runtime['batch_size'] == 64 and runtime['bucket_width'] == 32 and runtime['padding'] == 'fixed_bucket_max_length', 'Fixed tensor-shape namespace differs')
    require(runtime['precision'] == 'BF16 autocast' and runtime['tf32_matmul'] is False and runtime['tf32_cudnn'] is False,
            'Numerical precision namespace differs')
    require(runtime['torch'] == execution['torch_version'] and runtime['transformers'] == execution['transformers_version']
            and runtime['cuda'] == execution['cuda_version'] and runtime['gpu'] == execution['gpu'], 'Numerical runtime identity differs')
    require(runtime['gpu_uuid_driver_records'] == execution['gpu_uuid_driver_records']
            and int(runtime['random_seed']) == int(source_run['seed']) and runtime['threads'] == 8,
            'GPU UUID/driver/seed/threads namespace not bound to actual execution')


def output_block(raw, dataset, seed, condition, repeat, frame, threshold, pairs, exact_input, dimension_input, adapters):
    block = raw.loc[raw.condition.eq(condition) & raw.repeat.astype(int).eq(repeat)].reset_index(drop=True)
    require(len(block) == len(frame), f'Incomplete prediction block {dataset}/{seed}/{condition}/{repeat}')
    require(block.pair_id.tolist() == frame.pair_id.tolist(), 'Prediction pair order differs')
    for field in META:
        if field in frame:
            require(block[field].tolist() == frame[field].tolist(), f'Prediction metadata differs: {field}')
    require(block.threshold.astype(float).eq(threshold).all(), 'Output threshold changed')
    gated = condition.startswith('exact_dimension_')
    exact = exact_input if gated else np.zeros(len(frame), bool)
    rejected = (~exact & dimension_input) if gated else np.zeros(len(frame), bool)
    called = ~exact & ~rejected
    parsed = {field: binary(block, field) for field in MASKS}
    for field, mask in {'exact_match': exact, 'dimension_rejected': rejected, 'model_called': called}.items():
        require(np.array_equal(parsed[field], mask), f'Input-only mask mismatch: {field}')
    values = scores(block.score)
    require(np.isfinite(values[called]).all() and np.isnan(values[~called]).all(), 'Finite called / NaN uncalled contract fails')
    prediction = exact | (called & (values >= threshold))
    require(np.array_equal(parsed['prediction'], prediction), 'Prediction differs from exact or score>=frozen threshold')
    rank = block.returned_rank.astype(int).to_numpy()
    require(np.array_equal(rank, adapters.independent_rank(frame, exact, values, threshold)), 'Independent full-pool Top3 recomputation differs')
    require(not ((rank > 0) & ~prediction).any(), 'Rejected pair returned')
    block['score'], block['returned_rank'] = values, rank
    for field, values in parsed.items():
        block[field] = values.astype(int)
    return block, called


def verify_mapping(raw, block, frame, pairs, called, namespace_digest, condition, repeat):
    mapping = raw.loc[raw.condition.eq(condition) & raw.repeat.astype(int).eq(repeat)].reset_index(drop=True)
    require(len(mapping) == len(frame) and mapping.pair_id.tolist() == frame.pair_id.tolist(), 'Mapping row coverage/order differs')
    require(mapping.threshold.astype(float).eq(float(block.threshold.iloc[0])).all(), 'Mapping threshold differs')
    for field in META:
        if field in frame:
            require(mapping[field].tolist() == frame[field].tolist(), f'Mapping metadata differs: {field}')
    for field in MAP_INTS:
        values = pd.to_numeric(mapping[field], errors='raise').to_numpy(float)
        require(np.isfinite(values).all() and np.equal(values, np.floor(values)).all(), f'Noninteger mapping field: {field}')
        mapping[field] = values.astype(int)
    require(mapping.input_row_position.tolist() == list(range(len(frame))), 'Mapping original positions differ')
    ix = np.flatnonzero(called)
    selected = [pairs[i] for i in ix]
    cached = condition.endswith('_exact_cache')
    unique, inverse, first = first_unique(selected)
    chosen = unique if cached else selected
    if not cached:
        inverse, first = np.arange(len(selected)), np.arange(len(selected))
    representative_rows = ix[first] if len(ix) else np.asarray([], dtype=int)
    require(mapping.loc[~called, ['serialized_pair_sha256', 'cache_key_sha256']].eq('').all().all(), 'Uncalled row has model/cache text key')
    require(mapping.loc[~called, list(MAP_INTS[1:])].eq(-1).all().all(), 'Uncalled row has model mapping')
    lengths = [int(mapping.at[int(row), 'bucket_length']) for row in representative_rows]
    require(all(32 <= length <= 256 and length % 32 == 0 for length in lengths), 'Invalid fixed bucket length')
    batch_ids, positions, batch_n = np.full(len(chosen), -1), np.full(len(chosen), -1), 0
    for bucket in range(32, 257, 32):
        selected_indices = [i for i, length in enumerate(lengths) if length == bucket]
        for lo in range(0, len(selected_indices), 64):
            part = selected_indices[lo:lo + 64]
            batch_ids[part], positions[part] = batch_n, np.arange(len(part))
            batch_n += 1
    for j, row in enumerate(ix):
        i, pair = int(inverse[j]), selected[j]
        require(mapping.at[row, 'serialized_pair_sha256'] == object_hash(list(pair)), 'Mapping uses a nonexact/incorrect pair content key')
        require(mapping.at[row, 'cache_key_sha256'] == cache_key(namespace_digest, pair, lengths[i]), 'Production cache namespace/key differs')
        for field, expected in {'bucket_length': lengths[i], 'representative_input_row': int(representative_rows[i]),
                                'model_row_index': i, 'model_batch_id': int(batch_ids[i]), 'model_batch_position': int(positions[i])}.items():
            require(int(mapping.at[row, field]) == expected, f'Cache mapping differs: {field}')
        if cached:
            require(score_bits([block.at[row, 'score']])[0] == score_bits([block.at[representative_rows[i], 'score']])[0],
                    'Cache did not restore the representative score exactly')
    return {'rows': len(frame), 'model_required_pairs': len(ix), 'unique_serialized_pair_keys': len(unique),
            'actual_real_model_rows': len(chosen), 'actual_model_batches': batch_n,
            'actual_padded_gpu_rows': batch_n * 64, 'dummy_model_rows': batch_n * 64 - len(chosen),
            'cache_reused_pair_occurrences': len(ix) - len(chosen),
            'exact_accepted_pairs': int(block.exact_match.sum()), 'dimension_rejected_pairs': int(block.dimension_rejected.sum()),
            'cache_initial_state': 'empty', 'top3_applicable': 'query_id' in frame}, mapping


def verify_probe(path, summary, dataset, seed, frame, pairs, threshold, mappings):
    probe = inspect_csv(path)
    unique, _, first = first_unique(pairs)
    counts = Counter(pairs)
    keys = {object_hash(list(pair)): (pair, int(i)) for pair, i in zip(unique, first)}
    require(len(probe) == len(keys) and probe.serialized_pair_sha256.nunique() == len(keys)
            and set(probe.serialized_pair_sha256) == set(keys), 'Probe does not cover every unique exact serialized input')
    require(probe.dataset.eq(dataset).all() and probe.seed.astype(int).eq(seed).all() and probe.threshold.astype(float).eq(threshold).all(), 'Probe identity/threshold differs')
    first_scores, second_scores = scores(probe.score_original), scores(probe.score_permuted)
    require(np.isfinite(first_scores).all() and np.isfinite(second_scores).all(), 'Invalid probe scores')
    bits_a, bits_b = score_bits(first_scores), score_bits(second_scores)
    require(np.array_equal(bits_a.astype(np.uint64), probe.score_original_bits_u32.astype(np.uint64)), 'Probe original score-bit record differs')
    require(np.array_equal(bits_b.astype(np.uint64), probe.score_permuted_bits_u32.astype(np.uint64)), 'Probe permuted score-bit record differs')
    recorded_equal = probe.score_bitwise_equal.map({'True': True, 'False': False})
    require(recorded_equal.notna().all() and np.array_equal(recorded_equal.to_numpy(bool), bits_a == bits_b), 'Probe bitwise flags differ')
    require(np.array_equal(first_scores >= threshold, binary(probe, 'decision_original'))
            and np.array_equal(second_scores >= threshold, binary(probe, 'decision_permuted')), 'Probe decisions not from frozen threshold')
    for row in probe.to_dict('records'):
        pair, representative = keys[row['serialized_pair_sha256']]
        require(int(row['representative_input_row']) == representative and int(row['input_multiplicity']) == counts[pair], 'Probe representative/count differs')
        original, permuted = int(row['original_position']), int(row['permuted_position'])
        require(0 <= original < 64 and permuted == (original + 31) % 64 and original != permuted, 'Probe does not move original row by31')
        require(32 <= int(row['bucket_length']) <= 256 and int(row['bucket_length']) % 32 == 0, 'Probe bucket differs')
    full = mappings[('full_nocache', 0)]
    unique_mapping = mappings[('full_exact_cache', 0)]
    for row in probe.to_dict('records'):
        representative = int(row['representative_input_row'])
        require(int(row['original_position']) == int(unique_mapping.at[representative, 'model_batch_position'])
                and int(row['probe_batch_id']) == int(unique_mapping.at[representative, 'model_batch_id']),
                'Probe original stable-unique batch layout differs from verified full-cache mapping')
    probe_bucket = dict(zip(probe.serialized_pair_sha256, probe.bucket_length.astype(int)))
    require(full.apply(lambda row: int(row.bucket_length) == probe_bucket[row.serialized_pair_sha256], axis=1).all(), 'Probe/full-run bucket assignment differs')
    bit_differences = int((bits_a != bits_b).sum())
    decision_differences = int(((first_scores >= threshold) != (second_scores >= threshold)).sum())
    batches = int(probe.probe_batch_id.astype(int).max()) + 1
    require(probe.probe_batch_id.astype(int).nunique() == batches, 'Probe batch IDs not contiguous')
    for field, expected in {'unique_keys_probed': len(keys), 'probe_model_batches': batches * 2,
                            'probe_padded_gpu_rows': batches * 2 * 64, 'score_bitwise_difference_keys': bit_differences,
                            'decision_difference_keys': decision_differences,
                            'strict_equivalence_probe_pass': bit_differences == 0 and decision_differences == 0}.items():
        require(summary[field] == expected, f'Probe manifest differs: {field}')
    return {'dataset': dataset, 'seed': seed, 'unique_keys_probed': len(keys),
            'score_bitwise_difference_keys': bit_differences, 'decision_difference_keys': decision_differences,
            'strict_equivalence_probe_pass': bit_differences == 0 and decision_differences == 0}, probe


def label_free_audit(args, record):
    prepared = json.loads(args.audit_plan.read_text())
    require(prepared['schema'] == 'independent-canonical-output-audit-v1', 'Unexpected evaluation plan')
    require(sha(__file__) == prepared['evaluator_sha256'], 'Evaluator changed after freeze')
    frozen_path = HERE / 'canonical_bucket_gpu_plan.json'
    require(sha(frozen_path) == prepared['canonical_inference_plan_sha256'], 'Canonical inference plan changed')
    frozen = json.loads(frozen_path.read_text())
    adapter_path = GENERIC / 'evaluate_all_source_actual_cpu.py'
    require(sha(adapter_path) == prepared['metric_label_adapter_sha256'], 'Frozen metric/label adapter changed')
    adapter_plan_path = GENERIC / 'independent_all_source_cpu_evaluation_plan.json'
    require(sha(adapter_plan_path) == prepared['metric_label_adapter_plan_sha256'], 'Reference adapter plan changed')
    for path in (Path(__file__).resolve(), args.audit_plan, frozen_path, adapter_path, adapter_plan_path):
        record[str(path)] = sha(path)
    adapters = load_module('canonical_eval_frozen_metric_adapters', adapter_path)
    gate_path = GENERIC / 'generic_unit_gate.py'
    require(sha(gate_path) == frozen['file_sha256']['generic_gate'], 'Generic gate changed')
    require(sha(GENERIC / 'unit_dimension_ontology.json') == frozen['file_sha256']['ontology'], 'Ontology changed')
    gate = load_module('canonical_eval_frozen_generic_gate', gate_path)
    policy_path = WORKSPACE / 'output/rule_first_system_validation_20261005/scripts/system_policy.py'
    require(sha(policy_path) == frozen['file_sha256']['policy'], 'Frozen input serializer changed')
    policy = load_module('canonical_eval_frozen_serializer', policy_path)
    for path in (gate_path, GENERIC / 'unit_dimension_ontology.json', policy_path):
        record[str(path)] = sha(path)
    source_path = args.source / 'source_manifest.json'
    require(sha(source_path) == frozen['source_manifest_sha256'] == prepared['source_manifest_sha256'], 'Source model/threshold manifest changed')
    source = json.loads(source_path.read_text())
    require(source['labels_sha256'] == prepared['reference_sha256']['main220'], 'Frozen main reference version metadata differs')
    record[str(source_path)] = sha(source_path)
    source_runs = {int(row['seed']): row for row in source['runs']}
    require(set(source_runs) == set(SEEDS), 'Source checkpoint grid differs')
    for seed, run in source_runs.items():
        require(float(run['threshold']) == float(prepared['thresholds'][str(seed)]), 'Original threshold changed')
    paths = {'main220': args.source / 'inputs.csv', 'challenge600': args.supplement / 'model_inputs_challenge600.csv',
             'alberta_scope_core': args.supplement / 'model_inputs_alberta_scope_core.csv'}
    frames, pairs, input_masks = {}, {}, {}
    for dataset, path in paths.items():
        require(sha(path) == frozen['input_sha256'][dataset], 'Frozen model input changed')
        record[str(path)] = sha(path)
        header = pd.read_csv(path, nrows=0).columns
        require(not FORBIDDEN_PRELABEL.intersection(header), 'Label/reference column in model input')
        frame = pd.read_csv(path, usecols=[field for field in META + ITEM if field in header], dtype=str, keep_default_na=False)
        if dataset == 'main220':
            frame = frame.loc[frame.evaluation_split.ne('validation')].reset_index(drop=True)
        if dataset == 'alberta_scope_core':
            for side in ('query', 'candidate'):
                frame[f'{side}_description'] = frame[f'{side}_normalized_description']
        require(len(frame) == ROWS[dataset] and frame.pair_id.nunique() == len(frame), 'Frozen input count/IDs differ')
        frames[dataset] = frame
        pairs[dataset] = list(zip(policy.serialize(frame, 'query'), policy.serialize(frame, 'candidate')))
        exact = adapters.independent_exact(frame)
        dimension = np.asarray(gate.dimension_conflict_mask(frame), bool)
        require(not np.any(exact & dimension), 'Exact/dimension contradiction')
        input_masks[dataset] = exact, dimension
    execution_path = args.actual / 'execution_manifest.json'
    execution = json.loads(execution_path.read_text())
    record[str(execution_path)] = sha(execution_path)
    require(execution['status'] in ('complete_equivalence_pass', 'complete_strict_equivalence_failed'), 'Actual run incomplete')
    require(execution['labels_read'] is False and execution['training_performed'] is False
            and execution['thresholds_retuned'] is False, 'Actual run accessed labels/changed model policy')
    require(execution['new_gpu_inference_executed'] is True and execution['legacy_equivalence_claim'] is False,
            'Actual canonical regime incorrectly described')
    require(execution['runner_sha256'] == frozen['file_sha256']['runner']
            and execution['frozen_plan_sha256'] == sha(frozen_path), 'Actual runner/plan provenance differs')
    require(execution['source_manifest_sha256'] == sha(source_path) and execution['input_sha256'] == frozen['input_sha256'], 'Actual input/model manifest differs')
    require(execution['shared_policy_sha256'] == frozen['file_sha256']['policy'] and execution['ontology_sha256'] == frozen['file_sha256']['ontology'], 'Actual shared source hashes differ')
    require(execution['rows'] == ROWS and execution['conditions'] == list(CONDITIONS)
            and execution['batch_size'] == 64 and execution['bucket_width'] == 32 and execution['max_length'] == 256,
            'Actual fixed-shape/input grid differs')
    run_grid = {(row['dataset'], int(row['seed'])): row for row in execution['completed_runs']}
    expected_run_grid = {(dataset, seed) for dataset in ROWS for seed in SEEDS}
    require(len(execution['completed_runs']) == len(run_grid) == 9 and set(run_grid) == expected_run_grid, 'Actual completed-run grid differs')
    probe_grid = {(row['dataset'], int(row['seed'])): row for row in execution['probes']}
    require(len(execution['probes']) == len(probe_grid) == 9 and set(probe_grid) == expected_run_grid, 'Actual probe grid differs')
    require(len(execution['model_loads']) == 3 and {int(row['seed']) for row in execution['model_loads']} == set(SEEDS)
            and all(row['checkpoint_files_verified'] is True for row in execution['model_loads']), 'Checkpoint verification/load coverage differs')
    outputs, count_rows, independent_agreements, probe_rows = {}, [], [], []
    total_predictions = total_mappings = 0
    for dataset, seed in sorted(expected_run_grid):
        frame, ordered_pairs = frames[dataset], pairs[dataset]
        threshold, completed = float(source_runs[seed]['threshold']), run_grid[(dataset, seed)]
        require(float(completed['threshold']) == threshold, 'Completed-run threshold differs')
        filenames = {'predictions': f'predictions_{dataset}_seed_{seed}.csv.gz',
                     'cache_mapping': f'cache_mapping_{dataset}_seed_{seed}.csv.gz',
                     'namespace_file': f'cache_namespace_{dataset}_seed_{seed}.json'}
        for field, filename in filenames.items():
            require(completed[field] == filename, 'Unexpected output filename; never follow arbitrary manifest paths')
            path = args.actual / filename
            require(sha(path) == completed[field + '_sha256'], f'Actual file SHA differs: {filename}')
            record[str(path)] = sha(path)
        namespace = json.loads((args.actual / filenames['namespace_file']).read_text())
        verify_namespace(namespace, dataset, source_runs[seed], frozen, execution)
        namespace_digest = object_hash(namespace)
        require(namespace_digest == completed['namespace_sha256'], 'Namespace semantic digest differs')
        raw = inspect_csv(args.actual / filenames['predictions'])
        raw_mapping = inspect_csv(args.actual / filenames['cache_mapping'])
        expected_rows = len(frame) * len(CONDITIONS) * REPEATS[dataset]
        require(len(raw) == len(raw_mapping) == expected_rows, 'Actual prediction/mapping row count differs')
        total_predictions += len(raw)
        total_mappings += len(raw_mapping)
        expected_blocks = {(condition, repeat) for condition in CONDITIONS for repeat in range(REPEATS[dataset])}
        for table in (raw, raw_mapping):
            require(table.dataset.eq(dataset).all() and table.seed.astype(int).eq(seed).all(), 'Actual table dataset/checkpoint differs')
            require(not table[['pair_id', 'condition', 'repeat']].duplicated().any(), 'Duplicate actual row/condition/repeat')
            observed = set(zip(table.condition, table.repeat.astype(int)))
            require(observed == expected_blocks, 'Actual condition/repeat coverage differs')
        verified_maps = {}
        for condition, repeat in sorted(expected_blocks):
            block, called = output_block(raw, dataset, seed, condition, repeat, frame, threshold, ordered_pairs,
                                         *input_masks[dataset], adapters)
            counts, mapping = verify_mapping(raw_mapping, block, frame, ordered_pairs, called, namespace_digest, condition, repeat)
            outputs[(dataset, seed, condition, repeat)] = block
            verified_maps[(condition, repeat)] = mapping
            count_rows.append({'dataset': dataset, 'seed': seed, 'condition': condition, 'repeat': repeat,
                               'threshold': threshold, **counts})
            if repeat > 0:
                identity = {'dataset': dataset, 'seed': seed, 'repeat': repeat,
                            'comparison': f'repeat0_vs_repeat{repeat}_{condition}'}
                independent_agreements.append({**identity, **comparison(outputs[(dataset, seed, condition, 0)], block)})
        for repeat in range(REPEATS[dataset]):
            for mode in ('full', 'exact_dimension'):
                left = outputs[(dataset, seed, f'{mode}_nocache', repeat)]
                right = outputs[(dataset, seed, f'{mode}_exact_cache', repeat)]
                independent_agreements.append({'dataset': dataset, 'seed': seed, 'repeat': repeat,
                                                'comparison': f'{mode}_nocache_vs_exact_cache', **comparison(left, right)})
        probe_name = f'position_probe_{dataset}_seed_{seed}.csv.gz'
        probe_summary = probe_grid[(dataset, seed)]
        require(probe_summary['output'] == probe_name and sha(args.actual / probe_name) == probe_summary['sha256'], 'Probe raw SHA/name differs')
        record[str(args.actual / probe_name)] = sha(args.actual / probe_name)
        verified_probe, table = verify_probe(args.actual / probe_name, probe_summary, dataset, seed, frame, ordered_pairs,
                                             threshold, verified_maps)
        probe_rows.append(verified_probe)
        failed = ~table.score_bitwise_equal.eq('True') | table.decision_original.ne(table.decision_permuted)
        table.loc[failed].to_csv(args.output / f'all_probe_failures_{dataset}_seed_{seed}.csv', index=False)
    require(total_predictions == total_mappings == 1056420, 'Total actual output coverage differs')
    counts = pd.DataFrame(count_rows)
    require(len(counts) == 60 and len(independent_agreements) == 54 and len(probe_rows) == 9, 'Expected audit grid differs')
    timing_path = args.actual / 'timing.csv'
    agreement_path = args.actual / 'canonical_agreement.csv'
    for path, field in ((timing_path, 'timing_sha256'), (agreement_path, 'agreement_sha256')):
        require(sha(path) == execution[field], f'Actual final file SHA differs: {path.name}')
        record[str(path)] = sha(path)
    timing = pd.read_csv(timing_path)
    keys = ['dataset', 'seed', 'condition', 'repeat']
    require(len(timing) == 60 and not timing[keys].duplicated().any(), 'Actual timing not60 unique rows')
    require(set(map(tuple, timing[keys].to_numpy())) == set(map(tuple, counts[keys].to_numpy())), 'Timing grid differs')
    joined_counts = timing.merge(counts, on=keys, suffixes=('_actual', '_independent'), validate='one_to_one')
    for field in counts.columns.difference(keys):
        left, right = joined_counts[field + '_actual'], joined_counts[field + '_independent']
        require(left.eq(right).all(), f'Actual timing count/identity differs: {field}')
    require(np.isfinite(timing.seconds).all() and timing.seconds.gt(0).all(), 'Invalid actual elapsed times')
    agreements = pd.DataFrame(independent_agreements)
    reported_agreements = pd.read_csv(agreement_path)
    agreement_keys = ['dataset', 'seed', 'repeat', 'comparison']
    require(len(reported_agreements) == 54 and not reported_agreements[agreement_keys].duplicated().any(), 'Actual agreement not54 unique rows')
    joined = reported_agreements.merge(agreements, on=agreement_keys, suffixes=('_actual', '_independent'), validate='one_to_one')
    require(len(joined) == 54, 'Missing actual agreement comparisons')
    for field in agreements.columns.difference(agreement_keys):
        require(joined[field + '_actual'].eq(joined[field + '_independent']).all(), f'Actual agreement record differs: {field}')
    strict_pass = all(row['strict_equivalence_probe_pass'] for row in probe_rows) and agreements.strict_cache_equivalence_pass.all()
    require(bool(execution['strict_cache_equivalence_pass']) == bool(strict_pass), 'Actual strict equivalence status contradicted by outputs')
    require(execution['status'] == ('complete_equivalence_pass' if strict_pass else 'complete_strict_equivalence_failed'), 'Actual completion status incorrect')
    counts.to_csv(args.output / 'independent_actual_model_counts.csv', index=False)
    agreements.to_csv(args.output / 'independent_canonical_agreements.csv', index=False)
    agreements.loc[~agreements.strict_cache_equivalence_pass].to_csv(args.output / 'all_failed_canonical_comparisons.csv', index=False)
    all_changes = []
    for row in independent_agreements:
        dataset, seed, repeat, name = row['dataset'], row['seed'], row['repeat'], row['comparison']
        if name.startswith('repeat0_vs_repeat'):
            condition = name.split('_', 3)[3]
            a, b = outputs[(dataset, seed, condition, 0)], outputs[(dataset, seed, condition, repeat)]
        else:
            mode = name.removesuffix('_nocache_vs_exact_cache')
            a, b = outputs[(dataset, seed, f'{mode}_nocache', repeat)], outputs[(dataset, seed, f'{mode}_exact_cache', repeat)]
        all_changes.append(changed_rows(a, b, {'dataset': dataset, 'seed': seed, 'repeat': repeat, 'comparison': name}))
    pd.concat(all_changes, ignore_index=True).to_csv(args.output / 'all_changed_canonical_rows.csv', index=False)
    pd.DataFrame(probe_rows).to_csv(args.output / 'independent_probe_counts.csv', index=False)
    audit = {'passed': True, 'labels_read': False, 'phase': 'complete_prelabel_integrity',
             'prediction_files': 9, 'mapping_files': 9, 'namespace_files': 9, 'probe_files': 9,
             'prediction_rows': total_predictions, 'mapping_rows': total_mappings, 'timing_rows': 60, 'agreement_rows': 54,
             'canonical_strict_equivalence_pass': bool(strict_pass), 'actual_status': execution['status'],
             'all_numerical_failures_preserved': True, 'source_hashes': dict(record),
             'bucket_validation_limit': 'fixed-shape mapping, key/bucket consistency and frozen executed code verified; no offline tokenizer retokenization performed',
             'checked_utc': datetime.now(timezone.utc).isoformat()}
    dump(args.output / 'prelabel_canonical_integrity.json', audit)
    return source, frames, outputs, timing, audit, adapters


def canonical_timing(timing, adapters):
    rows = []
    for (dataset, seed, condition), group in timing.groupby(['dataset', 'seed', 'condition'], sort=False):
        mode = 'exact_dimension' if condition.startswith('exact_dimension_') else 'full'
        reference = timing.loc[timing.dataset.eq(dataset) & timing.seed.eq(seed) & timing.condition.eq(mode + '_nocache')]
        require(len(group) == len(reference) == REPEATS[dataset], 'Timing repeat scope differs')
        elapsed, base = float(group.seconds.median()), float(reference.seconds.median())
        real, padded = int(group.actual_real_model_rows.iloc[0]), int(group.actual_padded_gpu_rows.iloc[0])
        base_real, base_padded = int(reference.actual_real_model_rows.iloc[0]), int(reference.actual_padded_gpu_rows.iloc[0])
        rows.append({'dataset': dataset, 'seed': seed, 'condition': condition, 'baseline_condition': mode + '_nocache',
                     'repeat_n': len(group), 'seconds_seed_median': elapsed, 'baseline_seconds_seed_median': base,
                     'actual_real_model_rows': real, 'actual_padded_gpu_rows': padded,
                     'actual_model_batches': int(group.actual_model_batches.iloc[0]),
                     'unique_serialized_pair_keys': int(group.unique_serialized_pair_keys.iloc[0]),
                     'real_row_reduction_vs_same_mode_nocache': 1 - real / base_real if base_real else None,
                     'padded_row_reduction_vs_same_mode_nocache': 1 - padded / base_padded if base_padded else None,
                     'seconds_reduction_vs_same_mode_nocache': 1 - elapsed / base,
                     'speedup_vs_same_mode_nocache': base / elapsed,
                     'full_batch_cost_cny_2_88_per_hour': elapsed * adapters.RATE_CNY_PER_HOUR / 3600,
                     'time_claim_scope': 'actual same canonical experiment; synchronized resident model; preprocessing included; cold exact cache'})
    each = pd.DataFrame(rows)
    return each, adapters.seed_aggregate(each, ['dataset', 'condition', 'baseline_condition'], ['seed'])


def normal_batch_comparison(args, source, frames, outputs, timing, adapters, record):
    require(args.normal_actual is not None, 'Normal batching comparison requires the completed matching all_source_actual directory')
    normal_dir = args.output / 'normal_batch_integrity'
    normal_dir.mkdir()
    normal_args = argparse.Namespace(actual=args.normal_actual, source=args.source, supplement=args.supplement, output=normal_dir)
    normal_source, normal_frames, normal_outputs, normal_timing, normal_audit = adapters.label_free_audit(normal_args, record)
    require(normal_audit['passed'] and not normal_audit['labels_read'], 'Matched normal batching audit failed')
    require(normal_source['runs'] == source['runs'], 'Normal/canonical model checkpoint/threshold sources differ')
    summaries, changed, time_rows = [], [], []
    for dataset in ROWS:
        for seed in SEEDS:
            for mode, normal_policy in (('full', 'all_bge'), ('exact_dimension', 'dimension_gate_bge')):
                baseline = normal_outputs[(dataset, seed, normal_policy)].rename(columns={'bge_called': 'model_called'})
                current = outputs[(dataset, seed, mode + '_nocache', 0)]
                require(baseline.pair_id.tolist() == current.pair_id.tolist(), 'Normal/canonical input identity/order differs')
                identity = {'dataset': dataset, 'seed': seed, 'normal_policy': normal_policy,
                            'canonical_condition': mode + '_nocache', 'canonical_prediction_repeat': 0,
                            'comparison_type': 'normal_batching_vs_new_canonical_regime'}
                numerical = comparison(baseline, current)
                numerical['normal_vs_canonical_outputs_identical'] = numerical.pop('strict_cache_equivalence_pass')
                summaries.append({**identity, **numerical})
                changed.append(changed_rows(baseline, current, identity))
                old = normal_timing.loc[normal_timing.dataset.eq(dataset) & normal_timing.seed.eq(seed) & normal_timing.policy.eq(normal_policy)]
                new = timing.loc[timing.dataset.eq(dataset) & timing.seed.eq(seed) & timing.condition.eq(mode + '_nocache')]
                require(len(old) == len(new) == REPEATS[dataset], 'Normal/canonical timing repeats differ')
                old_seconds, new_seconds = float(old.seconds.median()), float(new.seconds.median())
                require(int(old.bge_pairs.iloc[0]) == int(new.model_required_pairs.iloc[0]), 'Normal/canonical required model rows differ')
                time_rows.append({**identity, 'normal_seconds_seed_median': old_seconds,
                                  'canonical_seconds_seed_median': new_seconds,
                                  'canonical_over_normal_seconds_ratio': new_seconds / old_seconds,
                                  'seconds_change_fraction': new_seconds / old_seconds - 1,
                                  'same_required_model_pairs': int(old.bge_pairs.iloc[0]),
                                  'normal_model_batches_inferred_from_frozen_batch64': math.ceil(int(old.bge_pairs.iloc[0]) / 64),
                                  'canonical_actual_model_batches': int(new.actual_model_batches.iloc[0]),
                                  'canonical_actual_padded_gpu_rows': int(new.actual_padded_gpu_rows.iloc[0]),
                                  'timing_scope': 'separate completed experiments; descriptive comparison, not same-session paired timing; same frozen inputs/models/gate, new padding/bucket regime'})
    pd.DataFrame(summaries).to_csv(args.output / 'normal_vs_canonical_numerical_each_seed.csv', index=False)
    pd.concat(changed, ignore_index=True).to_csv(args.output / 'all_normal_vs_canonical_changed_rows.csv', index=False)
    each_time = pd.DataFrame(time_rows)
    each_time.to_csv(args.output / 'normal_vs_canonical_timing_each_seed.csv', index=False)
    aggregate = adapters.seed_aggregate(each_time, ['dataset', 'normal_policy', 'canonical_condition'], ['seed', 'canonical_prediction_repeat'])
    aggregate.to_csv(args.output / 'normal_vs_canonical_timing_seed_mean_sample_sd.csv', index=False)
    return normal_outputs, normal_audit


def evaluate_labels(args, source, frames, outputs, audit, adapters, record, normal_outputs=None):
    require(audit['passed'] and audit['labels_read'] is False, 'Label join attempted before complete integrity PASS')
    # These existing adapters read only the specified label fields, never use
    # challenge-generation rules, and record the current frozen provenance.
    label_args = argparse.Namespace(source=args.source, reference600=args.reference600,
                                    alberta_reference=args.alberta_reference, challenge_labels=None, alberta_labels=None)
    labels, label_sources, details = adapters.label_join(label_args, source, frames, record)
    pair_rows, top_rows, joined = [], [], {}
    for (dataset, seed, condition, repeat), output in outputs.items():
        frame = output.merge(labels[dataset], on='pair_id', validate='one_to_one')
        require(len(frame) == ROWS[dataset], 'Label join changed model output coverage')
        joined[(dataset, seed, condition, repeat)] = frame
        for view, part in adapters.evaluation_views(dataset, frame):
            identity = {'dataset': dataset, 'seed': seed, 'condition': condition, 'repeat': repeat,
                        'group': view, 'label_source': label_sources[dataset]}
            pair_rows.append({**identity, **adapters.pair_metrics(part)})
            metrics = adapters.top3_metrics(part)
            if view == 'locked100_hard_pairs':
                metrics['scope_note'] = 'Actual full-pool ranks retained; filtered hard-pair view never refills returned slots'
                for key in ('completely_known_no_reference_query_n', 'no_reference_rejected_n', 'no_reference_rejection_rate'):
                    metrics[key] = None
            top_rows.append({**identity, **metrics})
    pair, top = pd.DataFrame(pair_rows), pd.DataFrame(top_rows)
    pair.to_csv(args.output / 'pair_metrics_each_seed_repeat.csv', index=False)
    top.to_csv(args.output / 'actual_top3_metrics_each_seed_repeat.csv', index=False)
    # Repeat0 is declared BEFORE actual results; all later repeat metrics remain
    # above, and no better repeat/model/threshold/representative is selected.
    pair0 = pair.loc[pair.repeat.eq(0)]
    adapters.seed_aggregate(pair0, ['dataset', 'condition', 'group', 'label_source'], ['seed', 'repeat']).to_csv(
        args.output / 'pair_metrics_repeat0_seed_mean_sample_sd.csv', index=False)
    top0 = top.loc[top.repeat.eq(0) & top.top3_available.eq(True)].copy()
    for field in top0:
        if field not in ('dataset', 'condition', 'group', 'label_source', 'reason', 'scope_note'):
            top0[field] = pd.to_numeric(top0[field], errors='coerce')
    adapters.seed_aggregate(top0, ['dataset', 'condition', 'group', 'label_source'], ['seed', 'repeat']).to_csv(
        args.output / 'actual_top3_repeat0_seed_mean_sample_sd.csv', index=False)
    deltas, loss_rows = [], []
    for dataset in ROWS:
        for seed in SEEDS:
            for repeat in range(REPEATS[dataset]):
                for mode in ('full', 'exact_dimension'):
                    baseline = joined[(dataset, seed, mode + '_nocache', repeat)]
                    current = joined[(dataset, seed, mode + '_exact_cache', repeat)]
                    require(baseline.pair_id.tolist() == current.pair_id.tolist(), 'Labelled cache comparison row order differs')
                    known_positive = ~current.uncertain & current.label.eq(1)
                    lost_accept = known_positive & baseline.prediction.eq(1) & current.prediction.eq(0)
                    gained_accept = known_positive & baseline.prediction.eq(0) & current.prediction.eq(1)
                    lost_returned = known_positive & baseline.returned_rank.gt(0) & current.returned_rank.eq(0)
                    gained_returned = known_positive & baseline.returned_rank.eq(0) & current.returned_rank.gt(0)
                    hard = current.difficulty.eq('hard') & current.get('evaluation_split', pd.Series('', index=current.index)).eq('locked')
                    identity = {'dataset': dataset, 'seed': seed, 'repeat': repeat, 'mode': mode,
                                'baseline_condition': mode + '_nocache', 'condition': mode + '_exact_cache',
                                'label_source': label_sources[dataset]}
                    deltas.append({**identity, 'accepted_true_positive_lost': int(lost_accept.sum()),
                                   'accepted_true_positive_gained': int(gained_accept.sum()),
                                   'returned_true_positive_lost': int(lost_returned.sum()),
                                   'returned_true_positive_gained': int(gained_returned.sum()),
                                   'locked_hard_accepted_tp_lost': int((lost_accept & hard).sum()),
                                   'locked_hard_returned_tp_lost': int((lost_returned & hard).sum())})
                    for event, mask in (('accepted_true_positive_lost', lost_accept), ('returned_true_positive_lost', lost_returned)):
                        part = current.loc[mask].copy()
                        for field, value in identity.items():
                            part[field] = value
                        part['event'] = event
                        for field in ('score', 'prediction', 'returned_rank'):
                            part['baseline_' + field] = baseline.loc[mask, field].to_numpy()
                        loss_rows.append(part)
    pd.DataFrame(deltas).to_csv(args.output / 'canonical_cache_true_positive_changes_all_repeats.csv', index=False)
    pd.concat(loss_rows, ignore_index=True).to_csv(args.output / 'all_canonical_cache_lost_true_positive_rows.csv', index=False)
    if normal_outputs is not None:
        normal_pair, normal_top, normal_losses, normal_changes = [], [], [], []
        for dataset in ROWS:
            for seed in SEEDS:
                for mode, normal_policy in (('full', 'all_bge'), ('exact_dimension', 'dimension_gate_bge')):
                    baseline = normal_outputs[(dataset, seed, normal_policy)].merge(labels[dataset], on='pair_id', validate='one_to_one')
                    current = joined[(dataset, seed, mode + '_nocache', 0)]
                    require(baseline.pair_id.tolist() == current.pair_id.tolist(), 'Labelled normal/canonical row order differs')
                    for view, part in adapters.evaluation_views(dataset, baseline):
                        identity = {'dataset': dataset, 'seed': seed, 'normal_policy': normal_policy, 'group': view,
                                    'label_source': label_sources[dataset]}
                        normal_pair.append({**identity, **adapters.pair_metrics(part)})
                        metric = adapters.top3_metrics(part)
                        if view == 'locked100_hard_pairs':
                            for field in ('completely_known_no_reference_query_n', 'no_reference_rejected_n', 'no_reference_rejection_rate'):
                                metric[field] = None
                        normal_top.append({**identity, **metric})
                    positive = ~current.uncertain & current.label.eq(1)
                    lost_accept = positive & baseline.prediction.eq(1) & current.prediction.eq(0)
                    lost_returned = positive & baseline.returned_rank.gt(0) & current.returned_rank.eq(0)
                    identity = {'dataset': dataset, 'seed': seed, 'normal_policy': normal_policy,
                                'canonical_condition': mode + '_nocache', 'canonical_repeat': 0,
                                'comparison_type': 'normal_batching_vs_new_canonical_regime', 'label_source': label_sources[dataset]}
                    normal_changes.append({**identity, 'accepted_true_positive_lost': int(lost_accept.sum()),
                                           'returned_true_positive_lost': int(lost_returned.sum())})
                    for event, mask in (('accepted_true_positive_lost', lost_accept), ('returned_true_positive_lost', lost_returned)):
                        part = current.loc[mask].copy()
                        for field, value in identity.items():
                            part[field] = value
                        part['event'] = event
                        for field in ('score', 'prediction', 'returned_rank'):
                            part['normal_' + field] = baseline.loc[mask, field].to_numpy()
                        normal_losses.append(part)
        pd.DataFrame(normal_pair).to_csv(args.output / 'matched_normal_batch_pair_metrics_each_seed.csv', index=False)
        pd.DataFrame(normal_top).to_csv(args.output / 'matched_normal_batch_top3_metrics_each_seed.csv', index=False)
        pd.DataFrame(normal_changes).to_csv(args.output / 'normal_vs_canonical_true_positive_changes.csv', index=False)
        pd.concat(normal_losses, ignore_index=True).to_csv(args.output / 'all_normal_vs_canonical_lost_true_positive_rows.csv', index=False)
    reference = {'reference_details': details, 'main_reference_source': label_sources['main220'],
                 '600_reference_source': label_sources['challenge600'], 'alberta_reference_source': label_sources['alberta_scope_core'],
                 'alberta_uncertain_pairs': int(labels['alberta_scope_core'].uncertain.sum()),
                 'unknown_actual_top3_slots_preserved': True, 'undefined_precision_is_missing': True,
                 'quality_report_repeat_selection': 'repeat0 predeclared; all repeat metrics and losses retained',
                 'label_values_joined_only_after_prelabel_integrity_pass': True,
                 'test_selected_settings': False, 'human_gold_claim_for_600_or_Alberta': False}
    dump(args.output / 'reference_provenance.json', reference)
    return {'pair_metric_rows_all_repeats': len(pair), 'top3_metric_rows_all_repeats': len(top),
            'accepted_and_returned_lost_tp_event_rows': int(sum(len(frame) for frame in loss_rows)),
            'references': reference}


def self_test():
    # Synthetic fixtures only. No actual prediction/input/reference files read.
    adapter = load_module('canonical_eval_synthetic_metrics', GENERIC / 'evaluate_all_source_actual_cpu.py')
    pairs = [('q0', 'c0'), ('q0', 'c0'), ('q1', 'c1'), ('q2', 'c2'), ('q3', 'c3')]
    frame = pd.DataFrame({'pair_id': [f'p{i}' for i in range(5)], 'evaluation_split': ['x'] * 5,
                          'query_id': ['q'] * 5, 'candidate_id': ['z', 'a', 'b', 'c', 'd']})
    unique, inverse, first = first_unique(pairs)
    require([unique[i] for i in inverse] == pairs and first.tolist() == [0, 2, 3, 4], 'Synthetic inverse/representatives fail')
    rank = adapter.independent_rank(frame, np.asarray([1, 1, 0, 0, 0], bool), np.asarray([np.nan, np.nan, 10., 10., 9.]), 9.)
    require(rank.tolist() == [2, 1, 3, 0, 0], 'Synthetic exact priority/ID tie-break rank fails')
    a = frame.copy()
    a['score'], a['model_called'], a['prediction'], a['returned_rank'] = [1., 1., 2., 3., 4.], 1, [0, 0, 1, 1, 1], [0, 0, 3, 2, 1]
    b = a.copy()
    require(comparison(a, b)['strict_cache_equivalence_pass'], 'Equal synthetic scores should pass')
    b.loc[0, 'score'] = float(np.nextafter(np.float32(1.), np.float32(2.)))
    require(comparison(a, b)['score_bitwise_difference_rows'] == 1 and not comparison(a, b)['strict_cache_equivalence_pass'], 'One-bit score drift ignored')
    changed = changed_rows(a, b, {'comparison': 'synthetic'})
    require(len(changed) == 1 and changed.score_bitwise_changed.all() and not changed.decision_changed.any(), 'Synthetic bit-only change report fails')
    unknown = a.copy()
    unknown['label'], unknown['uncertain'] = [1, 1, 1, 0, 0], [False, False, True, False, False]
    require(adapter.top3_metrics(unknown)['returned_uncertain_n'] == 1, 'Unknown actual slot was discarded/refilled')
    no_accept = unknown.copy()
    no_accept['prediction'] = 0
    require(adapter.pair_metrics(no_accept)['precision'] is None, 'Undefined precision must stay missing')
    require(cache_key('n', ('q', 'c'), 32) != cache_key('n', ('c', 'q'), 32), 'Ordered input cache identity fails')
    require(cache_key('n', ('q', 'c'), 32) != cache_key('n', ('q', 'c'), 64), 'Bucket cache identity fails')
    # Full and cached mapping fixtures cover duplicate scatter and real batches.
    called = np.ones(5, bool)
    with tempfile.TemporaryDirectory(prefix='canonical_eval_synthetic_') as temporary:
        path = Path(temporary)
        fixture = a.copy()
        fixture['threshold'], fixture['exact_match'], fixture['dimension_rejected'] = 0., 0, 0
        for cached in (False, True):
            condition = 'full_exact_cache' if cached else 'full_nocache'
            fixture['condition'], fixture['repeat'] = condition, 0
            mapping = frame.copy()
            mapping['condition'], mapping['repeat'], mapping['threshold'] = condition, 0, 0.
            mapping['input_row_position'] = np.arange(5)
            mapping['serialized_pair_sha256'] = [object_hash(list(pair)) for pair in pairs]
            mapping['cache_key_sha256'] = [cache_key('synthetic', pair, 32) for pair in pairs]
            mapping['bucket_length'] = 32
            mapping['representative_input_row'] = first[inverse] if cached else np.arange(5)
            mapping['model_row_index'] = inverse if cached else np.arange(5)
            mapping['model_batch_id'] = 0
            mapping['model_batch_position'] = inverse if cached else np.arange(5)
            result, _ = verify_mapping(mapping, fixture, frame, pairs, called, 'synthetic', condition, 0)
            require(result['actual_real_model_rows'] == (4 if cached else 5) and result['actual_padded_gpu_rows'] == 64,
                    'Synthetic real/padded model rows differ')
        broken = mapping.copy()
        broken.loc[1, 'representative_input_row'] = 1
        try:
            verify_mapping(broken, fixture, frame, pairs, called, 'synthetic', condition, 0)
            raise RuntimeError('Corrupt representative accepted')
        except AssertionError:
            pass
    print(json.dumps({'synthetic_self_test': 'passed', 'actual_outputs_read': False,
                      'real_reference_values_read': False, 'GPU_or_SSH_used': False}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--actual', type=Path, default=HERE / 'canonical_gpu_actual')
    parser.add_argument('--source', type=Path, default=WORKSPACE / 'output/rule_first_system_20261004/results/server')
    parser.add_argument('--supplement', type=Path, default=WORKSPACE / 'output/paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs')
    parser.add_argument('--normal-actual', type=Path, default=None,
                        help='Optional matching completed generic_unit_gate/all_source_actual; independently audited before comparison/labels')
    parser.add_argument('--reference600', type=Path, default=WORKSPACE / 'output/internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv')
    parser.add_argument('--alberta-reference', type=Path, default=HERE.parent / 'rule_verification/alberta_reference_index.csv')
    parser.add_argument('--audit-plan', type=Path, default=HERE / 'frozen_canonical_cpu_audit_plan.json')
    parser.add_argument('--output', type=Path, default=HERE / 'canonical_actual_cpu_evaluation')
    parser.add_argument('--evaluate-labels', action='store_true')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if args.evaluate_labels:
        require(args.normal_actual is not None, 'Full quality evaluation requires --normal-actual so matched normal integrity is checked before labels')
    require(not args.output.exists(), 'Evaluation directory must be new; preserve earlier failures/results')
    require(args.output.resolve() != args.actual.resolve(), 'Evaluation must not overwrite actual inference')
    if args.normal_actual:
        require(args.output.resolve() != args.normal_actual.resolve(), 'Evaluation must not overwrite normal inference')
    args.output.mkdir(parents=True)
    record = {}
    labels_started = False
    try:
        source, frames, outputs, timing, audit, adapters = label_free_audit(args, record)
        each_time, aggregate_time = canonical_timing(timing, adapters)
        each_time.to_csv(args.output / 'canonical_timing_each_seed.csv', index=False)
        aggregate_time.to_csv(args.output / 'canonical_timing_seed_mean_sample_sd.csv', index=False)
        normal_outputs = None
        normal_audit = None
        if args.normal_actual is not None:
            normal_outputs, normal_audit = normal_batch_comparison(args, source, frames, outputs, timing, adapters, record)
        quality = None
        if args.evaluate_labels:
            labels_started = True
            quality = evaluate_labels(args, source, frames, outputs, audit, adapters, record, normal_outputs)
        for path, digest in record.items():
            require(sha(path) == digest, f'Read source changed during CPU evaluation: {path}')
        summary = {'status': 'completed_cpu_canonical_audit_and_quality' if args.evaluate_labels else 'completed_cpu_canonical_audit_no_label_values',
                   'canonical_strict_equivalence_pass': audit['canonical_strict_equivalence_pass'],
                   'normal_batch_comparison_performed': normal_audit is not None, 'quality': quality,
                   'source_hashes_unchanged': True, 'source_hashes': record,
                   'timing_scope': 'canonical cache-v-nocache paired within same canonical experiment; normal-v-canonical separate completed experiments; no old grouped timings',
                   'precision_undefined_policy': 'missing, with metric-specific defined seed counts',
                   'all_failures_retained': True, 'test_selected_settings': False,
                   'model_system_contribution': 'canonical bucket/cache/generic routing are shared model-independent system optimizations',
                   'completed_utc': datetime.now(timezone.utc).isoformat()}
        dump(args.output / 'summary.json', summary)
        checksums = {str(p.relative_to(args.output)): sha(p) for p in args.output.rglob('*')
                     if p.is_file() and p.name != 'evaluation_artifact_sha256.json' and '__pycache__' not in p.parts}
        dump(args.output / 'evaluation_artifact_sha256.json', checksums)
        print(json.dumps({'status': summary['status'], 'output': str(args.output),
                          'canonical_strict_equivalence_pass': audit['canonical_strict_equivalence_pass']}))
    except Exception as error:
        dump(args.output / 'evaluation_failure.json', {'status': 'failed_integrity_or_evaluation',
             'error_type': type(error).__name__, 'error': str(error), 'label_evaluation_requested': args.evaluate_labels,
             'label_phase_started': labels_started, 'original_sources_not_modified': True})
        raise


if __name__ == '__main__':
    main()
