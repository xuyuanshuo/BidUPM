#!/usr/bin/env python3
"""Independent actual-output second pass; no GPU, SSH or result edits."""
from pathlib import Path
import hashlib
import json
import math

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
WORK = ROOT.parent
ACTUAL = HERE / 'canonical_gpu_actual'
EVALUATION = HERE / 'canonical_actual_cpu_evaluation'
SEEDS = (20260904, 20260905, 20260906)
ROWS = {'main220': 6600, 'challenge600': 600, 'alberta_scope_core': 67635}
CONDITIONS = ('full_nocache', 'full_exact_cache', 'exact_dimension_nocache', 'exact_dimension_exact_cache')
checks = []


def require(condition, description):
    if not bool(condition):
        raise AssertionError(description)
    checks.append(description)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def close(a, b):
    return bool(pd.isna(a) and pd.isna(b)) if pd.isna(a) or pd.isna(b) else math.isclose(float(a), float(b), rel_tol=1e-11, abs_tol=1e-11)


def bits(values):
    return np.asarray(values, dtype=np.float32).view(np.uint32)


def compare(left, right):
    require(left.pair_id.tolist() == right.pair_id.tolist(), 'Raw comparison pair order')
    mask = left.model_called.to_numpy(bool)
    require(np.array_equal(mask, right.model_called.to_numpy(bool)), 'Raw comparison same called rows')
    a, b = left.loc[mask, 'score'].to_numpy(float), right.loc[mask, 'score'].to_numpy(float)
    return {'score_bitwise_difference_rows': int((bits(a) != bits(b)).sum()),
            'decision_difference_rows': int(left.prediction.ne(right.prediction).sum()),
            'returned_rank_difference_rows': int(left.returned_rank.ne(right.returned_rank).sum()),
            'maximum_absolute_score_difference': float(np.max(np.abs(a - b))) if len(a) else 0.0}


summary = json.loads((EVALUATION / 'summary.json').read_text())
require(summary['status'] == 'completed_cpu_canonical_audit_and_quality' and summary['canonical_strict_equivalence_pass'], 'Completed canonical strictPASS status')
for path, digest in summary['source_hashes'].items():
    require(sha(path) == digest, 'Protected canonical/normal/source SHA: ' + Path(path).name)
require(sha(HERE / 'evaluate_canonical_actual_cpu.py') == '2cbfe9eca8ae65bb0f87b7438697780c7a22d008394e6fd1c221b4498d8f7f6f', 'Frozen evaluator unchanged')
artifact_hashes = json.loads((EVALUATION / 'evaluation_artifact_sha256.json').read_text())
for filename, digest in artifact_hashes.items():
    require(sha(EVALUATION / filename) == digest, 'Evaluation output SHA: ' + filename)
agreements = pd.read_csv(EVALUATION / 'independent_canonical_agreements.csv')
require(len(agreements) == 54 and not agreements[['dataset', 'seed', 'repeat', 'comparison']].duplicated().any(), '54 unique numerical comparison conditions')
require(agreements[['score_bitwise_difference_rows', 'decision_difference_rows', 'returned_rank_difference_rows', 'maximum_absolute_score_difference']].eq(0).all().all(), '54 recorded comparisons allzero')
probe_counts = pd.read_csv(EVALUATION / 'independent_probe_counts.csv')
require(len(probe_counts) == 9 and probe_counts.unique_keys_probed.sum() == 102576, 'Nine probes and102576 key/checkpoint observations')
labels = {}
for dataset, path, field in [('main220', WORK / 'rule_first_system_20261004/results/server/labels.csv', 'final_label'),
                             ('challenge600', WORK / 'internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv', 'provisional_label'),
                             ('alberta_scope_core', ROOT / 'rule_verification/alberta_reference_index.csv', 'reference_label')]:
    columns = ['pair_id', field] + (['reference_uncertain'] if dataset == 'alberta_scope_core' else [])
    f = pd.read_csv(path, usecols=columns)
    f['known'] = ~f.reference_uncertain.astype(bool) if dataset == 'alberta_scope_core' else True
    labels[dataset] = f.set_index('pair_id')[[field, 'known']].rename(columns={field: 'label'})

normal_comparisons = pd.read_csv(EVALUATION / 'normal_vs_canonical_numerical_each_seed.csv')
normal_tp_losses = pd.read_csv(EVALUATION / 'normal_vs_canonical_true_positive_changes.csv')
pair = pd.read_csv(EVALUATION / 'pair_metrics_each_seed_repeat.csv')
blocks = {}
normal_changes = []
comparison_count = probe_key_total = total_prediction_rows = 0
for dataset in ROWS:
    for seed in SEEDS:
        raw = pd.read_csv(ACTUAL / f'predictions_{dataset}_seed_{seed}.csv.gz')
        repeat_n = 3 if dataset == 'main220' else 1
        require(len(raw) == ROWS[dataset] * 4 * repeat_n and not raw[['pair_id', 'condition', 'repeat']].duplicated().any(), 'Raw prediction coverage: ' + str((dataset, seed)))
        total_prediction_rows += len(raw)
        for condition in CONDITIONS:
            for repeat in range(repeat_n):
                block = raw.loc[raw.condition.eq(condition) & raw.repeat.eq(repeat)].reset_index(drop=True)
                require(len(block) == ROWS[dataset], 'Full condition rows: ' + str((dataset, seed, condition, repeat)))
                blocks[(dataset, seed, condition, repeat)] = block
        pairs = []
        for repeat in range(repeat_n):
            pairs.extend([(repeat, 'full_nocache_vs_exact_cache', ('full_nocache', repeat), ('full_exact_cache', repeat)),
                          (repeat, 'exact_dimension_nocache_vs_exact_cache', ('exact_dimension_nocache', repeat), ('exact_dimension_exact_cache', repeat))])
        if repeat_n > 1:
            for condition in CONDITIONS:
                for repeat in (1, 2):
                    pairs.append((repeat, f'repeat0_vs_repeat{repeat}_{condition}', (condition, 0), (condition, repeat)))
        for repeat, name, left_key, right_key in pairs:
            got = compare(blocks[(dataset, seed, *left_key)], blocks[(dataset, seed, *right_key)])
            recorded = agreements.loc[agreements.dataset.eq(dataset) & agreements.seed.eq(seed) & agreements.repeat.eq(repeat) & agreements.comparison.eq(name)]
            require(len(recorded) == 1 and all(close(value, recorded.iloc[0][field]) for field, value in got.items()), 'Independent raw54 comparison: ' + str((dataset, seed, repeat, name)))
            comparison_count += 1
        probe = pd.read_csv(ACTUAL / f'position_probe_{dataset}_seed_{seed}.csv.gz')
        expected_n = {'main220': 3562, 'challenge600': 600, 'alberta_scope_core': 30030}[dataset]
        require(len(probe) == probe.serialized_pair_sha256.nunique() == expected_n, 'Unique actual probe count: ' + str((dataset, seed)))
        probe_key_total += len(probe)
        require(np.array_equal(bits(probe.score_original), bits(probe.score_permuted))
                and np.array_equal(bits(probe.score_original), probe.score_original_bits_u32.to_numpy(np.uint32))
                and np.array_equal(bits(probe.score_permuted), probe.score_permuted_bits_u32.to_numpy(np.uint32))
                and probe.decision_original.eq(probe.decision_permuted).all(), 'Probe raw bits/decisions independent: ' + str((dataset, seed)))
        require(probe.permuted_position.eq((probe.original_position + 31) % 64).all(), 'Probe inverse shift31 actual: ' + str((dataset, seed)))
        normal = pd.read_csv(ROOT / 'generic_unit_gate/all_source_actual' / f'predictions_{dataset}_seed_{seed}.csv')
        for normal_policy, canonical in [('all_bge', 'full_nocache'), ('dimension_gate_bge', 'exact_dimension_nocache')]:
            left = normal.loc[normal.policy.eq(normal_policy)].reset_index(drop=True).rename(columns={'bge_called': 'model_called'})
            right = blocks[(dataset, seed, canonical, 0)]
            got = compare(left, right)
            recorded = normal_comparisons.loc[normal_comparisons.dataset.eq(dataset) & normal_comparisons.seed.eq(seed) & normal_comparisons.normal_policy.eq(normal_policy)]
            require(len(recorded) == 1 and all(close(value, recorded.iloc[0][field]) for field, value in got.items()), 'Independent normal-canonical drift: ' + str((dataset, seed, normal_policy)))
            aligned = labels[dataset].loc[left.pair_id]
            positive = aligned.label.eq(1).to_numpy() & aligned.known.to_numpy(bool)
            negative = aligned.label.eq(0).to_numpy() & aligned.known.to_numpy(bool)
            tp_loss = int((positive & left.prediction.eq(1) & right.prediction.eq(0)).sum())
            returned_tp_loss = int((positive & left.returned_rank.gt(0) & right.returned_rank.eq(0)).sum())
            require(tp_loss == returned_tp_loss == 0, 'No known accepted/returnedTP loss vsnormal: ' + str((dataset, seed, normal_policy)))
            change = {'dataset': dataset, 'seed': seed, 'normal_policy': normal_policy,
                      'normal_tp': int((positive & left.prediction.eq(1)).sum()),
                      'canonical_tp': int((positive & right.prediction.eq(1)).sum()),
                      'normal_fp': int((negative & left.prediction.eq(1)).sum()),
                      'canonical_fp': int((negative & right.prediction.eq(1)).sum()), **got}
            normal_changes.append(change)
            scope = {'main220': 'all220_diagnostic', 'challenge600': 'all600_construction_reference', 'alberta_scope_core': 'both_years_pooled'}[dataset]
            scored = pair.loc[pair.dataset.eq(dataset) & pair.seed.eq(seed) & pair.condition.eq(canonical) & pair.repeat.eq(0) & pair.group.eq(scope)]
            require(len(scored) == 1 and scored.tp.iloc[0] == change['canonical_tp'] and scored.fp.iloc[0] == change['canonical_fp'], 'Direct reference confusion matches reported: ' + str((dataset, seed, canonical)))
require(comparison_count == 54 and probe_key_total == 102576 and total_prediction_rows == 1056420, 'Independent54/9/1056420 completeness totals')

timing = pd.read_csv(ACTUAL / 'timing.csv')
per_seed = pd.read_csv(EVALUATION / 'canonical_timing_each_seed.csv')
seed_mean = pd.read_csv(EVALUATION / 'canonical_timing_seed_mean_sample_sd.csv')
require(len(timing) == 60 and not timing[['dataset', 'seed', 'condition', 'repeat']].duplicated().any(), 'All60 actual timing rows')
fields = ['seconds_seed_median', 'baseline_seconds_seed_median', 'seconds_reduction_vs_same_mode_nocache', 'speedup_vs_same_mode_nocache', 'full_batch_cost_cny_2_88_per_hour']
for row in per_seed.to_dict('records'):
    selection = timing.loc[timing.dataset.eq(row['dataset']) & timing.seed.eq(row['seed']) & timing.condition.eq(row['condition'])]
    base = timing.loc[timing.dataset.eq(row['dataset']) & timing.seed.eq(row['seed']) & timing.condition.eq(row['baseline_condition'])]
    secs, baseline = float(selection.seconds.median()), float(base.seconds.median())
    expected = [secs, baseline, 1 - secs / baseline, baseline / secs, secs * 2.88 / 3600]
    require(len(selection) == row['repeat_n'] and all(close(value, row[field]) for field, value in zip(fields, expected)), 'Independent timing median/ratio/cost: ' + str((row['dataset'], row['seed'], row['condition'])))
    for field in ['actual_real_model_rows', 'actual_padded_gpu_rows', 'actual_model_batches', 'unique_serialized_pair_keys']:
        require(selection[field].nunique() == 1 and row[field] == selection[field].iloc[0], 'Actual model/padding/batch count: ' + field + '/' + str((row['dataset'], row['seed'], row['condition'])))
for (dataset, condition), part in per_seed.groupby(['dataset', 'condition']):
    row = seed_mean.loc[seed_mean.dataset.eq(dataset) & seed_mean.condition.eq(condition)].iloc[0]
    for field in fields:
        require(close(part[field].mean(), row[field + '_mean']) and close(part[field].std(ddof=1), row[field + '_sample_sd']), 'Independent timing mean/sampleSD: ' + field + '/' + str((dataset, condition)))
normal_changes = pd.DataFrame(normal_changes)
require(normal_changes.score_bitwise_difference_rows.sum() == 13031, 'Normal-canonical13031 bit-change row events')
changed = normal_changes.loc[normal_changes.decision_difference_rows.gt(0)]
require(len(changed) == 4, 'Onlyfour condition blocks with normal-canonicaldecision drift')
for row in changed.to_dict('records'):
    if row['dataset'] == 'challenge600':
        require(row['seed'] == 20260906 and row['normal_tp'] == 164 and row['canonical_tp'] == 166
                and row['normal_fp'] == row['canonical_fp'], '600canonicaltwo new positive accepts')
    else:
        require(row['dataset'] == 'alberta_scope_core' and row['seed'] == 20260904
                and row['normal_tp'] == row['canonical_tp'] and row['canonical_fp'] - row['normal_fp'] == row['decision_difference_rows'], 'Alberta canonicaldecisiondrift addsFP only')
require(len(pd.read_csv(EVALUATION / 'all_canonical_cache_lost_true_positive_rows.csv')) == 0
        and len(pd.read_csv(EVALUATION / 'all_normal_vs_canonical_lost_true_positive_rows.csv')) == 0, 'AllknownTPLoss filesempty canonical andnormal comparisons')
report = {'all_passed': True, 'check_count': len(checks), 'checks': checks,
          'GPU_used': False, 'SSH_used': False, 'result_or_frozen_source_modified': False,
          'independently_recomputed_comparisons': comparison_count, 'independently_checked_probe_files': 9,
          'probe_key_checkpoint_observations': probe_key_total, 'actual_prediction_rows': total_prediction_rows,
          'actual_timing_records': len(timing), 'normal_vs_canonical_changed_decision_conditions': changed.to_dict('records'),
          'normal_vs_canonical_is_new_regime_not_cache_equivalence': True,
          'report_clarity_feedback': ['Top3 R values in summary are microRecall@3; name explicitly.',
             'Hard-positive full-query recall includes easy positives; hard-pair-only returnedTP mean5.6667/23 full vs1/23 exact+dimension.'],
          'verified_summary_sha256': sha(HERE / 'canonical_actual_results_summary.txt')}
(HERE / 'independent_canonical_actual_final_qa.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
normal_changes.to_csv(HERE / 'independent_normal_canonical_confusion_changes.csv', index=False)
print(json.dumps({key: report[key] for key in ['all_passed', 'check_count', 'independently_recomputed_comparisons', 'probe_key_checkpoint_observations', 'actual_prediction_rows', 'actual_timing_records']}))
