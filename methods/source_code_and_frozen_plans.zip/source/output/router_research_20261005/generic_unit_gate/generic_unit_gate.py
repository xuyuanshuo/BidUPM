"""Generic, label-independent known-unit dimensional gate."""
from __future__ import annotations
import hashlib, json, re, unicodedata
from pathlib import Path

ONTOLOGY_PATH=Path(__file__).resolve().parent/'unit_dimension_ontology.json'
ONTOLOGY=json.loads(ONTOLOGY_PATH.read_text())

def canonical_unit(value):
    text=unicodedata.normalize('NFKC',str(value or '')).strip().lower()
    return ' '.join(re.sub('[^a-z0-9]+',' ',text).split())

ALIASES={}
for dimension,values in ONTOLOGY['aliases'].items():
    for value in values:
        key=canonical_unit(value)
        if key in ALIASES and ALIASES[key]!=dimension:raise ValueError('Ambiguous ontology alias: '+key)
        ALIASES[key]=dimension
PHYSICAL_OR_COUNT_DIMENSIONS=frozenset(ONTOLOGY['hard_reject_known_dimensions'])

def unit_dimension(value):
    return ALIASES.get(canonical_unit(value),'unknown')

def certain_dimension_conflict(query_unit,candidate_unit):
    query=unit_dimension(query_unit);candidate=unit_dimension(candidate_unit)
    return query in PHYSICAL_OR_COUNT_DIMENSIONS and candidate in PHYSICAL_OR_COUNT_DIMENSIONS and query!=candidate

def dimension_conflict_mask(frame):
    return [certain_dimension_conflict(q,c) for q,c in zip(frame['query_normalized_unit'],frame['candidate_normalized_unit'])]

def ontology_sha256():
    return hashlib.sha256(ONTOLOGY_PATH.read_bytes()).hexdigest()
