"""Check frozen generic unit ontology on train/validation, input-only source audit."""
from pathlib import Path
import ast,csv,json,hashlib,re
from collections import Counter
from generic_unit_gate import unit_dimension,certain_dimension_conflict,canonical_unit

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
DATA=ROOT/'revise3_full_20260920/supplementary/data'
SOURCE=ROOT/'rule_first_system_20261004/results/server/inputs.csv'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def writecsv(p,rs):
    if not rs:return
    keys=list(dict.fromkeys(k for r in rs for k in r))
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rs)
def canonical_description(v):return ' '.join(re.sub('[^a-z0-9]+',' ',v.lower().replace('&',' and ')).split())
def exact(r):
    qd,cd=canonical_description(r['query_normalized_description']),canonical_description(r['candidate_normalized_description'])
    qu,cu=(' '.join(r[f'{side}_normalized_unit'].strip().lower().split()) for side in ['query','candidate'])
    return bool(qd) and bool(qu) and qd==cd and qu==cu
plan=json.loads((HERE/'frozen_generic_gate_plan.json').read_text())
checks=[]
def check(name,p,v):checks.append({'check':name,'passed':bool(p),'details':v})
for name,key in [('unit_dimension_ontology.json','ontology_sha256'),('generic_unit_gate.py','helper_sha256'),('run_generic_unit_gate_gpu.py','gpu_script_sha256')]:
    check(name+'_matches_pre_support_freeze',sha(HERE/name)==plan[key],sha(HERE/name))
testcases=[('m','ft','length','length',False),('m2','ft²','area','area',False),('m3','cubic yard','volume','volume',False),('kg','ton','mass','mass',False),('ea','piece','count','count',False),('hour','day','time','time',False),('m','m2','length','area',True),('each','linear_foot','count','length',True),('','ft','unknown','length',False),('nonstandard named unit','each','unknown','count',False),('lump_sum','ft','project_scope','length',False),('m/hr','ft','unknown','length',False)]
for q,c,qd,cd,rej in testcases:
    check('synthetic_'+q+'_'+c,(unit_dimension(q),unit_dimension(c),certain_dimension_conflict(q,c))==(qd,cd,rej),{'query_dimension':unit_dimension(q),'candidate_dimension':unit_dimension(c),'reject':certain_dimension_conflict(q,c)})

support=[];units=[];validation_rejected=[]
for name,path in [('train_dedup2278',DATA/'training/training_pairs_semantic_deduplicated.csv'),('validation900',DATA/'evaluation/validation_pairs.csv')]:
    rs=read(path)
    rejected=[r for r in rs if certain_dimension_conflict(r['query_normalized_unit'],r['candidate_normalized_unit'])]
    false_reject=[r for r in rejected if int(r['final_label'])]
    support.append({'scope':name,'input_sha256':sha(path),'rows':len(rs),'dimension_rejected':len(rejected),'positive_rejected':len(false_reject),'hard_positive_rejected':sum(int(r['final_label']) and r['difficulty']=='hard' for r in rejected),'exact_accept':sum(exact(r) for r in rs),'bge_remaining':sum(not exact(r) and not certain_dimension_conflict(r['query_normalized_unit'],r['candidate_normalized_unit']) for r in rs)})
    check(name+'_no_positive_rejected',not false_reject,[r['pair_id'] for r in false_reject])
    counts=Counter(r[f'{side}_normalized_unit'] for r in rs for side in ['query','candidate'])
    units += [{'scope':name,'normalized_unit':u,'canonical_alias':canonical_unit(u),'dimension':unit_dimension(u),'side_occurrences':n} for u,n in sorted(counts.items())]
    if name=='validation900':validation_rejected=[{'pair_id':r['pair_id'],'query_id':r['query_id'],'final_label':r['final_label'],'difficulty':r['difficulty'],'query_unit':r['query_normalized_unit'],'candidate_unit':r['candidate_normalized_unit'],'query_dimension':unit_dimension(r['query_normalized_unit']),'candidate_dimension':unit_dimension(r['candidate_normalized_unit'])} for r in rejected]
writecsv(HERE/'train_validation_gate_support.csv',support)
writecsv(HERE/'train_validation_unit_inventory.csv',units)
writecsv(HERE/'validation_dimension_rejected_pairs.csv',validation_rejected)

source=read(SOURCE);check('source_matches_original_label_free_hash',sha(SOURCE)==plan['source_sha256'],sha(SOURCE))
check('source_no_answer_columns',not set(source[0])&{'final_label','difficulty','label','provisional_label','training_label'},list(source[0]))
states=[]
for r in source:
    ex=exact(r);reject=certain_dimension_conflict(r['query_normalized_unit'],r['candidate_normalized_unit'])
    states.append({'pair_id':r['pair_id'],'evaluation_split':r['evaluation_split'],'query_id':r['query_id'],'candidate_id':r['candidate_id'],'query_normalized_unit':r['query_normalized_unit'],'candidate_normalized_unit':r['candidate_normalized_unit'],'query_dimension':unit_dimension(r['query_normalized_unit']),'candidate_dimension':unit_dimension(r['candidate_normalized_unit']),'exact_accept':int(ex),'dimension_reject':int(reject and not ex),'bge_called':int(not ex and not reject)})
counts=Counter((r['evaluation_split'],'exact_accept' if r['exact_accept'] else 'dimension_reject' if r['dimension_reject'] else 'bge_called') for r in states)
source_support=[{'evaluation_split':split,'state':state,'rows':n} for (split,state),n in sorted(counts.items())]
writecsv(HERE/'source_unit_dimensions_before_inference.csv',states)
writecsv(HERE/'source_input_only_gate_counts.csv',source_support)
tree=ast.parse((HERE/'generic_unit_gate.py').read_text())
strings={n.value for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,str)}
check('gate_has_no_answer_key_strings',not strings&{'final_label','difficulty','label','sampling_role','final_relevance','provisional_label'},sorted(strings))
check('source_all_states_complete_exclusive',len(states)==7500 and all(r['exact_accept']+r['dimension_reject']+r['bge_called']==1 for r in states),len(states))
result={'passed_checks':sum(x['passed'] for x in checks),'failed_checks':[x for x in checks if not x['passed']],'checks':checks,'frozen_plan_sha256':sha(HERE/'frozen_generic_gate_plan.json'),'train_validation_support':support,'source_input_only_counts':source_support,'test_alberta_600_labels_read':False,'ontology_modified_after_support_check':False,'source_test_items_read':'Input unit strings and metadata only, no labels or outcomes; counts do not select aliases.'}
(HERE/'generic_gate_independent_qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
