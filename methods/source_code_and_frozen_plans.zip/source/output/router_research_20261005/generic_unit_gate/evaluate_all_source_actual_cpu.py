#!/usr/bin/env python3
"""Independent CPU audit/evaluation of completed frozen all-source GPU output.

Default: input/output audit only, no label-value reads. --evaluate-labels is the
explicit second phase, executed only after all actual-output checks pass.
Never launch a model, GPU, SSH, change a gate/threshold, or rewrite source data.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
import tempfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
DEFAULT_SOURCE = WORKSPACE / 'output/rule_first_system_20261004/results/server'
DEFAULT_SUPPLEMENT = WORKSPACE / 'output/paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs'
DEFAULT_REFERENCE600 = WORKSPACE / 'output/internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv'
DEFAULT_ALBERTA_REFERENCE = HERE.parent / 'rule_verification/alberta_reference_index.csv'
SEEDS = (20260904, 20260905, 20260906)
DATASET_N = {'main220':6600, 'challenge600':600, 'alberta_scope_core':67635}
POLICIES = {'main220':('all_bge','exact_pair_bge','dimension_gate_bge','dimension_size_gate_bge'),
            'challenge600':('all_bge','dimension_gate_bge','dimension_size_gate_bge'),
            'alberta_scope_core':('all_bge','dimension_gate_bge','dimension_size_gate_bge')}
PRIMARY_SPLITS = {'locked','external','no_reference'}
MASK_COLUMNS = ('prediction','exact_match','dimension_rejected','size_rejected','any_gate_rejected','bge_called')
RATE_CNY_PER_HOUR = 2.88
FORBIDDEN = {'label','final_label','provisional_label','reference_label','reference_uncertain','difficulty','generation_rule'}


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path, value): Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def require(condition, message):
    if not bool(condition): raise AssertionError(message)


def normalize(value): return ' '.join(str(value).strip().lower().split())
def canonical(value): return ' '.join(re.sub('[^a-z0-9]+',' ',str(value).lower().replace('&',' and ')).split())


def independent_exact(frame):
    qd,cd=(frame[f'{side}_normalized_description'].map(canonical).to_numpy() for side in ('query','candidate'))
    qu,cu=(frame[f'{side}_normalized_unit'].map(normalize).to_numpy() for side in ('query','candidate'))
    return (qd!='') & (qu!='') & (qd==cd) & (qu==cu)


def independent_rank(frame, exact, score, threshold):
    """Actual full-pool rank: exact ID order, then thresholded score/ID order."""
    rank=np.zeros(len(frame),dtype=int)
    if 'query_id' not in frame: return rank
    require({'evaluation_split','candidate_id'}<=set(frame),'Missing query-pool identity')
    require(not frame[['evaluation_split','query_id','candidate_id']].duplicated().any(),'Duplicate candidate in query pool')
    candidate=frame.candidate_id.to_numpy(str)
    for indices in frame.groupby(['evaluation_split','query_id'],sort=False).indices.values():
        rules=sorted((int(i) for i in indices if exact[i]),key=lambda i:candidate[i])
        modeled=sorted((int(i) for i in indices if not exact[i] and np.isfinite(score[i]) and score[i]>=threshold),key=lambda i:(-score[i],candidate[i]))
        selected=(rules+modeled)[:3]
        rank[selected]=np.arange(1,len(selected)+1)
    return rank


def parse_binary(frame, column):
    require(frame[column].isin(['0','1']).all(),f'Nonbinary {column}')
    return frame[column].astype(int).to_numpy(bool)


def query_count(frame):
    return frame.groupby(['evaluation_split','query_id']).ngroups if 'query_id' in frame else 0


def pair_metrics(frame):
    known=frame.loc[~frame.uncertain]
    y=known.label.to_numpy(int); p=known.prediction.to_numpy(bool)
    tp=int(((y==1)&p).sum());fp=int(((y==0)&p).sum());fn=int(((y==1)&~p).sum());tn=int(((y==0)&~p).sum())
    return {'input_pairs':len(frame),'known_pairs':len(known),'uncertain_excluded':int(frame.uncertain.sum()),
            'positive_n':int((y==1).sum()),'tp':tp,'fp':fp,'fn':fn,'tn':tn,
            'precision':tp/(tp+fp) if tp+fp else None,'recall':tp/(tp+fn) if tp+fn else None,
            'f1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,'accuracy':(tp+tn)/len(known) if len(known) else None}


def top3_metrics(frame):
    """Never rerank/drop uncertain rows. Stored actual returned ranks stay fixed."""
    if 'query_id' not in frame: return {'top3_available':False,'reason':'no_query_pool_rank_zero'}
    returned=frame.returned_rank.to_numpy(int)>0
    known=~frame.uncertain.to_numpy(bool); y=frame.label.to_numpy(int)
    tp=int((returned&known&(y==1)).sum());fp=int((returned&known&(y==0)).sum())
    uncertain_returned=int((returned&~known).sum()); positive_n=int((known&(y==1)).sum())
    recalls=[];hits=[];no_ref_n=0;no_ref_rejected=0
    for _,group in frame.groupby(['evaluation_split','query_id'],sort=False):
        known_group=group.loc[~group.uncertain]
        positives=int(known_group.label.sum())
        returned_tp=int(((known_group.returned_rank>0)&known_group.label.eq(1)).sum())
        if positives:
            recalls.append(returned_tp/positives);hits.append(int(returned_tp>0))
        elif not group.uncertain.any():
            no_ref_n+=1;no_ref_rejected+=int(not (group.returned_rank>0).any())
    return {'top3_available':True,'query_n':query_count(frame),'positive_query_n':len(recalls),
            'returned_total_n':int(returned.sum()),'returned_known_n':tp+fp,'returned_uncertain_n':uncertain_returned,
            'returned_known_coverage':(tp+fp)/int(returned.sum()) if returned.sum() else None,
            'returned_tp':tp,'returned_fp':fp,'returned_precision_known':tp/(tp+fp) if tp+fp else None,
            'micro_recall_at3':tp/positive_n if positive_n else None,
            'macro_recall_at3':float(np.mean(recalls)) if recalls else None,
            'hit_at3':float(np.mean(hits)) if hits else None,
            'completely_known_no_reference_query_n':no_ref_n,'no_reference_rejected_n':no_ref_rejected,
            'no_reference_rejection_rate':no_ref_rejected/no_ref_n if no_ref_n else None}


def seed_aggregate(frame, keys, excluded):
    result=[]
    numeric=[name for name in frame if name not in set(keys)|set(excluded) and pd.api.types.is_numeric_dtype(frame[name])]
    for identity,group in frame.groupby(keys,dropna=False,sort=False):
        identity=identity if isinstance(identity,tuple) else (identity,)
        require(len(group)==3 and set(group.seed)==set(SEEDS),f'Aggregate is not all three seeds: {identity}')
        row=dict(zip(keys,identity),seed_n=3)
        for name in numeric:
            values=pd.to_numeric(group[name]).dropna().to_numpy(float)
            row[name+'_defined_seed_n']=len(values)
            row[name+'_mean']=float(np.mean(values)) if len(values) else None
            row[name+'_sample_sd']=float(np.std(values,ddof=1)) if len(values)>1 else None
        result.append(row)
    return pd.DataFrame(result)


def input_frames(args, frozen, record):
    manifest_path=args.source/'source_manifest.json'
    sm=json.loads(manifest_path.read_text());record[str(manifest_path)]=sha(manifest_path)
    paths={'main220':args.source/'inputs.csv','challenge600':args.supplement/'model_inputs_challenge600.csv',
           'alberta_scope_core':args.supplement/'model_inputs_alberta_scope_core.csv'}
    require(sm['inputs_sha256']==frozen['input_sha256']['main220'],'Source manifest input hash differs')
    frames={}
    for dataset,path in paths.items():
        digest=sha(path);require(digest==frozen['input_sha256'][dataset],f'Input source hash differs: {dataset}')
        record[str(path)]=digest
        frame=pd.read_csv(path,dtype=str,keep_default_na=False)
        require(not FORBIDDEN&set(frame),f'Answer field present in source: {dataset}')
        if dataset=='main220': frame=frame.loc[frame.evaluation_split.ne('validation')].reset_index(drop=True)
        require(len(frame)==DATASET_N[dataset] and frame.pair_id.nunique()==len(frame),f'Input IDs/row count: {dataset}')
        if dataset=='challenge600':require('query_id' not in frame,'600 unexpectedly has query pools')
        frames[dataset]=frame
    metadata_path=HERE/'raw_units_metadata.csv';metadata=pd.read_csv(metadata_path,dtype=str,keep_default_na=False)
    require(set(metadata)=={'dataset','pair_id','query_unit','candidate_unit'},'Raw metadata has unexpected fields')
    for dataset in ('main220','challenge600'):
        units=metadata.loc[metadata.dataset.eq(dataset)].drop(columns='dataset')
        require(set(units.pair_id)==set(frames[dataset].pair_id) and units.pair_id.nunique()==len(units),'Raw units do not align')
        frames[dataset]=frames[dataset].merge(units,on='pair_id',how='left',sort=False,validate='one_to_one')
    for side in ('query','candidate'):
        frames['alberta_scope_core'][f'{side}_description']=frames['alberta_scope_core'][f'{side}_normalized_description']
    require(query_count(frames['main220'])==220,'Main query count differs')
    require(query_count(frames['main220'].loc[frames['main220'].evaluation_split.isin(PRIMARY_SPLITS)])==218,'Primary scope differs')
    require(query_count(frames['main220'].loc[frames['main220'].evaluation_split.eq('locked')])==100,'Locked scope differs')
    require(query_count(frames['main220'].loc[frames['main220'].evaluation_split.eq('external')])==80,'External scope differs')
    return sm,frames


def label_free_audit(args, record):
    prepared_path=HERE/'independent_all_source_cpu_evaluation_plan.json'
    prepared=json.loads(prepared_path.read_text());record[str(prepared_path)]=sha(prepared_path)
    require(sha(__file__)==prepared['evaluator_source_sha256'],'Evaluator source changed after preparation freeze')
    frozen_path=HERE/'frozen_all_source_inference_plan.json'
    frozen=json.loads(frozen_path.read_text());record[str(frozen_path)]=sha(frozen_path)
    require(record[str(frozen_path)]==prepared['frozen_inference_plan_sha256'],'Frozen runner plan changed after evaluator preparation')
    for filename,expected in frozen['file_sha256'].items():
        path=HERE/filename;actual=sha(path);require(actual==expected,f'Frozen source changed: {filename}');record[str(path)]=actual
    sm,frames=input_frames(args,frozen,record)
    require(sha(args.source/'source_manifest.json')==prepared['source_manifest_sha256'],'Canonical checkpoint/threshold source manifest changed')
    shared_policy_path=WORKSPACE/'output/rule_first_system_validation_20261005/scripts/system_policy.py'
    require(sha(shared_policy_path)==frozen['shared_policy_sha256'],'Shared exact/ranking policy source hash changed')
    record[str(shared_policy_path)]=sha(shared_policy_path)
    execution_path=args.actual/'execution_manifest.json';execution=json.loads(execution_path.read_text());record[str(execution_path)]=sha(execution_path)
    require(execution['status']=='complete' and execution['labels_accessed'] is False,'Actual GPU run is not completed label-free')
    require(execution['new_training'] is False and execution['thresholds_retuned'] is False,'Actual run altered training/threshold')
    require(execution['input_hashes']==frozen['input_sha256'] and execution['input_rows']==DATASET_N,'Actual input provenance differs')
    require(execution['source_manifest_sha256']==sha(args.source/'source_manifest.json'),'Actual source manifest differs')
    require(execution['script_sha256']==frozen['file_sha256']['run_generic_gate_all_sources_gpu.py'],'Actual runner hash differs')
    require(execution['shared_policy_sha256']==frozen['shared_policy_sha256'],'Actual shared exact/rank policy hash differs')
    require(execution['helper_sha256']==frozen['file_sha256']['generic_unit_gate.py'],'Actual dimensional helper hash differs')
    require(execution['ontology_sha256']==frozen['file_sha256']['unit_dimension_ontology.json'],'Actual ontology hash differs')
    require(execution['raw_units_metadata_sha256']==frozen['file_sha256']['raw_units_metadata.csv'],'Actual raw-unit metadata differs')
    require(execution['engineering_gate_sha256']=={name:frozen['file_sha256'][name] for name in ('engineering_gate.py','engineering_gate_v2.py','enabled_rules.json')},'Actual size gate hashes differ')
    require(execution['batch_size']==64 and execution['max_length']==256,'Actual inference batch contract differs')
    runs=execution['completed_runs'];require(len(runs)==9,'Actual run is not nine dataset/seed outputs')
    by_run={(row['dataset'],int(row['seed'])):row for row in runs}
    require(len(by_run)==9 and set(by_run)=={(dataset,seed) for dataset in DATASET_N for seed in SEEDS},'Actual output run grid differs')
    thresholds={int(run['seed']):float(run['threshold']) for run in sm['runs']}
    require(set(thresholds)==set(SEEDS),'Source checkpoint seed grid differs')
    # Execute existing pure frozen helpers without inspecting/modifying their logic.
    sys.path.insert(0,str(HERE))
    from generic_unit_gate import dimension_conflict_mask
    from engineering_gate_v2 import contradiction_gate
    input_masks={}
    for dataset,frame in frames.items():
        def item(row,side):return {key:row.get(f'{side}_{key}','') for key in ('description','normalized_description','unit','category','spec_tokens')}
        sizes=np.asarray([contradiction_gate(item(row,'query'),item(row,'candidate'),enabled_rules=('physical_size',)).decision=='reject' for row in frame.to_dict('records')],bool)
        input_masks[dataset]={'exact':independent_exact(frame),'dimension':np.asarray(dimension_conflict_mask(frame),bool),'size':sizes}
        if dataset=='alberta_scope_core':require(not sizes.any(),'Alberta unsupported size evidence did not defer')
    outputs={};counts=[]
    for (dataset,seed),run in by_run.items():
        require(float(run['threshold'])==thresholds[seed],'Actual threshold was not inherited')
        require(run['repeat_decisions_identical'] is True,'Runner reports unstable repeat decisions')
        expected_name=f'predictions_{dataset}_seed_{seed}.csv';require(run['output']==expected_name,'Unexpected actual output filename')
        path=args.actual/expected_name;require(sha(path)==run['sha256'],'Actual prediction file hash differs');record[str(path)]=sha(path)
        result=pd.read_csv(path,dtype=str,keep_default_na=False)
        require(not FORBIDDEN&set(result),'Answer fields in actual predictions')
        require(len(result)==len(frames[dataset])*len(POLICIES[dataset]) and set(result.policy)==set(POLICIES[dataset]),'Actual policy/row coverage differs')
        require(not result[['pair_id','policy']].duplicated().any(),'Duplicate actual pair/policy')
        require(result.dataset.eq(dataset).all() and result.seed.astype(int).eq(seed).all(),'Actual dataset/seed identity differs')
        for policy in POLICIES[dataset]:
            block=result.loc[result.policy.eq(policy)].reset_index(drop=True)
            frame=frames[dataset]
            require(block.pair_id.tolist()==frame.pair_id.tolist(),'Actual pair IDs/order differ from frozen inputs')
            for key in ('evaluation_split','query_id','candidate_id','source_year'):
                if key in frame:require(block[key].tolist()==frame[key].tolist(),f'Actual identity field differs: {key}')
            require(block.threshold.astype(float).eq(thresholds[seed]).all(),'Actual row threshold differs')
            exact=input_masks[dataset]['exact'] if policy!='all_bge' else np.zeros(len(frame),bool)
            dimension=input_masks[dataset]['dimension'] if policy in ('dimension_gate_bge','dimension_size_gate_bge') else np.zeros(len(frame),bool)
            size=input_masks[dataset]['size'] if policy=='dimension_size_gate_bge' else np.zeros(len(frame),bool)
            union=dimension|size;called=~exact&~union
            expected={'exact_match':exact,'dimension_rejected':dimension,'size_rejected':size,'any_gate_rejected':union,'bge_called':called}
            parsed={key:parse_binary(block,key) for key in MASK_COLUMNS}
            for key,mask in expected.items():require(np.array_equal(parsed[key],mask),f'Actual input mask differs: {dataset}/{seed}/{policy}/{key}')
            score=np.asarray([float(value) if value.strip() else np.nan for value in block.score],float)
            require(np.isfinite(score[called]).all() and np.isnan(score[~called]).all(),'Finite called/NaN uncalled score contract failed')
            prediction=exact|(np.isfinite(score)&(score>=thresholds[seed]))
            require(np.array_equal(parsed['prediction'],prediction),'Actual prediction differs from exact OR score>=inherited threshold')
            rank=block.returned_rank.astype(int).to_numpy()
            expected_rank=independent_rank(frame,exact,score,thresholds[seed])
            require(np.array_equal(rank,expected_rank),'Actual Top3 order differs from full-pool independent recomputation')
            require(not ((rank>0)&~prediction).any(),'Actual rejected pair was returned')
            if dataset=='challenge600':require(not rank.any(),'600 rank must remain zero without query pools')
            normalized=block.copy()
            normalized['score']=score;normalized['threshold']=thresholds[seed];normalized['returned_rank']=rank
            for key,mask in parsed.items():normalized[key]=mask.astype(int)
            outputs[(dataset,seed,policy)]=normalized
            counts.append({'dataset':dataset,'seed':seed,'policy':policy,'rows':len(frame),'query_pools':query_count(frame),
                           'bge_pairs':int(called.sum()),'exact_pairs':int(exact.sum()),'dimension_rejected_pairs':int(dimension.sum()),
                           'size_rejected_pairs':int(size.sum()),'any_gate_rejected_pairs':int(union.sum()),
                           'exact_and_gate_overlap':int((exact&union).sum()),'dimension_and_size_overlap':int((dimension&size).sum())})
    timing_path=args.actual/'timing.csv';require(sha(timing_path)==execution['timing_sha256'],'Actual timing hash differs');record[str(timing_path)]=sha(timing_path)
    timing=pd.read_csv(timing_path)
    require(len(timing)==54 and not timing[['dataset','seed','policy','repeat']].duplicated().any(),'Actual timing is not 54 unique full-batch rows')
    expected_grid={(dataset,seed,policy,repeat) for dataset in DATASET_N for seed in SEEDS for policy in POLICIES[dataset] for repeat in range(3 if dataset=='main220' else 1)}
    require(set(map(tuple,timing[['dataset','seed','policy','repeat']].to_numpy()))==expected_grid,'Actual timing grid differs')
    require(np.isfinite(timing.seconds.to_numpy(float)).all() and timing.seconds.gt(0).all(),'Actual timing has invalid seconds')
    count_map={(row['dataset'],row['seed'],row['policy']):row for row in counts}
    for row in timing.to_dict('records'):
        expected=count_map[(row['dataset'],row['seed'],row['policy'])]
        for key in ('rows','query_pools','bge_pairs','exact_pairs','dimension_rejected_pairs','size_rejected_pairs','any_gate_rejected_pairs'):
            require(int(row[key])==expected[key],f'Actual timing count differs: {key}')
    audit={'passed':True,'phase':'all_actual_outputs_and_full_rank_verified_before_label_values_read',
           'labels_read':False,'actual_status':'complete','prediction_files':9,'timing_rows':54,'policies_checked':len(outputs),
           'thresholds_inherited':thresholds,'source_hashes':record,'input_counts':DATASET_N,
           'rank_check':'independent full pool: exact candidate ID first, then accepted logit descending/candidate ID; no refill after uncertain removal',
           'score_contract':'finite on every called row; NaN on every uncalled row',
           'no_cached_or_querygrouped_timing_sources':True,'completed_utc':datetime.now(timezone.utc).isoformat()}
    dump(args.output/'prelabel_actual_integrity.json',audit)
    pd.DataFrame(counts).to_csv(args.output/'input_mask_and_actual_call_counts.csv',index=False)
    return sm,frames,outputs,timing,audit


def label_values(path, allowed_ids, fields, expected_hash, record):
    actual=sha(path);require(actual==expected_hash,f'Label reference hash differs: {path}');record[str(path)]=actual
    rows=[]
    with Path(path).open(newline='',encoding='utf-8-sig') as stream:
        reader=csv.reader(stream);header=next(reader);indices={name:header.index(name) for name in ['pair_id',*fields]}
        for cells in reader:
            pair_id=cells[indices['pair_id']]
            if pair_id not in allowed_ids:continue
            rows.append({name:cells[index] for name,index in indices.items()})
    data=pd.DataFrame(rows);require(set(data.pair_id)==allowed_ids and data.pair_id.nunique()==len(data),'Label IDs are not complete unique')
    return data


def replacement_label_values(path, allowed_ids, record):
    """User-supplied quality reference: exactly all input IDs, never assume human."""
    record[str(path)]=sha(path)
    frame=pd.read_csv(path,dtype=str,keep_default_na=False)
    require('pair_id' in frame,'Replacement reference lacks pair_id')
    label_field='label' if 'label' in frame else 'final_label' if 'final_label' in frame else None
    require(label_field is not None,'Replacement reference must provide label or final_label')
    require(len(frame)==len(allowed_ids) and frame.pair_id.nunique()==len(frame) and set(frame.pair_id)==allowed_ids,'Replacement reference must cover exactly every unique input ID; no missing/extra rows')
    value=pd.to_numeric(frame[label_field],errors='raise')
    require(value.isin([0,1]).all(),'Replacement reference labels must be binary 0/1')
    frame['label']=value.astype(int)
    if 'label' in frame and 'final_label' in frame:
        require(pd.to_numeric(frame.final_label,errors='raise').eq(frame.label).all(),'Replacement label/final_label fields disagree')
    uncertainty_field='reference_uncertain' if 'reference_uncertain' in frame else 'uncertain' if 'uncertain' in frame else None
    if uncertainty_field:
        uncertainty=pd.to_numeric(frame[uncertainty_field],errors='raise')
        require(uncertainty.isin([0,1]).all(),'Replacement uncertainty flag must be 0/1')
        frame['uncertain']=uncertainty.astype(bool)
    else:frame['uncertain']=False
    frame['difficulty']=''
    return frame[['pair_id','label','uncertain','difficulty']],{'path':str(path),'sha256':record[str(path)],'label_field':label_field,'uncertainty_field':uncertainty_field,'rows':len(frame),'uncertain_rows':int(frame.uncertain.sum()),'source_type':'user_supplied_quality_reference_not_verified_as_human_gold'}


def label_join(args, sm, frames, record):
    prepared=json.loads((HERE/'independent_all_source_cpu_evaluation_plan.json').read_text())
    main=label_values(args.source/'labels.csv',set(frames['main220'].pair_id),['final_label','difficulty'],sm['labels_sha256'],record)
    main['label']=main.final_label.astype(int);main['uncertain']=False
    require(main.label.isin([0,1]).all() and main.difficulty.isin(['easy','hard']).all(),'Main label/difficulty invalid')
    sources={'main220':'original_held_out_reference','challenge600':'construction_intent_provisional_not_human_gold','alberta_scope_core':'frozen_GPT6Sol_AI_reference_not_human_gold'}
    reference_details={}
    if args.challenge_labels:
        challenge,reference_details['challenge600']=replacement_label_values(args.challenge_labels,set(frames['challenge600'].pair_id),record)
        sources['challenge600']='user_supplied_replacement_quality_reference_not_verified_as_human_gold'
    else:
        challenge=label_values(args.reference600,set(frames['challenge600'].pair_id),['provisional_label'],prepared['reference_sha256']['challenge600'],record)
        challenge['label']=challenge.provisional_label.astype(int);challenge['uncertain']=False;challenge['difficulty']=''
        require(challenge.label.isin([0,1]).all() and challenge.label.sum()==300,'Construction reference not 300/300 binary')
        reference_details['challenge600']={'path':str(args.reference600),'sha256':record[str(args.reference600)],'source_type':sources['challenge600'],'rows':len(challenge),'uncertain_rows':0}
    if args.alberta_labels:
        alberta,reference_details['alberta_scope_core']=replacement_label_values(args.alberta_labels,set(frames['alberta_scope_core'].pair_id),record)
        sources['alberta_scope_core']='user_supplied_replacement_quality_reference_not_verified_as_human_gold'
    else:
        alberta=label_values(args.alberta_reference,set(frames['alberta_scope_core'].pair_id),['reference_label','reference_uncertain','query_id','candidate_id','source_year','label_source'],prepared['reference_sha256']['alberta_scope_core'],record)
        alberta['label']=alberta.reference_label.astype(int);alberta['uncertain']=alberta.reference_uncertain.astype(int).astype(bool);alberta['difficulty']=''
        require(alberta.label.isin([0,1]).all() and alberta.reference_uncertain.isin(['0','1']).all() and alberta.uncertain.sum()==56,'Alberta reference/56 uncertain contract differs')
        for key in ('query_id','candidate_id','source_year'):
            check=frames['alberta_scope_core'][['pair_id',key]].merge(alberta[['pair_id',key]],on='pair_id',suffixes=('_input','_label'),validate='one_to_one')
            require(check[key+'_input'].eq(check[key+'_label']).all(),'Alberta reference identity differs from input')
        reference_details['alberta_scope_core']={'path':str(args.alberta_reference),'sha256':record[str(args.alberta_reference)],'source_type':sources['alberta_scope_core'],'rows':len(alberta),'uncertain_rows':56}
    return {'main220':main[['pair_id','label','uncertain','difficulty']],
            'challenge600':challenge[['pair_id','label','uncertain','difficulty']],
            'alberta_scope_core':alberta[['pair_id','label','uncertain','difficulty']]},sources,reference_details


def evaluation_views(dataset, frame):
    if dataset=='main220':
        yield 'all220_diagnostic',frame
        yield 'primary218',frame.loc[frame.evaluation_split.isin(PRIMARY_SPLITS)]
        locked=frame.loc[frame.evaluation_split.eq('locked')]
        yield 'locked100',locked
        yield 'locked100_hard_pairs',locked.loc[locked.difficulty.eq('hard')]
        hard_query_keys=set(map(tuple,locked.loc[locked.difficulty.eq('hard')&locked.label.eq(1),['evaluation_split','query_id']].to_numpy()))
        query_selected=np.asarray([(split,qid) in hard_query_keys for split,qid in locked[['evaluation_split','query_id']].itertuples(index=False,name=None)],dtype=bool)
        yield 'locked100_hard_positive_full_queries',locked.loc[query_selected]
        yield 'external80',frame.loc[frame.evaluation_split.eq('external')]
    elif dataset=='challenge600': yield 'all600_construction_reference',frame
    else:
        yield 'both_years_pooled',frame
        for year in sorted(frame.source_year.unique()):yield str(year),frame.loc[frame.source_year.eq(year)]


def timing_analysis(timing):
    rows=[]
    for (dataset,seed,policy),group in timing.groupby(['dataset','seed','policy'],sort=False):
        seconds=float(group.seconds.median())
        baseline=timing.loc[timing.dataset.eq(dataset)&timing.seed.eq(seed)&timing.policy.eq('all_bge')]
        base_seconds=float(baseline.seconds.median());base_calls=int(baseline.bge_pairs.iloc[0]);calls=int(group.bge_pairs.iloc[0])
        q=int(group.query_pools.iloc[0]);pairs=int(group.rows.iloc[0])
        rows.append({'dataset':dataset,'seed':seed,'policy':policy,'actual_full_batch_repeats':len(group),
                     'full_batch_seconds_seed_median':seconds,'same_seed_all_bge_seconds_median':base_seconds,
                     'seconds_reduction_vs_same_seed_all_bge':1-seconds/base_seconds,'speedup_vs_same_seed_all_bge':base_seconds/seconds,
                     'bge_pairs':calls,'same_seed_all_bge_pairs':base_calls,'bge_calls_saved':base_calls-calls,
                     'bge_call_reduction':1-calls/base_calls,'full_batch_cost_cny_2_88_per_hour':seconds*RATE_CNY_PER_HOUR/3600,
                     'full_batch_queries':q,'full_batch_pairs':pairs,
                     'cny_per_1000_queries_throughput':seconds/q*1000*RATE_CNY_PER_HOUR/3600 if q else None,
                     'cny_per_1000_pairs_throughput':seconds/pairs*1000*RATE_CNY_PER_HOUR/3600})
    each=pd.DataFrame(rows)
    return each,seed_aggregate(each,['dataset','policy'],['seed'])


def evaluate(args, sm, frames, outputs, timing, audit, record):
    require(audit['passed'] and audit['labels_read'] is False,'Prelabel audit failed')
    labels,label_source,reference_details=label_join(args,sm,frames,record)  # first actual label-value access
    pair_rows=[];top_rows=[];joined={};veto=[]
    for (dataset,seed,policy),output in outputs.items():
        identity_cols=[name for name in ('pair_id','evaluation_split','query_id','candidate_id','source_year') if name in frames[dataset]]
        details=frames[dataset].drop(columns=[name for name in identity_cols if name!='pair_id'])
        frame=output.merge(details,on='pair_id',how='left',validate='one_to_one').merge(labels[dataset],on='pair_id',validate='one_to_one')
        require(len(frame)==DATASET_N[dataset],'Label join changed output row count')
        joined[(dataset,seed,policy)]=frame
        for group,part in evaluation_views(dataset,frame):
            identity={'dataset':dataset,'seed':seed,'policy':policy,'group':group,'label_source':label_source[dataset]}
            pair_rows.append({**identity,**pair_metrics(part)})
            top_metrics=top3_metrics(part)
            if group=='locked100_hard_pairs':
                top_metrics['scope_note']='Frozen hard-pair subset with actual full-pool ranks retained; easy/other returned slots are not refilled. No-reference query rate is unavailable for a filtered pair subset.'
                for key in ('completely_known_no_reference_query_n','no_reference_rejected_n','no_reference_rejection_rate'):top_metrics[key]=None
            top_rows.append({**identity,**top_metrics})
        positives=frame.loc[~frame.uncertain&frame.label.eq(1)&frame.any_gate_rejected.eq(1)&frame.exact_match.eq(0)].copy()
        if len(positives):veto.append(positives)
    pair=pd.DataFrame(pair_rows);top=pd.DataFrame(top_rows)
    pair.to_csv(args.output/'pair_metrics_each_seed.csv',index=False);top.to_csv(args.output/'actual_top3_metrics_each_seed.csv',index=False)
    seed_aggregate(pair,['dataset','policy','group','label_source'],['seed']).to_csv(args.output/'pair_metrics_seed_mean_sample_sd.csv',index=False)
    top_available=top.loc[top.top3_available.eq(True)].copy()
    for column in top_available:
        if column not in ('dataset','policy','group','label_source','reason','scope_note'):top_available[column]=pd.to_numeric(top_available[column],errors='coerce')
    seed_aggregate(top_available,['dataset','policy','group','label_source'],['seed']).to_csv(args.output/'actual_top3_seed_mean_sample_sd.csv',index=False)
    time_each,time_aggregate=timing_analysis(timing)
    time_each.to_csv(args.output/'actual_full_batch_timing_each_seed.csv',index=False)
    time_aggregate.to_csv(args.output/'actual_full_batch_timing_seed_mean_sample_sd.csv',index=False)
    losses=[];deltas=[]
    for dataset in DATASET_N:
        for seed in SEEDS:
            for policy in POLICIES[dataset]:
                if policy=='all_bge':continue
                for baseline_policy in ('all_bge',*(('dimension_gate_bge',) if policy=='dimension_size_gate_bge' else ())):
                    current=joined[(dataset,seed,policy)]
                    base=joined[(dataset,seed,baseline_policy)][['pair_id','prediction','returned_rank','score']].rename(columns={name:'baseline_'+name for name in ('prediction','returned_rank','score')})
                    change=current.merge(base,on='pair_id',validate='one_to_one')
                    positive=~change.uncertain&change.label.eq(1)
                    accepted_lost=positive&change.baseline_prediction.eq(1)&change.prediction.eq(0)
                    returned_lost=positive&change.baseline_returned_rank.gt(0)&change.returned_rank.eq(0)
                    accepted_gained=positive&change.baseline_prediction.eq(0)&change.prediction.eq(1)
                    returned_gained=positive&change.baseline_returned_rank.eq(0)&change.returned_rank.gt(0)
                    deltas.append({'dataset':dataset,'seed':seed,'policy':policy,'baseline_policy':baseline_policy,
                                   'accepted_true_positive_lost':int(accepted_lost.sum()),'accepted_true_positive_gained':int(accepted_gained.sum()),
                                   'returned_true_positive_lost':int(returned_lost.sum()),'returned_true_positive_gained':int(returned_gained.sum()),
                                   'locked_hard_accepted_tp_lost':int((accepted_lost&change.get('evaluation_split',pd.Series('',index=change.index)).eq('locked')&change.difficulty.eq('hard')).sum())})
                    for event,mask in [('accepted_true_positive_lost',accepted_lost),('returned_true_positive_lost',returned_lost)]:
                        for row in change.loc[mask].to_dict('records'):
                            if row['any_gate_rejected'] and not row['exact_match']:cause='direct_input_gate_veto'
                            elif row['prediction']==0:cause='called_model_below_threshold_after_actual_rescoring'
                            else:cause='actual_full_pool_ranking_displacement'
                            losses.append({'dataset':dataset,'seed':seed,'policy':policy,'baseline_policy':baseline_policy,'event':event,'cause':cause,
                                           'label_source':label_source[dataset],**{key:row.get(key,'') for key in ('pair_id','evaluation_split','query_id','candidate_id','source_year','difficulty','label','prediction','baseline_prediction','returned_rank','baseline_returned_rank','score','baseline_score','threshold','exact_match','dimension_rejected','size_rejected','any_gate_rejected','bge_called','query_description','candidate_description','query_unit','candidate_unit','query_normalized_unit','candidate_normalized_unit')}})
    loss_fields=['dataset','seed','policy','baseline_policy','event','cause','label_source','pair_id','evaluation_split','query_id','candidate_id','source_year','difficulty','label','prediction','baseline_prediction','returned_rank','baseline_returned_rank','score','baseline_score','threshold','exact_match','dimension_rejected','size_rejected','any_gate_rejected','bge_called','query_description','candidate_description','query_unit','candidate_unit','query_normalized_unit','candidate_normalized_unit']
    pd.DataFrame(losses,columns=loss_fields).to_csv(args.output/'all_lost_true_positive_rows.csv',index=False)
    pd.DataFrame(deltas).to_csv(args.output/'true_positive_changes_each_seed.csv',index=False)
    veto_frame=pd.concat(veto,ignore_index=True) if veto else pd.DataFrame(columns=list(next(iter(joined.values())).columns))
    veto_frame.to_csv(args.output/'all_known_positive_gate_veto_rows.csv',index=False)
    for path,digest in record.items():require(sha(path)==digest,f'Read source changed during evaluation: {path}')
    dump(args.output/'evaluation_integrity.json',{'passed':True,'labels_joined_after_actual_output_audit':True,'source_hashes_unchanged':True,
         'source_hashes':record,'reference_details':reference_details,'uncertain_alberta_rows_retained_in_actual_slots':int(labels['alberta_scope_core'].uncertain.sum()),'seed_n':3,'sample_sd_ddof':1,
         'main_seconds':'median of three full-batch repeats per seed, then arithmetic seed mean and sample SD',
         'supplement_seconds':'one actual full-batch run per seed, then cross-seed mean/sample SD; not repeat measurement SD',
         'cost_rate_cny_per_hour':RATE_CNY_PER_HOUR,'cost_scope':'actual synchronized resident GPU full batch; excludes import/loading/retrieval; throughput only, not interactive latency/API cost',
         'no_old_querygrouped_timings_or_cached_scores_combined':True,'lost_tp_rows':len(losses),'known_positive_gate_veto_rows':len(veto_frame),
         'completed_utc':datetime.now(timezone.utc).isoformat()})
    dump(args.output/'summary.json',{'status':'completed_cpu_evaluation_of_actual_gpu_outputs','pair_metric_rows':len(pair),'top3_metric_rows':len(top),
         'lost_true_positive_event_rows':len(losses),'known_positive_gate_veto_rows':len(veto_frame),
         'main_primary218':json.loads(pair.loc[pair.group.eq('primary218')].to_json(orient='records')),
         'main_timing':json.loads(time_aggregate.loc[time_aggregate.dataset.eq('main220')].to_json(orient='records')),
         'reference_details':reference_details,
         'notes':['600 has no query pools/Top3. Default provisional construction reference is not human gold.',
                  'Default Alberta AI reference is not human gold; its 56 uncertain pairs are excluded from quality only after actual ranking.',
                  'Optional supplied replacement references cover every input ID, are recorded under a new output directory, and are not presumed to be human gold.',
                  'Undefined ratios remain missing; every aggregate records metric-specific defined seed count instead of inventing values.',
                  'Hard pair views use frozen difficulty=hard including positive and negative pairs; stored full-pool ranks are never recomputed after filtering.',
                  'All accepted/returned lost TPs, including locked hard and Alberta, are retained without exceptions.']})


def self_test():
    frame=pd.DataFrame({'evaluation_split':['x']*5,'query_id':['q']*5,'candidate_id':['z','a','b','c','d']})
    exact=np.asarray([True,True,False,False,False]);score=np.asarray([np.nan,np.nan,10.,10.,9.])
    rank=independent_rank(frame,exact,score,9.)
    require(rank.tolist()==[2,1,3,0,0],'Exact priority/score tie rank self-test')
    second=frame.copy();second['label']=[1,0,1,0,1];second['uncertain']=[False,True,False,False,False];second['prediction']=[1,1,1,0,1];second['returned_rank']=rank
    metrics=top3_metrics(second)
    require(metrics['returned_uncertain_n']==1 and metrics['returned_known_n']==2 and metrics['micro_recall_at3']==2/3,'Uncertain actual slot/no refill self-test')
    require(pair_metrics(second)['tp']==3 and pair_metrics(second)['fp']==0,'Known-only pair self-test')
    poolless=pd.DataFrame({'pair_id':['a','b']})
    require(not independent_rank(poolless,np.zeros(2,bool),np.asarray([1.,2.]),0.).any(),'Poolless rank zero self-test')
    fake=pd.DataFrame([{'dataset':'main220','seed':seed,'policy':policy,'seconds':seconds,'bge_pairs':calls,'query_pools':220,'rows':6600,'repeat':repeat}
                       for seed in SEEDS for policy,calls in [('all_bge',6600),('dimension_gate_bge',3300)]
                       for repeat,seconds in enumerate([1.,9.,2.])])
    each,aggregate=timing_analysis(fake)
    require(each.full_batch_seconds_seed_median.eq(2.).all(),'Seed median timing self-test')
    require(np.allclose(each.full_batch_cost_cny_2_88_per_hour,2.*2.88/3600),'Full-batch cost self-test')
    require(aggregate.full_batch_seconds_seed_median_sample_sd.eq(0.).all(),'Three-seed sample SD self-test')
    with tempfile.TemporaryDirectory(prefix='all_source_eval_synthetic_') as folder:
        path=Path(folder)/'labels.csv'
        path.write_text('pair_id,final_label\na,1\nb,0\n')
        replacement,metadata=replacement_label_values(path,{'a','b'},{})
        require(replacement.label.tolist()==[1,0] and not replacement.uncertain.any(),'Synthetic replacement label adaptation')
        path.write_text('pair_id,label\na,1\nc,0\n')
        try:replacement_label_values(path,{'a','b'},{});raise RuntimeError('Coverage mismatch was accepted')
        except AssertionError:pass
    print(json.dumps({'self_tests_passed':9,'actual_predictions_read':False,'real_reference_labels_read':False}))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--actual',type=Path,default=HERE/'all_source_actual')
    parser.add_argument('--source',type=Path,default=DEFAULT_SOURCE)
    parser.add_argument('--supplement',type=Path,default=DEFAULT_SUPPLEMENT)
    parser.add_argument('--reference600',type=Path,default=DEFAULT_REFERENCE600)
    parser.add_argument('--alberta-reference',type=Path,default=DEFAULT_ALBERTA_REFERENCE)
    parser.add_argument('--challenge-labels',type=Path,help='Optional replacement 600 quality reference, exactly pair_id plus label/final_label for all IDs')
    parser.add_argument('--alberta-labels',type=Path,help='Optional replacement Alberta quality reference, exactly pair_id plus label/final_label for all IDs')
    parser.add_argument('--output',type=Path,default=None)
    parser.add_argument('--evaluate-labels',action='store_true',help='Explicitly authorize the second phase after completed actual-output integrity checks')
    parser.add_argument('--self-test',action='store_true',help='Only synthetic CPU function checks; read no actual outputs or labels')
    args=parser.parse_args()
    if args.self_test:self_test();return
    replacement=bool(args.challenge_labels or args.alberta_labels)
    if args.output is None:
        if replacement:
            suffix='_'.join(sha(path)[:12] for path in (args.challenge_labels,args.alberta_labels) if path)
            args.output=HERE/('all_source_actual_cpu_eval_references_'+suffix)
        else:args.output=HERE/'all_source_actual_cpu_eval'
    if replacement:
        require(args.output.resolve()!=(HERE/'all_source_actual_cpu_eval').resolve(),'Replacement reference evaluation must use a new output directory')
        require(not args.output.exists(),'Replacement reference output directory must be new')
    require(args.actual.resolve()!=args.output.resolve(),'Evaluation output must not overwrite actual inference directory')
    args.output.mkdir(parents=True,exist_ok=True)
    record={str(Path(__file__).resolve()):sha(__file__)}
    try:
        sm,frames,outputs,timing,audit=label_free_audit(args,record)
        if args.evaluate_labels:
            evaluate(args,sm,frames,outputs,timing,audit,record)
            print(json.dumps({'status':'evaluated_actual_outputs_on_authorized_labels','output':str(args.output)}))
        else:
            print(json.dumps({'status':'actual_output_audit_passed_no_label_values_read','output':str(args.output),'next_phase_requires':'--evaluate-labels'}))
    except Exception as error:
        dump(args.output/'evaluation_failure.json',{'status':'failed','error_type':type(error).__name__,'error':str(error),'label_evaluation_requested':args.evaluate_labels,'source_files_not_modified':True})
        raise


if __name__=='__main__':main()
