#!/usr/bin/env python3
"""Real frozen BGE comparison on main, construction600 and Alberta; no labels."""
import argparse, gc, hashlib, json, os, sys, time
from pathlib import Path
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
ROOT=Path('experiment_runtime')
sys.path.insert(0,str(ROOT/'system_validation_20261005/scripts'))
from system_policy import exact_mask, serialize, rank_returned
from generic_unit_gate import dimension_conflict_mask, ontology_sha256
from engineering_gate_v2 import contradiction_gate

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v): Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
KEYS=['pair_id','evaluation_split','query_id','candidate_id']
ITEM=[f'{side}_{field}' for side in ('query','candidate') for field in ('description','normalized_description','normalized_unit','category','spec_tokens')]

def physical_size_mask(frame):
    def item(row,side):
        return {key:row.get(f'{side}_{key}','') for key in ('description','normalized_description','unit','category','spec_tokens')}
    return np.asarray([contradiction_gate(item(row,'query'),item(row,'candidate'),enabled_rules=('physical_size',)).decision=='reject' for row in frame.to_dict('records')],bool)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--supplement',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--check-inputs',action='store_true')
    a=ap.parse_args();sm=json.loads((a.source/'source_manifest.json').read_text())
    frozen=json.loads((Path(__file__).parent/'frozen_all_source_inference_plan.json').read_text())
    assert sha(ROOT/'system_validation_20261005/scripts/system_policy.py')==frozen['shared_policy_sha256']
    for name in ('run_generic_gate_all_sources_gpu.py','generic_unit_gate.py','engineering_gate.py','engineering_gate_v2.py','enabled_rules.json','unit_dimension_ontology.json','raw_units_metadata.csv'):
        assert sha(Path(__file__).parent/name)==frozen['file_sha256'][name]
    assert sha(a.source/'inputs.csv')==sm['inputs_sha256']
    paths={'main220':a.source/'inputs.csv','challenge600':a.supplement/'model_inputs_challenge600.csv','alberta_scope_core':a.supplement/'model_inputs_alberta_scope_core.csv'}
    for name,path in paths.items(): assert sha(path)==frozen['input_sha256'][name]
    frames={name:pd.read_csv(path,dtype=str,keep_default_na=False) for name,path in paths.items()}
    frames['main220']=frames['main220'][frames['main220'].evaluation_split.ne('validation')].reset_index(drop=True)
    metadata_path=Path(__file__).parent/'raw_units_metadata.csv'
    metadata=pd.read_csv(metadata_path,dtype=str,keep_default_na=False)
    assert set(metadata)=={'dataset','pair_id','query_unit','candidate_unit'}
    for name in ('main220','challenge600'):
        units=metadata[metadata.dataset.eq(name)].drop(columns='dataset')
        frames[name]=frames[name].merge(units,on='pair_id',how='left',validate='one_to_one')
        assert frames[name][['query_unit','candidate_unit']].notna().all().all()
    assert {k:len(v) for k,v in frames.items()}=={'main220':6600,'challenge600':600,'alberta_scope_core':67635}
    for name,f in frames.items():
        assert not {'label','final_label','provisional_label','difficulty','reference_label'} & set(f)
        assert f.pair_id.nunique()==len(f) and set(['pair_id']+ITEM)<=set(f)
        if name!='challenge600':assert set(KEYS)<=set(f)
    for side in ('query','candidate'):
        frames['alberta_scope_core'][f'{side}_description']=frames['alberta_scope_core'][f'{side}_normalized_description']
    if a.check_inputs:
        print(json.dumps({'status':'input_preflight_pass','rows':{k:len(v) for k,v in frames.items()},'labels_accessed':False,'planned_timing_rows':54}));return
    assert not a.output.exists();a.output.mkdir(parents=True)
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    plan={'status':'running','labels_accessed':False,'new_training':False,'thresholds_retuned':False,
          'source_manifest_sha256':sha(a.source/'source_manifest.json'),'input_hashes':{k:sha(v) for k,v in paths.items()},
          'input_rows':{k:len(v) for k,v in frames.items()},'ontology_sha256':ontology_sha256(),
          'helper_sha256':sha(Path(__file__).parent/'generic_unit_gate.py'),'script_sha256':sha(__file__),
          'shared_policy_sha256':sha(ROOT/'system_validation_20261005/scripts/system_policy.py'),
          'raw_units_metadata_sha256':sha(metadata_path),
          'engineering_gate_sha256':{name:sha(Path(__file__).parent/name) for name in ('engineering_gate.py','engineering_gate_v2.py','enabled_rules.json')},
          'timing':'synchronized resident-model input gate, serialization, tokenization, actual scoring, threshold and ranking; excludes file import/model loading/retrieval; main 3 repeats, supplementary one pass per seed/policy',
          'gate':'exact accept; only known different length/area/volume/mass/count/time rejects; unknown/same dimension/lump-sum defer; no query earlystop or price conversion',
          'gpu':torch.cuda.get_device_name(0),'torch_version':torch.__version__,'batch_size':64,'max_length':256,'completed_runs':[]}
    dump(a.output/'execution_manifest.json',plan);times=[]

    @torch.inference_mode()
    def execute(model,tok,t,policy,f):
        torch.cuda.synchronize();start=time.perf_counter();n=len(f)
        exact=exact_mask(f) if policy!='all_bge' else np.zeros(n,bool)
        dimension_conflict=np.asarray(dimension_conflict_mask(f),bool) if policy in ('dimension_gate_bge','dimension_size_gate_bge') else np.zeros(n,bool)
        size_conflict=physical_size_mask(f) if policy=='dimension_size_gate_bge' else np.zeros(n,bool)
        conflict=dimension_conflict|size_conflict
        called=~exact & ~conflict;ix=np.flatnonzero(called);scores=np.full(n,np.nan)
        q,c=serialize(f.iloc[ix],'query'),serialize(f.iloc[ix],'candidate')
        for lo in range(0,len(ix),64):
            enc=tok(q[lo:lo+64],c[lo:lo+64],padding=True,truncation=True,max_length=256,return_tensors='pt')
            enc={k:v.to('cuda') for k,v in enc.items()}
            with torch.autocast('cuda',dtype=torch.bfloat16): z=model(**enc).logits.reshape(-1)
            scores[ix[lo:lo+64]]=z.float().cpu().numpy()
        assert np.isfinite(scores[called]).all(), 'Nonfinite called-model logits'
        kept=np.isfinite(scores)&(scores>=t)
        prediction=(exact|kept).astype(int)
        rank=rank_returned(f,exact,np.where(kept,scores,np.nan),float('-inf')) if 'query_id' in f else np.zeros(n,dtype=int)
        torch.cuda.synchronize();seconds=time.perf_counter()-start
        return dict(score=scores,prediction=prediction,returned_rank=rank,exact_match=exact.astype(int),dimension_rejected=dimension_conflict.astype(int),size_rejected=size_conflict.astype(int),any_gate_rejected=conflict.astype(int),bge_called=called.astype(int)),dict(seconds=seconds,bge_pairs=int(called.sum()),exact_pairs=int(exact.sum()),dimension_rejected_pairs=int(dimension_conflict.sum()),size_rejected_pairs=int(size_conflict.sum()),any_gate_rejected_pairs=int(conflict.sum()))

    for run in sm['runs']:
        seed=int(run['seed']);t=float(run['threshold']);cp=Path(run['checkpoint'])
        for name,h in run['checkpoint_files'].items(): assert sha(cp/name)==h
        torch.manual_seed(seed);tok=AutoTokenizer.from_pretrained(cp,local_files_only=True)
        model=AutoModelForSequenceClassification.from_pretrained(cp,local_files_only=True).to('cuda').eval()
        for dataset,f in frames.items():
            policies=('all_bge','exact_pair_bge','dimension_gate_bge','dimension_size_gate_bge') if dataset=='main220' else ('all_bge','dimension_gate_bge','dimension_size_gate_bge')
            for policy in policies: execute(model,tok,t,policy,f.head(128).reset_index(drop=True))
            cached={};outputs=[]
            for repeat in range(3 if dataset=='main220' else 1):
                for policy in np.random.default_rng(seed+repeat).permutation(policies):
                    values,timing=execute(model,tok,t,str(policy),f)
                    times.append(dict(dataset=dataset,seed=seed,policy=str(policy),repeat=repeat,rows=len(f),query_pools=f.groupby(['evaluation_split','query_id']).ngroups if 'query_id' in f else 0,**timing))
                    if policy in cached: assert np.array_equal(cached[policy],values['prediction']) and np.array_equal(cached[policy+'_rank'],values['returned_rank'])
                    else:
                        cached[policy]=values['prediction'].copy();cached[policy+'_rank']=values['returned_rank'].copy()
                        out=f[[key for key in KEYS+['source_year'] if key in f]].copy()
                        out['dataset']=dataset;out['seed']=seed;out['policy']=str(policy);out['threshold']=t
                        for k,v in values.items(): out[k]=v
                        outputs.append(out)
                    print('FINISH',dataset,seed,policy,repeat,round(timing['seconds'],3),timing['bge_pairs'],flush=True)
            path=a.output/f'predictions_{dataset}_seed_{seed}.csv';pd.concat(outputs).to_csv(path,index=False)
            plan['completed_runs'].append(dict(dataset=dataset,seed=seed,threshold=t,output=path.name,sha256=sha(path),repeat_decisions_identical=True))
            pd.DataFrame(times).to_csv(a.output/'timing.csv',index=False);dump(a.output/'execution_manifest.json',plan)
        del model,tok;gc.collect();torch.cuda.empty_cache()
    assert len(times)==54 and len(plan['completed_runs'])==9
    plan['status']='complete';plan['timing_sha256']=sha(a.output/'timing.csv');dump(a.output/'execution_manifest.json',plan)
    print('ALL_COMPLETE',flush=True)

if __name__=='__main__': main()
