#!/usr/bin/env python3
"""All existing complete600 cached methods plus unchanged generic dimension veto."""
from pathlib import Path
import json,hashlib,importlib.util,datetime
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent;WORK=HERE.parents[2]
OUT=HERE/'challenge600_all_model_cached_dimension_diagnostic'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,obj):Path(p).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def check(condition,reason):assert bool(condition),reason
def main():
    plan=json.loads((OUT/'frozen_diagnostic_plan.json').read_text());check(sha(__file__)==plan['script_sha256'],'Code changed after diagnostic freeze');check(not (OUT/'predictions_frozen_before_reference.csv').exists(),'Preserve all prior diagnostics')
    hashes={}
    def protect(p,h):check(sha(p)==h,'Source SHA changed: '+str(p));hashes[str(p)]=h
    for name,h in plan['gate_files_sha256'].items():protect(HERE/name,h)
    spec=importlib.util.spec_from_file_location('frozen_dimension_diagnostic',HERE/'generic_unit_gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    ip=Path(plan['input_path']);protect(ip,plan['input_sha256']);f=pd.read_csv(ip,dtype=str,keep_default_na=False)
    check(len(f)==600 and f.pair_id.nunique()==600 and 'query_id' not in f,'600 input IDs/schema')
    check(not {'label','difficulty','final_label','provisional_label','reference_label','generation_rule'}&set(f),'Forbidden input field')
    gate=np.asarray(m.dimension_conflict_mask(f),bool);gateframe=pd.DataFrame({'pair_id':f.pair_id,'dimension_reject':gate.astype(int)})
    gatepath=OUT/'dimension_decisions_before_reference.csv';gateframe.to_csv(gatepath,index=False)
    outputs=[];inventory=[]
    for source in plan['sources']:
        path=Path(source['path']);protect(path,source['sha256'])
        if source['format']=='jsonl':
            raw=pd.DataFrame([json.loads(line) for line in path.read_text().splitlines() if line.strip()]);raw=raw[['pair_id','prediction']]
        else:raw=pd.read_csv(path,usecols=['pair_id',source['prediction_field']],dtype=str,keep_default_na=False).rename(columns={source['prediction_field']:'prediction'})
        check(len(raw)==600 and raw.pair_id.nunique()==600 and set(raw.pair_id)==set(f.pair_id),'Complete unique cached predictions: '+source['run'])
        p=raw.set_index('pair_id').loc[f.pair_id,'prediction'].to_numpy(int);check(np.isin(p,[0,1]).all(),'Nonbinary cached prediction')
        original=pd.DataFrame({'run':source['run'],'model':source['model'],'seed':source['seed'],'pair_id':f.pair_id,'original_prediction':p,'dimension_reject':gate.astype(int),'plus_dimension_prediction':(p&~gate).astype(int)})
        outputs.append(original);inventory.append({'run':source['run'],'model':source['model'],'seed':source['seed'],'path':str(path),'sha256':source['sha256'],'read_columns':['pair_id',source['prediction_field']],'rows':600,'changed_accept_to_reject':int(((p==1)&gate).sum()),'upstream_method':source['upstream_method']})
    check(len(outputs)==plan['run_count']==24 and len({x['run'] for x in inventory})==24,'Report every frozen method exactly once')
    out=pd.concat(outputs,ignore_index=True);predpath=OUT/'predictions_frozen_before_reference.csv';out.to_csv(predpath,index=False)
    freeze={'status':'all_cached_combinations_frozen_before_new_reference_access','script_sha256':sha(__file__),'plan_sha256':sha(OUT/'frozen_diagnostic_plan.json'),'labels_read':False,'gpu_used':False,'thresholds_changed':False,'gate_files_sha256':plan['gate_files_sha256'],'input_sha256':plan['input_sha256'],'source_hashes':hashes,'run_count':24,'rows':len(out),'dimension_reject_rows':int(gate.sum()),'output_sha256':sha(predpath),'gate_output_sha256':sha(gatepath),'sources':inventory,'no_model_or_policy_selection_from600':True,'no_cost_or_latency_measured':True,'scope':'cached complete decisions plus fixed input-only veto; no rescue or exact acceptance added'}
    dump(OUT/'predictions_freeze_manifest.json',freeze)
    # Only after every source/output is protected do reference values enter.
    ref=Path(plan['reference_path']);protect(ref,plan['reference_sha256']);label=pd.read_csv(ref,usecols=['pair_id','provisional_label'],dtype=str,keep_default_na=False)
    check(len(label)==600 and label.pair_id.nunique()==600 and set(label.pair_id)==set(f.pair_id),'Complete construction reference')
    y=label.set_index('pair_id').loc[f.pair_id,'provisional_label'].to_numpy(int);check(np.isin(y,[0,1]).all() and y.sum()==300,'600 construction reference300/300')
    rows=[];events=[]
    for group in outputs:
        meta={key:group[key].iloc[0] for key in ('run','model','seed')}
        p0=group.original_prediction.to_numpy(int);p1=group.plus_dimension_prediction.to_numpy(int)
        lost=(y==1)&(p0==1)&(p1==0);corrected=(y==0)&(p0==1)&(p1==0)
        for variant,p in [('original_cached',p0),('plus_frozen_generic_dimension',p1)]:
            tp=int(((y==1)&(p==1)).sum());fp=int(((y==0)&(p==1)).sum());fn=int(((y==1)&(p==0)).sum());tn=int(((y==0)&(p==0)).sum())
            rows.append({**meta,'variant':variant,'rows':600,'tp':tp,'fp':fp,'fn':fn,'tn':tn,'precision':tp/(tp+fp) if tp+fp else None,'recall':tp/(tp+fn),'f1':2*tp/(2*tp+fp+fn),'accuracy':(tp+tn)/600,'correct_acceptances_falsely_deleted':int(lost.sum()) if variant!='original_cached' else 0,'false_acceptances_corrected':int(corrected.sum()) if variant!='original_cached' else 0,'label_source':'construction_intent_provisional_not_human_gold'})
        for i in np.flatnonzero(lost|corrected):events.append({**meta,'pair_id':f.pair_id.iloc[i],'reference_label':int(y[i]),'original_prediction':int(p0[i]),'gated_prediction':int(p1[i]),'event':'correct_acceptance_falsely_deleted' if lost[i] else 'false_acceptance_corrected'})
    metrics=pd.DataFrame(rows);metrics.to_csv(OUT/'metrics_every_cached_run_and_fixed_combination.csv',index=False);pd.DataFrame(events,columns=['run','model','seed','pair_id','reference_label','original_prediction','gated_prediction','event']).to_csv(OUT/'all_changed_acceptance_outcomes.csv',index=False)
    aggregates=[]
    for (model,variant),part in metrics.groupby(['model','variant'],sort=False):
        entry={'model':model,'variant':variant,'reported_run_n':len(part)}
        check(len(part) in (1,3),'No unrelated experimental schemes pooled')
        if len(part)==3:check(set(part.seed)=={'20260904','20260905','20260906'},'Aggregate only original three seeds')
        for name in ['precision','recall','f1','accuracy','tp','fp','fn','tn','correct_acceptances_falsely_deleted','false_acceptances_corrected']:
            v=part[name].dropna().to_numpy(float);entry[name+'_mean']=float(np.mean(v)) if len(v) else None;entry[name+'_sample_sd']=float(np.std(v,ddof=1)) if len(v)>1 else None
        aggregates.append(entry)
    pd.DataFrame(aggregates).to_csv(OUT/'metrics_model_seed_mean_sample_sd.csv',index=False)
    for path,h in hashes.items():check(sha(path)==h,'Protected source changed during diagnostic')
    check(sha(predpath)==freeze['output_sha256'],'Predictions changed after label join')
    dump(OUT/'completed_diagnostic_qa.json',{'all_passed':True,'cached_runs':24,'prediction_rows':len(out),'metric_rows':len(metrics),'gate_rejects':int(gate.sum()),'gate_rejected_reference_positive':int(((y==1)&gate).sum()),'gate_rejected_reference_negative':int(((y==0)&gate).sum()),'labels_joined_after_predictions_frozen':True,'source_hashes':hashes,'output_sha256':freeze['output_sha256'],'all_model_results_preserved':True,'test_based_model_or_policy_selection':False,'gpu_used':False,'no_timing_or_cost_claim':True,'label_source':'construction_intent_provisional_not_human_gold','source_scope_note':'Qwen0.6B sources are already routed existing methods, not new complete pure Qwen0.6B inference; all upstream scopes explicitly preserved.'})
    print(metrics.loc[metrics.model.isin(['GPT6Sol_blind','bge_hard','qwen_4B_standard','qwen06_hard_strict_unit_single','qwen06_hard_strict_unit_mean'])].to_string(index=False))
if __name__=='__main__':main()
