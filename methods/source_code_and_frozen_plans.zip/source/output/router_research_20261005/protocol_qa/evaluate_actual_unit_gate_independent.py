from pathlib import Path
import csv, json, re, math, hashlib, statistics, ast
from collections import defaultdict
import numpy as np

OUTROOT=Path(__file__).resolve().parents[2]
BASE=OUTROOT/'router_research_20261005/gpu_unit_gate'
RUN=BASE/'unit_gate_gpu'
OUT=BASE/'analysis'
OUT.mkdir(exist_ok=True)
INPUT=OUTROOT/'rule_first_system_20261004/results/server/inputs.csv'
SOURCE=INPUT.parent/'source_manifest.json'
DATA=OUTROOT/'revise3_full_20260920/supplementary/data'
SCRIPT=OUTROOT/'router_research_20261005/scripts/run_unit_gate_gpu.py'
HELPER=OUTROOT/'rule_first_system_validation_20261005/scripts/system_policy.py'

def read(p):
    with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def writecsv(p,rs):
    if not rs:return
    with p.open('w',newline='',encoding='utf-8') as f:
        fields=list(dict.fromkeys(k for r in rs for k in r))
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rs)
def number(s):return float(s) if s else float('nan')
def canon(s):return ' '.join(re.sub('[^a-z0-9]+',' ',s.lower().replace('&',' and ')).split())
def unit(s):return ' '.join(s.strip().lower().split())
def exact(r):
    q,c=canon(r['query_normalized_description']),canon(r['candidate_normalized_description'])
    qu,cu=unit(r['query_normalized_unit']),unit(r['candidate_normalized_unit'])
    return bool(q) and bool(qu) and q==c and qu==cu
def udiff(r):
    q,c=r['query_normalized_unit'].strip().lower(),r['candidate_normalized_unit'].strip().lower()
    return bool(q) and bool(c) and q!=c

inputs=read(INPUT)
source=json.loads(SOURCE.read_text())
manifest=json.loads((RUN/'execution_manifest.json').read_text())
plan=json.loads((BASE/'pre_test_frozen_plan.json').read_text())
labelrows=[]
for name in ['validation_pairs.csv','locked_pairs.csv','external_mixed_pairs.csv','no_reference_top30_pairs.csv','no_reference_reclassified_positive_pairs.csv']:
    labelrows+=read(DATA/'evaluation'/name)
labels={r['pair_id']:r for r in labelrows}
fr={r['pair_id']:r for r in inputs if r['evaluation_split']!='validation'}
checks=[]
def check(name,p,details):checks.append({'check':name,'passed':bool(p),'details':details})
protected=[INPUT,SOURCE,SCRIPT,HELPER,RUN/'execution_manifest.json',RUN/'timing.csv',BASE/'pre_test_frozen_plan.json']+[RUN/x['output'] for x in manifest['completed_runs']]
before={str(p):sha(p) for p in protected}
check('status_complete',manifest['status']=='complete',manifest['status'])
check('source_input_hash',sha(INPUT)==manifest['source_sha256']==source['inputs_sha256']==plan['source_sha256'],sha(INPUT))
check('script_hash',sha(SCRIPT)==manifest['script_sha256']==plan['script_sha256'],sha(SCRIPT))
check('timing_hash',sha(RUN/'timing.csv')==manifest['timing_sha256'],sha(RUN/'timing.csv'))
check('source_inputs_have_no_answer_fields',not set(inputs[0])&{'final_label','difficulty','label','provisional_label','training_label','final_relevance'},list(inputs[0]))
tree=ast.parse(SCRIPT.read_text())
calls=[n.func.id for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)]
read_fields={n.attr for n in ast.walk(tree) if isinstance(n,ast.Attribute) and isinstance(n.value,ast.Name) and n.value.id in {'f','frame','sub','group'}}
check('runtime_never_calls_old_query_earlystop_route','route' not in calls,calls)
check('runtime_never_reads_gold_difficulty_fields',not read_fields&{'final_label','difficulty','label','provisional_label','final_relevance','training_label'},sorted(read_fields))
check('source_6600_pool',len(fr)==6600 and len({r['query_id'] for r in fr.values()})==220,len(fr))
check('all_input_ids_have_canonical_label',set(fr)<=set(labels),len(set(fr)-set(labels)))
policies=['all_bge','exact_pair_bge','unit_gate_bge']
seeds=[20260904,20260905,20260906]
allpred={}
for done in manifest['completed_runs']:
    check(f"seed_{done['seed']}_output_hash",sha(RUN/done['output'])==done['sha256'],sha(RUN/done['output']))
    check(f"seed_{done['seed']}_original_validation_threshold",float(done['threshold'])==float(next(x['threshold'] for x in source['runs'] if x['seed']==done['seed'])),done['threshold'])
    rs=read(RUN/done['output'])
    bypolicy={p:{r['pair_id']:r for r in rs if r['policy']==p} for p in policies}
    check(f"seed_{done['seed']}_3_complete_unique_6600_policies",len(rs)==19800 and all(set(d)==set(fr) for d in bypolicy.values()),{p:len(d) for p,d in bypolicy.items()})
    for p,d in bypolicy.items():
        gate_mismatch=[];pred_mismatch=[];rank_mismatch=[];metadata_mismatch=[]
        queries=defaultdict(list)
        for pid,r in d.items():
            x=fr[pid];ex=exact(x) if p!='all_bge' else False
            called=p=='all_bge' or (not exact(x) and (p!='unit_gate_bge' or not udiff(x)))
            s=number(r['score']);pred=ex or (called and s>=float(r['threshold']))
            if (int(r['exact_match'])!=int(ex) or int(r['bge_called'])!=int(called) or int(r['qwen_called'])!=0 or math.isfinite(s)!=called or r['qwen_score']):gate_mismatch.append(pid)
            if int(r['prediction'])!=int(pred):pred_mismatch.append(pid)
            if (r['query_id'],r['candidate_id'],r['evaluation_split'],int(r['seed']),float(r['threshold']))!=(x['query_id'],x['candidate_id'],x['evaluation_split'],done['seed'],float(done['threshold'])):metadata_mismatch.append(pid)
            queries[(r['evaluation_split'],r['query_id'])].append(r)
        for key,rr in queries.items():
            if p=='all_bge':
                ranked=sorted([r for r in rr if int(r['prediction'])==1],key=lambda r:(-float(r['score']),r['candidate_id']))[:3]
            else:
                rules=sorted([r for r in rr if exact(fr[r['pair_id']])],key=lambda r:r['candidate_id'])
                model=sorted([r for r in rr if not exact(fr[r['pair_id']]) and int(r['prediction'])==1],key=lambda r:(-float(r['score']),r['candidate_id']))
                ranked=(rules+model)[:3]
            expected={r['pair_id']:i+1 for i,r in enumerate(ranked)}
            rank_mismatch += [r['pair_id'] for r in rr if int(r['returned_rank'])!=expected.get(r['pair_id'],0)]
        check(f"{done['seed']}_{p}_input_only_gate_and_finite_scores",not gate_mismatch,gate_mismatch)
        check(f"{done['seed']}_{p}_threshold_decisions",not pred_mismatch,pred_mismatch)
        check(f"{done['seed']}_{p}_correct_policy_top3_order",not rank_mismatch,rank_mismatch)
        check(f"{done['seed']}_{p}_source_metadata",not metadata_mismatch,metadata_mismatch)
        allpred[(done['seed'],p)]=d

def pairmetrics(rows,predkey):
    tp=fp=fn=tn=0
    for r in rows:
        y=int(labels[r['pair_id']]['final_label']);p=int(r[predkey])>0
        if y and p:tp+=1
        elif not y and p:fp+=1
        elif y and not p:fn+=1
        else:tn+=1
    return dict(rows=len(rows),tp=tp,fp=fp,fn=fn,tn=tn,precision=100*tp/(tp+fp) if tp+fp else None,recall=100*tp/(tp+fn) if tp+fn else None,f1=100*2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None,accuracy=100*(tp+tn)/len(rows) if rows else None)
groups={'primary218':lambda x:x['evaluation_split']!='no_reference_reclassified','locked100':lambda x:x['evaluation_split']=='locked','external80':lambda x:x['evaluation_split']=='external','internal138':lambda x:x['evaluation_split'] in ['locked','no_reference'],'no_reference38':lambda x:x['evaluation_split']=='no_reference','audit2':lambda x:x['evaluation_split']=='no_reference_reclassified','all220':lambda x:True}
pairout=[];listout=[];queryout=[];diffout=[];scorecontext=[]
for (seed,p),d in allpred.items():
    for name,keep in groups.items():
        rows=[r for r in d.values() if keep(r)]
        for sub in ['all','hard']:
            rs=[r for r in rows if sub=='all' or labels[r['pair_id']]['difficulty']=='hard']
            pairout.append({'seed':seed,'policy':p,'scope':name,'subset':sub,**pairmetrics(rs,'prediction')})
            listout.append({'seed':seed,'policy':p,'scope':name,'subset':sub,**pairmetrics(rs,'returned_rank')})
        qq=defaultdict(list)
        for r in rows:qq[r['query_id']].append(r)
        qm=[]
        for q,rs in qq.items():
            g=sum(int(labels[r['pair_id']]['final_label']) for r in rs)
            hp=sum(int(labels[r['pair_id']]['final_label']) and labels[r['pair_id']]['difficulty']=='hard' for r in rs)
            rr=[r for r in rs if int(r['returned_rank'])>0]
            tp=sum(int(labels[r['pair_id']]['final_label']) for r in rr)
            htp=sum(int(labels[r['pair_id']]['final_label']) and labels[r['pair_id']]['difficulty']=='hard' for r in rr)
            qm.append({'seed':seed,'policy':p,'scope':name,'query_id':q,'gold_positives':g,'hard_gold_positives':hp,'returned':len(rr),'returned_tp':tp,'returned_fp':len(rr)-tp,'returned_hard_tp':htp,'recall_at3':tp/g if g else None,'hit_at3':int(tp>0) if g else None,'no_reference_correct_rejection':int(not rr) if not g else None})
        queryout+=qm
        positive=[q for q in qm if q['gold_positives']]
        zero=[q for q in qm if not q['gold_positives']]
        lm=listout[-2]
        lm.update(queries=len(qm),positive_queries=len(positive),no_reference_queries=len(zero),macro_recall_at3=100*statistics.mean(q['recall_at3'] for q in positive) if positive else None,hit_at3=100*statistics.mean(q['hit_at3'] for q in positive) if positive else None,no_reference_rejection=100*statistics.mean(q['no_reference_correct_rejection'] for q in zero) if zero else None)

for seed in seeds:
    base=allpred[(seed,'all_bge')]
    for policy in ['exact_pair_bge','unit_gate_bge']:
        dst=allpred[(seed,policy)]
        dropped=[];gained=[];hard_drop=[]
        for pid,r in base.items():
            if int(r['prediction'])!=int(dst[pid]['prediction']):
                z=labels[pid];typ='drop' if int(r['prediction']) else 'gain'
                diffout.append({'seed':seed,'policy':policy,'pair_id':pid,'evaluation_split':r['evaluation_split'],'query_id':r['query_id'],'candidate_id':r['candidate_id'],'difference':typ,'gold':int(z['final_label']),'difficulty':z['difficulty'],'all_bge_score':r['score'],'policy_score':dst[pid]['score'],'exact_rule':int(exact(fr[pid])),'different_unit':int(udiff(fr[pid])),'query_unit':fr[pid]['query_normalized_unit'],'candidate_unit':fr[pid]['candidate_normalized_unit']})
                if int(z['final_label']):
                    (dropped if typ=='drop' else gained).append(pid)
                    if typ=='drop' and z['difficulty']=='hard':hard_drop.append(pid)
        check(f'{seed}_{policy}_no_bge_true_positive_lost',not dropped,{'dropped_tp':dropped,'gained_tp':gained})
        check(f'{seed}_{policy}_no_bge_hard_true_positive_lost',not hard_drop,hard_drop)
        shared=[pid for pid in base if math.isfinite(number(base[pid]['score'])) and math.isfinite(number(dst[pid]['score']))]
        delta=[abs(float(base[pid]['score'])-float(dst[pid]['score'])) for pid in shared]
        scorecontext.append({'seed':seed,'policy':policy,'shared_scored_pairs':len(shared),'score_differences':sum(x!=0 for x in delta),'max_abs_score_difference':max(delta),'mean_abs_score_difference':statistics.mean(delta),'threshold_decision_differences_on_shared_scored':sum(int(base[pid]['prediction'])!=int(dst[pid]['prediction']) for pid in shared)})

timing=read(RUN/'timing.csv')
check('27_timing_conditions_unique',len(timing)==27 and len({(x['seed'],x['policy'],x['repeat']) for x in timing})==27,len(timing))
timingout=[]
for seed in seeds:
    bt=[float(x['seconds']) for x in timing if int(x['seed'])==seed and x['policy']=='all_bge']
    for policy in policies:
        ts=[x for x in timing if int(x['seed'])==seed and x['policy']==policy]
        expected_calls=sum(int(x['bge_called']) for x in allpred[(seed,policy)].values())
        check(f'{seed}_{policy}_3_repeat_actual_counts',len(ts)==3 and {int(x['repeat']) for x in ts}=={0,1,2} and all(int(x['bge_pairs'])==expected_calls and int(x['qwen_pairs'])==0 and int(x['qwen_prompt_tokens'])==0 and int(x['pairs'])==6600 and int(x['queries'])==220 and math.isfinite(float(x['seconds'])) and float(x['seconds'])>0 for x in ts),{'repeats':len(ts),'expected_bge_calls':expected_calls})
        seconds=statistics.median(float(x['seconds']) for x in ts)
        timingout.append({'seed':seed,'policy':policy,'bge_pairs':expected_calls,'qwen_pairs':0,'bge_call_reduction_vs_all_pct':100*(1-expected_calls/6600),'median_220_query_batch_seconds':seconds,'mean_220_query_batch_seconds':statistics.mean(float(x['seconds']) for x in ts),'within_seed_repeat_sd_seconds':statistics.stdev(float(x['seconds']) for x in ts),'median_time_reduction_vs_all_pct':100*(1-seconds/statistics.median(bt)),'amortized_cny_per_1000_query_at_2_88_hour':seconds/220*1000/3600*2.88})

aggregates=[]
for family,rs in [('pair',pairout),('returned_list',listout)]:
    group=defaultdict(list)
    for r in rs:group[(r['policy'],r['scope'],r['subset'])].append(r)
    for (p,sc,sub),vv in group.items():
        o=dict(metric_family=family,policy=p,scope=sc,subset=sub,seeds=len(vv))
        for field in [k for k in vv[0] if k not in ['seed','policy','scope','subset']]:
            nums=[float(v[field]) for v in vv if v.get(field) is not None]
            o[field+'_mean']=statistics.mean(nums) if nums else None
            o[field+'_seed_sd']=statistics.stdev(nums) if len(nums)>1 else None
        aggregates.append(o)
costaggregate=[]
for policy in policies:
    vv=[x for x in timingout if x['policy']==policy]
    row={'policy':policy,'seeds':3}
    for key in [k for k in vv[0] if k not in ['seed','policy']]:row[key]=statistics.mean(x[key] for x in vv)
    costaggregate.append(row)
secondsbase=costaggregate[0]['median_220_query_batch_seconds']
for row in costaggregate:row['time_reduction_ratio_of_mean_seed_medians_pct']=100*(1-row['median_220_query_batch_seconds']/secondsbase)

unitgold=[]
for name,rows in [('train_all4138',read(DATA/'training/training_pairs_all_rows.csv')),('train_deduplicated2278',read(DATA/'training/training_pairs_semantic_deduplicated.csv')),('validation',read(DATA/'evaluation/validation_pairs.csv')),('heldout220',[labels[x] for x in fr])]:
    rr=[r for r in rows if udiff(r)]
    unitgold.append({'split':name,'explicit_different_normalized_unit_rows':len(rr),'positive_gold_rows':sum(int(r['final_label']) for r in rr),'hard_positive_gold_rows':sum(int(r['final_label']) and r['difficulty']=='hard' for r in rr)})
check('gate_training_rationale_595_deduplicated_unit_conflict_rows_zero_positive',unitgold[1]['explicit_different_normalized_unit_rows']==595 and unitgold[1]['positive_gold_rows']==0,unitgold[1])
check('gate_validation_rationale_160_unit_conflict_rows_zero_positive',unitgold[2]['explicit_different_normalized_unit_rows']==160 and unitgold[2]['positive_gold_rows']==0,unitgold[2])

# Resample the same queries for all policies and all seeds. This is a quality CI,
# not a p-value from27 timing rows or an independence claim about repeated seeds.
bootstrap=[]
for sc,sub in [('primary218','all'),('locked100','all'),('locked100','hard')]:
    qids=sorted({r['query_id'] for r in fr.values() if groups[sc](r)})
    qmap={q:i for i,q in enumerate(qids)}
    counters={p:np.zeros((3,len(qids),3),dtype=float) for p in policies}
    for si,seed in enumerate(seeds):
        for p in policies:
            for pid,r in allpred[(seed,p)].items():
                if not groups[sc](r) or (sub=='hard' and labels[pid]['difficulty']!='hard'):continue
                y=int(labels[pid]['final_label']);pred=int(r['prediction']);qi=qmap[r['query_id']]
                if y and pred:counters[p][si,qi,0]+=1
                elif not y and pred:counters[p][si,qi,1]+=1
                elif y and not pred:counters[p][si,qi,2]+=1
    rng=np.random.default_rng(20261005)
    weights=rng.multinomial(len(qids),np.full(len(qids),1/len(qids)),size=10000)
    def measures(v):
        tp,fp,fn=v[...,0],v[...,1],v[...,2]
        out={}
        for name,numer,denom in [('precision',tp,tp+fp),('recall',tp,tp+fn),('f1',2*tp,2*tp+fp+fn)]:
            values=np.divide(100*numer,denom,out=np.full_like(numer,np.nan),where=denom!=0)
            out[name]=np.nanmean(values,axis=0)
        return out
    sampled={p:measures(np.einsum('bq,sqc->sbc',weights,v)) for p,v in counters.items()}
    point={p:measures(v.sum(axis=1)) for p,v in counters.items()}
    for p in ['exact_pair_bge','unit_gate_bge']:
        for metric in ['precision','recall','f1']:
            delta=sampled[p][metric]-sampled['all_bge'][metric]
            bootstrap.append({'scope':sc,'subset':sub,'policy':p,'baseline':'all_bge','metric':metric,'query_clusters':len(qids),'bootstrap_seed':20261005,'bootstrap_replicates':10000,'finite_replicates':int(np.isfinite(delta).sum()),'point_delta_percentage_points':float(point[p][metric]-point['all_bge'][metric]),'ci95_low_percentage_points':float(np.nanpercentile(delta,2.5)),'ci95_high_percentage_points':float(np.nanpercentile(delta,97.5))})

writecsv(OUT/'actual_pair_metrics_per_seed.csv',pairout)
writecsv(OUT/'actual_top3_metrics_per_seed.csv',listout)
writecsv(OUT/'actual_metrics_aggregate.csv',aggregates)
writecsv(OUT/'actual_per_query_metrics.csv',queryout)
writecsv(OUT/'decision_differences_vs_pure_bge.csv',diffout)
writecsv(OUT/'bf16_shared_score_context_differences.csv',scorecontext)
writecsv(OUT/'actual_timing_cost_per_seed.csv',timingout)
writecsv(OUT/'actual_timing_cost_aggregate.csv',costaggregate)
writecsv(OUT/'explicit_unit_conflict_gold_support.csv',unitgold)
writecsv(OUT/'paired_query_bootstrap_quality.csv',bootstrap)
after={str(p):sha(p) for p in protected}
check('protected_inputs_outputs_unchanged',before==after,{'files':len(protected)})
qa={'pass_checks':sum(c['passed'] for c in checks),'failed_checks':[c for c in checks if not c['passed']],'checks':checks,'protected_sha256':after,'gpu_inference':True,'cached_scores_used_for_metrics':False,'rank_recomputed_from_actual_policy_scores':True,'repeat_limit':'Only one predictions file per seed/policy was exported; repeat-rank equality is runner attestation, not independently reproducible per-repeat predictions. All27 timing rows independently checked.','hardware_timing_limit':'Resident model batch timing includes gate/serialization/tokenization/inference/merge/rank, excludes loading/CSV/candidate retrieval. Amortized2.88CNY/hour figures are not invoices or single-query latency.','gate_coverage':'Nonempty unequal normalized units; missing units never rule-rejected. Rule-negative is conditional on supplied units denoting comparable pay bases; unit conversion/reconciliation outside this gate.'}
(OUT/'independent_gpu_unit_gate_qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pass_checks':qa['pass_checks'],'failed_checks':qa['failed_checks'],'actual_time':costaggregate,'bf16_context':scorecontext,'unit_support':unitgold,'bootstrap':bootstrap},ensure_ascii=False,indent=2))
