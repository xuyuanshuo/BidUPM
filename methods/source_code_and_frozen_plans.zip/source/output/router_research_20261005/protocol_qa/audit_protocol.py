from pathlib import Path
import csv, json, hashlib, math
from collections import Counter, defaultdict

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / 'revise3_full_20260920/supplementary/data'
RUNS = ROOT / 'remote_experiments_20260923/runs'
OUT = Path(__file__).resolve().parent

def read(p):
    with p.open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def exact(r):
    return bool(r['query_normalized_description']) and r['query_normalized_description'] == r['candidate_normalized_description'] and bool(r['query_normalized_unit']) and r['query_normalized_unit'] == r['candidate_normalized_unit']

def positive(r):
    return int(r['final_label']) == 1

def keys(rows, field):
    return set(r[field] for r in rows if r.get(field))

def temporal(rows):
    pairs = [(r.get('query_letting_date',''), r.get('candidate_letting_date','')) for r in rows]
    pairs = [(q,c) for q,c in pairs if q and c]
    return {'dated_pairs':len(pairs), 'candidate_strictly_earlier_rows':sum(c < q for q,c in pairs), 'candidate_equal_date_rows':sum(c == q for q,c in pairs), 'candidate_later_rows':sum(c > q for q,c in pairs), 'query_date_min':min((q for q,c in pairs),default=None), 'query_date_max':max((q for q,c in pairs),default=None), 'candidate_date_min':min((c for q,c in pairs),default=None), 'candidate_date_max':max((c for q,c in pairs),default=None)}

def summarize(rows):
    pos = [r for r in rows if positive(r)]
    hard = [r for r in rows if r['difficulty']=='hard']
    hp = [r for r in hard if positive(r)]
    nonexact_pos = [r for r in pos if not exact(r)]
    perquery=defaultdict(list)
    for r in rows:
        perquery[r['query_id']].append(r)
    return {'rows':len(rows), 'query_ids':len(perquery), 'positive_rows':len(pos), 'negative_rows':len(rows)-len(pos), 'exact_rule_positive_rows':sum(exact(r) and positive(r) for r in rows), 'exact_rule_negative_rows':sum(exact(r) and not positive(r) for r in rows), 'hard_rows':len(hard), 'hard_positive_rows':len(hp), 'hard_positive_queries':len(keys(hp,'query_id')), 'hard_positive_directional_semantic_pairs':len(keys(hp,'pair_semantic_key')), 'hard_positive_unordered_semantic_pairs':len(keys(hp,'unordered_pair_key')), 'nonexact_positive_rows':len(nonexact_pos), 'nonexact_positive_queries':len(keys(nonexact_pos,'query_id')), 'nonexact_positive_directional_semantic_pairs':len(keys(nonexact_pos,'pair_semantic_key')), 'nonexact_positive_unordered_semantic_pairs':len(keys(nonexact_pos,'unordered_pair_key')), 'no_positive_queries':sum(not any(positive(r) for r in v) for v in perquery.values()), 'queries_with_at_least_three_exact_positives':sum(sum(exact(r) and positive(r) for r in v)>=3 for v in perquery.values()), 'query_agencies':sorted(keys(rows,'query_agency')), 'candidate_agencies':sorted(keys(rows,'candidate_agency')), **temporal(rows)}

names={'train':'training/training_pairs_all_rows.csv', 'train_deduplicated':'training/training_pairs_semantic_deduplicated.csv', 'validation':'evaluation/validation_pairs.csv', 'locked':'evaluation/locked_pairs.csv', 'no_reference':'evaluation/no_reference_top30_pairs.csv', 'external':'evaluation/external_mixed_pairs.csv', 'reclassified_audit':'evaluation/no_reference_reclassified_positive_pairs.csv'}
splits={k:read(DATA/p) for k,p in names.items()}
physical_file_rows={k:len(v) for k,v in splits.items()}
# This pooled tail audit file repeats WSDOT no-reference rows already present in
# external_mixed_pairs.csv. Canonical split membership, not the filename, defines
# the internal no-reference split.
splits['no_reference']=[r for r in splits['no_reference'] if r['split_final']=='no_reference']
train=splits['train']
primary=splits['locked']+splits['no_reference']+splits['external']
eval_all=splits['validation']+primary+splits['reclassified_audit']
meta={r['pair_id']:r for r in eval_all}
summary={k:summarize(v) for k,v in splits.items()}
summary['primary_heldout_218']=summarize(primary)
summary['all_evaluation_250']=summarize(eval_all)
train_part={k:[r for r in train if r['split_final']==k] for k in sorted(keys(train,'split_final'))}
summary['training_parts']={k:summarize(v) for k,v in train_part.items()}

overlaps=[]
for k,rs in splits.items():
    if k.startswith('train'): continue
    row={'split':k}
    for f in ['pair_id','query_id','candidate_id','query_semantic_key','candidate_semantic_key','pair_semantic_key','unordered_pair_key','query_source_group_id','candidate_source_group_id','query_contract_id','candidate_contract_id']:
        shared=keys(train,f)&keys(rs,f)
        row[f+'_train_overlap_count']=len(shared)
        if f in ['query_id','pair_semantic_key','unordered_pair_key']:
            row[f+'_shared_values']=sorted(shared)
    overlaps.append(row)

checks=[]
def check(name,passed,details): checks.append({'check':name,'passed':bool(passed),'details':details})
check('canonical_training_rows',len(train)==4138,len(train))
check('deduplicated_training_rows',len(splits['train_deduplicated'])==2278,len(splits['train_deduplicated']))
check('evaluation_pair_ids_unique',len(meta)==7500,len(meta))
check('primary_heldout_rows_and_queries',len(primary)==6540 and len(keys(primary,'query_id'))==218,{'rows':len(primary),'queries':len(keys(primary,'query_id'))})
for r in overlaps:
    check(r['split']+'_no_train_pair_id_overlap',r['pair_id_train_overlap_count']==0,r['pair_id_train_overlap_count'])
    check(r['split']+'_no_train_unordered_semantic_pair_overlap',r['unordered_pair_key_train_overlap_count']==0,r['unordered_pair_key_train_overlap_count'])
for a in ['validation','locked','no_reference','external','reclassified_audit']:
    for b in ['validation','locked','no_reference','external','reclassified_audit']:
        if a >= b: continue
        shared=keys(splits[a],'query_id')&keys(splits[b],'query_id')
        check(a+'_'+b+'_query_ids_disjoint',not shared,sorted(shared))

coverage=[]
for d in sorted(RUNS.iterdir()):
    p=d/'pair_scores.csv'
    if not p.exists(): continue
    rows=read(p); ids=[r['pair_id'] for r in rows]
    cols=[c for c in rows[0] if c.startswith('score_')]
    finite=all(math.isfinite(float(r[c])) for r in rows for c in cols)
    unique=len(set(ids))==len(ids)
    full=set(ids)==set(meta)
    aligned=all((r['query_id'],r['candidate_id'],r['final_label'],r['difficulty'])==(meta[r['pair_id']]['query_id'],meta[r['pair_id']]['candidate_id'],meta[r['pair_id']]['final_label'],meta[r['pair_id']]['difficulty']) for r in rows if r['pair_id'] in meta)
    manifest=json.loads((d/'manifest.json').read_text()) if (d/'manifest.json').exists() else {}
    mismatch=[]
    for rel,h in manifest.get('input_hashes',{}).items():
        hp=DATA/rel
        if hp.exists() and sha(hp)!=h: mismatch.append(rel)
    row={'run':d.name,'rows':len(rows),'unique_pair_ids':unique,'complete_7500_pair_ids':full,'finite_all_score_columns':finite,'labels_ids_difficulty_align':aligned,'score_columns':cols,'input_manifest_hash_mismatches':mismatch,'pair_scores_sha256':sha(p),'manifest_threshold_selection':manifest.get('threshold_selection'), 'manifest_checkpoint_selection':manifest.get('checkpoint_selection')}
    coverage.append(row)
    check(d.name+'_coverage_labels_and_finite',unique and full and aligned and finite,row)
    check(d.name+'_known_input_hashes_align',not mismatch,mismatch)
check('old_run_count',len(coverage)==25,len(coverage))

valid_detail=[]
for q,rs in sorted({qid:[r for r in splits['validation'] if r['query_id']==qid] for qid in keys(splits['validation'],'query_id')}.items()):
    valid_detail.append({'query_id':q,'rows':len(rs),'positive_rows':sum(positive(r) for r in rs),'hard_positive_rows':sum(positive(r) and r['difficulty']=='hard' for r in rs),'nonexact_positive_rows':sum(positive(r) and not exact(r) for r in rs),'exact_rule_positive_rows':sum(positive(r) and exact(r) for r in rs),'hard_semantic_concepts':len({r['unordered_pair_key'] for r in rs if positive(r) and r['difficulty']=='hard'})})
with (OUT/'validation_query_composition.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(valid_detail[0]));w.writeheader();w.writerows(valid_detail)

result={'summary':summary,'physical_file_rows':physical_file_rows,'training_overlap_details':overlaps,'old_score_coverage':coverage,'checks':checks,'pass_checks':sum(c['passed'] for c in checks),'failed_checks':[c for c in checks if not c['passed']],'canonical_input_sha256':{k:sha(DATA/p) for k,p in names.items()},'candidate_search_test_outputs_read':False,'gold_used_for_router_training':False,'scope':'metadata/split QA and original frozen score coverage only; no current search outputs were opened'}
(OUT/'protocol_independent_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pass_checks':result['pass_checks'],'failed_checks':result['failed_checks'],'validation':summary['validation'],'training_parts':summary['training_parts'],'overlaps':overlaps,'coverage_runs':len(coverage)},ensure_ascii=False,indent=2))
