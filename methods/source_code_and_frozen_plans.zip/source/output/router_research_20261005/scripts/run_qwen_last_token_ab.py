#!/usr/bin/env python3
"""Same-checkpoint official last-token-only head A/B; no model/threshold change."""
import argparse,hashlib,inspect,json,os,sys,time
from pathlib import Path
os.environ.setdefault('HF_HUB_OFFLINE','1');os.environ.setdefault('TRANSFORMERS_OFFLINE','1');os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np,pandas as pd,torch
from transformers import AutoTokenizer
from transformers.models.qwen3.modeling_qwen3 import Qwen3ForCausalLM
from peft import PeftModel
ROOT=Path('experiment_runtime')
sys.path.insert(0,str(ROOT/'scripts'));sys.path.insert(0,str(ROOT/'system_validation_20261005/scripts'))
from local_experiment_utils import item_text
from run_qwen_reranker import QwenPairCollator,load_base_model,label_token_ids
from system_policy import rank_returned
FORBIDDEN={'label','final_label','provisional_label','difficulty','annotator_a_label','annotator_b_label','final_relevance','final_conflict_type','proposed_label'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def gates(f):
    qd,cd,qu,cu=[f[x].str.strip().to_numpy() for x in ['query_normalized_description','candidate_normalized_description','query_normalized_unit','candidate_normalized_unit']]
    return (qd!='')&(qd==cd)&(qu!='')&(qu==cu),(qu!='')&(cu!='')&(qu!=cu)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--plan',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    plan=json.loads(a.plan.read_text());run=next(x for x in plan['models'] if int(x['seed'])==20260906)
    sm=json.loads((a.source/'source_manifest.json').read_text());assert sha(a.source/'inputs.csv')==sm['inputs_sha256']
    f=pd.read_csv(a.source/'inputs.csv',dtype=str,keep_default_na=False);f=f[f.evaluation_split.ne('validation')].reset_index(drop=True)
    assert len(f)==6600 and not set(f)&FORBIDDEN;assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    assert 'logits_to_keep' in inspect.signature(Qwen3ForCausalLM.forward).parameters
    assert not a.output.exists();a.output.mkdir(parents=True)
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    cp=Path(run['checkpoint']);assert sha(cp.parent/'validation_thresholds.csv')==run['original_threshold_sha256'];assert sha(cp.parent/'manifest.json')==run['original_manifest_sha256']
    weights={p.name:sha(p) for p in cp.glob('*.safetensors')};assert weights
    tok=AutoTokenizer.from_pretrained(run['base_model_path'],local_files_only=True,padding_side='left');tok.pad_token=tok.pad_token or tok.eos_token
    model=PeftModel.from_pretrained(load_base_model(run['base_model_path'],torch.device('cuda')),cp).eval()
    collator=QwenPairCollator(tok,256,run['instruction']);no_id,yes_id=label_token_ids(tok);threshold=float(run['threshold'])
    manifest={'status':'running','inference_labels_read':False,'new_training':False,'threshold_changed':False,
        'policy_change':'Only official Qwen3ForCausalLM logits_to_keep=0 versus 1; backbone, input, LoRA, instruction, batch32, max256, yes-minus-no threshold unchanged.',
        'seed':20260906,'checkpoint':str(cp),'adapter_weight_sha256':weights,'source_input_sha256':sha(a.source/'inputs.csv'),
        'plan_sha256':sha(a.plan),'script_sha256':sha(__file__),'qwen_forward_source_sha256':hashlib.sha256(inspect.getsource(Qwen3ForCausalLM.forward).encode()).hexdigest(),
        'gpu':torch.cuda.get_device_name(0),'threshold':threshold,'batch_size':32,'max_length':256,'repeats':3,'completed_outputs':[],
        'timing_scope':'Randomized same-session resident synchronized gate/serialize/collate/inference/CPU-transfer/accept/rank; excludes load, IO, retrieval and preprocessing.'}
    dump(a.output/'execution_manifest.json',manifest);times=[];reference={}
    @torch.inference_mode()
    def execute(frame,gated,keep):
        torch.cuda.synchronize();start=time.perf_counter();exact,mismatch=gates(frame);called=~exact&~mismatch if gated else np.ones(len(frame),bool)
        ix=np.flatnonzero(called);sub=frame.iloc[ix];qs=item_text(sub,'query','full');cs=item_text(sub,'candidate','full');score=np.full(len(frame),np.nan);tokens=0
        for lo in range(0,len(ix),32):
            enc=collator([(q,c,0,0.) for q,c in zip(qs[lo:lo+32],cs[lo:lo+32])]);enc.pop('labels_local');enc.pop('hard_local');tokens+=int(enc['attention_mask'].sum());enc={k:v.to('cuda') for k,v in enc.items()}
            with torch.autocast('cuda',dtype=torch.bfloat16):
                logits=model(**enc,logits_to_keep=keep).logits;diff=logits[:,-1,yes_id]-logits[:,-1,no_id]
            score[ix[lo:lo+32]]=diff.float().cpu().numpy()
        rule=exact if gated else np.zeros(len(frame),bool);accepted=rule|(called&(score>=threshold))
        rank=rank_returned(frame,rule,np.where(accepted&~rule,score,np.nan),float('-inf'))
        torch.cuda.synchronize();secs=time.perf_counter()-start
        out=frame[['pair_id','evaluation_split','query_id','candidate_id']].copy();out['exact_match']=exact.astype(int);out['unit_mismatch']=mismatch.astype(int);out['model_called']=called.astype(int);out['score']=score;out['threshold']=threshold;out['accepted']=accepted.astype(int);out['returned_rank']=rank
        return out,dict(seconds=secs,pairs=len(frame),model_pairs=int(called.sum()),prompt_tokens=tokens)
    conditions=[(False,0),(False,1),(True,0),(True,1)]
    for gated,keep in conditions:execute(f.head(120).reset_index(drop=True),gated,keep)
    for repeat in range(3):
        order=np.random.default_rng(20261005+repeat).permutation(len(conditions))
        for index in order:
            gated,keep=conditions[index];policy=('unit_gate' if gated else 'full')+'_logits_keep'+str(keep)
            out,ti=execute(f,gated,keep);times.append(dict(policy=policy,gated=int(gated),logits_to_keep=keep,repeat=repeat,**ti))
            if policy in reference:
                assert np.array_equal(reference[policy]['accepted'],out.accepted.to_numpy());assert np.array_equal(reference[policy]['returned_rank'],out.returned_rank.to_numpy())
            else:
                p=a.output/(policy+'.csv');out.to_csv(p,index=False);reference[policy]={'accepted':out.accepted.to_numpy().copy(),'returned_rank':out.returned_rank.to_numpy().copy()}
                manifest['completed_outputs'].append(dict(policy=policy,rows=len(out),file=p.name,sha256=sha(p)))
            pd.DataFrame(times).to_csv(a.output/'timing.csv',index=False);dump(a.output/'execution_manifest.json',manifest)
            print('FINISH_AB',policy,repeat,round(ti['seconds'],3),ti['model_pairs'],flush=True)
    assert len(times)==12;manifest['status']='complete';manifest['timing_sha256']=sha(a.output/'timing.csv');dump(a.output/'execution_manifest.json',manifest);print('ALL_COMPLETE',flush=True)
if __name__=='__main__':main()
