"""Freeze policy family; use only validation labels; freeze all-candidate predictions.

No test metric is computed here. Existing model logits are replayed, not new GPU runs.
"""
from pathlib import Path
import csv, json, hashlib, datetime
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'output/router_research_20261005'
OUT=BASE/'validation_search'
RUNS=ROOT/'output/remote_experiments_20260923/runs'
SEEDS=[20260904,20260905,20260906]

def read(p):
    with p.open(newline='') as f: return list(csv.DictReader(f))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def writecsv(p,rs):
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)

SOURCES={}
for seed in SEEDS:
    for short,dirname,col in [
        ('bge',f'bge_hard_seed_{seed}','score_bge_v2_m3_hard_hard_refined'),
        ('bge_std',f'bge_standard_seed_{seed}','score_bge_v2_m3_standard'),
        ('bge_desc',f'bge_hard_description_only_seed_{seed}','score_bge_v2_m3_hard_hard_refined'),
        ('bge_nocat',f'bge_hard_no_category_specs_seed_{seed}','score_bge_v2_m3_hard_hard_refined'),
        ('bge_nounit',f'bge_hard_no_unit_seed_{seed}','score_bge_v2_m3_hard_hard_refined'),
        ('q06hard',f'qwen_0.6B_hard_refined_seed_{seed}','score_qwen3_reranker_06b_hard_hard_refined'),
        ('q06std',f'qwen_0.6B_standard_seed_{seed}','score_qwen3_reranker_06b_standard'),
        ('q4',f'qwen_4B_standard_seed_{seed}','score_qwen3_reranker_4b_standard')]:
        SOURCES[f'{short}_{seed}']=(RUNS/dirname/'pair_scores.csv',col)
SOURCES['zero']=(RUNS/'bge_standard_seed_20260904/pair_scores.csv','score_bge_v2_m3_zero_shot')
SOURCES['prompt']=(RUNS/'qwen3_4b_instruct_verifier/pair_scores.csv','score_qwen3_4b_instruct_verifier')
SOURCES['feature']=(RUNS.parent/'baselines/classical/pair_scores.csv','score_feature_full')
SOURCES['tfidf']=(RUNS.parent/'baselines/classical/pair_scores.csv','score_tfidf')
SOURCES['embedding']=(RUNS.parent/'baselines/embedding/pair_scores.csv','score_bge_small_full')

GROUPS={k:[f'{k}_{s}' for s in SEEDS] for k in ['bge','bge_std','bge_desc','bge_nocat','bge_nounit','q06hard','q06std','q4']}
GROUPS.update({k:[k] for k in ['zero','prompt','feature','tfidf','embedding']})
GROUPS['field_all']=[f'{k}_20260904' for k in ['bge','bge_desc','bge_nocat','bge_nounit']]
GROUPS['field_units']=[f'{k}_20260904' for k in ['bge','bge_nocat','bge_desc']]

def build_specs():
    ss=[]
    def add(name,kind,models=None,**kw): ss.append(dict(name=name,kind=kind,models=models or [],**kw))
    add('exact_unit_only','exact')
    for seed in SEEDS: add(f'bge_single_{seed}','aggregate',[f'bge_{seed}'],reducer='mean',exact=False)
    for g in GROUPS:
        add(f'{g}_mean','aggregate',GROUPS[g],reducer='mean',exact=False)
    for red in ['median','max','min','majority']:
        add(f'bge_{red}','aggregate',GROUPS['bge'],reducer=red,exact=False)
    for g in ['bge','bge_nocat','bge_desc','q06hard','q06std','q4','prompt','feature','embedding']:
        add(f'exact_plus_{g}','aggregate',GROUPS[g],reducer='mean',exact=True)
    for g in ['q06hard','q4','prompt','bge_nocat','bge_desc']:
        for operation in ['and','or','average']:
            add(f'exact_bge_{operation}_{g}','combine',GROUPS['bge']+GROUPS[g],
                left=GROUPS['bge'],right=GROUPS[g],operation=operation,exact=True)
    for g in ['q06hard','q4','prompt','bge_nocat']:
        add(f'bge_uncertainty_to_{g}','cascade', [f'bge_20260904']+GROUPS[g],
            first=['bge_20260904'],second=GROUPS[g],cascade_operation='second',exact=True)
    add('q06_uncertainty_to_bge','cascade',['q06hard_20260904','bge_20260904'],
        first=['q06hard_20260904'],second=['bge_20260904'],cascade_operation='second',exact=True)
    add('bge_uncertainty_to_fields','cascade',['bge_20260904']+GROUPS['field_units'],
        first=['bge_20260904'],second=GROUPS['field_units'],cascade_operation='second',exact=True)
    for g in ['q06hard','q4','prompt']:
        add(f'bge_positive_verify_{g}','positive_verify',['bge_20260904']+GROUPS[g],
            first=['bge_20260904'],second=GROUPS[g],exact=True)
        add(f'bge_negative_rescue_{g}','negative_rescue',['bge_20260904']+GROUPS[g],
            first=['bge_20260904'],second=GROUPS[g],exact=True)
    for objective in ['quality','precision_preserve','recall_preserve','hard_preserve']:
        add(f'feature_negative_gate_bge_{objective}','cheap_negative_gate',['feature','bge_20260904'],
            first=['feature'],second=['bge_20260904'],objective=objective,exact=True)
    add('unit_conditioned_bge_fields','input_router',['bge_20260904','bge_nocat_20260904'],exact=True)
    add('derived_conflict_reject_bge','input_conflict',['bge_20260904'],exact=True)
    return ss

SPECS=build_specs()
OUT.mkdir(parents=True,exist_ok=True)
design={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'policies':SPECS,'policy_count':len(SPECS),
    'selection_metric':'0.60 validation overall F1 + 0.40 validation hard F1; tie overall F1, hard recall, fewer model pairs; no test labels or metrics.',
    'secondary_checks':'5 group-query folds; each fold thresholds learned from other queries. Existing model checkpoints themselves previously selected on full validation, so CV checks only new router calibration; it is not fully nested training.',
    'route_inputs':'normalized description exact flag, unit_match, derived action/material/dimension/class/type/spec input conflict flags, existing raw model scores only. No difficulty, final_label/relevance/conflict in routing.',
    'enumerated_gate_bands':[0.0,0.01,0.025,0.05,0.1,0.25,0.5,1.0,2.0,4.0],
    'enumerated_cheap_negative_thresholds':[0.,.00001,.0001,.001,.01,.05,.1,.2,.5],
    'ranking':'exact accepted first, then accepted aggregate calibrated score, stable candidate_id; final cap 3 only after complete candidate-level decisions.',
    'inference_note':'Cached-score replay, not new GPU timing. Model pair counts are a workload proxy; parameter sizes do not define latency.',
    'sources':{k:{'file':str(v[0].relative_to(ROOT)),'column':v[1],'sha256':sha(v[0])} for k,v in SOURCES.items()}}
designp=OUT/'design_before_validation.json'
if designp.exists():
    old=json.loads(designp.read_text())
    assert old['policies']==SPECS, 'Do not mutate a frozen design; use a new output folder.'
else: designp.write_text(json.dumps(design,indent=2,ensure_ascii=False))

# Prediction arrays include every candidate, but labels read for VALIDATION ONLY.
ref=read(next(iter(SOURCES.values()))[0]); ids=[r['pair_id'] for r in ref]
meta=[{k:r[k] for k in ['pair_id','evaluation_split','query_id','candidate_id']} for r in ref]
validation=np.array([r['evaluation_split']=='validation' for r in ref])
y=np.zeros(len(ref),dtype=int); hard=np.zeros(len(ref),dtype=bool)
for i,r in enumerate(ref):
    if validation[i]: y[i]=int(r['final_label']);hard[i]=r['difficulty']=='hard'
raw={}
for key,(p,col) in SOURCES.items():
    rr=read(p);assert [r['pair_id'] for r in rr]==ids
    raw[key]=np.array([float(r[col]) for r in rr]);assert np.isfinite(raw[key]).all()
inputp=ROOT/'output/revise3_full_20260920/supplementary/data/canonical/all_pairs_vfinal_12092.csv'
visible={r['pair_id']:{k:r[k] for k in ['exact_description','unit_match','action_conflict','material_conflict','dimension_conflict','class_conflict','type_conflict','spec_conflict']} for r in read(inputp)}
exact=np.array([int(visible[x]['exact_description'])==1 and int(visible[x]['unit_match'])==1 for x in ids])
unit=np.array([int(visible[x]['unit_match'])==1 for x in ids])
conflict=np.array([any(int(visible[x][k]) for k in ['action_conflict','material_conflict','dimension_conflict','class_conflict','type_conflict','spec_conflict']) for x in ids])

def mtr(pred,sel):
    a=y[sel];p=pred[sel];tp=int(np.sum((a==1)&p));fp=int(np.sum((a==0)&p));fn=int(np.sum((a==1)&~p));tn=int(np.sum((a==0)&~p))
    return dict(tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else 0.,recall=tp/(tp+fn) if tp+fn else 0.,f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.)
def utility(pred,sel):
    a=mtr(pred,sel);b=mtr(pred,sel&hard)
    return .6*a['f1']+.4*b['f1']
def threshold(score,fit,rule=None):
    # Strongest threshold compatible with best fit objective; exact override is applied during fitting.
    levels=np.unique(score[fit]);candidates=np.r_[np.nextafter(levels[-1],np.inf),levels]
    best=None
    for t in candidates:
        p=score>=t
        if rule is not None:p=p|rule
        a=mtr(p,fit);b=mtr(p,fit&hard)
        key=(utility(p,fit),a['f1'],b['recall'],t)
        if best is None or key>best[0]:best=(key,float(t))
    return best[1]
def calibrate(fit):
    out={};th={};sc={}
    for k,s in raw.items():
        t=threshold(s,fit);iqr=float(np.quantile(s[fit],.75)-np.quantile(s[fit],.25));scale=max(iqr,1e-3)
        th[k]=t;sc[k]=scale;out[k]=(s-t)/scale
    return out,th,sc
def group(ms,norm,reducer='mean'):
    a=np.stack([norm[k] for k in ms])
    if reducer=='mean':return a.mean(axis=0)
    if reducer=='median':return np.median(a,axis=0)
    if reducer=='max':return a.max(axis=0)
    if reducer=='min':return a.min(axis=0)
    if reducer=='majority':return (a>=0).sum(axis=0)/len(ms)-.5
    raise ValueError(reducer)

def run(sp,fit,norm):
    typ=sp['kind'];override=exact if sp.get('exact',False) else np.zeros(len(ids),bool)
    calls={k:np.zeros(len(ids),bool) for k in set(sp['models'])}
    params={}
    eligible=~override
    if typ=='exact':return exact.copy(),exact.astype(float),calls,params
    if typ=='aggregate':
        s=group(sp['models'],norm,sp['reducer'])
        t=0. if sp['reducer']=='majority' else threshold(s,fit,override)
        params['aggregate_threshold']=t
        for k in calls:calls[k]=eligible.copy()
        p=(s>=t)|override
    elif typ=='combine':
        l=group(sp['left'],norm);r=group(sp['right'],norm)
        if sp['operation']=='and':s=np.minimum(l,r)
        elif sp['operation']=='or':s=np.maximum(l,r)
        else:s=(l+r)/2
        t=threshold(s,fit,override);params['aggregate_threshold']=t;p=(s>=t)|override
        for k in calls:calls[k]=eligible.copy()
    elif typ in ['cascade','positive_verify','negative_rescue','cheap_negative_gate']:
        first=sp['first'];second=sp['second'];f=group(first,norm);s=group(second,norm)
        for k in first:calls[k]=eligible.copy()
        if typ=='cascade':
            opts=[]
            for band in design['enumerated_gate_bands']:
                gate=(np.abs(f)<=band)&eligible
                score=np.where(gate,s,f);p0=(score>=0)|override
                a=mtr(p0,fit);b=mtr(p0,fit&hard)
                opts.append(((utility(p0,fit),a['f1'],b['recall'],-int(gate[fit].sum())),band,gate,score,p0))
            _,band,gate,score,p= max(opts,key=lambda z:z[0]);params['uncertainty_band']=band;s=score
        elif typ=='positive_verify':
            gate=(f>=0)&eligible;s=np.where(gate,np.minimum(f,s),f);p=(s>=0)|override
        elif typ=='negative_rescue':
            gate=(f<0)&eligible;s=np.where(gate,np.maximum(f,s),f);p=(s>=0)|override
        else:
            # First is a frozen train-fitted feature probability; select only validation safe negative cutoff.
            probs=raw[first[0]];baseline=(s>=0)|override;baseoverall=mtr(baseline,fit);basehard=mtr(baseline,fit&hard)
            opts=[]
            for cut in design['enumerated_cheap_negative_thresholds']:
                gate=(probs>=cut)&eligible;p0=(gate&(s>=0))|override
                a=mtr(p0,fit);b=mtr(p0,fit&hard)
                ok={'quality':True,'precision_preserve':a['precision']>=baseoverall['precision'],
                    'recall_preserve':a['recall']>=baseoverall['recall'],'hard_preserve':b['f1']>=basehard['f1']}[sp['objective']]
                if ok:opts.append(((utility(p0,fit),a['f1'],b['recall'],-int(gate[fit].sum())),cut,gate,p0))
            _,cut,gate,p=max(opts,key=lambda z:z[0]);params['feature_negative_cutoff']=cut
        for k in second:calls[k]|=gate
        if typ!='cascade':params['second_threshold']='validation raw model normalized threshold zero'
    elif typ=='input_router':
        s=np.where(unit,norm['bge_nocat_20260904'],norm['bge_20260904'])
        t=threshold(s,fit,override);params['aggregate_threshold']=t;p=(s>=t)|override
        calls['bge_nocat_20260904']=unit&eligible;calls['bge_20260904']=(~unit)&eligible
    elif typ=='input_conflict':
        s=norm['bge_20260904'];t=threshold(s,fit,override);params['aggregate_threshold']=t
        p=((s>=t)&~conflict)|override;calls['bge_20260904']=eligible&~conflict
    else:raise ValueError(typ)
    assert p.dtype==bool
    return p,s,calls,params

fit=validation.copy();norm,cal_th,cal_scale=calibrate(fit)
results={};summ=[];params={}
for sp in SPECS:
    pred,s,calls,pa=run(sp,fit,norm);results[sp['name']]=(pred,s,calls)
    params[sp['name']]=pa
    a=mtr(pred,fit);b=mtr(pred,fit&hard)
    summ.append(dict(policy=sp['name'],kind=sp['kind'],validation_objective=utility(pred,fit),
        **{f'overall_{k}':v for k,v in a.items()},**{f'hard_{k}':v for k,v in b.items()},
        model_candidate_calls=sum(int(x[fit].sum()) for x in calls.values()),
        bge_candidate_calls=sum(int(v[fit].sum()) for k,v in calls.items() if k.startswith('bge') or k=='zero'),
        qwen_candidate_calls=sum(int(v[fit].sum()) for k,v in calls.items() if k.startswith('q') or k=='prompt')))
writecsv(OUT/'validation_metrics.csv',summ)

# New router calibration robustness: query-disjoint folds, no test labels.
qids=np.array([r['query_id'] for r in meta]);uq=sorted(set(qids[validation]));rng=np.random.default_rng(20261005);rng.shuffle(uq)
foldmap={q:i%5 for i,q in enumerate(uq)};oof={sp['name']:np.zeros(len(ids),bool) for sp in SPECS};foldrows=[]
for f in range(5):
    held=validation&np.array([foldmap.get(q,-1)==f for q in qids]);learn=validation&~held
    nn,_,_=calibrate(learn)
    for sp in SPECS:
        pp,ss,cc,pa=run(sp,learn,nn);oof[sp['name']][held]=pp[held]
        a=mtr(pp,held);b=mtr(pp,held&hard)
        foldrows.append(dict(policy=sp['name'],fold=f,queries=int(len(set(qids[held]))),rows=int(held.sum()),
            **{f'overall_{k}':v for k,v in a.items()},**{f'hard_{k}':v for k,v in b.items()},
            parameters=json.dumps(pa,sort_keys=True)))
writecsv(OUT/'query_group_cv_fold_metrics.csv',foldrows)
cv=[]
for sp in SPECS:
    pp=oof[sp['name']];a=mtr(pp,validation);b=mtr(pp,validation&hard)
    cv.append(dict(policy=sp['name'],cv_objective=utility(pp,validation),**{f'overall_{k}':v for k,v in a.items()},**{f'hard_{k}':v for k,v in b.items()}))
writecsv(OUT/'query_group_cv_aggregate.csv',cv)

cvdict={r['policy']:r for r in cv}
selection=sorted(summ,key=lambda a:(cvdict[a['policy']]['cv_objective'],a['validation_objective'],a['overall_f1'],a['hard_recall'],-a['model_candidate_calls']),reverse=True)
# Pareto workload fronts are separate; no claim all-metric global optimum.
pareto=[]
for a in summ:
    dominated=any((b['overall_f1']>=a['overall_f1'] and b['hard_f1']>=a['hard_f1'] and b['model_candidate_calls']<=a['model_candidate_calls']) and (b['overall_f1']>a['overall_f1'] or b['hard_f1']>a['hard_f1'] or b['model_candidate_calls']<a['model_candidate_calls']) for b in summ)
    if not dominated:pareto.append(a['policy'])
frozen={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'design_sha256':sha(designp),
    'base_raw_thresholds':cal_th,'base_iqr_scales':cal_scale,'policy_parameters':params,
    'query_folds':foldmap,'selection_order':selection,'validation_workload_pareto':pareto,
    'validation_selected_quality_policy':selection[0]['policy'],
    'strict_test_selection':False,'test_metrics_seen_by_search':False,
    'frozen_predictions_include_validation_and_test':True}
(OUT/'parameters_and_selection_frozen_before_test.json').write_text(json.dumps(frozen,indent=2,ensure_ascii=False))

# Write labels-free predictions for ALL policies before any test evaluation by another worker.
predpath=OUT/'all_policy_predictions_before_test.csv'
with predpath.open('w',newline='') as f:
    fields=['policy','pair_id','evaluation_split','query_id','candidate_id','accepted','ranking_score','exact_rule_accept','model_candidate_calls','bge_calls','qwen_calls','models_called']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for sp in SPECS:
        p,s,cc=results[sp['name']]
        for i,r in enumerate(meta):
            called=[k for k,v in cc.items() if v[i]]
            w.writerow(dict(policy=sp['name'],**r,accepted=int(p[i]),ranking_score=float(s[i]),
                exact_rule_accept=int(exact[i]),model_candidate_calls=len(called),
                bge_calls=sum(k.startswith('bge') or k=='zero' for k in called),
                qwen_calls=sum(k.startswith('q') or k=='prompt' for k in called),models_called=';'.join(called)))
(OUT/'prediction_freeze_manifest.json').write_text(json.dumps({'sha256':sha(predpath),'rows':len(SPECS)*len(ids),
    'policy_count':len(SPECS),'source_rows':len(ids),'test_labels_read_for_selection':False,
    'parameters_sha256':sha(OUT/'parameters_and_selection_frozen_before_test.json')},indent=2))
print(json.dumps({'policies':len(SPECS),'prediction_rows':len(SPECS)*len(ids),'quality_selected':selection[0]['policy'],
    'selection':selection[:8],'pareto':pareto},ensure_ascii=False,indent=2))
