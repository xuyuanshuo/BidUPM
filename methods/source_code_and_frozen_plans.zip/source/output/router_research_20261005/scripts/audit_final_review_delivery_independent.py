#!/usr/bin/env python3
"""Read-only audit of root delivery; write only separate reviewer evidence."""
from pathlib import Path
import hashlib
import json
import math
import re

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'final_review_delivery'
checks = []


def require(condition, description):
    if not bool(condition):
        raise AssertionError(description)
    checks.append(description)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def close(a, b):
    return bool(pd.isna(a) and pd.isna(b)) if pd.isna(a) or pd.isna(b) else math.isclose(float(a), float(b), rel_tol=1e-11, abs_tol=1e-11)


manifest = json.loads((OUT / 'delivery_source_integrity.json').read_text())
for path, digest in manifest['source_sha256'].items():
    require(sha(ROOT / path) == digest, 'Delivery source unchanged: ' + path)
rule_table = pd.read_csv(OUT / '规则与BGE同口径比较.csv')
source_pair = pd.read_csv(ROOT / 'generic_unit_gate/all_source_actual_cpu_eval/pair_metrics_each_seed.csv')
names = {'all_bge': '全量专项BGE', 'exact_pair_bge': '精确接受，其余BGE',
         'dimension_gate_bge': '精确接受+物理维度冲突排除，其余BGE',
         'dimension_size_gate_bge': '精确接受+维度及限定尺寸冲突排除，其余BGE'}
display = {'locked100': 'NCDOT锁定测试3000对', 'external80': 'WSDOT测试2400对',
           'both_years_pooled': 'Alberta两年份67635对', 'all600_construction_reference': '新增600对',
           'locked100_hard_pairs': 'NCDOT锁定困难子集2411对', 'primary218': '主测试6540对（内部+外部+无参考）'}
for (dataset, group, policy), rows in source_pair.groupby(['dataset', 'group', 'policy'], sort=False):
    if group not in display:
        continue
    selected = rule_table.loc[rule_table.数据集.eq(display[group]) & rule_table.方法.eq(names[policy])]
    require(len(selected) == 1 and len(rows) == 3, 'Unique three-checkpoint pair result: ' + str((dataset, group, policy)))
    actual = selected.iloc[0]
    for field, target, scale in [('input_pairs', '配对数', 1), ('known_pairs', '确定标签配对数', 1),
                                  ('positive_n', '正例数', 1), ('tp', 'TP均值', 1), ('fp', 'FP均值', 1),
                                  ('fn', 'FN均值', 1), ('precision', '精确率百分比', 100),
                                  ('recall', '召回率百分比', 100), ('f1', 'F1百分比', 100)]:
        require(close(rows[field].mean() * scale, actual[target]), 'Independent checkpoint mean: ' + target + '/' + str((dataset, group, policy)))
    require(close(rows.f1.std(ddof=1) * 100, actual['F1样本标准差百分点']), 'Independent sample SD F1: ' + str((dataset, group, policy)))
    require(actual['重复训练数'] == 3, 'Correct pair checkpoint count: ' + str((dataset, group, policy)))
fixed = rule_table.loc[rule_table['重复训练数'].eq(0)]
for row in fixed.to_dict('records'):
    tp, fp, fn = row['TP均值'], row['FP均值'], row['FN均值']
    require(close(100 * tp / (tp + fp) if tp + fp else np.nan, row['精确率百分比'])
            and close(100 * tp / (tp + fn), row['召回率百分比'])
            and close(200 * tp / (2 * tp + fp + fn), row['F1百分比']),
            'Fixed rule confusion arithmetic: ' + row['数据集'] + '/' + row['方法'])
    require(pd.isna(row['F1样本标准差百分点']), 'Fixed rule no fake replication SD: ' + row['数据集'] + '/' + row['方法'])

timing_table = pd.read_csv(OUT / '服务器实测处理时间与租价折算.csv')
raw_time = pd.read_csv(ROOT / 'generic_unit_gate/all_source_actual/timing.csv')
mean_header = '各checkpoint完整输入中位秒数均值' if '各checkpoint完整输入中位秒数均值' in timing_table else '完整输入秒数均值'
sd_header = '三个checkpoint中位秒数样本标准差' if '三个checkpoint中位秒数样本标准差' in timing_table else '秒数样本标准差'
reduction_header = '同checkpoint减少耗时比例的均值百分比' if '同checkpoint减少耗时比例的均值百分比' in timing_table else '相对全量减少耗时百分比'
for (dataset, policy), rows in raw_time.groupby(['dataset', 'policy'], sort=False):
    selected = timing_table.loc[timing_table.计时输入.eq(dataset) & timing_table.方法.eq(names[policy])]
    require(len(selected) == 1, 'Unique actual timing method: ' + str((dataset, policy)))
    row = selected.iloc[0]
    medians = rows.groupby('seed').seconds.median()
    baselines = raw_time.loc[raw_time.dataset.eq(dataset) & raw_time.policy.eq('all_bge')].groupby('seed').seconds.median()
    reductions = 1 - medians / baselines
    require(len(medians) == 3 and close(medians.mean(), row[mean_header]) and close(medians.std(ddof=1), row[sd_header]),
            'Independent same-seed median then checkpoint mean/SD: ' + str((dataset, policy)))
    require(close(100 * reductions.mean(), row[reduction_header]), 'Mean same-seed timing reductions: ' + str((dataset, policy)))
    require(row['配对数'] == rows.rows.iloc[0] and row['模型实际打分配对数'] == rows.bge_pairs.iloc[0],
            'Actual rows/calls scope: ' + str((dataset, policy)))
    require(row['单seed完整输入重复次数'] == (3 if dataset == 'main220' else 1), 'Correct timing repetitions: ' + str((dataset, policy)))
    if row['查询池数']:
        require(close(medians.mean() / row['查询池数'] * 1000 * 2.88 / 3600, row['每千查询池按2点88元小时折算']),
                'Rental arithmetic: ' + str((dataset, policy)))
    else:
        require(pd.isna(row['每千查询池按2点88元小时折算']), 'No query denominator invented for600')

mask_summary = pd.read_csv(OUT / '核验与解释/独立精确规则实现与实际分流一致性.csv')
require(len(mask_summary) == 30 and mask_summary.pairs.sum() == 693315, '693315 actual mask records across30 condition blocks')
work = ROOT.parent
input_paths = {'main220': work / 'rule_first_system_20261004/results/server/inputs.csv',
               'challenge600': work / 'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_challenge600.csv',
               'alberta_scope_core': work / 'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_alberta_scope_core.csv'}
original_rows = 0
for dataset, path in input_paths.items():
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    if dataset == 'main220':
        frame = frame.loc[frame.evaluation_split.ne('validation')]
    original_rows += len(frame)
    def desc(value):
        return ' '.join(re.sub('[^a-z0-9]+', ' ', value.lower().replace('&', ' and ')).split())
    def unit(value):
        return ' '.join(value.strip().lower().split())
    expected = dict(zip(frame.pair_id, [(bool(a) and bool(u) and a == b and u == v)
                    for a, b, u, v in zip(frame.query_normalized_description.map(desc), frame.candidate_normalized_description.map(desc),
                                          frame.query_normalized_unit.map(unit), frame.candidate_normalized_unit.map(unit))]))
    for seed in [20260904, 20260905, 20260906]:
        actual = pd.read_csv(ROOT / 'generic_unit_gate/all_source_actual' / f'predictions_{dataset}_seed_{seed}.csv', dtype={'pair_id': str})
        for policy, block in actual.groupby('policy', sort=False):
            wanted = np.asarray([False if policy == 'all_bge' else expected[key] for key in block.pair_id], dtype=int)
            require(len(block) == len(frame) and np.array_equal(wanted, block.exact_match.to_numpy(int)),
                    'Independent rule mask all actual rows: ' + str((dataset, seed, policy)))
require(original_rows == 74835, 'Original input rows74835 reused across condition checks')

lost = pd.read_csv(OUT / '核验与解释/all_lost_true_positive_rows.csv')
veto = pd.read_csv(OUT / '核验与解释/all_known_positive_gate_veto_rows.csv')
require(len(lost) == 42 and lost.cause.eq('actual_full_pool_ranking_displacement').all(), '42 logged rank-displacement events')
require(lost.prediction.eq(1).all() and lost.baseline_prediction.eq(1).all()
        and lost.returned_rank.eq(0).all() and lost.baseline_returned_rank.gt(0).all()
        and lost.any_gate_rejected.eq(0).all() and lost.bge_called.eq(1).all(), 'Lost events remainaccepted/called and onlyranklost')
require(len(veto) == 0, 'No known positive gate veto rows')
lost_unique_seed_pair = len(lost[['seed', 'pair_id']].drop_duplicates())
lost_unique_pair = lost.pair_id.nunique()
report = {'numeric_audit_pass': True, 'check_count': len(checks), 'checks': checks,
          'root_deliverables_modified': False, 'labels_changed': False, 'GPU_used': False,
          'source_file_count': len(manifest['source_sha256']), 'rule_table_rows': len(rule_table), 'timing_table_rows': len(timing_table),
          'actual_mask_record_checks': 693315, 'mask_condition_blocks': 30, 'original_input_rows_reused': original_rows,
          'lost_rank_events': 42, 'lost_unique_seed_pair': lost_unique_seed_pair, 'lost_unique_pair_id': lost_unique_pair,
          'known_positive_gate_veto_rows': 0,
          'qualification_requests_sent_to_root': ['Explicit per-seed timing median then three-checkpoint mean/sample SD.',
             '693315 flags are repeated condition records, not693315 independent inputs.',
             'Qwen0.6B93.01/94.50 include strict unit-string gate; do not name pure Qwen baseline.',
             'Qwen4+dimension91.17 is cached-score CPU quality diagnostic, not new routed GPU timing.'],
          'reviewed_file_sha256': {str(p.relative_to(ROOT)): sha(p) for p in [OUT / '先读这个_实验结论与规则高分原因.txt',
                                   OUT / '规则与BGE同口径比较.csv', OUT / '服务器实测处理时间与租价折算.csv',
                                   ROOT / 'scripts/build_final_review_delivery.py']}}
(ROOT / 'final_review_delivery_independent_numeric_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ['numeric_audit_pass', 'check_count', 'actual_mask_record_checks',
                 'lost_rank_events', 'lost_unique_seed_pair', 'lost_unique_pair_id']}, ensure_ascii=False))
