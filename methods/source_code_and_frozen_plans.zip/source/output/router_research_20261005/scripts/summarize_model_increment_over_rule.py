"""Describe completed-model corrections/losses against a frozen exact rule."""
from pathlib import Path
import hashlib, importlib.util, json
import numpy as np
import pandas as pd

WORK = Path(__file__).resolve().parents[1]
BASE = WORK.parents[1] / 'output'
SOURCE = BASE / 'rule_first_system_20261004/results/server'
POLICY = BASE / 'rule_first_system_validation_20261005/scripts/system_policy.py'
SEEDS = (20260904, 20260905, 20260906)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    paths = [SOURCE / 'inputs.csv', SOURCE / 'labels.csv', POLICY]
    frozen = {str(p): sha(p) for p in paths}
    spec = importlib.util.spec_from_file_location('input_rules', POLICY)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    f = pd.read_csv(paths[0], dtype=str, keep_default_na=False)
    f = f.loc[f.evaluation_split.ne('validation')].reset_index(drop=True)
    f['rule'] = mod.exact_mask(f)
    labels = pd.read_csv(paths[1], dtype=str, keep_default_na=False, usecols=['pair_id', 'final_label', 'difficulty'])
    f = f.merge(labels, on='pair_id', validate='one_to_one'); f['y'] = f.final_label.astype(int)
    rows = []
    for seed in SEEDS:
        p = WORK / 'gpu_unit_gate/unit_gate_gpu' / f'predictions_seed_{seed}.csv'
        frozen[str(p)] = sha(p)
        pred = pd.read_csv(p, dtype=str, keep_default_na=False)
        pred = pred.loc[pred.policy.eq('all_bge'), ['pair_id', 'prediction']]
        assert len(pred) == 6600 and pred.pair_id.nunique() == 6600
        joined = f.merge(pred, on='pair_id', validate='one_to_one')
        joined['model'] = joined.prediction.astype(int).eq(1)
        scopes = {'primary218': joined.evaluation_split.isin(['locked', 'external', 'no_reference']),
                  'locked100': joined.evaluation_split.eq('locked'),
                  'WSDOT80': joined.evaluation_split.eq('external'),
                  'locked_hard': joined.evaluation_split.eq('locked') & joined.difficulty.eq('hard')}
        for name, mask in scopes.items():
            b = joined.loc[mask]; y = b.y.eq(1); r = b.rule; m = b.model
            rows.append({'scope': name, 'seed': seed, 'positive_n': int(y.sum()),
                         'rule_tp': int((y & r).sum()), 'rule_fp': int((~y & r).sum()),
                         'model_tp': int((y & m).sum()), 'model_fp': int((~y & m).sum()),
                         'model_found_rule_missed_positive_n': int((y & ~r & m).sum()),
                         'model_lost_rule_found_positive_n': int((y & r & ~m).sum()),
                         'model_new_false_positive_n': int((~y & ~r & m).sum()),
                         'model_removed_rule_false_positive_n': int((~y & r & ~m).sum())})
    result = pd.DataFrame(rows)
    result.to_csv(WORK / 'rule_verification/model_increment_over_rule_per_seed.csv', index=False)
    agg = result.groupby('scope', sort=False).agg({c: ['mean', 'std'] for c in result if c not in {'scope', 'seed'}})
    agg.columns = ['_'.join(c) for c in agg.columns]
    agg.to_csv(WORK / 'rule_verification/model_increment_over_rule_mean_sample_sd.csv')
    assert frozen == {p: sha(Path(p)) for p in frozen}
    (WORK / 'rule_verification/model_increment_integrity.json').write_text(json.dumps({
        'passed': True, 'inference': 'completed actual original BGE checkpoints, all_bge policy',
        'source_sha256': frozen, 'new_training_or_threshold_selection': False,
        'no_test_selected_checkpoint': True
    }, indent=2) + '\n')
    print(result.to_string(index=False))

if __name__ == '__main__': main()
