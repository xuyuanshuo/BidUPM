"""Paired query-cluster CIs from completed original 3-seed actual BGE inference."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
WORK=ROOT/'router_research_20261005'
INPUT=ROOT/'rule_first_system_20261004/results/server/inputs.csv'
CANON=ROOT/'revise3_full_20260920/supplementary/data/canonical/all_pairs_vfinal_12092.csv'
SEEDS=[20260904,20260905,20260906]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def f1(c):
    tp,fp,fn=c[...,0],c[...,1],c[...,2]
    return np.divide(200*tp,2*tp+fp+fn,out=np.full_like(tp,np.nan),where=2*tp+fp+fn>0)
def main():
    out=WORK/'rule_verification';paths=[INPUT,CANON]
    x=pd.read_csv(INPUT,dtype=str,keep_default_na=False);x=x[x.evaluation_split.ne('validation')].reset_index(drop=True)
    labels=pd.read_csv(CANON,dtype=str,keep_default_na=False,usecols=['pair_id','final_label','difficulty'])
    x=x.merge(labels,on='pair_id',validate='one_to_one');x['y']=x.final_label.astype(int)
    def canon(s):return s.str.lower().str.replace('&',' and ',regex=False).str.replace('[^a-z0-9]+',' ',regex=True).str.strip().str.replace(' +',' ',regex=True)
    x['rule']=(canon(x.query_normalized_description).ne('')&canon(x.query_normalized_description).eq(canon(x.candidate_normalized_description))&x.query_normalized_unit.str.lower().str.strip().ne('')&x.query_normalized_unit.str.lower().str.strip().eq(x.candidate_normalized_unit.str.lower().str.strip())).astype(int)
    preds={}
    for seed in SEEDS:
        path=WORK/'gpu_unit_gate/unit_gate_gpu'/f'predictions_seed_{seed}.csv';paths.append(path)
        p=pd.read_csv(path,dtype=str,keep_default_na=False);p=p[p.policy.eq('all_bge')]
        assert p.pair_id.nunique()==6600 and set(p.pair_id)==set(x.pair_id)
        preds[seed]=p.set_index('pair_id').prediction.astype(int)
    before={str(p):sha(p) for p in paths};rows=[];rng=np.random.default_rng(20261005)
    scopes={'primary218':x.evaluation_split.ne('no_reference_reclassified'),'locked100':x.evaluation_split.eq('locked'),'WSDOT80':x.evaluation_split.eq('external'),'locked_hard':x.evaluation_split.eq('locked')&x.difficulty.eq('hard')}
    for name,mask in scopes.items():
        g=x[mask].copy();queries=sorted(g.query_id.unique());qmap={q:i for i,q in enumerate(queries)}
        counters={k:np.zeros((3,len(queries),3),float) for k in ['rule','bge']}
        for si,seed in enumerate(SEEDS):
            for r in g.to_dict('records'):
                qi=qmap[r['query_id']];y=r['y']
                for method,p in [('rule',r['rule']),('bge',int(preds[seed].loc[r['pair_id']]))]:
                    if y and p:counters[method][si,qi,0]+=1
                    elif not y and p:counters[method][si,qi,1]+=1
                    elif y and not p:counters[method][si,qi,2]+=1
        w=rng.multinomial(len(queries),np.full(len(queries),1/len(queries)),size=10000)
        sampled={k:np.nanmean(f1(np.einsum('bq,sqc->sbc',w,v)),axis=0) for k,v in counters.items()}
        points={k:float(np.nanmean(f1(v.sum(axis=1)))) for k,v in counters.items()}
        delta=sampled['bge']-sampled['rule']
        rows.append(dict(scope=name,queries=len(queries),reference_positive_n=int(g.y.sum()),rule_f1_pct=points['rule'],bge_mean_f1_pct=points['bge'],bge_minus_rule_f1_pp=points['bge']-points['rule'],paired_query_cluster_ci95_low_pp=float(np.nanpercentile(delta,2.5)),paired_query_cluster_ci95_high_pp=float(np.nanpercentile(delta,97.5)),replicates=10000,finite_replicates=int(np.isfinite(delta).sum()),bootstrap_seed=20261005))
    pd.DataFrame(rows).to_csv(out/'paired_query_cluster_rule_vs_bge_f1_ci.csv',index=False)
    assert before=={str(p):sha(p) for p in paths}
    (out/'rule_bge_bootstrap_integrity.json').write_text(json.dumps({'source_files_unchanged':True,'source_sha256':before,'inference_source':'completed real original 3seed GPU predictions; no new GPU inference','uncertainty_scope':'query cluster sampling conditional on supplied references; three checkpoints are correlated repeats, not independent datasets','training_rows_excluded':True},indent=2)+'\n')
    print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__':main()
