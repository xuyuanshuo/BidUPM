"""Train/validation-only deterministic abbreviation baseline; no LLM or test read."""
from pathlib import Path
from collections import defaultdict
from difflib import SequenceMatcher
import hashlib,json,re,time
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'router_research_20261005/training_abbreviation_rules'
DATA=ROOT/'revise3_full_20260920/supplementary/data'
STOP={'of','and','for','in','to','or','on','by','with','no','not','is','at','as'}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical(text):return ' '.join(re.sub(r'[^a-z0-9]+',' ',str(text).lower().replace('&',' and ')).split())
def abbreviation(short,long):
    if not 2<=len(short)<=6 or short in STOP or not short.isalpha():return False
    words=long.split()
    if not 1<=len(words)<=2 or not all(w.isalpha() for w in words):return False
    expanded=''.join(words)
    if len(expanded)<len(short)+2:return False
    if len(words)>1:return short==''.join(w[0] for w in words)
    it=iter(expanded)
    return (expanded.startswith(short) or all(ch in it for ch in short)) and len(short)/len(expanded)>=.25
def discover(train):
    support=defaultdict(set)
    for r in train.to_dict('records'):
        if int(r['final_label'])!=1 or not r['query_normalized_unit'] or r['query_normalized_unit']!=r['candidate_normalized_unit']:continue
        q=canonical(r['query_normalized_description']).split();c=canonical(r['candidate_normalized_description']).split()
        for op,i,j,k,l in SequenceMatcher(None,q,c,autojunk=False).get_opcodes():
            if op!='replace':continue
            left,right=q[i:j],c[k:l]
            candidates=[]
            if len(left)==1:candidates.append((left[0],' '.join(right)))
            if len(right)==1:candidates.append((right[0],' '.join(left)))
            for short,long in candidates:
                if abbreviation(short,long):support[(short,long)].add(r['pair_id'])
    targets=defaultdict(set)
    for short,long in support:targets[short].add(long)
    return support,targets
def predict(frame,mapping):
    def rewrite(value):return ' '.join(mapping.get(token,token) for token in canonical(value).split())
    q=frame.query_normalized_description.map(rewrite);c=frame.candidate_normalized_description.map(rewrite)
    qu=frame.query_normalized_unit.str.strip().str.lower();cu=frame.candidate_normalized_unit.str.strip().str.lower()
    return (q.ne('')&qu.ne('')&q.eq(c)&qu.eq(cu)).to_numpy(bool)
def metrics(y,p):
    y=np.asarray(y,int);p=np.asarray(p,bool);tp=int(((y==1)&p).sum());fp=int(((y==0)&p).sum());fn=int(((y==1)&~p).sum());tn=int(((y==0)&~p).sum())
    return dict(tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else None,recall=tp/(tp+fn),f1=2*tp/(2*tp+fp+fn))
def main():
    assert not OUT.exists(),'Do not overwrite a frozen training run'
    OUT.mkdir()
    plan={'algorithm':'positive-training exact token-difference abbreviation expansion; ambiguous short tokens excluded; no insert/delete rewrites; numbers preserved','minimum_support_options':[1,2,3],'selection':'highest validation F1 among zero-false-positive settings; tied choose highest minimum support','test_or_supplement_files_read':[], 'LLM_used':False,'script_sha256':sha(__file__)}
    (OUT/'design_before_training.json').write_text(json.dumps(plan,indent=2)+'\n')
    cols=['pair_id','final_label','query_normalized_description','candidate_normalized_description','query_normalized_unit','candidate_normalized_unit']
    paths={'train':DATA/'training/training_pairs_semantic_deduplicated.csv','validation':DATA/'evaluation/validation_pairs.csv'}
    frames={k:pd.read_csv(v,usecols=cols,dtype=str,keep_default_na=False) for k,v in paths.items()}
    assert len(frames['train'])==2278 and len(frames['validation'])==900
    start=time.perf_counter();support,targets=discover(frames['train']);seconds=time.perf_counter()-start
    aliases=[];conditions=[];outputs=[];maps={}
    for short,long in sorted(support):aliases.append(dict(short=short,expanded=long,training_support=len(support[(short,long)]),ambiguous=len(targets[short])>1,training_pair_ids='|'.join(sorted(support[(short,long)]))))
    for min_support in plan['minimum_support_options']:
        mapping={short:long for (short,long),pids in support.items() if len(pids)>=min_support and len(targets[short])==1}
        maps[min_support]=mapping
        for name,frame in frames.items():
            p=predict(frame,mapping);conditions.append(dict(minimum_support=min_support,dataset=name,aliases=len(mapping),**metrics(frame.final_label,p)))
            if name=='validation':outputs.append(pd.DataFrame(dict(pair_id=frame.pair_id,minimum_support=min_support,prediction=p.astype(int))))
    validation=[r for r in conditions if r['dataset']=='validation' and r['fp']==0]
    assert validation,'No eligible conservative validation policy'
    chosen=max(validation,key=lambda r:(r['f1'],r['minimum_support']))
    frozen={**plan,'train_sha256':sha(paths['train']),'validation_sha256':sha(paths['validation']),'training_discovery_seconds':seconds,'selected':chosen,'mapping':maps[chosen['minimum_support']]}
    (OUT/'parameters_frozen_before_unseen.json').write_text(json.dumps(frozen,indent=2)+'\n')
    pd.DataFrame(aliases).to_csv(OUT/'training_alias_support.csv',index=False)
    pd.DataFrame(conditions).to_csv(OUT/'train_validation_metrics.csv',index=False)
    pd.concat(outputs).to_csv(OUT/'validation_predictions.csv',index=False)
    print(json.dumps({'selected':chosen,'mapping':frozen['mapping'],'training_seconds':seconds},indent=2))
if __name__=='__main__':main()
