"""Describe exact-rule success at row and distinct input-relationship levels.

No training, threshold selection, score changes, or source-file writes.
Distinct relationships are a sensitivity analysis, not a replacement benchmark.
"""
from pathlib import Path
import hashlib, importlib.util, json
import pandas as pd

OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parents[1]
INPUT = ROOT / 'output/rule_first_system_20261004/results/server/inputs.csv'
LABELS = ROOT / 'output/rule_first_system_20261004/results/server/labels.csv'
POLICY = ROOT / 'output/rule_first_system_validation_20261005/scripts/system_policy.py'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    paths = [INPUT, LABELS, POLICY]
    hashes = {str(path): sha(path) for path in paths}
    spec = importlib.util.spec_from_file_location('frozen_input_policy', POLICY)
    policy = importlib.util.module_from_spec(spec); spec.loader.exec_module(policy)
    inputs = pd.read_csv(INPUT, dtype=str, keep_default_na=False)
    inputs = inputs.loc[inputs.evaluation_split.ne('validation')].reset_index(drop=True)
    labels = pd.read_csv(LABELS, dtype=str, keep_default_na=False,
                         usecols=['pair_id', 'final_label', 'difficulty'])
    frame = inputs.merge(labels, on='pair_id', validate='one_to_one')
    frame['y'] = frame.final_label.astype(int)
    frame['prediction'] = policy.exact_mask(frame).astype(int)
    frame['relationship'] = list(zip(policy.serialize(frame, 'query'), policy.serialize(frame, 'candidate')))
    rows, conflicts = [], []
    scopes = {'primary218': frame.evaluation_split.isin(['locked', 'external', 'no_reference']),
              'locked100': frame.evaluation_split.eq('locked'),
              'WSDOT80': frame.evaluation_split.eq('external'),
              'locked_hard': frame.evaluation_split.eq('locked') & frame.difficulty.eq('hard')}
    for name, mask in scopes.items():
        current = frame.loc[mask].copy()
        grouped = current.groupby('relationship', sort=False)
        disagreement = grouped.y.nunique().gt(1)
        for key in disagreement.loc[disagreement].index:
            block = current.loc[current.relationship.map(lambda value: value == key)]
            conflicts.append({'scope': name, 'pair_ids': '|'.join(block.pair_id),
                              'labels': '|'.join(block.final_label)})
        for level, block in [('candidate_records', current),
                             ('unique_serialized_ordered_relationships', current.drop_duplicates('relationship'))]:
            if level.startswith('unique') and disagreement.any():
                rows.append({'scope': name, 'unit': level, 'status': 'undefined_conflicting_relationship_labels'})
                continue
            y, p = block.y, block.prediction
            tp, fp, fn = int(((y == 1) & (p == 1)).sum()), int(((y == 0) & (p == 1)).sum()), int(((y == 1) & (p == 0)).sum())
            rows.append({'scope': name, 'unit': level, 'status': 'measured', 'n': len(block),
                         'positive_n': int(y.sum()), 'accepted_n': int(p.sum()),
                         'tp': tp, 'fp': fp, 'fn': fn,
                         'precision_pct': 100 * tp / (tp + fp) if tp + fp else None,
                         'recall_pct': 100 * tp / (tp + fn) if tp + fn else None,
                         'f1_pct': 200 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0})
    target = OUT / 'rule_verification'
    pd.DataFrame(rows).to_csv(target / 'rule_record_vs_unique_relationship_sensitivity.csv', index=False)
    pd.DataFrame(conflicts, columns=['scope', 'pair_ids', 'labels']).to_csv(target / 'relationship_label_conflicts.csv', index=False)
    assert hashes == {str(path): sha(path) for path in paths}
    (target / 'relationship_weighting_integrity.json').write_text(json.dumps({
        'source_files_unchanged': True, 'source_sha256': hashes,
        'new_training_or_threshold_tuning': False, 'label_conflicting_groups': len(conflicts),
        'scope': 'descriptive sensitivity only; original benchmark remains candidate-record based',
        'limitations': 'Input relationships omit project specifications and price. Counts are not independent samples or a deployment guarantee.'
    }, indent=2) + '\n')
    print(pd.DataFrame(rows).to_string(index=False))

if __name__ == '__main__': main()
