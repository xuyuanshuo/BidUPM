"""Independent exact-string implementation; validate actual GPU router rule masks."""
from pathlib import Path
import hashlib,json,re
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'rule_verification'
WORK=ROOT.parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
paths={
 'main220':WORK/'rule_first_system_20261004/results/server/inputs.csv',
 'challenge600':WORK/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_challenge600.csv',
 'alberta_scope_core':WORK/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_alberta_scope_core.csv',
}
protected={str(p):sha(p) for p in paths.values()}
# This implementation imports neither the experiment's rule helper nor its labels.
def desc(x):
 return ' '.join(re.sub('[^a-z0-9]+',' ',str(x).lower().replace('&',' and ')).split())
def unit(x): return ' '.join(str(x).strip().lower().split())
checks=[];pre={}
for dataset,path in paths.items():
 f=pd.read_csv(path,dtype=str,keep_default_na=False)
 if dataset=='main220':f=f[~f.evaluation_split.eq('validation')].reset_index(drop=True)
 q=list(map(desc,f.query_normalized_description));c=list(map(desc,f.candidate_normalized_description))
 u=list(map(unit,f.query_normalized_unit));v=list(map(unit,f.candidate_normalized_unit))
 pred=np.array([bool(a and b and a==z and b==w) for a,z,b,w in zip(q,c,u,v)],bool)
 pre[dataset]=dict(frame=f,prediction=pred)
 for seed in [20260904,20260905,20260906]:
  p=ROOT/'generic_unit_gate/all_source_actual'/f'predictions_{dataset}_seed_{seed}.csv'
  protected[str(p)]=sha(p);actual=pd.read_csv(p,dtype={'pair_id':str})
  assert not f.pair_id.duplicated().any()
  predicted=dict(zip(f.pair_id,pred))
  for policy,g in actual.groupby('policy',sort=False):
   got=g.exact_match.to_numpy(int)
   potential=np.array([predicted[k] for k in g.pair_id],int)
   # The all-model control deliberately bypasses every rule, so its flag is 0.
   wanted=np.zeros(len(g),int) if policy=='all_bge' else potential
   assert set(g.pair_id)==set(f.pair_id) and len(g)==len(f)
   n=int(np.count_nonzero(got!=wanted));assert n==0
   checks.append(dict(dataset=dataset,seed=seed,policy=policy,pairs=len(f),
                      exact_mask_disagreements=n,accepted_by_exact_rule=int(wanted.sum()),
                      potential_exact_matches=int(potential.sum())))
# Only after the full independent decision/mask audit, read reference columns.
metric=[];examples=[]
def measure(ds,scope,f,p,y,known):
 tp=int(np.sum(p&known&(y==1)));fp=int(np.sum(p&known&(y==0)))
 fn=int(np.sum(~p&known&(y==1)));tn=int(np.sum(~p&known&(y==0)))
 metric.append(dict(dataset=ds,scope=scope,known_pairs=int(known.sum()),positive_n=tp+fn,
                    tp=tp,fp=fp,fn=fn,tn=tn,accepted_unknown=int(np.sum(p&~known)),
                    precision_pct=100*tp/(tp+fp) if tp+fp else None,
                    recall_pct=100*tp/(tp+fn) if tp+fn else None,
                    f1_pct=200*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None))
 for i in np.flatnonzero(known & (p|(y==1))):
  rr=f.iloc[i]
  examples.append(dict(dataset=ds,scope=scope,pair_id=rr.pair_id,
   query_id=rr.get('query_id',''),candidate_id=rr.get('candidate_id',''),
   query_description=rr.query_description,candidate_description=rr.candidate_description,
   query_normalized_description=rr.query_normalized_description,
   candidate_normalized_description=rr.candidate_normalized_description,
   query_normalized_unit=rr.query_normalized_unit,candidate_normalized_unit=rr.candidate_normalized_unit,
   reference_label=int(y[i]),rule_accept=int(p[i]),
   outcome='TP' if p[i] and y[i] else ('FP' if p[i] else 'FN')))
for ds,pack in pre.items():
 f,p=pack['frame'],pack['prediction']
 if ds=='main220':
  lp=WORK/'rule_first_system_20261004/results/server/labels.csv';protected[str(lp)]=sha(lp)
  labels=pd.read_csv(lp).set_index('pair_id');y=labels.loc[f.pair_id].final_label.to_numpy(int)
  for scope,splits in [('primary218',['locked','external','no_reference']),('locked100',['locked']),('WSDOT80',['external'])]:
   m=f.evaluation_split.isin(splits).to_numpy();measure(ds,scope,f[m].reset_index(drop=True),p[m],y[m],np.ones(int(m.sum()),bool))
 elif ds=='challenge600':
  lp=WORK/'internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv';protected[str(lp)]=sha(lp)
  labels=pd.read_csv(lp).set_index('pair_id');y=labels.loc[f.pair_id].provisional_label.to_numpy(int)
  measure(ds,'all600',f,p,y,np.ones(len(f),bool))
 else:
  lp=OUT/'alberta_reference_index.csv';protected[str(lp)]=sha(lp)
  labels=pd.read_csv(lp).set_index('pair_id');aligned=labels.loc[f.pair_id]
  measure(ds,'both_years_pooled',f,p,aligned.reference_label.to_numpy(int),~aligned.reference_uncertain.to_numpy(bool))
assert all(sha(Path(p))==s for p,s in protected.items())
pd.DataFrame(checks).to_csv(OUT/'独立精确规则实现与实际分流一致性.csv',index=False)
pd.DataFrame(metric).to_csv(OUT/'独立精确规则重新计数.csv',index=False)
pd.DataFrame(examples).to_csv(OUT/'精确规则所有接受与漏检实例.csv',index=False,encoding='utf-8-sig')
(OUT/'independent_exact_recheck_integrity.json').write_text(json.dumps(dict(
 passed=True,independent_implementation_no_shared_helper=True,LLM_used=False,
 labels_read_only_after_prediction_audit=True,actual_conditions_checked=len(checks),
 actual_row_mask_checks=sum(r['pairs'] for r in checks),
 source_sha256=protected,all_sources_unchanged=True),ensure_ascii=False,indent=2)+'\n')
print(pd.DataFrame(metric).to_string(index=False))
print('actual_mask_checks',sum(r['pairs'] for r in checks),'all_agree')
