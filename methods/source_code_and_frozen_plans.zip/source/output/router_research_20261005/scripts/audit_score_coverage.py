from pathlib import Path
import csv, json, hashlib, math
from collections import Counter

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'output/router_research_20261005'
RUNS = ROOT / 'output/remote_experiments_20260923/runs'
DATA = ROOT / 'output/revise3_full_20260920/supplementary/data'
OUT = BASE / 'data_audit'
OUT.mkdir(parents=True, exist_ok=True)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
    with p.open(newline='') as f: return list(csv.DictReader(f))

files = sorted(RUNS.glob('*/pair_scores.csv')) + sorted((RUNS.parent/'baselines').glob('*/pair_scores.csv'))
coverage = []
available = []
reference_ids = None
for p in files:
    rr = rows(p)
    ids = [r['pair_id'] for r in rr]
    if reference_ids is None: reference_ids = ids
    splits = Counter(r['evaluation_split'] for r in rr)
    vals = [r for r in rr if r['evaluation_split']=='validation']
    raw = [c for c in rr[0] if c.startswith('score_') and not c.endswith('_conflict_refined')]
    refined = [c for c in rr[0] if c.startswith('score_') and c.endswith('_conflict_refined')]
    thresholds = p.with_name('validation_thresholds.csv')
    tr = rows(thresholds) if thresholds.exists() else []
    manifest = p.with_name('manifest.json')
    mm = json.loads(manifest.read_text()) if manifest.exists() else {}
    row = {'file':str(p.relative_to(ROOT)), 'sha256':sha(p), 'rows':len(rr),
        'unique_pair_ids':len(set(ids)), 'same_id_order_as_reference':ids==reference_ids,
        'split_counts':dict(splits), 'validation_queries':len({r['query_id'] for r in vals}),
        'training_score_rows':sum(v for k,v in splits.items() if 'train' in k),
        'raw_score_columns':raw, 'postprocessed_score_columns':refined,
        'all_scores_finite':all(math.isfinite(float(r[c])) for r in rr for c in raw+refined),
        'threshold_file':str(thresholds.relative_to(ROOT)) if thresholds.exists() else None,
        'threshold_sha256':sha(thresholds) if thresholds.exists() else None,
        'thresholds':tr, 'manifest_file':str(manifest.relative_to(ROOT)) if manifest.exists() else None,
        'manifest_sha256':sha(manifest) if manifest.exists() else None,
        'gpu_name':mm.get('gpu_name'), 'input_variant':mm.get('input_variant'),
        'training_seconds':sum(x.get('training_seconds',0) for x in mm.get('training_summaries',[])),
        'timing':mm.get('timing')}
    coverage.append(row)
    for c in raw:
        available.append({'file':str(p.relative_to(ROOT)),'column':c,'rows':len(rr),
            'validation_rows':len(vals),'training_rows':row['training_score_rows'], 'sha256':sha(p)})

train = rows(DATA/'training/training_pairs_semantic_deduplicated.csv')
val = rows(DATA/'evaluation/validation_pairs.csv')
test_files=['locked_pairs.csv','no_reference_top30_pairs.csv','external_mixed_pairs.csv','no_reference_reclassified_positive_pairs.csv']
test=[]
for f in test_files: test += rows(DATA/'evaluation'/f)
keys = ['query_id','unordered_pair_key']
isolation={k:{'train_val_overlap':len({r[k] for r in train}&{r[k] for r in val}),
               'val_test_overlap':len({r[k] for r in val}&{r[k] for r in test}),
               'train_test_overlap':len({r[k] for r in train}&{r[k] for r in test})} for k in keys}
validation = {'rows':len(val), 'queries':len({r['query_id'] for r in val}),
    'positives':sum(int(r['final_label']) for r in val),
    'exact_unit_rule_positives':sum(int(r['exact_description']) and int(r['unit_match']) for r in val),
    'positive_relevance':dict(Counter(r['final_relevance'] for r in val if r['final_label']=='1')),
    'hard_rows':sum(r['difficulty']=='hard' for r in val),
    'hard_positive_rows':sum(r['difficulty']=='hard' and r['final_label']=='1' for r in val),
    'train_rows':len(train), 'train_queries':len({r['query_id'] for r in train}),
    'train_eligible_all':all(r['training_eligibility']=='1' for r in train)}
result={'coverage':coverage,'validation':validation,'isolation':isolation,
    'note':'This audit reads split metadata, not test performance; future parameter selection uses validation labels only. Raw model scores preferred; *_conflict_refined is explicit separate postprocessing. No training model score coverage exists.'}
(OUT/'score_coverage.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
with (OUT/'available_scores.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=available[0]);w.writeheader();w.writerows(available)
lines=['模型分数覆盖核查','',f'{len(coverage)} 份既有分数文件，全部提供验证集与测试集候选级分数。',
    json.dumps(validation,ensure_ascii=False,indent=2),'','隔离检查：',json.dumps(isolation,ensure_ascii=False,indent=2),
    '', '分数不覆盖训练集，因此禁止用测试分数或测试标签训练 stacking。轻量第一阶段可以仅使用 2,278 条训练数据中可见的输入属性训练。',
    '验证集有 900 对、30 个查询。新参数选择只能使用这 900 个验证标签；同查询成组交叉验证，不能把一对两种方向随机分进不同折。',
    '完整候选判定不因已有三条精确结果提前停止。最终三条列表是另外的展示截断步骤。',
    '本地分数重放只能说明质量和模型候选调用数量，不能宣称重新实测 GPU 延迟。']
(OUT/'coverage_report_中文.txt').write_text('\n'.join(lines))
print(json.dumps({'files':len(coverage),'available_raw_columns':len(available),'validation':validation,'isolation':isolation},ensure_ascii=False,indent=2))
