#!/usr/bin/env python3
"""CPU-only reconstruction of the existing full-pool GPT blind workflow.

Validates raw anonymous input/output, mapping, and prior provenance before
opening current reference labels. Does not perform inference, selection,
retuning, reranking, or modification of any pre-existing artifacts.
"""
import hashlib
import json
from pathlib import Path
from collections import Counter

import numpy as np
import pandas as pd


WORK = Path(__file__).resolve().parents[3]
OLD = WORK / 'output/rule_first_system_validation_20261005'
RESEARCH = WORK / 'output/router_research_20261005'
SOURCE = WORK / 'output/rule_first_system_20261004/results/server'
BLIND = OLD / 'blind_gpt6_sol'
PRIOR = OLD / 'results/gpt6_sol_blind'
CANONICAL = RESEARCH / 'exact_serialization_cache/canonical_actual_cpu_evaluation'
OUT = RESEARCH / 'final_review_delivery/gpt6_matched_comparison'
FIELDS = ('description', 'normalized_description', 'normalized_unit', 'category', 'spec_tokens')
SEEDS = {20260904, 20260905, 20260906}
CHECKS = []
HASHES = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    path=Path(path)
    HASHES[str(path.relative_to(WORK))] = sha(path)
    return HASHES[str(path.relative_to(WORK))]


def check(condition, name):
    if not bool(condition):
        raise AssertionError(name)
    CHECKS.append(name)


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def jsonl(path):
    record(path)
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def readjson(path):
    record(path)
    return json.loads(Path(path).read_text())


def rates(tp, fp, fn, tn):
    return {'precision': tp/(tp+fp) if tp+fp else None,
            'recall': tp/(tp+fn) if tp+fn else None,
            'f1': 2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,
            'accuracy': (tp+tn)/(tp+fp+fn+tn) if tp+fp+fn+tn else None}


def pair_metrics(frame):
    counts = Counter((int(y), int(p)) for y, p in frame[['label', 'prediction']].itertuples(index=False, name=None))
    tp, fp, fn, tn = (counts[x] for x in ((1, 1), (0, 1), (1, 0), (0, 0)))
    vector = frame.label.to_numpy(int)*2 + frame.prediction.to_numpy(int)
    check(np.array_equal(np.bincount(vector, minlength=4), [tn, fp, fn, tp]), 'confusion scalar/vector agrees')
    return {'input_pairs':len(frame), 'positive_n':tp+fn, 'tp':tp, 'fp':fp, 'fn':fn, 'tn':tn,
            **rates(tp, fp, fn, tn)}


def top3_metrics(frame, hard_subset=False):
    """Keep the actual full-pool ranks; never refill a filtered hard-pair subset."""
    tp=fp=positive_n=0
    recalls=[]; hits=[]; query_n=0; no_ref=0; rejected=0
    for _, part in frame.groupby(['evaluation_split','query_id'], sort=False):
        query_n+=1
        positives=int(part.label.sum())
        returned=part.loc[part.returned_rank.gt(0)]
        part_tp=int(returned.label.sum())
        tp+=part_tp; fp+=len(returned)-part_tp; positive_n+=positives
        if positives:
            recalls.append(part_tp/positives); hits.append(int(part_tp>0))
        else:
            no_ref+=1; rejected+=int(len(returned)==0)
    direct_tp=int((frame.returned_rank.gt(0)&frame.label.eq(1)).sum())
    direct_fp=int((frame.returned_rank.gt(0)&frame.label.eq(0)).sum())
    check((tp, fp)==(direct_tp, direct_fp), 'Top3 scalar/vector counts agree')
    return {'query_n':query_n, 'positive_query_n':len(recalls), 'positive_n':positive_n,
            'returned_total_n':tp+fp, 'returned_tp':tp, 'returned_fp':fp,
            'returned_precision_known':tp/(tp+fp) if tp+fp else None,
            'micro_recall_at3':tp/positive_n if positive_n else None,
            'macro_recall_at3':sum(recalls)/len(recalls) if recalls else None,
            'hit_at3':sum(hits)/len(hits) if hits else None,
            'completely_known_no_reference_query_n':None if hard_subset else no_ref,
            'no_reference_rejected_n':None if hard_subset else rejected,
            'no_reference_rejection_rate':None if hard_subset or not no_ref else rejected/no_ref,
            'scope_note':'Stored full-pool Top3 ranks retained; no slot refill; filtered-subset no-reference unavailable' if hard_subset else 'Actual supplied Top3, no reranking'}


def views(frame):
    yield 'all220_diagnostic', frame
    yield 'primary218', frame.loc[frame.evaluation_split.isin(['locked','external','no_reference'])]
    locked=frame.loc[frame.evaluation_split.eq('locked')]
    yield 'locked100', locked
    yield 'locked100_hard_pairs', locked.loc[locked.difficulty.eq('hard')]
    hardq=set(locked.loc[locked.difficulty.eq('hard')&locked.label.eq(1),'query_id'])
    yield 'locked100_hard_positive_full_queries', locked.loc[locked.query_id.isin(hardq)]
    yield 'external80', frame.loc[frame.evaluation_split.eq('external')]


def matched_tables(gpt_pair, gpt_top):
    pair_path=CANONICAL/'pair_metrics_repeat0_seed_mean_sample_sd.csv'
    top_path=CANONICAL/'actual_top3_repeat0_seed_mean_sample_sd.csv'
    record(pair_path); record(top_path)
    pair=pd.read_csv(pair_path); top=pd.read_csv(top_path)
    final=readjson(CANONICAL/'summary.json')
    check(final['status']=='completed_cpu_canonical_audit_and_quality', 'Canonical evaluation complete')
    pair_rows=[]; top_rows=[]
    for g in gpt_pair.group:
        p=gpt_pair.loc[gpt_pair.group.eq(g)].iloc[0]
        t=gpt_top.loc[gpt_top.group.eq(g)].iloc[0]
        one={'dataset':'main220','group':g,'method':'GPT-6 Sol full-pool Codex agent blind workflow',
             'run_n':1,'repeat_basis':'One workflow; no repeat SD','label_source':'current_original_main_labels',
             'measured_time_s':None,'measured_api_cost':None}
        pair_rows.append({**one, **{k+'_mean':p[k] for k in ('input_pairs','positive_n','tp','fp','fn','tn','precision','recall','f1','accuracy')},
                          **{k+'_sample_sd':None for k in ('precision','recall','f1','accuracy')}})
        top_rows.append({**one,**{k+'_mean':t[k] for k in ('query_n','positive_query_n','returned_total_n','returned_tp','returned_fp','returned_precision_known','micro_recall_at3','macro_recall_at3','hit_at3','completely_known_no_reference_query_n','no_reference_rejected_n','no_reference_rejection_rate')},
                         **{k+'_sample_sd':None for k in ('returned_precision_known','micro_recall_at3','macro_recall_at3','hit_at3','no_reference_rejection_rate')}})
        for condition,name in [('full_nocache','Full fine-tuned BGE, canonical fixed computation'),
                                ('exact_dimension_exact_cache','Final exact+dimension+BGE+exact serialization cache')]:
            pp=pair.loc[pair.dataset.eq('main220')&pair.condition.eq(condition)&pair.group.eq(g)]
            tt=top.loc[top.dataset.eq('main220')&top.condition.eq(condition)&top.group.eq(g)]
            check(len(pp)==len(tt)==1, f'Canonical scope/condition unique: {g}/{condition}')
            check(int(pp.iloc[0].seed_n)==int(tt.iloc[0].seed_n)==3, 'Canonical three checkpoint mean')
            common={'dataset':'main220','group':g,'method':name,'run_n':3,
                    'repeat_basis':'Three original independently trained checkpoint seeds; mean/sample SD',
                    'label_source':'current_original_main_labels','measured_time_s':None,'measured_api_cost':None}
            prow={**common}; trow={**common}
            for k in ('input_pairs','positive_n','tp','fp','fn','tn','precision','recall','f1','accuracy'):
                for suffix in ('mean','sample_sd'): prow[k+'_'+suffix]=pp.iloc[0][k+'_'+suffix]
            for k in ('query_n','positive_query_n','returned_total_n','returned_tp','returned_fp','returned_precision_known','micro_recall_at3','macro_recall_at3','hit_at3','completely_known_no_reference_query_n','no_reference_rejected_n','no_reference_rejection_rate'):
                for suffix in ('mean','sample_sd'): trow[k+'_'+suffix]=tt.iloc[0][k+'_'+suffix]
            check(prow['input_pairs_mean']==p['input_pairs'] and prow['positive_n_mean']==p['positive_n'], 'Same pair/positive denominator')
            pair_rows.append(prow); top_rows.append(trow)
    pd.DataFrame(pair_rows).to_csv(OUT/'matched_pair_quality_comparison.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(top_rows).to_csv(OUT/'matched_actual_top3_comparison.csv', index=False, encoding='utf-8-sig')


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    check(not (OUT/'independent_qa.json').exists(), 'Do not overwrite completed audit')
    record(__file__)
    plan=readjson(PRIOR/'plan.json'); manifest=readjson(BLIND/'output_manifest.json')
    oldqa=readjson(PRIOR/'evaluation/qa.json')
    inputs=jsonl(BLIND/'inputs/query_pools.jsonl'); predictions=jsonl(BLIND/'outputs/predictions.jsonl')
    check(plan['model_requested']==manifest['requested_model']=='gpt-6-sol', 'Requested model gpt-6-sol')
    check(plan['reasoning_effort']==manifest['reasoning_effort']=='medium', 'Requested medium reasoning')
    check(plan['gold_available_to_judge'] is False and manifest['gold_access'] is False, 'Provenance declares no gold access')
    check(plan['api_cost_and_latency_available'] is False, 'No measured API fees/latency')
    check(manifest['all_pools_judged'] is True and manifest['pools_judged']==220, 'Manifest all 220 pools complete')
    check(sha(BLIND/'inputs/query_pools.jsonl')==plan['input_sha256']==manifest['input_sha256']==oldqa['blind_integrity']['input_sha256'], 'Input frozen SHA agrees')
    check(sha(BLIND/'outputs/predictions.jsonl')==oldqa['blind_integrity']['prediction_sha256'], 'Raw prediction SHA agrees with prior evaluator')
    check(sha(PRIOR/'plan.json')==oldqa['blind_integrity']['plan_sha256'], 'Plan hash preserved')
    check(sha(BLIND/'output_manifest.json')==oldqa['blind_integrity']['output_manifest_sha256'], 'Output manifest hash preserved')
    check('prediction_sha256' not in manifest, 'Manifest did not predeclare raw prediction hash, qualification retained')
    check(len(inputs)==len(predictions)==220, '220 inputs and outputs')
    ikeys=[p['query_key'] for p in inputs]; okeys=[p['query_key'] for p in predictions]
    check(len(set(ikeys))==len(set(okeys))==220 and set(ikeys)==set(okeys)=={f'Q{i:03d}' for i in range(220)}, 'Complete unique anonymous query keys')
    pool_index={p['query_key']:p for p in inputs}
    flat=[]; reconstructed=[]; accepted_sizes=[]; batches={}
    for pool in inputs:
        check(set(pool)=={'query_key','query','candidates'}, 'Blind pool field allowlist')
        check(set(pool['query'])==set(FIELDS), 'Blind query allowlist excludes answers')
        check(all(isinstance(pool['query'][f],str) for f in FIELDS), 'Blind query fields are text')
        check(len(pool['candidates'])==30 and {c['candidate_key'] for c in pool['candidates']}=={f'C{i:02d}' for i in range(30)}, 'Unique complete C00..C29')
        for c in pool['candidates']:
            check(set(c)=={'candidate_key',*FIELDS} and all(isinstance(c[f],str) for f in FIELDS), 'Blind candidate allowlist/text')
            flat.append({'query_key':pool['query_key'],'candidate_key':c['candidate_key'],**{'query_'+f:pool['query'][f] for f in FIELDS},**{'candidate_'+f:c[f] for f in FIELDS}})
    for p in predictions:
        check(set(p)=={'query_key','accepted_candidates','top3','adjudication_complete'}, 'Complete prediction contract: accepted and Top3 separate')
        check(p['adjudication_complete'] is True, 'All candidate adjudication complete')
        accepted=p['accepted_candidates']; top=p['top3']
        valid={c['candidate_key'] for c in pool_index[p['query_key']]['candidates']}
        check(isinstance(accepted,list) and len(set(accepted))==len(accepted) and set(accepted)<=valid, 'Unique accepted candidates within complete pool')
        check(isinstance(top,list) and len(set(top))==len(top)<=3 and set(top)<=set(accepted), 'Actual Top3 subset of accepted')
        check(top==accepted[:3], 'Recorded Top3 matches recorded first three accepted IDs')
        accepted_sizes.append(len(accepted))
        for cid in sorted(valid):
            reconstructed.append({'query_key':p['query_key'],'candidate_key':cid,'prediction':int(cid in accepted),'returned_rank':top.index(cid)+1 if cid in top else 0})
    for path in sorted((BLIND/'outputs').glob('batch_*.json')):
        part=readjson(path)
        check(not set(part)&set(batches), 'No duplicate query across completed batches')
        batches.update(part)
    check(len(batches)==220 and set(batches)==set(okeys), 'Eleven completed batches cover 220 pools')
    check(all(batches[p['query_key']]==p['accepted_candidates'] for p in predictions), 'Merged predictions exactly preserve per-batch accepted IDs')
    mapping_path=PRIOR/'private_mapping.csv'; record(mapping_path)
    check(sha(mapping_path)==oldqa['blind_integrity']['mapping_sha256'], 'Mapping original hash preserved')
    mapping=pd.read_csv(mapping_path,dtype=str,keep_default_na=False)
    check(list(mapping)==['query_key','candidate_key','pair_id'] and len(mapping)==6600 and mapping.pair_id.is_unique and not mapping[['query_key','candidate_key']].duplicated().any(), 'Mapping 6600 key-to-pair bijection')
    source_path=SOURCE/'inputs.csv'; record(source_path)
    check(sha(source_path)==oldqa['blind_integrity']['frozen_inputs_sha256']=='f6e2bee795c6ddf591960325c7cb1151fad6b1b19b18f8e7388b952d06e62554', 'Current source same frozen input SHA')
    source=pd.read_csv(source_path,dtype=str,keep_default_na=False)
    check(not {'final_label','difficulty','final_relevance','label'}&set(source), 'Current source input is answer-free')
    source=source.loc[source.evaluation_split.ne('validation')]
    check(len(source)==6600 and set(source.pair_id)==set(mapping.pair_id), 'Current nonvalidation scope covers same 6600 IDs')
    decoded=pd.DataFrame(flat).merge(mapping,on=['query_key','candidate_key'],validate='one_to_one').merge(source,on='pair_id',validate='one_to_one',suffixes=('_blind',''))
    for side in ('query','candidate'):
        for f in FIELDS:
            check(decoded[side+'_'+f].eq(decoded[side+'_'+f+'_blind']).all(), 'Identical current five fields: '+side+'_'+f)
    check(decoded.groupby('query_key').apply(lambda g:len(g[['evaluation_split','query_id']].drop_duplicates()),include_groups=False).eq(1).all(), 'Anonymous pools each map to one current query')
    check(decoded.groupby(['evaluation_split','query_id']).query_key.nunique().eq(1).all(), 'Current queries each map to one anonymous pool')
    recovered=pd.DataFrame(reconstructed).merge(mapping,on=['query_key','candidate_key'],validate='one_to_one').merge(source,on='pair_id',validate='one_to_one')
    legacy_path=PRIOR/'evaluation/blind_pair_predictions.csv'; record(legacy_path)
    check(sha(legacy_path)=='4f42d29a643b38792639d7ad11a01ab8d830074521f00ba900c32abd8fa117c4', 'Legacy decoded output original hash preserved')
    legacy=pd.read_csv(legacy_path,usecols=['pair_id','prediction','returned_rank'],dtype={'pair_id':str})
    same=recovered.merge(legacy,on='pair_id',validate='one_to_one',suffixes=('','_prior'))
    check(same.prediction.eq(same.prediction_prior).all() and same.returned_rank.eq(same.returned_rank_prior).all(), 'Independent raw reconstruction identical to all 6600 prior decisions/ranks')
    recovered.to_csv(OUT/'reconstructed_label_free_predictions.csv',index=False)
    prelabel={'status':'passed_before_current_label_read','checks_passed':len(CHECKS),'rows':6600,'queries':220,
              'accepted_count_histogram':dict(sorted(Counter(accepted_sizes).items())),
              'pools_accepting_more_than_three':sum(n>3 for n in accepted_sizes),'accepted_pairs':sum(accepted_sizes),
              'actual_returned_pairs':int(recovered.returned_rank.gt(0).sum()),'input_sha256':sha(source_path),
              'prediction_sha256':sha(BLIND/'outputs/predictions.jsonl'),'prediction_hash_predeclared':False,
              'gold_access_declaration_is_self_reported':True,'current_labels_read':False}
    dump(OUT/'prelabel_integrity.json',prelabel)
    # First read of current reference label values occurs after all raw contract checks.
    label_path=SOURCE/'labels.csv'; record(label_path)
    check(sha(label_path)==oldqa['frozen_labels_sha256']=='9760723a1aceeb63dfa61c474ecc0cb8d8e549a81af277dcc064f2f8bd9f9cc4', 'Current main labels identical to prior evaluation')
    labels=pd.read_csv(label_path,dtype=str,keep_default_na=False)
    check(labels.pair_id.is_unique and set(recovered.pair_id)<=set(labels.pair_id), 'Current labels uniquely cover all 6600 reconstructed predictions')
    labeled=recovered.merge(labels[['pair_id','final_label','difficulty']],on='pair_id',validate='one_to_one')
    check(labeled.final_label.isin(['0','1']).all(), 'Current labels all binary in evaluation scope')
    labeled['label']=labeled.final_label.astype(int)
    pair_rows=[];top_rows=[]
    expected={'all220_diagnostic':(6600,434),'primary218':(6540,431),'locked100':(3000,283),
              'locked100_hard_pairs':(2411,23),'locked100_hard_positive_full_queries':(300,48),'external80':(2400,148)}
    for group, part in views(labeled):
        p=pair_metrics(part); t=top3_metrics(part,group=='locked100_hard_pairs')
        check((p['input_pairs'],p['positive_n'])==expected[group], 'Expected fixed scope denominator '+group)
        pair_rows.append({'dataset':'main220','group':group,'method':'GPT-6 Sol full-pool Codex agent blind workflow','workflow_n':1,**p})
        top_rows.append({'dataset':'main220','group':group,'method':'GPT-6 Sol full-pool Codex agent blind workflow','workflow_n':1,**t})
    gpt_pair=pd.DataFrame(pair_rows);gpt_top=pd.DataFrame(top_rows)
    gpt_pair.to_csv(OUT/'gpt6_current_main_pair_metrics.csv',index=False,encoding='utf-8-sig')
    gpt_top.to_csv(OUT/'gpt6_current_main_actual_top3_metrics.csv',index=False,encoding='utf-8-sig')
    labeled.to_csv(OUT/'gpt6_current_main_labeled_predictions.csv',index=False)
    matched_tables(gpt_pair,gpt_top)
    for name,digest in HASHES.items():check(sha(WORK/name)==digest,'Input/source unchanged '+name)
    qa={'status':'passed','check_count':len(CHECKS),'checks':CHECKS,'source_sha256':HASHES,
        'workflow_n':1,'no_new_inference':True,'no_gpu_or_ssh':True,'no_selection_or_threshold_tuning':True,
        'no_existing_files_modified':True,'raw_accepted_mask_reconstructed_not_top3_substitution':True,
        'same_current_inputs_and_labels_as_canonical':True,'gpt_api_time_cost_available':False,
        'sample_sd_for_single_gpt_workflow':None,
        'provenance_limitations':['Model requested gpt-6-sol via Codex agent workflow, not standalone API.','No repeated GPT workflow, token counts, API fees or latency.','Output manifest gold_access=false is a workflow self-declaration, not a complete internal-access audit.','Prediction SHA recorded by prior evaluator, not predeclared by judge manifest.','Current main tests have already been viewed in research; this is matched retrospective evaluation, not untouched confirmatory testing.','Alberta reference was produced by GPT itself; no independent GPT-versus-Alberta-reference accuracy row.'],
        'main_pair_metrics':pair_rows,'main_actual_top3_metrics':top_rows}
    dump(OUT/'independent_qa.json',qa)
    text=['GPT-6 Sol 旧全池盲测：当前同口径独立重算','',
          '结论：可以加入当前 main 同口径质量比较。原输出包含全部接受候选 accepted_candidates，另有实际 top3；未把前三条以外的接受候选误算为拒绝。',
          f'完整输入：220 个查询，每查询 30 候选，共 6600 对。接受 {sum(accepted_sizes)} 对，实际返回 {int(recovered.returned_rank.gt(0).sum())} 对；{sum(n>3 for n in accepted_sizes)} 个查询接受超过 3 对。',
          '当前 inputs.csv 的全部十个字段槽（查询与候选各五字段）、匿名映射与原盲测逐项相同；当前 labels.csv 的完整文件哈希与旧评价相同。',
          '主要总体是 primary218/6540 对，额外 2 个审计查询只放 all220_diagnostic。困难配对范围是 locked 且 difficulty=hard，共 2411 对/23 正例。','']
    for p,t in zip(pair_rows,top_rows):
        text.append(f"{p['group']}: 配对 TP/FP/FN/TN={p['tp']}/{p['fp']}/{p['fn']}/{p['tn']}，P={p['precision']*100:.6f}%，R={p['recall']*100:.6f}%，F1={p['f1']*100:.6f}%；实际前三条 TP/FP={t['returned_tp']}/{t['returned_fp']}，P={t['returned_precision_known']*100:.6f}%，microR@3={t['micro_recall_at3']*100:.6f}%，macroR@3={t['macro_recall_at3']*100:.6f}%，Hit@3={t['hit_at3']*100:.6f}%。")
    text+=['','困难前三条保持原完整候选池返回排名；不会删掉简单记录后用困难记录补位。困难查询完整池的 48 个正例中包括简单正例，不能等同于 23 个困难正例。',
           'GPT 是一次已完成的 Codex 指定模型 gpt-6-sol/medium 盲判工作流；系统是原 BGE 三个训练 checkpoint 的均值与样本标准差。GPT 的标准差必须留空，不能将一个 workflow 写成三个模型种子或三次重复。',
           '本次只用 CPU 重建已有判断并重算指标，没有新调用模型，没有 API 费用、token 数或 API 延迟实测。比较 CSV 留空时间/费用；服务器常驻 GPU 批处理耗时不能充作 GPT API 耗时。',
           '旧 manifest 声明全部完成且无标签访问，属于工作流自报；原判断哈希由旧评估程序首次记录，不是 judge manifest 预先承诺。当前表述保留这两个限制。',
           '600 独立 GPT 盲判已有 TP300/FP6/FN0/TN294、F1=99.00990099%；它是构造标签参考，不能写成双人人工金标。本次 main 重算没有使用 600 选择方法。',
           'Alberta 当前参考由 GPT-6 Sol 生成，不能把 GPT 自评 100% 加进质量比较；这一项无独立 GPT 对照值，保留空缺。',
           '本比较是同输入、同标签、同指标的回顾性比较，适合同时呈现当前系统与通用模型质量；不构成普遍 SOTA、API 费用或未查看测试集上的保证。']
    (OUT/'GPT同口径重算说明.txt').write_text('\n'.join(text)+'\n')
    products={p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file()}
    dump(OUT/'output_sha256.json',products)
    print(json.dumps({'status':'passed','checks':len(CHECKS),'output':str(OUT),'accepted_pairs':sum(accepted_sizes),'pools_accepting_more_than_three':sum(n>3 for n in accepted_sizes),'pair_metrics':pair_rows,'top3_metrics':top_rows},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
