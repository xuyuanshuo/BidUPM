"""Apply frozen train/validation-selected aliases, save decisions, then join labels."""
from pathlib import Path
import hashlib,json,time
import pandas as pd
from train_abbreviation_rules import ROOT,OUT,DATA,sha,predict,metrics

def main():
    p=OUT/'parameters_frozen_before_unseen.json';v=json.loads(p.read_text())
    assert v['script_sha256']==sha(Path(__file__).parent/'train_abbreviation_rules.py')
    inputs={'main220':ROOT/'rule_first_system_20261004/results/server/inputs.csv',
            'challenge600':ROOT/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_challenge600.csv',
            'Alberta':ROOT/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_alberta_scope_core.csv'}
    frames={k:pd.read_csv(path,dtype=str,keep_default_na=False) for k,path in inputs.items()}
    frames['main220']=frames['main220'][frames['main220'].evaluation_split.ne('validation')].reset_index(drop=True)
    output=OUT/'unseen';assert not output.exists();output.mkdir()
    manifest={'frozen_plan_sha256':sha(p),'input_sha256':{k:sha(path) for k,path in inputs.items()},'script_sha256':sha(__file__),'decision_status':'before_reference_join','LLM_used':False,'threshold_retuned':False,'files':[],'timing':'local CPU resident pandas frame prediction only; excludes CSV import, retrieval and model load'}
    for name,f in frames.items():
        assert not {'final_label','provisional_label','label','difficulty'}&set(f)
        ts=[]
        for repeat in range(7):
            start=time.perf_counter();pred=predict(f,v['mapping']);ts.append(time.perf_counter()-start)
        out=f[[c for c in ['pair_id','evaluation_split','query_id','candidate_id','source_year'] if c in f]].copy();out['prediction']=pred.astype(int)
        path=output/f'{name}_predictions.csv';out.to_csv(path,index=False)
        manifest['files'].append(dict(dataset=name,rows=len(out),output=path.name,sha256=sha(path),prediction_seconds=ts))
    (output/'decisions_frozen_before_reference_join.json').write_text(json.dumps(manifest,indent=2)+'\n')
    canon=pd.read_csv(DATA/'canonical/all_pairs_vfinal_12092.csv',dtype=str,keep_default_na=False,usecols=['pair_id','final_label','difficulty'])
    c6=pd.read_csv(ROOT/'internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv',dtype=str,keep_default_na=False,usecols=['pair_id','provisional_label']).rename(columns={'provisional_label':'final_label'})
    ca=pd.read_csv(ROOT/'router_research_20261005/rule_verification/alberta_reference_index.csv',dtype=str,keep_default_na=False).rename(columns={'reference_label':'final_label'})
    rows=[]
    for item in manifest['files']:
        path=output/item['output'];assert sha(path)==item['sha256'];f=pd.read_csv(path,dtype=str,keep_default_na=False)
        ref={'main220':canon,'challenge600':c6,'Alberta':ca}[item['dataset']]
        fields=['pair_id','final_label']+[c for c in ['difficulty','reference_uncertain'] if c in ref]
        z=f.merge(ref[fields],on='pair_id',validate='one_to_one')
        views=[('all',z)]
        if item['dataset']=='main220':
            views=[('primary218',z[z.evaluation_split.ne('no_reference_reclassified')]),('locked100',z[z.evaluation_split.eq('locked')]),('locked_hard',z[z.evaluation_split.eq('locked')&z.difficulty.eq('hard')]),('WSDOT80',z[z.evaluation_split.eq('external')])]
        elif item['dataset']=='Alberta':views=[('known_pairs',z[z.reference_uncertain.eq('0')])]
        for subset,g in views:rows.append(dict(dataset=item['dataset'],subset=subset,rows=len(g),label_source='existing_reference' if item['dataset']=='main220' else 'construction_intent' if item['dataset']=='challenge600' else 'independent_AI_reference',**metrics(g.final_label,g.prediction.astype(int).eq(1))))
    pd.DataFrame(rows).to_csv(output/'frozen_alias_rule_metrics.csv',index=False)
    print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__':main()
