"""One-shot holdout reporting AFTER all policy families and selection freeze.

Do not rank or select a new winner from these test metrics.
"""
from pathlib import Path
from collections import defaultdict
import csv,json,hashlib,datetime

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'output/router_research_20261005'
OUT=BASE/'holdout_report'
OUT.mkdir(exist_ok=True)
DIRS=[BASE/x for x in ['validation_search','validation_weighted_extension','validation_input_unit_gate']]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))
def write(p,rows):
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)

selection_path=BASE/'validation_joint_selection_v2_before_test.json'
assert selection_path.exists()
freeze=json.loads(selection_path.read_text())
assert not freeze['test_metrics_used']
source=ROOT/'output/remote_experiments_20260923/runs/bge_hard_seed_20260904/pair_scores.csv'
gold={r['pair_id']:r for r in read(source)}
canonical=ROOT/'output/revise3_full_20260920/supplementary/data/canonical/all_pairs_vfinal_12092.csv'
sem={r['pair_id']:r['unordered_pair_key'] for r in read(canonical)}
valkeys={sem[k] for k,v in gold.items() if v['evaluation_split']=='validation'}
groups={
    'primary_218':{k for k,v in gold.items() if v['evaluation_split'] in ['locked','no_reference','external']},
    'locked_100':{k for k,v in gold.items() if v['evaluation_split']=='locked'},
    'external_80':{k for k,v in gold.items() if v['evaluation_split']=='external'},
    'no_reference_38':{k for k,v in gold.items() if v['evaluation_split']=='no_reference'},
    'audit_220':{k for k,v in gold.items() if v['evaluation_split']!='validation'},
}
groups['primary_semantic_disjoint']={k for k in groups['primary_218'] if sem[k] not in valkeys}
metrics=[];lists=[];workload=[];checks=[];man=[]
SPECS={}
for directory in DIRS:
    SPECS.update({p['name']:p for p in json.loads((directory/'design_before_validation.json').read_text())['policies']})

def metric(pairs,accepted):
    tp=sum(gold[k]['final_label']=='1' and k in accepted for k in pairs)
    fp=sum(gold[k]['final_label']=='0' and k in accepted for k in pairs)
    fn=sum(gold[k]['final_label']=='1' and k not in accepted for k in pairs)
    tn=len(pairs)-tp-fp-fn
    return dict(tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else '',
        recall=tp/(tp+fn) if tp+fn else '',f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,accuracy=(tp+tn)/len(pairs))

def evaluate(policy,rr,d):
    assert len(rr)==len(gold)
    seen={r['pair_id'] for r in rr};assert seen==set(gold)
    assert len(seen)==len(rr)
    by={r['pair_id']:r for r in rr};accepted={k for k,r in by.items() if int(r['accepted'])}
    # A bare model has no exact-rule acceptance stage. Only a rule-containing
    # system can prioritize its accepted exact references before model scores.
    rule_priority=SPECS[policy].get('exact',False) or SPECS[policy]['kind']=='exact'
    for name,pairs in groups.items():
        hard={k for k in pairs if gold[k]['difficulty']=='hard'}
        a=metric(pairs,accepted);b=metric(hard,accepted)
        metrics.append(dict(policy=policy,family_dir=d.name,group=name,rows=len(pairs),queries=len({gold[k]['query_id'] for k in pairs}),
            **{f'overall_{k}':v for k,v in a.items()},**{f'hard_{k}':v for k,v in b.items()},hard_rows=len(hard)))
        queries=defaultdict(list)
        for k in pairs:queries[gold[k]['query_id']].append(k)
        returned=set();positivequeries=0;hits=0;macrorecalls=[];norefs=0;emptycorrect=0
        for q,kk in queries.items():
            selected=[k for k in kk if k in accepted]
            selected.sort(key=lambda k:(-int(by[k]['exact_rule_accept']) if rule_priority else 0,-float(by[k]['ranking_score']),gold[k]['candidate_id']))
            top=selected[:3];returned.update(top)
            pos={k for k in kk if gold[k]['final_label']=='1'}
            if pos:
                positivequeries+=1;hits+=bool(pos&set(top));macrorecalls.append(len(pos&set(top))/len(pos))
            else:norefs+=1;emptycorrect+=len(top)==0
        la=metric(pairs,returned);lb=metric(hard,returned)
        lists.append(dict(policy=policy,family_dir=d.name,group=name,rule_priority=rule_priority,top3_returned=len(returned),
            returned_precision=la['precision'],macro_recall3=sum(macrorecalls)/len(macrorecalls) if macrorecalls else '',
            hit3=hits/positivequeries if positivequeries else '',positive_queries=positivequeries,
            no_reference_rejection=emptycorrect/norefs if norefs else '',no_reference_queries=norefs,
            returned_tp=la['tp'],returned_fp=la['fp'],returned_hard_tp=lb['tp'],returned_hard_fp=lb['fp'],returned_hard_recall=lb['recall']))
        calls=defaultdict(int)
        for k in pairs:
            for model in by[k]['models_called'].split(';'):
                if model:calls[model]+=1
        workload.append(dict(policy=policy,family_dir=d.name,group=name,rows=len(pairs),
            model_candidate_calls=sum(int(by[k]['model_candidate_calls']) for k in pairs),
            bge_calls=sum(int(by[k]['bge_calls']) for k in pairs),qwen_calls=sum(int(by[k]['qwen_calls']) for k in pairs),
            model_call_counts=json.dumps(dict(calls),sort_keys=True)))
    checks.append(dict(policy=policy,unique_ids=len(seen),rows=len(rr),matched_all_source_ids=True,called_model_count_consistent=all(len([m for m in r['models_called'].split(';') if m])==int(r['model_candidate_calls']) for r in rr)))

for d in DIRS:
    freeze_d=json.loads((d/'prediction_freeze_manifest.json').read_text())
    pp=d/'all_policy_predictions_before_test.csv';assert sha(pp)==freeze_d['sha256']
    man.append({'family_dir':d.name,'prediction_sha256':sha(pp),'parameters_sha256':sha(d/'parameters_and_selection_frozen_before_test.json'),'design_sha256':sha(d/'design_before_validation.json')})
    with pp.open(newline='') as f:
        rr=[];name=None
        for r in csv.DictReader(f):
            if name is not None and r['policy']!=name:
                evaluate(name,rr,d);rr=[]
            name=r['policy'];rr.append(r)
        if rr:evaluate(name,rr,d)

write(OUT/'complete_pair_metrics_all_policies.csv',metrics)
write(OUT/'top3_metrics_all_policies.csv',lists)
write(OUT/'workload_counts_all_policies.csv',workload)
write(OUT/'prediction_integrity_checks.csv',checks)
write(OUT/'validation_preselected_gpu_policies.csv',[r for r in metrics if r['policy'] in freeze['selected_for_gpu_validation']])
(OUT/'holdout_evaluation_manifest.json').write_text(json.dumps(dict(evaluation_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    selection_freeze_sha256=sha(selection_path),gold_scores_sha256=sha(source),families=man,
    policy_count=len(checks),prediction_rows=sum(r['rows'] for r in checks),test_selected_winner=False,
    selection_unchanged_after_test=True,validation_selected=freeze['validation_selected'],
    semantic_overlap_removed=len(groups['primary_218'])-len(groups['primary_semantic_disjoint'])),indent=2))
selected=freeze['selected_for_gpu_validation']
print(json.dumps({'preselected_primary':[r for r in metrics if r['policy'] in selected and r['group']=='primary_218'],
    'preselected_locked_hard':[r for r in metrics if r['policy'] in selected and r['group']=='locked_100'],
    'preselected_workload':[r for r in workload if r['policy'] in selected and r['group']=='primary_218']},ensure_ascii=False,indent=2))
