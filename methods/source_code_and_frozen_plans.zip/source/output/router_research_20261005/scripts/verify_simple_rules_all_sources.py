from pathlib import Path
import pandas as pd,numpy as np,re,json,hashlib
ROOT=Path(__file__).resolve().parents[2];B=ROOT/'router_research_20261005';O=B/'rule_verification';O.mkdir(exist_ok=True)
C=ROOT/'revise3_full_20260920/supplementary/data/canonical/all_pairs_vfinal_12092.csv'
def canon(x):return ' '.join(str(x).lower().split())
def punct(x):return ' '.join(re.sub(r'[^\w\s]',' ',canon(x).replace('&',' and ')).split())
def rules(f):
 q=f.query_description.astype(str);c=f.candidate_description.astype(str)
 qu=f.query_unit.astype(str);cu=f.candidate_unit.astype(str)
 nq=f.query_normalized_description.astype(str).map(punct);nc=f.candidate_normalized_description.astype(str).map(punct)
 nuq=f.query_normalized_unit.astype(str).map(canon);nuc=f.candidate_normalized_unit.astype(str).map(canon)
 sameunit=nuq.eq(nuc)&nuq.ne('')&nuc.ne('')
 j=np.asarray([len(set(a.split())&set(b.split()))/max(len(set(a.split())|set(b.split())),1) for a,b in zip(nq,nc)])
 return {'literal_description_and_literal_unit':(q.eq(c)&qu.eq(cu)&q.ne('')&qu.ne('')).to_numpy(),
 'case_whitespace_only':(q.map(canon).eq(c.map(canon))&qu.map(canon).eq(cu.map(canon))&q.map(canon).ne('')&qu.map(canon).ne('')).to_numpy(),
 'punctuation_with_literal_units':(q.map(punct).eq(c.map(punct))&qu.map(canon).eq(cu.map(canon))&q.map(punct).ne('')&qu.map(canon).ne('')).to_numpy(),
 'normalized_exact_plus_unit':(nq.eq(nc)&nq.ne('')&sameunit).to_numpy(),
 'normalized_description_only':(nq.eq(nc)&nq.ne('')).to_numpy(),
 'fuzzy_jaccard90_plus_unit':(j>=.9)&sameunit.to_numpy(),
 'fuzzy_jaccard80_plus_unit':(j>=.8)&sameunit.to_numpy()}
def met(y,p):
 tp=int(((y==1)&p).sum());fp=int(((y==0)&p).sum());fn=int(((y==1)&~p).sum());tn=int(((y==0)&~p).sum())
 return dict(tp=tp,fp=fp,fn=fn,tn=tn,precision_pct=100*tp/(tp+fp) if tp+fp else None,recall_pct=100*tp/(tp+fn) if tp+fn else None,f1_pct=200*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None)
f=pd.read_csv(C,dtype=str,keep_default_na=False);y=f.final_label.to_numpy(int);allrules=rules(f)
plan={'rules':list(allrules),'thresholds_frozen_constants':[.8,.9],'fitted_on_test':False,'rule_inputs':['actual description','actual unit','frozen normalized description and unit'],'LLM_used_in_rules':False,'labels_for_measurement_only':True,'canonical_sha256':hashlib.sha256(C.read_bytes()).hexdigest(),'600_label_source':'existing construction_intent, human labels absent','Alberta_label_source':'independent GPT-6 Sol blind AI reference, not human gold','AI_uncertain_pairs':'excluded from quality denominator; counted separately'}
(O/'measurement_protocol.json').write_text(json.dumps(plan,indent=2))
rows=[];errors=[];scores=[]
scopes={'all12092_descriptive':np.ones(len(f),bool),'train4138_fit_diagnostic':f.training_eligibility.eq('1').to_numpy(),'validation900':f.split_final.eq('validation').to_numpy(),'locked100':f.split_final.eq('locked').to_numpy(),'internal_primary138':f.split_final.isin(['locked','no_reference']).to_numpy(),'WSDOT80':f.split_final.eq('external').to_numpy(),'primary218':f.split_final.isin(['locked','no_reference','external']).to_numpy()}
for name,p in allrules.items():
 for scope,m in scopes.items():
  if not m.any():continue
  rows.append(dict(dataset=scope,label_source='canonical_existing_gold',policy=name,pair_n=int(m.sum()),positive_n=int(y[m].sum()),**met(y[m],p[m])))
  hard=m&f.difficulty.eq('hard').to_numpy();rows.append(dict(dataset=scope+'_hard',label_source='canonical_existing_gold',policy=name,pair_n=int(hard.sum()),positive_n=int(y[hard].sum()),**met(y[hard],p[hard])))
 for r,yp,pp in zip(f.to_dict('records'),y,p):
  if r['split_final'] in ['locked','no_reference','external'] and yp!=int(pp):errors.append({k:r[k] for k in ['pair_id','split_final','query_description','query_unit','candidate_description','candidate_unit']}|dict(policy=name,label=int(yp),prediction=int(pp)))
# 600 current reference values, untouched; do not promote them to human labels.
f6=pd.read_csv(ROOT/'internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv',dtype=str,keep_default_na=False);y6=f6.provisional_label.to_numpy(int)
for name,p in rules(f6).items():rows.append(dict(dataset='challenge600_existing_reference',label_source='construction_intent_not_human',policy=name,pair_n=600,positive_n=int(y6.sum()),**met(y6,p)))
# Alberta exhaustive universe, independent AI accepted links, exclude AI-uncertain links.
af=pd.read_csv(ROOT/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_alberta_scope_core.csv',dtype=str,keep_default_na=False)
source=json.loads((B/'alberta_ai_reference/inputs/blind_source_items.json').read_text());qd={r['query_id']:r for r in source['queries']};cd={r['candidate_id']:r for r in source['catalog']}
af['query_unit']=[qd[q]['raw_unit'] for q in af.query_id];af['candidate_unit']=[cd[c]['raw_unit'] for c in af.candidate_id];af['query_description']=[qd[q]['raw_description'] for q in af.query_id];af['candidate_description']=[cd[c]['raw_description'] for c in af.candidate_id]
refs=[json.loads(l) for l in (B/'alberta_ai_reference/outputs/ai_reference.jsonl').read_text().splitlines()]
accepted={(r['query_id'],c) for r in refs for c in r['compatible_candidate_ids']};uncertain={(r['query_id'],c) for r in refs for c in r['uncertain_candidate_ids']}
ay=np.array([(q,c) in accepted for q,c in zip(af.query_id,af.candidate_id)],int);au=np.array([(q,c) in uncertain for q,c in zip(af.query_id,af.candidate_id)])
assert int(ay.sum())==len(accepted)==142
labels=af[['pair_id','query_id','candidate_id','source_year']].copy();labels['reference_label']=ay;labels['reference_uncertain']=au.astype(int);labels['label_source']='GPT6Sol_blind_AI_reference_not_human';labels.to_csv(O/'alberta_reference_index.csv',index=False)
for name,p in rules(af).items():
 for year in ['2024','2026']:
  mask=af.source_year.eq(year).to_numpy()&~au;rows.append(dict(dataset='Alberta'+year+'_AI_reference',label_source='blind_GPT6Sol_AI_reference_not_human',policy=name,pair_n=int(mask.sum()),positive_n=int(ay[mask].sum()),**met(ay[mask],p[mask])))
 for i,(pid,yp,pp,uu) in enumerate(zip(af.pair_id,ay,p,au)):scores.append(dict(pair_id=pid,policy=name,prediction=int(pp),reference_label=int(yp),reference_uncertain=int(uu)))
pd.DataFrame(rows).to_csv(O/'simple_rule_metrics_all_sources.csv',index=False);pd.DataFrame(errors).to_csv(O/'primary_rule_error_examples.csv',index=False);pd.DataFrame(scores).to_csv(O/'alberta_rule_predictions_all_stages.csv',index=False)
# Data composition is reported independently of routing decisions.
comp=[]
for scope,m in scopes.items():
 ex=allrules['normalized_exact_plus_unit'];pos=m&(y==1);comp.append(dict(scope=scope,pairs=int(m.sum()),positives=int(pos.sum()),exact_rule_positive=int((pos&ex).sum()),positive_exact_fraction_pct=100*(pos&ex).sum()/max(pos.sum(),1),rule_false_positive=int((m&(y==0)&ex).sum())))
pd.DataFrame(comp).to_csv(O/'positive_exact_composition.csv',index=False)
report=pd.DataFrame(rows);print(report[report.dataset.isin(['primary218','WSDOT80','challenge600_existing_reference','Alberta2024_AI_reference','Alberta2026_AI_reference'])][['dataset','policy','tp','fp','fn','precision_pct','recall_pct','f1_pct']].to_string(index=False))
