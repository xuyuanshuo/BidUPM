#!/usr/bin/env python3
"""Real GPU validation of previously frozen Qwen0.6 LoRA routing policies.

All model inputs are allowlisted and label free. No calibration or training.
"""
import argparse, gc, hashlib, json, os, sys, time
from pathlib import Path
os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer,AutoModelForSequenceClassification
from peft import PeftModel

ROOT=Path('experiment_runtime')
sys.path.insert(0,str(ROOT/'scripts'))
sys.path.insert(0,str(ROOT/'system_validation_20261005/scripts'))
from local_experiment_utils import item_text
from run_qwen_reranker import QwenPairCollator,load_base_model,label_token_ids
from system_policy import rank_returned

FORBIDDEN={'label','final_label','provisional_label','difficulty','annotator_a_label','annotator_b_label','final_relevance','final_conflict_type','proposed_label'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def gates(f):
    qd=f.query_normalized_description.str.strip().to_numpy()
    cd=f.candidate_normalized_description.str.strip().to_numpy()
    qu=f.query_normalized_unit.str.strip().to_numpy()
    cu=f.candidate_normalized_unit.str.strip().to_numpy()
    exact=(qd!='')&(qd==cd)&(qu!='')&(qu==cu)
    mismatch=(qu!='')&(cu!='')&(qu!=cu)
    return exact,mismatch

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--supplemental-inputs',type=Path,required=True);ap.add_argument('--plan',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    plan=json.loads(a.plan.read_text());sm=json.loads((a.source/'source_manifest.json').read_text())
    assert sha(a.source/'inputs.csv')==sm['inputs_sha256']
    f=pd.read_csv(a.source/'inputs.csv',dtype=str,keep_default_na=False)
    f=f[f.evaluation_split.ne('validation')].reset_index(drop=True)
    assert len(f)==6600 and f.pair_id.nunique()==6600 and not set(f)&FORBIDDEN
    supplementary={}
    for name,file,n in [('challenge600','model_inputs_challenge600.csv',600),('alberta_scope_core','model_inputs_alberta_scope_core.csv',67635)]:
        inp=a.supplemental_inputs/file;ff=pd.read_csv(inp,dtype=str,keep_default_na=False)
        assert len(ff)==n and ff.pair_id.nunique()==n and not set(ff)&FORBIDDEN
        supplementary[name]=(ff,inp)
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    assert not a.output.exists();a.output.mkdir(parents=True)
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    manifest={'status':'running','labels_read':False,'new_training':False,'threshold_retuning':False,
        'gpu':torch.cuda.get_device_name(0),'gpu_total_memory':torch.cuda.get_device_properties(0).total_memory,
        'script_sha256':sha(__file__),'plan_sha256':sha(a.plan),'source_input_sha256':sha(a.source/'inputs.csv'),
        'supplemental_input_sha256':{k:sha(p) for k,(ff,p) in supplementary.items()},
        'timing_scope':'Synchronized resident models: input gate, serialization, tokenizer/collator, genuine model inference and CPU transfer, acceptance and rank merge. Excludes checkpoint loading, CSV IO, candidate generation, previous preprocessing. Main policies repeat 3; supplement each seed repeat 1.',
        'max_length':256,'qwen_batch_size':32,'bge_batch_size':64,'all_complete':False,'completed_outputs':[]}
    dump(a.output/'execution_manifest.json',manifest)
    qmodels={};qtoks={};collators={};tokenids={};loadrows=[]
    for run in plan['models']:
        seed=int(run['seed']);cp=Path(run['checkpoint']);thresholdfile=cp.parent/'validation_thresholds.csv'
        assert sha(thresholdfile)==run['original_threshold_sha256']
        assert sha(cp.parent/'manifest.json')==run['original_manifest_sha256']
        weights={p.name:sha(p) for p in cp.glob('*.safetensors')};assert weights
        started=time.perf_counter();tok=AutoTokenizer.from_pretrained(run['base_model_path'],local_files_only=True,padding_side='left')
        tok.pad_token=tok.pad_token or tok.eos_token
        model=PeftModel.from_pretrained(load_base_model(run['base_model_path'],torch.device('cuda')),cp).eval()
        torch.cuda.synchronize();loading=time.perf_counter()-started
        qmodels[seed]=model;qtoks[seed]=tok;collators[seed]=QwenPairCollator(tok,256,run['instruction']);tokenids[seed]=label_token_ids(tok)
        loadrows.append({'kind':'qwen06','seed':seed,'loading_seconds':loading,'adapter_weight_sha256':weights})
    bgerun=next(r for r in sm['runs'] if int(r['seed'])==20260906);bgecp=Path(bgerun['checkpoint']);bgeth=float(bgerun['threshold'])
    for name,h in bgerun['checkpoint_files'].items():assert sha(bgecp/name)==h
    started=time.perf_counter();bgetok=AutoTokenizer.from_pretrained(bgecp,local_files_only=True)
    bgemodel=AutoModelForSequenceClassification.from_pretrained(bgecp,local_files_only=True).to('cuda').eval()
    torch.cuda.synchronize();loadrows.append({'kind':'bge','seed':20260906,'loading_seconds':time.perf_counter()-started,'weight_sha256':bgerun['checkpoint_files']})
    manifest['model_loads']=loadrows;dump(a.output/'execution_manifest.json',manifest)
    runs={int(r['seed']):r for r in plan['models']};timings=[]

    @torch.inference_mode()
    def model_scores(frame,called,seed,kind):
        ix=np.flatnonzero(called);sub=frame.iloc[ix];qs=item_text(sub,'query','full');cs=item_text(sub,'candidate','full')
        ans=np.full(len(frame),np.nan);tokens=0;bs=64 if kind=='bge' else 32
        for lo in range(0,len(ix),bs):
            if kind=='bge':
                enc=bgetok(qs[lo:lo+bs],cs[lo:lo+bs],padding=True,truncation=True,max_length=256,return_tensors='pt')
            else:
                enc=collators[seed]([(x,y,0,0.) for x,y in zip(qs[lo:lo+bs],cs[lo:lo+bs])]);enc.pop('labels_local');enc.pop('hard_local')
            tokens+=int(enc['attention_mask'].sum());enc={k:v.to('cuda') for k,v in enc.items()}
            with torch.autocast('cuda',dtype=torch.bfloat16):
                logits=(bgemodel if kind=='bge' else qmodels[seed])(**enc).logits
                if kind=='bge':score=logits.reshape(-1)
                else:
                    no_id,yes_id=tokenids[seed];score=logits[:,-1,yes_id]-logits[:,-1,no_id]
            ans[ix[lo:lo+bs]]=score.float().cpu().numpy()
        assert np.isfinite(ans[called]).all() and np.isnan(ans[~called]).all()
        return ans,tokens

    def execute(frame,policy,seed=20260906):
        torch.cuda.synchronize();started=time.perf_counter();n=len(frame);exact,mismatch=gates(frame)
        gated=policy.startswith('unit_gate');called=(~exact&~mismatch) if gated else np.ones(n,bool)
        rule=exact if gated else np.zeros(n,bool);tokcount=0;scorecols={}
        if policy=='all_bge_seed6':
            score,tokcount=model_scores(frame,called,20260906,'bge');threshold=bgeth;modelcalls=int(called.sum())
        elif policy=='unit_gate_q06hard_mean':
            margins=[]
            for ss in sorted(runs):
                raw,tt=model_scores(frame,called,ss,'qwen');tokcount+=tt;scorecols[f'raw_score_seed_{ss}']=raw
                margins.append((raw-runs[ss]['threshold'])/runs[ss]['scale'])
            score=np.mean(np.stack(margins),axis=0);threshold=float(plan['mean_threshold']);modelcalls=int(called.sum())*3
        else:
            score,tokcount=model_scores(frame,called,seed,'qwen');threshold=float(runs[seed]['threshold']);modelcalls=int(called.sum())
        accepted=rule|(called&(score>=threshold));out=frame.copy();out['policy']=policy;out['seed']=seed
        out['exact_match']=exact.astype(int);out['unit_mismatch']=mismatch.astype(int)
        out['model_called']=called.astype(int);out['model_candidate_calls']=called.astype(int)*(3 if policy=='unit_gate_q06hard_mean' else 1)
        out['score']=score;out['threshold']=threshold;out['accepted']=accepted.astype(int)
        for k,v in scorecols.items():out[k]=v
        if set(frame)&{'query_id'}:
            out['returned_rank']=rank_returned(frame,rule,np.where(accepted&~rule,score,np.nan),float('-inf'))
        torch.cuda.synchronize();secs=time.perf_counter()-started
        return out,dict(seconds=secs,pairs=n,query_pools=len(frame.groupby(['evaluation_split','query_id'])) if 'evaluation_split' in frame and 'query_id' in frame else None,
            model_candidate_calls=modelcalls,qwen_calls=modelcalls if policy!='all_bge_seed6' else 0,bge_calls=modelcalls if policy=='all_bge_seed6' else 0,prompt_tokens=tokcount)

    # Same-server resident control; all four policies randomized in each repeat.
    warm=f.head(120).reset_index(drop=True)
    for policy in plan['main_policies']:execute(warm,policy)
    reference={}
    for repeat in range(3):
        for policy in np.random.default_rng(20261005+repeat).permutation(plan['main_policies']):
            out,ti=execute(f,str(policy));timings.append(dict(dataset='main6600',policy=str(policy),seed=20260906,repeat=repeat,**ti))
            if policy in reference:
                assert np.array_equal(reference[policy]['accepted'],out.accepted.to_numpy()),'repeat decisions changed'
                assert np.array_equal(reference[policy]['returned_rank'],out.returned_rank.to_numpy()),'repeat ranks changed'
            else:
                path=a.output/(str(policy)+'_main6600.csv');out.to_csv(path,index=False)
                reference[policy]={'accepted':out.accepted.to_numpy().copy(),'returned_rank':out.returned_rank.to_numpy().copy()}
                manifest['completed_outputs'].append(dict(dataset='main6600',policy=str(policy),seed=20260906,pair_n=len(out),output=path.name,sha256=sha(path)))
            pd.DataFrame(timings).to_csv(a.output/'timing.csv',index=False);dump(a.output/'execution_manifest.json',manifest)
            print('FINISH_MAIN',policy,repeat,round(ti['seconds'],3),ti['model_candidate_calls'],flush=True)
    for name,(ff,inp) in supplementary.items():
        means=[]
        for seed in sorted(runs):
            out,ti=execute(ff,'unit_gate_q06hard_single',seed);timings.append(dict(dataset=name,policy='unit_gate_q06hard_single',seed=seed,repeat=0,**ti))
            path=a.output/f'unit_gate_q06hard_{name}_seed_{seed}.csv';out.to_csv(path,index=False)
            means.append((out.score.to_numpy()-runs[seed]['threshold'])/runs[seed]['scale'])
            manifest['completed_outputs'].append(dict(dataset=name,policy='unit_gate_q06hard_single',seed=seed,pair_n=len(out),output=path.name,sha256=sha(path)))
            pd.DataFrame(timings).to_csv(a.output/'timing.csv',index=False);dump(a.output/'execution_manifest.json',manifest)
            print('FINISH_SUPPLEMENT',name,seed,round(ti['seconds'],3),int(out.accepted.sum()),flush=True)
        exact,mismatch=gates(ff);called=~exact&~mismatch;score=np.mean(np.stack(means),axis=0)
        accepted=exact|(called&(score>=float(plan['mean_threshold'])));out=ff.copy()
        out['policy']='unit_gate_q06hard_mean';out['exact_match']=exact.astype(int);out['unit_mismatch']=mismatch.astype(int)
        out['model_called']=called.astype(int);out['model_candidate_calls']=called.astype(int)*3;out['score']=score
        out['threshold']=float(plan['mean_threshold']);out['accepted']=accepted.astype(int)
        if 'query_id' in ff:out['returned_rank']=rank_returned(ff,exact,np.where(accepted&~exact,score,np.nan),float('-inf'))
        path=a.output/f'unit_gate_q06hard_mean_{name}.csv';out.to_csv(path,index=False)
        manifest['completed_outputs'].append(dict(dataset=name,policy='unit_gate_q06hard_mean',seed=None,pair_n=len(out),output=path.name,sha256=sha(path),timing_source='sum three genuine single-model supplementary runs plus merge; not independently timed ensemble'))
    assert len(timings)==18 and len(manifest['completed_outputs'])==12
    manifest['status']='complete';manifest['all_complete']=True;manifest['timing_sha256']=sha(a.output/'timing.csv')
    manifest['supplemental_predictions_frozen_before_quality']=True;dump(a.output/'execution_manifest.json',manifest)
    print('ALL_COMPLETE',flush=True)

if __name__=='__main__':main()
