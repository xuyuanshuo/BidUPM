from pathlib import Path
import json,csv,hashlib,statistics
import numpy as np
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'output/router_research_20261005';RES=BASE/'qwen_last_token_ab_results';OUT=RES/'analysis'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
    with Path(p).open(newline='') as f:return list(csv.DictReader(f))
def write(p,rr):
    with Path(p).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
m=json.loads((RES/'execution_manifest.json').read_text());assert m['status']=='complete'
OUT.mkdir(exist_ok=True);allrows={}
for o in m['completed_outputs']:
    p=RES/o['file'];assert sha(p)==o['sha256'];rr=read(p);assert len(rr)==6600 and len({r['pair_id'] for r in rr})==6600
    allrows[o['policy']]={r['pair_id']:r for r in rr}
t=read(RES/'timing.csv');assert len(t)==12 and sha(RES/'timing.csv')==m['timing_sha256']
comparison=[];changed=[];timing=[]
for gated in ['full','unit_gate']:
    a=allrows[gated+'_logits_keep0'];b=allrows[gated+'_logits_keep1'];assert set(a)==set(b)
    deltas=[];pred_changed=0;rank_changed=0;exact_changed=0
    for k in a:
        r,s=a[k],b[k];assert r['model_called']==s['model_called'] and r['threshold']==s['threshold']
        assert r['exact_match']==s['exact_match'] and r['unit_mismatch']==s['unit_mismatch']
        dp=r['accepted']!=s['accepted'];dr=r['returned_rank']!=s['returned_rank'];pred_changed+=dp;rank_changed+=dr
        exact_changed+=bool(int(r['exact_match'])) and dp
        if int(r['model_called']):delta=abs(float(r['score'])-float(s['score']));deltas.append(delta)
        else:assert not r['score'] and not s['score'];delta=0.
        if dp or dr:changed.append(dict(policy=gated,pair_id=k,old_score=r['score'],optimized_score=s['score'],old_decision=r['accepted'],optimized_decision=s['accepted'],old_rank=r['returned_rank'],optimized_rank=s['returned_rank'],absolute_score_difference=delta))
    qa_queries={}
    for k in a:
        r,s=a[k],b[k];q=(r['evaluation_split'],r['query_id'])
        old,new=qa_queries.setdefault(q,([],[]))
        if int(r['returned_rank'])>0:old.append((int(r['returned_rank']),k))
        if int(s['returned_rank'])>0:new.append((int(s['returned_rank']),k))
    membership_changed=sum({k for _,k in old}!={k for _,k in new} for old,new in qa_queries.values())
    ordered_queries_changed=sum([k for _,k in sorted(old)]!=[k for _,k in sorted(new)] for old,new in qa_queries.values())
    comparison.append(dict(policy=gated,rows=6600,scored_rows=len(deltas),score_identical_rows=sum(x==0 for x in deltas),max_abs_logit_difference=max(deltas),mean_abs_logit_difference=statistics.mean(deltas),changed_decisions=pred_changed,changed_ranks=rank_changed,changed_exact_rule_decisions=exact_changed,queries=len(qa_queries),changed_returned_memberships=membership_changed,changed_ordered_queries=ordered_queries_changed))
    old=statistics.median(float(r['seconds']) for r in t if r['policy']==gated+'_logits_keep0');new=statistics.median(float(r['seconds']) for r in t if r['policy']==gated+'_logits_keep1')
    timing.append(dict(policy=gated,repeats_each=3,old_median_seconds=old,last_token_median_seconds=new,seconds_reduction=1-new/old,speedup=old/new,cny_per_1000_queries_old_2_88=old/220*1000*2.88/3600,cny_per_1000_queries_optimized_2_88=new/220*1000*2.88/3600))
write(OUT/'candidate_logit_decision_rank_comparison.csv',comparison);write(OUT/'same_session_ab_timing.csv',timing)
if changed:write(OUT/'changed_candidate_decisions_or_ranks.csv',changed)
else:(OUT/'changed_candidate_decisions_or_ranks.csv').write_text('policy,pair_id,old_score,optimized_score,old_decision,optimized_decision,old_rank,optimized_rank,absolute_score_difference\n')
qa={'status':'passed','outputs':len(allrows),'rows_each':6600,'main_conditions':4,'real_timing_repeats':3,'timing_rows':12,'checkpoint_prompt_input_threshold_unchanged':True,'only_logit_head_positions_changed':True,'whole_output_not_assumed_bitwise_equivalent':True,'pairwise_score_decision_rank_verified':True,'comparisons':comparison,'api_calls':False}
(OUT/'last_token_ab_qa.json').write_text(json.dumps(qa,indent=2,ensure_ascii=False));print(json.dumps({'timing':timing,'candidate_comparison':comparison},indent=2))
