#!/usr/bin/env python3
"""Read-only original Excel import and deterministic preprocessing timing."""
import hashlib
import importlib.util
import json
import platform
import statistics
import time
from pathlib import Path

import pandas as pd

WORK = Path('research_workspace')
ADAPTER = WORK/'output/rule_first_system_validation_20261005/scripts/audit_raw_alberta_import.py'
OUT = WORK/'output/router_research_20261005/preprocessing_profile'
spec = importlib.util.spec_from_file_location('original_excel_import', ADAPTER)
adapter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    before = {str(p): sha(p) for p in (adapter.BID_PATH, adapter.UPA_PATH)}
    rows, coverage = [], []
    for repeat in range(7):
        start = time.perf_counter()
        queries, _, _ = adapter.parse_bid(adapter.BID_PATH)
        sources = {year: adapter.parse_upa(adapter.UPA_PATH, year)[0] for year in (2024, 2026)}
        elapsed = time.perf_counter()-start
        assert len(queries) == 135 and len(sources[2024]) == 237 and len(sources[2026]) == 264
        rows.append({'repeat':repeat, 'operation':'parse_two_original_workbooks', 'seconds':elapsed, 'unique_items':636})
        for stage in range(5):
            start = time.perf_counter()
            qkeys = [adapter.normal_key(item, stage) for item in queries]
            ckeys = {year:[adapter.normal_key(item, stage) for item in pool] for year,pool in sources.items()}
            normalization_seconds = time.perf_counter()-start
            start = time.perf_counter()
            matches = {}
            for year,pool in ckeys.items():
                index = {}
                for n,key in enumerate(pool):
                    index.setdefault(key, []).append(n)
                matches[year] = [index.get(key, []) if key[0] and key[1] else [] for key in qkeys]
            index_seconds = time.perf_counter()-start
            rows.append({'repeat':repeat,'operation':adapter.STAGES[stage]+'_normalize_unique_items','seconds':normalization_seconds,'unique_items':636})
            rows.append({'repeat':repeat,'operation':adapter.STAGES[stage]+'_index_and_lookup','seconds':index_seconds,'unique_items':636})
            if repeat == 0:
                for year,pools in matches.items():
                    coverage.append({'stage':adapter.STAGES[stage],'year':year,'queries':135,'candidate_items':len(sources[year]),'queries_with_rule_candidate':sum(bool(x) for x in pools),'rule_returned_links':sum(map(len,pools))})
    timings = pd.DataFrame(rows)
    timings.to_csv(OUT/'actual_preprocessing_timings.csv', index=False)
    summary = timings.groupby('operation', sort=False).seconds.agg(['count','median','mean','min','max']).reset_index()
    summary.to_csv(OUT/'preprocessing_timing_summary.csv', index=False)
    pd.DataFrame(coverage).to_csv(OUT/'raw_workbook_rule_coverage_by_stage.csv', index=False)
    after = {str(p):sha(p) for p in (adapter.BID_PATH,adapter.UPA_PATH)}
    assert before == after
    report = {'status':'complete','source_hashes_before':before,'source_hashes_after':after,'source_unchanged':True,
              'adapter_sha256':sha(ADAPTER),'script_sha256':sha(__file__),'repeats':7,
              'host':platform.platform(),'device':'local CPU, not GPU server','llm_or_gpu_used':False,
              'labels_used':False,'timing_includes':'actual read-only Excel schema parsing; separate unique-item normalization and exact-key index/lookup',
              'timing_excludes':'candidate/model scoring, arbitrary workbook layout detection, OCR, model loading, manual engineering review',
              'schema_scope':'Observed Owner Bid Form and 2024/2026 UPA schemas only; warm OS/file cache possible across repeated reads',
              'coverage_is_accuracy':False,'rules_return_matches':True,'human_annotations_modified':False}
    (OUT/'execution_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(summary.to_string(index=False))


if __name__ == '__main__':
    main()
