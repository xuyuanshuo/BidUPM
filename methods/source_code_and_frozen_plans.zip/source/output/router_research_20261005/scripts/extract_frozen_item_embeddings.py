from pathlib import Path
import os,json,hashlib,time,sys
os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
import pandas as pd,numpy as np,torch
from transformers import AutoModelForSequenceClassification,AutoTokenizer
R=Path('experiment_runtime');B=R/'router_research_20261005';P=B/'semantic_student';P.mkdir(exist_ok=True)
wait=B/'unit_gate_gpu/execution_manifest.json'
while not wait.exists() or json.loads(wait.read_text()).get('status')!='complete':time.sleep(3)
f=pd.read_csv(P/'item_embedding_map.csv',dtype=str,keep_default_na=False)
plan=json.loads((P/'frozen_representation.json').read_text());assert hashlib.sha256((P/'item_embedding_map.csv').read_bytes()).hexdigest()==plan['item_map_sha256']
cp=R/'runs/bge_hard_seed_20260904/checkpoint_hard_refined';manifest=json.loads((R/'runs/bge_hard_seed_20260904/manifest.json').read_text())
torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.manual_seed(20260904)
tok=AutoTokenizer.from_pretrained(cp,local_files_only=True);model=AutoModelForSequenceClassification.from_pretrained(cp,local_files_only=True,dtype=torch.bfloat16).cuda().eval();arrays=[]
with torch.inference_mode():
 for lo in range(0,64,64):
  e=tok(f.model_text.iloc[lo:lo+64].tolist(),padding=True,truncation=True,max_length=256,return_tensors='pt');model.base_model(**{k:v.cuda() for k,v in e.items()})
 torch.cuda.synchronize();start=time.perf_counter()
 for lo in range(0,len(f),64):
  e=tok(f.model_text.iloc[lo:lo+64].tolist(),padding=True,truncation=True,max_length=256,return_tensors='pt');e={k:v.cuda() for k,v in e.items()};h=model.base_model(**e).last_hidden_state.float();mask=e['attention_mask'].unsqueeze(-1).float();v=(h*mask).sum(1)/mask.sum(1);v=torch.nn.functional.normalize(v,dim=1);arrays.append(v.cpu().numpy())
 torch.cuda.synchronize();elapsed=time.perf_counter()-start
np.savez_compressed(P/'embeddings.npz',embeddings=np.concatenate(arrays))
plan.update({'status':'complete','frozen_encoder_checkpoint':str(cp),'encoder_original_manifest_sha256':hashlib.sha256((R/'runs/bge_hard_seed_20260904/manifest.json').read_bytes()).hexdigest(),'single_item_embedding_gpu_seconds':elapsed,'batch_size':64,'dtype':'bf16','embedding_shape':list(np.concatenate(arrays).shape),'embeddings_sha256':hashlib.sha256((P/'embeddings.npz').read_bytes()).hexdigest(),'new_encoder_training':False,'any_labels_read_during_extraction':False,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
(P/'embedding_execution_manifest.json').write_text(json.dumps(plan,indent=2));print('EMBEDDING_ALL_COMPLETE',elapsed,len(f),flush=True)
