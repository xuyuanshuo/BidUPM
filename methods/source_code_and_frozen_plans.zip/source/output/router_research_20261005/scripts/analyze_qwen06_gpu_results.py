"""Verify downloaded actual GPU outputs, then report held-out/exploratory quality.

No new policy selection, thresholds or routing changes are allowed here.
"""
from pathlib import Path
from collections import defaultdict
import csv,json,hashlib,statistics,datetime
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'output/router_research_20261005';RES=BASE/'qwen06_gpu_results';OUT=RES/'analysis'
INPUT=ROOT/'output/paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,rr):
    with Path(p).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
def mask(r):
    qd,cd,qu,cu=[r[x].strip() for x in ['query_normalized_description','candidate_normalized_description','query_normalized_unit','candidate_normalized_unit']]
    return bool(qd and qu and qd==cd and qu==cu),bool(qu and cu and qu!=cu)
def mtr(gold,pred):
    tp=sum(gold[k]==1 and pred.get(k,0)==1 for k in gold);fp=sum(gold[k]==0 and pred.get(k,0)==1 for k in gold)
    fn=sum(gold[k]==1 and pred.get(k,0)==0 for k in gold);tn=len(gold)-tp-fp-fn
    return dict(rows=len(gold),tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else '',recall=tp/(tp+fn) if tp+fn else '',f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,accuracy=(tp+tn)/len(gold) if gold else '')

manifest=json.loads((RES/'execution_manifest.json').read_text());assert manifest['status']=='complete' and manifest['all_complete']
assert manifest['supplemental_predictions_frozen_before_quality']
plan=json.loads((BASE/'qwen06_gpu_plan_before_inference.json').read_text());assert sha(BASE/'qwen06_gpu_plan_before_inference.json')==manifest['plan_sha256']
OUT.mkdir(exist_ok=True);outs={};checks=[]
for o in manifest['completed_outputs']:
    p=RES/o['output'];assert sha(p)==o['sha256'];rr=read(p);assert len(rr)==o['pair_n'] and len({r['pair_id'] for r in rr})==len(rr)
    for r in rr:
        e,u=mask(r);assert e==bool(int(r['exact_match'])) and u==bool(int(r['unit_mismatch']))
        gated=r['policy'].startswith('unit_gate');called=(not e and not u) if gated else True
        assert int(r['model_called'])==int(called)
        score=float(r['score']) if r['score'] else float('nan');t=float(r['threshold'])
        assert np.isfinite(score)==called
        assert int(r['accepted'])==int((gated and e) or (called and score>=t))
    outs[o['output']]=rr;checks.append(dict(file=o['output'],rows=len(rr),sha256=sha(p),all_input_gate_and_decision_checks=True))
times=read(RES/'timing.csv');assert len(times)==18 and sha(RES/'timing.csv')==manifest['timing_sha256']
for policy in plan['main_policies']:assert len([x for x in times if x['dataset']=='main6600' and x['policy']==policy])==3
write(OUT/'prediction_integrity_checks.csv',checks)

# Label access starts here, only after complete output file hashes verified.
source=ROOT/'output/remote_experiments_20260923/runs/bge_hard_seed_20260906/pair_scores.csv'
goldrows={r['pair_id']:r for r in read(source) if r['evaluation_split']!='validation'}
groups={'primary218':{'locked','no_reference','external'},'locked100':{'locked'},'external80':{'external'},'all220':{'locked','no_reference','external','no_reference_reclassified'}}
metrics=[];rankmetrics=[]
for fn,rr in outs.items():
    if not fn.endswith('_main6600.csv'):continue
    pred={r['pair_id']:int(r['accepted']) for r in rr};by={r['pair_id']:r for r in rr}
    assert set(pred)==set(goldrows)
    for group,splits in groups.items():
        g={k:int(v['final_label']) for k,v in goldrows.items() if v['evaluation_split'] in splits}
        gh={k:v for k,v in g.items() if goldrows[k]['difficulty']=='hard'}
        metrics.append(dict(policy=rr[0]['policy'],group=group,quality_source='original held-out reference labels',**{f'overall_{k}':v for k,v in mtr(g,pred).items()},**{f'hard_{k}':v for k,v in mtr(gh,pred).items()}))
        qs=defaultdict(list)
        for k in g:qs[(goldrows[k]['evaluation_split'],goldrows[k]['query_id'])].append(k)
        top={k:int(by[k]['returned_rank'])>0 for k in g};pt=mtr(g,top);hit=[];rec=[];reject=[]
        for ids in qs.values():
            gg={k for k in ids if g[k]};tt={k for k in ids if top[k]}
            if gg:hit.append(bool(gg&tt));rec.append(len(gg&tt)/len(gg))
            else:reject.append(not tt)
        rankmetrics.append(dict(policy=rr[0]['policy'],group=group,returned_precision=pt['precision'],returned_tp=pt['tp'],returned_fp=pt['fp'],macro_recall3=statistics.mean(rec) if rec else '',hit3=statistics.mean(hit) if hit else '',no_reference_rejection=statistics.mean(reject) if reject else '',hard_returned_tp=mtr(gh,top)['tp'],hard_returned_fp=mtr(gh,top)['fp']))
write(OUT/'main_actual_complete_pair_metrics.csv',metrics);write(OUT/'main_actual_top3_metrics.csv',rankmetrics)
timing=[];control=statistics.median(float(r['seconds']) for r in times if r['dataset']=='main6600' and r['policy']=='all_bge_seed6')
for policy in plan['main_policies']:
    tr=[r for r in times if r['dataset']=='main6600' and r['policy']==policy];s=statistics.median(float(r['seconds']) for r in tr)
    timing.append(dict(policy=policy,repeats=3,median_batch_seconds=s,min_seconds=min(float(r['seconds']) for r in tr),max_seconds=max(float(r['seconds']) for r in tr),ratio_vs_actual_bge_control=s/control,seconds_reduction_vs_control=1-s/control,cny_per_1000_queries_2_88_per_hour=s/220*1000*2.88/3600,model_calls=int(tr[0]['model_candidate_calls']),scope='same-session resident main6600 batch-throughput, not one-request latency or API invoice'))
write(OUT/'main_actual_timing_and_cost.csv',timing)

# Actual versus frozen cached decisions: differences remain visible, never replace real output.
cached={};needed={'unit_gate_q06hard_single_20260906','unit_gate_q06hard_mean'}
with (BASE/'validation_input_unit_gate/all_policy_predictions_before_test.csv').open(newline='') as f:
    for r in csv.DictReader(f):
        if r['policy'] in needed and r['evaluation_split']!='validation':cached[(r['policy'],r['pair_id'])]=int(r['accepted'])
replay=[]
for actual,old in [('unit_gate_q06hard_single_seed6','unit_gate_q06hard_single_20260906'),('unit_gate_q06hard_mean','unit_gate_q06hard_mean')]:
    rr=outs[actual+'_main6600.csv'];diff=sum(int(r['accepted'])!=cached[(old,r['pair_id'])] for r in rr)
    replay.append(dict(actual_policy=actual,cached_frozen_policy=old,rows=len(rr),changed_decisions=diff))
write(OUT/'actual_vs_cached_decisions.csv',replay)

# Supplementary predictions were frozen before opening constructed/AI labels.
challenge_path=ROOT/'output/internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv'
cc=read(challenge_path);assert len(cc)==600 and all(not r['final_label'] and not r['annotator_a_label'] and not r['annotator_b_label'] for r in cc)
challenge_gold={r['pair_id']:int(r['provisional_label']) for r in cc}
ai_path=BASE/'alberta_ai_reference/outputs/ai_reference.jsonl';ai=[json.loads(x) for x in ai_path.read_text().splitlines() if x.strip()]
airef={(str(r['year']),r['query_id']):r for r in ai};assert len(airef)==270
albertainput=read(INPUT/'model_inputs_alberta_scope_core.csv');alberta_gold={};uncertain=set()
for r in albertainput:
    ref=airef[(r['source_year'],r['query_id'])];k=r['pair_id'];cand=r['candidate_id']
    if cand in ref['uncertain_candidate_ids']:uncertain.add(k)
    else:alberta_gold[k]=int(cand in ref['compatible_candidate_ids'])
suppmetrics=[];suppranks=[]
for dataset,gold in [('challenge600',challenge_gold),('alberta_scope_core',alberta_gold)]:
    reference_input=read(INPUT/('model_inputs_challenge600.csv' if dataset=='challenge600' else 'model_inputs_alberta_scope_core.csv'))
    references={r['pair_id']:r for r in reference_input};policies={}
    policies['exact_unit_rule']={k:int(mask(r)[0]) for k,r in references.items()}
    for seed in [20260904,20260905,20260906]:
        src=read(INPUT/'source_bge'/f'{dataset}_seed_{seed}.csv');assert {r['pair_id'] for r in src}==set(references)
        policies[f'full_bge_{seed}']={r['pair_id']:int(r['prediction']) for r in src}
        policies[f'unit_gate_bge_{seed}']={r['pair_id']:int(mask(references[r['pair_id']])[0] or (not mask(references[r['pair_id']])[1] and int(r['prediction']))) for r in src}
    for name,rr in outs.items():
        if name.endswith('_main6600.csv'):continue
        if dataset not in name:continue
        policies[rr[0]['policy']+(('_'+rr[0]['seed']) if 'seed' in rr[0] else '')]={r['pair_id']:int(r['accepted']) for r in rr}
    for policy,pred in policies.items():
        met=mtr(gold,pred);suppmetrics.append(dict(dataset=dataset,policy=policy,quality_source='construction intent labels; no human confirmation' if dataset=='challenge600' else 'single blind AI reference; not human gold',excluded_uncertain_pairs=0 if dataset=='challenge600' else len(uncertain),**met))
    if dataset=='alberta_scope_core':
        for name,rr in outs.items():
            if dataset not in name:continue
            by={r['pair_id']:r for r in rr};top={k:int(r['returned_rank'])>0 for k,r in by.items()}
            met=mtr(gold,top);suppranks.append(dict(dataset=dataset,policy=rr[0]['policy']+(('_'+rr[0]['seed']) if 'seed' in rr[0] else ''),returned_tp=met['tp'],returned_fp=met['fp'],returned_precision_known_ai=met['precision'],returned_ai_uncertain=sum(top.get(k,False) for k in uncertain),no_human_accuracy_claim=True))
write(OUT/'supplementary_constructed_and_ai_reference_metrics.csv',suppmetrics)
write(OUT/'alberta_qwen_top3_ai_reference_metrics.csv',suppranks)
qa={'status':'passed','output_files':len(checks),'checked_actual_rows':sum(x['rows'] for x in checks),'timing_rows':len(times),
    'main_repeated_real_gpu_controls':True,'supplement_each_seed_timing_singlepass':True,
    'supplement_mean_output_reuses_three_new_actual_scores_not_independently_timed':True,
    'checkpoint_training_or_threshold_updates':False,'supplemental_quality_started_after_all_output_hashes_verified':True,
    'challenge_human_annotations_present':False,'alberta_human_gold':False,
    'source_challenge_sha256':sha(challenge_path),'source_ai_reference_sha256':sha(ai_path),'actual_vs_cached_decisions':replay,
    'evaluated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'gpu_output_and_evaluation_qa.json').write_text(json.dumps(qa,indent=2,ensure_ascii=False))
print(json.dumps({'main_timing':timing,'main_complete_primary':[r for r in metrics if r['group']=='primary218'],'supplementary':suppmetrics,'qa':qa},ensure_ascii=False,indent=2))
