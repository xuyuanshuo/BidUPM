#!/usr/bin/env python3
"""Read-only extraction of old routing/capacity summaries for chat tables."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

W=Path(__file__).resolve().parents[3]
A=W/'output/router_research_20261005/all_experiment_tables'
INV=json.loads((A/'method_family_inventory.json').read_text())
FAM={x['id']:x for x in INV['families']}
USED={}; TABLES=[]; LINES=[]

METHOD={
 'all_bge':'全量微调BGE','rule_only':'仅精确规则','stop_3':'规则+BGE，三条早停','system_top3':'规则+BGE，三条早停',
 'all_bge_published_all':'全量BGE，完整接受名单','all_bge_published_top3':'全量BGE，返回3条',
 'exact_rescue_published_all':'精确接受+其余BGE，完整名单','exact_rescue_published_top3':'精确接受+其余BGE，返回3条',
 'rule_only_top3':'仅规则，返回3条','stop3_published_top3':'规则+BGE，三条早停','validation_selected':'验证集预选策略',
 'old_system_top3':'原规则+BGE早停名单','selective_gpt_top3':'少量候选独立GPT核验',
 'same_runtime_fullpool_gpt_and_top3':'同批BGE+旧全池GPT判断重放',
 'prior_posthoc_fullscore_and_top3':'旧BGE分数+旧全池GPT判断重放',
 'exact_pair_bge_exact_priority':'全配对规则+BGE，精确优先','exact_pair_bge_nonexact_first':'全配对规则+BGE，非精确优先',
 'gpt6_sol_fullpool':'GPT-6 Sol全池盲判',
 'exact_pair_bge_cached_fullpool_gpt_exact_priority':'BGE+旧全池GPT重放，精确优先',
 'exact_pair_bge_cached_fullpool_gpt_nonexact_first':'BGE+旧全池GPT重放，非精确优先',
 'rule_exact':'仅精确规则','gpt6_sol_blind_full_acceptance':'GPT完整接受判断',
 'bge_hard_base_three_seed_macro_mean':'专项BGE（三checkpoint均值）',
 'bge_hard_conflict_refined_three_seed_macro_mean':'专项BGE+旧冲突规则（三checkpoint均值）',
 'bge_zero_shot_base':'BGE零样本','bge_zero_shot_conflict_refined':'BGE零样本+旧冲突规则',
 'rule_bge':'规则+BGE早停','rule_bge_qwen_threshold':'规则+BGE阳性+Qwen阈值核验',
 'rule_bge_qwen_top10':'规则+BGE前10候选+Qwen核验（仍返回3条）',
 'expanded_verified_k10':'扩展前10候选+独立GPT核验（仍返回3条）'
}
LABEL={
 'policy':'方法','model':'方法','batch_size':'批大小','exact_n':'精确候选数',
 'query_n':'查询数','queries':'查询数','positive_query_n':'有参考查询','positive_queries':'有参考查询','no_reference_query_n':'无参考查询',
 'pair_n':'配对数','candidate_n':'候选配对','candidate_pair_n':'候选配对','candidate_pairs':'候选配对','gold_positive_n':'正例数',
 'returned_tp_n':'返回TP','returned_fp_n':'返回FP','returned_fn_n':'未返回正例','returned_n':'返回总数',
 'returned_tp':'返回TP','returned_fp':'返回FP','returned_precision_pct':'返回P(%)','returned_precision':'返回P(%)',
 'macro_recall_at3_pct':'宏R@3(%)','macro_recall':'名单宏R(%)','micro_recall_at3_pct':'微R@3(%)','returned_micro_recall':'名单微R(%)',
 'hit_at3_pct':'Hit@3(%)','hit_returned':'名单Hit(%)','hit_query_n':'命中查询',
 'wrong_reference_query_rate_pct':'误参考查询率(%)','wrong_reference_query_rate_pct_mean':'误参考查询率(%)','wrong_query_rate':'误参考查询率(%)',
 'wrong_reference_query_pct':'误参考查询率(%)','wrong_reference_query_n':'误参考查询数',
 'no_reference_pool_rejection_pct':'无参考拒绝(%)','no_reference_rejection_pct':'无参考拒绝(%)','no_reference_rejection':'无参考拒绝(%)',
 'no_reference_rejected_query_n':'正确空列表查询','average_returned_n':'平均返回条数','mean_returned_n':'平均返回条数',
 'model_called_n':'BGE候选打分数','model_candidate_calls':'模型候选打分数','model_pairs':'模型候选打分数',
 'model_candidate_fraction_pct':'模型候选比例(%)','model_candidate_fraction':'模型候选比例(%)','model_scoring_reduction_pct':'少打分比例(%)',
 'model_calls_mean_per_query':'每查询模型候选数','unscored_n':'未评分候选数','unobserved_pair_n':'未观测候选数',
 'nonexact_positive_query_n':'有非精确正例查询','returned_nonexact_tp_n':'非精确返回TP','nonexact_positive_n':'非精确正例数',
 'nonexact_positive_query_rescue_pct':'非精确查询救回率(%)','nonexact_positive_query_hit':'非精确查询命中(%)',
 'nonexact_returned_tp':'非精确返回TP','nonexact_returned_recall':'非精确微召回(%)','nonexact_micro_recall_at3_pct':'非精确微R@3(%)',
 'returned_nonexact_fp_n':'非精确返回FP','accepted_nonexact_tp_n':'非精确接受TP','accepted_nonexact_fp_n':'非精确接受FP',
 'no_exact_positive_query_n':'无精确正例查询','no_exact_positive_query_hit_n':'无精确正例命中数','no_exact_positive_query_hit_pct':'无精确正例Hit(%)',
 'semantic_returned_n':'语义返回数','semantic_tp':'语义返回TP','semantic_fp':'语义返回FP','semantic_precision':'语义P(%)',
 'semantic_precision_zero_error_95pct_lower':'零误报语义P的95%下界(%)','pair_precision':'配对P(%)','pair_recall':'配对R(%)','pair_f1':'配对F1(%)',
 'returned_f1':'名单F1(%)','pair_tp':'配对TP','pair_fp':'配对FP','pair_fn':'配对FN','pair_tn':'配对TN',
 'pair_precision_pct':'配对P(%)','pair_recall_pct':'配对R(%)','pair_f1_pct':'配对F1(%)',
 'tp':'TP','fp':'FP','fn':'FN','tn':'TN','precision_pct':'P(%)','recall_pct':'R(%)','f1_pct':'F1(%)',
 'precision':'P(%)','recall':'R(%)','f1':'F1(%)','hard_pairs':'困难配对','hard_positive':'困难正例','hard_negative':'困难负例',
 'hard_pair_n':'困难配对','hard_positive_n':'困难正例','hard_positive_query_n':'有困难正例查询',
 'returned_hard_tp_n':'困难返回TP','returned_hard_fp_n':'困难返回FP','unreturned_hard_positive_n':'未返回困难正例',
 'hard_returned_precision_pct':'困难返回P(%)','hard_micro_recall_at3_pct':'困难微R@3(%)','hard_macro_recall_at3_pct':'困难宏R@3(%)','hard_hit_at3_pct':'困难Hit@3(%)',
 'accepted_n':'接受总数','gate_skipped_positive_n':'早停未判正例','rejected_positive_n':'明确拒绝正例','accepted_positive_not_returned_n':'已接受未返回正例',
 'condition_n':'checkpoint条件数','shared_gpt_judgment_n':'共用GPT判断套数','shared_old_gpt_judgment_n':'共用旧GPT判断套数','new_selective_judgment_n':'新增选择性判断套数',
 'weighted_mean_latency_ms':'单查询平均延迟(ms)','query_median_latency_ms':'单查询中位延迟(ms)','query_p95_latency_ms':'单查询P95延迟(ms)',
 'seconds_median':'各checkpoint中位秒数均值','seconds_mean':'各checkpoint重复均值秒数','seconds_repeat_sample_sd':'checkpoint内计时SD均值(秒)',
 'seconds_min':'checkpoint最小秒数均值','seconds_max':'checkpoint最大秒数均值','repeat_n':'每checkpoint计时重复数',
 'model_batches':'GPU模型批次数','zero_model_queries':'不调模型查询','zero_model_query_pct':'不调模型查询率(%)',
 'candidate_scoring_reduction_pct':'少打分比例(%)','model_batch_reduction_pct':'少GPU批次比例(%)','wall_time_saving_pct':'同checkpoint省时比例(%)',
 'wall_speedup_ratio':'同checkpoint加速倍数','queries_per_second':'查询池/秒','input_candidate_pairs_per_second':'输入配对/秒',
 'model_call_mask_difference_n':'调用掩码差异','threshold_decision_difference_on_common_scored_n':'共同评分接受差异',
 'returned_membership_difference_n':'返回成员差异','returned_rank_difference_n':'返回排名差异','returned_list_changed_query_n':'变化列表查询',
 'score_max_abs_difference':'最大分数差','score_mean_abs_difference':'平均分数差','score_p95_abs_difference':'分数差P95',
 'paired_candidates':'配对行数','scored_by_both_candidates':'共同评分行数','returned_tp_a':'A返回TP','returned_tp_b':'B返回TP','returned_fp_a':'A返回FP','returned_fp_b':'B返回FP',
 'hard_positive_blocked_E_ge3_n':'被3精确项占满阻挡的困难正例','hard_positive_queries_blocked_E_ge3_n':'被占满的困难查询',
 'unrestricted_cap3_hard_oracle_n':'不限精确优先的困难TP上限','exact_priority_cap3_hard_oracle_n':'精确优先困难TP上限','exact_priority_cap3_hard_oracle_recall_pct':'精确优先困难召回上限(%)',
 'cap3_oracle_macro_recall_pct':'三条宏召回上限(%)','cap3_oracle_micro_recall_pct':'三条微召回上限(%)','cap3_oracle_returned_tp_n':'三条返回TP上限',
 'queries_with_more_than3_gold_positives':'超过3正例查询','gold_positive_per_query_max':'单查询最多正例',
 'added_by_nonexact_first_n':'非精确优先新进入条数','added_by_nonexact_first_tp_n':'新进入TP','added_by_nonexact_first_fp_n':'新进入FP','added_by_nonexact_first_exact_tp_n':'新进入精确TP','added_by_nonexact_first_hard_tp_n':'新进入困难TP',
 'removed_by_nonexact_first_n':'被挤出条数','removed_by_nonexact_first_tp_n':'被挤出TP','removed_by_nonexact_first_fp_n':'被挤出FP','removed_by_nonexact_first_exact_tp_n':'被挤出精确TP','removed_by_nonexact_first_hard_tp_n':'被挤出困难TP'
}
FRACTIONS={'precision','recall','f1','returned_precision','returned_micro_recall','macro_recall','hit_returned','wrong_query_rate','no_reference_rejection','semantic_precision','semantic_precision_zero_error_95pct_lower','nonexact_returned_recall','nonexact_positive_query_hit','model_candidate_fraction','pair_precision','pair_recall','pair_f1','returned_f1','max_eligible_recall'}


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(family,name):
    entries=sum((FAM[family][k] for k in ('preferred_summary_csv','seed_or_condition_detail_csv','supporting_csv')),[])
    e=next(x for x in entries if Path(x['path']).name==name);p=Path(e['path']);assert sha(p)==e['sha256'],p
    USED[str(p.relative_to(W))]=e['sha256'];return pd.read_csv(p)
def line(s=''):LINES.append(s)
def fmt(x,k):
    if pd.isna(x):return '—'
    if isinstance(x,str):return METHOD.get(x,x).replace('|','/')
    value=float(x)*(100 if k in FRACTIONS else 1)
    return f'{value:.2f}' if abs(value-round(value))>1e-9 else f'{value:.0f}'
def table(title,frame,keys,metrics):
    assert len(frame)>0,title
    fields=keys+metrics
    assert all(k in frame for k in fields),(title,set(fields)-set(frame))
    line('### '+title);line()
    line('| '+' | '.join(LABEL.get(k,k) for k in fields)+' |')
    line('| '+' | '.join(['---']*len(fields))+' |')
    for _,r in frame.iterrows():line('| '+' | '.join(fmt(r[k],k) for k in fields)+' |')
    line();TABLES.append({'title':title,'rows':len(frame),'keys':keys,'metrics':metrics})
def all_tables(title,frame,keys,metrics,chunk=7):
    for i in range(0,len(metrics),chunk):table(title+f'（{i//chunk+1}）',frame,keys,metrics[i:i+chunk])
def strip_means(frame):
    return frame.rename(columns={k:k[:-5] for k in frame if k.endswith('_mean')})
def long_pivot(frame,keys):
    assert not frame.duplicated(keys+['metric']).any()
    return frame.pivot(index=keys,columns='metric',values='mean').reset_index()
def selected(frame,group):
    return frame.loc[frame.evaluation_group.eq(group)].reset_index(drop=True)


line('所有旧路由、输出容量、困难路径及批次对照表')
line()
line('以下保留各方法均值，不重复列三个seed。百分数以0–100表示，计数是各checkpoint均值，可能为小数；“—”表示未定义或未测。配对判断与最终名单分别列。')
line('有现成218查询汇总的实验用主测试6540对；只有旧220查询汇总的实验明确标为6600对、含额外两组审计。旧路由策略与当前维度分流+精确缓存系统分别展示。')
line()

fam='old_top3_earlystop_system'
line('## A. 原三条早停系统：220查询、6600对')
line()
line('三个原BGE训练checkpoint的平均结果。早停未评分项保持未知，不能报告这个系统的完整配对F1。单查询延迟为旧逐query驻留模型实测，不能与后面连续batch总秒数直接相除。')
line()
d=strip_means(load(fam,'formal_summary_aggregate.csv'))
metrics=[k[:-5] for k in load(fam,'formal_summary_aggregate.csv') if k.endswith('_mean')]
all_tables('原三方法全部名单、调用与非精确指标',d,['policy'],metrics)
lat=strip_means(load(fam,'formal_latency_aggregate.csv'))
table('原三方法逐查询真实延迟',lat,['policy'],['weighted_mean_latency_ms','query_median_latency_ms','query_p95_latency_ms'])
strata=strip_means(load(fam,'exact_count_groups_aggregate.csv'))
table('精确候选数量分层',strata,['policy','exact_n'],['query_n','positive_query_n','returned_precision_pct','macro_recall_at3_pct','hit_at3_pct','model_called_n'])

fam='policy_exploration_caps'
line('## B. 七种容量/接受/排序策略：220查询、6600对')
line()
line('这是既有分数上的策略对照，未测这些七方案分别部署的GPU耗时。“完整名单”不限三条，其名单召回不叫Recall@3；“返回3条”才是Top3。名单F1和完整配对F1不是同一个指标。')
line()
orig=selected(load(fam,'formal_aggregate.csv'),'formal_combined');d=strip_means(orig)
metrics=[k[:-5] for k in orig if k.endswith('_mean')]
all_tables('七方案全部平均指标',d,['policy'],metrics)
vi=load(fam,'validation_identifiability.csv')
v=pd.DataFrame([{'配置总数':int(vi.policy_grid_n.sum()),'每seed配置数均值':vi.policy_grid_n.mean(),'每seed配置数最少':vi.policy_grid_n.min(),'每seed配置数最多':vi.policy_grid_n.max(),'最多非精确验证返回TP':vi.max_returned_nonexact_validation_tp.max(),'有非精确返回的合格配置数':vi.eligible_policies_with_semantic_positive_n.sum(),'合格最大召回(%)':vi.max_eligible_recall.max()*100}])
table('验证网格的可识别性',v,[],list(v.columns))
line('1499是配置数量，不是1499个独立模型；这些Top3验证配置没有实际返回非精确正例，验证预选在本轮落到规则水平。')
line()

fam='selective_gpt6_verifier'
line('## C. 少量独立GPT核验及原全池GPT上下文重放：220查询')
line()
line('新选择性盲判只审查9个匿名查询的25个候选并集，接受2个；下面把这套判断接到各BGE checkpoint名单后计分，不是三轮GPT盲判。旧全池GPT重放单独列；均无API时间/费用实测。只有原规则/BGE早停名单的GPU部分是实测，不能把这些组合称为已实测GPT部署路线。')
line()
raw=selected(load(fam,'summary_aggregate.csv'),'all_formal');d=long_pivot(raw,['policy'])
all_tables('五种名单核验/重放条件全部平均指标',d,['policy'],[k for k in d if k!='policy'])
change=load(fam,'prior_fullpool_and_comparison.csv').groupby('baseline_policy',as_index=False).mean(numeric_only=True)
change=change.rename(columns={'baseline_policy':'policy'}).drop(columns='seed')
table('选择性GPT与全池GPT重放输出差异均值',change,['policy'],[k for k in change if k!='policy'])

fam='exact_pair_route_before_cap_ranking'
line('## D. 不早停的完整配对判断与两种排序：主测试218查询')
line()
line('所有30候选均有判断，配对P/R/F1可用；返回最多3条单独计分。精确优先与非精确优先共享同一接受集合，排序差异不能当作配对分类提升。此处是固定既有分数的CPU重组质量对照，未测两种排序路线的完整GPU部署耗时。GPT为一套全池盲判。')
line()
for name,title in [('full_pair_metrics_aggregate.csv','五方法完整配对指标'),('hard_pair_metrics_aggregate.csv','五方法主范围困难配对指标'),('list_metrics_aggregate.csv','五方法实际Top3与困难Top3指标')]:
    d=selected(load(fam,name),'primary218')
    metrics=[k for k in d if k not in ['evaluation_group','policy','shared_gpt_judgment_n']]
    all_tables(title,d,['policy'],metrics)
trade=selected(load(fam,'ranking_tradeoff_counts_aggregate.csv'),'primary218')
all_tables('非精确优先相对精确优先换入/换出',trade,['evaluation_group'],[k for k in trade if k!='evaluation_group'])
line('主范围非精确优先平均换入12.67个困难真阳性，同时换入7.67个误接受，并挤出20.33个精确真阳性；不能只报告困难覆盖提升而隐藏整体损失。')
line()

fam='cached_fullpool_gpt_replay'
line('## E. 全配对路由接旧全池GPT判断缓存：主测试218查询')
line()
line('两种策略复用同一套既有完整池GPT判断，不是新的少量候选盲判，不是实测API核验方案；没有新增GPT调用和部署计时。三个条件是BGE checkpoint，shared_old_gpt_judgment_n=1不能当三次GPT重复。')
line()
for name,title in [('full_pair_metrics_aggregate.csv','两种缓存重放完整配对'),('hard_pair_metrics_aggregate.csv','两种缓存重放困难配对'),('list_metrics_aggregate.csv','两种缓存重放真实名单')]:
    d=selected(load(fam,name),'primary218')
    all_tables(title,d,['policy'],[k for k in d if k not in ['evaluation_group','policy']])

fam='hard_sample_failure_and_oracles'
line('## F. 困难配对、实际返回、失败路径和容量上限')
line()
line('这里是原标签预定义困难子集：内部锁定23正例，主范围26正例，不是新增600对。标志只用于离线评价；审核列表仍按完整候选池排名，不能删简单项后补困难项。前10指扩大核验候选，最终仍最多3条。')
line()
hard=load(fam,'hard_fullpair.csv')
keep=['rule_exact','gpt6_sol_blind_full_acceptance','bge_zero_shot_base','bge_zero_shot_conflict_refined','bge_hard_base_three_seed_macro_mean','bge_hard_conflict_refined_three_seed_macro_mean']
for group,name in [('locked100','内部锁定23个困难正例'),('primary218','主范围26个困难正例')]:
    d=hard.loc[hard.scope.eq(group)&hard.model.isin(keep)]
    all_tables(name+'：全部六方法完整配对指标',d,['model'],[k for k in d if k not in ['scope','model']])
ret=load(fam,'hard_returned_lists_aggregate.csv')
for group,name in [('primary_heldout','主范围26个困难正例'),('locked','内部锁定23个困难正例')]:
    orig=selected(ret,group);d=strip_means(orig)
    all_tables(name+'：全部七方法实际困难Top3',d,['policy'],[k for k in d if k not in ['evaluation_group','policy'] and not k.endswith('_sample_sd')])
paths=load(fam,'failurepath_counts.csv');paths=paths.loc[paths.evaluation_split.isin(['locked','external','no_reference'])]
pathavg=paths.groupby(['policy','failure_or_success_path'],as_index=False).hard_positive_n.sum()
# All frozen BGE methods have three checkpoints; GPT is one shared workflow.
pathavg['hard_positive_n']=pathavg.apply(lambda r:r.hard_positive_n/(1 if r.policy=='gpt6_sol_fullpool' else 3),axis=1)
pathwide=pathavg.pivot(index='policy',columns='failure_or_success_path',values='hard_positive_n').fillna(0).reset_index()
pathlabels={'returned_hard_positive':'实际返回','bge_threshold_rejected':'BGE阈值拒绝','blocked_by_three_exact_references':'3条精确项占满','accepted_not_returned_after_score_top3':'BGE接受但分数排名挤出','accepted_not_returned_after_cap3':'接受但3条上限挤出','outside_bge_top10':'不在BGE前10候选','gpt_rejected':'GPT拒绝','gpt_accepted_not_returned_in_top3':'GPT接受但未进3条','qwen_threshold_rejected':'Qwen阈值拒绝','nonexact_not_accepted_by_rule':'规则未接受非精确项'}
pathwide=pathwide.rename(columns=pathlabels)
all_tables('主范围困难正例失败/成功路径均值',pathwide,['policy'],[k for k in pathwide if k!='policy'])
oracle=load(fam,'hard_structural_oracles.csv')
oracle=oracle.loc[oracle.evaluation_group.isin(['locked','primary_heldout','external'])]
all_tables('困难Top3结构上限（答案已知的理论上限，不是可部署方法）',oracle,['evaluation_group'],[k for k in oracle if k not in ['evaluation_group','interpretation']])
cap=load('exact_pair_route_before_cap_ranking','cap3_capacity_oracle.csv')
cap=cap.loc[cap.group.isin(['primary218','locked100','WSDOT80'])]
all_tables('整体三条容量上限（非实际方法）',cap,['group'],[k for k in cap if k not in ['group','interpretation']])

fam='runtime_batch_fairness'
line('## G. 实际GPU批次公平性：批大小1/16/64，220查询')
line()
line('三个方法×三个批大小×三个checkpoint×三次重复，共81个真实计时条件。质量各seed单列计算后取均值；时间是每checkpoint三次的中位秒数再取checkpoint均值。此处旧batch设置是1/16/64，不是8/32/64。系统仍是旧三条早停，不是当前维度缓存系统。')
line()
qual=long_pivot(selected(load(fam,'runtime_quality_seed_summary.csv'),'all_formal'),['policy','batch_size'])
all_tables('九种GPU条件全部平均质量指标',qual,['policy','batch_size'],[k for k in qual if k not in ['policy','batch_size']])
time=long_pivot(load(fam,'runtime_timing_seed_summary.csv'),['policy','batch_size'])
all_tables('九种GPU条件全部计时/调用/吞吐指标',time,['policy','batch_size'],[k for k in time if k not in ['policy','batch_size']])
diff=selected(load(fam,'runtime_bf16_differences.csv'),'all_formal')
keys=['comparison_kind','policy_a','batch_a','policy_b','batch_b']
dg=diff.groupby(keys,as_index=False).mean(numeric_only=True).drop(columns='seed')
all_tables('跨批次/策略BF16变化：三checkpoint均值',dg,keys,[k for k in dg if k not in keys],chunk=5)
rep=load(fam,'runtime_repeat_consistency.csv')
line(f'同条件重复一致性：{len(rep)}组repeat对照，接受判断差异总数={int(rep.decision_difference_n.sum())}，返回排名差异总数={int(rep.rank_difference_n.sum())}。跨批次分数可变，但不能把分数变化自动解释为名单质量变化。')
line()
line('这些是已经完成的旧实验对照，不是把不同策略的最佳单项合并成一个新系统。所有GPT判断重复数、未观测候选和理论上限分别保留；没有增加GPU任务或重调阈值。')

for p,h in USED.items():assert sha(W/p)==h,p
out=A/'old_route_and_capacity_tables.md';out.write_text('\n'.join(LINES)+'\n')
qa={'status':'passed_read_only_summary_extraction','table_n':len(TABLES),'table_rows':sum(t['rows'] for t in TABLES),'families':7,'source_hashes_unchanged':True,'new_inference':False,'existing_results_modified':False,'source_csv_sha256':USED,'tables':TABLES,'markdown_sha256':sha(out),'notes':['Runtime actual batch sizes are1/16/64, correcting inventory title8/32/64.','primary218 used where available; old aggregate-only tables220 explicitly retain2auditqueries.','Mean tables only; original individualseed rows are not repeated.','Full-list recall is not mislabeledRecall@3.','k10 expands judgedcandidatebudget; finalmax3 retained.','CachedGPT replay/scoreCPU combinations notmeasuredGPU/APIroutes.']}
(A/'old_route_and_capacity_tables_qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':qa['status'],'tables':len(TABLES),'rows':qa['table_rows'],'csv_n':len(USED),'output':str(out),'sha256':qa['markdown_sha256']},ensure_ascii=False,indent=2))
