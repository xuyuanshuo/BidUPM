#!/usr/bin/env python3
"""Independent standard-library raw GPT comparison arithmetic crosscheck."""
import csv, gzip, hashlib, json, math, statistics
from collections import defaultdict
from pathlib import Path
W=Path(__file__).resolve().parents[3]
O=W/'output/router_research_20261005/final_review_delivery/gpt6_matched_comparison'
B=W/'output/rule_first_system_validation_20261005'
C=W/'output/router_research_20261005/exact_serialization_cache'
checks=[]
def ck(v,n):
    if not v: raise AssertionError(n)
    checks.append(n)
def reader(path):
    with Path(path).open(newline='',encoding='utf-8-sig') as h:return list(csv.DictReader(h))
def close(a,b):return (a is None and (b is None or b=='')) or (a is not None and math.isclose(float(a),float(b),abs_tol=1e-11,rel_tol=0))
mapping=reader(B/'results/gpt6_sol_blind/private_mapping.csv')
keymap={(r['query_key'],r['candidate_key']):r['pair_id'] for r in mapping}
raw=[json.loads(x) for x in (B/'blind_gpt6_sol/outputs/predictions.jsonl').read_text().splitlines()]
label={r['pair_id']:r for r in reader(W/'output/rule_first_system_20261004/results/server/labels.csv')}
source={r['pair_id']:r for r in reader(W/'output/rule_first_system_20261004/results/server/inputs.csv') if r['evaluation_split']!='validation'}
rebuild={}
for p in raw:
    for i in range(30):
        k=f'C{i:02d}'; pid=keymap[p['query_key'],k]
        rebuild[pid]={'prediction':int(k in p['accepted_candidates']),'returned_rank':p['top3'].index(k)+1 if k in p['top3'] else 0,**source[pid],**label[pid]}
ck(len(rebuild)==6600,'Raw GPT rederived 6600 independent candidate decisions')
for r in reader(O/'reconstructed_label_free_predictions.csv'):
    for k in ('prediction','returned_rank'):ck(int(r[k])==rebuild[r['pair_id']][k],'New decision/rank equals raw JSONL')
hardq={r['query_id'] for r in rebuild.values() if r['evaluation_split']=='locked' and r['difficulty']=='hard' and r['final_label']=='1'}
def view(g,r):
    s=r['evaluation_split']
    return {'all220_diagnostic':True,'primary218':s in ('locked','external','no_reference'),'locked100':s=='locked','locked100_hard_pairs':s=='locked' and r['difficulty']=='hard','locked100_hard_positive_full_queries':s=='locked' and r['query_id'] in hardq,'external80':s=='external'}[g]
def calc(rows,hard=False):
    counts=[0,0,0,0]
    qs=defaultdict(list)
    for r in rows:
        y=int(r['final_label']);p=int(r['prediction'])
        counts[{(1,1):0,(0,1):1,(1,0):2,(0,0):3}[y,p]]+=1
        qs[r['evaluation_split'],r['query_id']].append(r)
    tp,fp,fn,tn=counts
    pair=dict(input_pairs=len(rows),positive_n=tp+fn,tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else None,recall=tp/(tp+fn) if tp+fn else None,f1=2*tp/(2*tp+fp+fn),accuracy=(tp+tn)/len(rows))
    rt=rf=0;rec=[];hits=[];nn=nr=0
    for q in qs.values():
        yes=sum(int(r['final_label']) for r in q); t=sum(int(r['final_label']) for r in q if int(r['returned_rank'])>0);n=sum(int(r['returned_rank'])>0 for r in q)
        rt+=t;rf+=n-t
        if yes:rec.append(t/yes);hits.append(int(t>0))
        else:nn+=1;nr+=int(n==0)
    top=dict(query_n=len(qs),positive_query_n=len(rec),positive_n=tp+fn,returned_total_n=rt+rf,returned_tp=rt,returned_fp=rf,returned_precision_known=rt/(rt+rf) if rt+rf else None,micro_recall_at3=rt/(tp+fn),macro_recall_at3=sum(rec)/len(rec),hit_at3=sum(hits)/len(hits),completely_known_no_reference_query_n=None if hard else nn,no_reference_rejected_n=None if hard else nr,no_reference_rejection_rate=None if hard or not nn else nr/nn)
    return pair,top
pair=reader(O/'gpt6_current_main_pair_metrics.csv'); top=reader(O/'gpt6_current_main_actual_top3_metrics.csv')
for p,t in zip(pair,top):
    g=p['group'];ck(g==t['group'],'Pair and Top3 scope align')
    pp,tt=calc([r for r in rebuild.values() if view(g,r)],g=='locked100_hard_pairs')
    for k,v in pp.items():ck(close(v,p[k]),'GPT independent pair metric '+g+'/'+k)
    for k,v in tt.items():ck(close(v,t[k]),'GPT independent actual Top3 metric '+g+'/'+k)
matchedp=reader(O/'matched_pair_quality_comparison.csv'); matchedt=reader(O/'matched_actual_top3_comparison.csv')
ck(len(matchedp)==len(matchedt)==18,'Six scopes times three methods complete')
actual={}
for seed in (20260904,20260905,20260906):
    path=C/'canonical_gpu_actual'/f'predictions_main220_seed_{seed}.csv.gz'
    with gzip.open(path,'rt',newline='') as h:
        groups=defaultdict(list)
        for r in csv.DictReader(h):
            if int(r['repeat'])!=0 or r['condition'] not in ('full_nocache','exact_dimension_exact_cache'):continue
            groups[r['condition']].append({**source[r['pair_id']],**label[r['pair_id']],**r})
    for condition,rows in groups.items():
        ck(len(rows)==6600,'Canonical raw representative repeat full scope')
        for g in (p['group'] for p in pair):actual[seed,condition,g]=calc([r for r in rows if view(g,r)],g=='locked100_hard_pairs')
for p,t in zip(matchedp,matchedt):
    ck(p['method']==t['method'] and p['group']==t['group'],'Matched rows align')
    if p['method'].startswith('GPT'):
        ck(p['run_n']=='1' and t['run_n']=='1','GPT one workflow, no invented replicate')
        for r in (p,t):
            ck(all(v=='' for k,v in r.items() if k.endswith('_sample_sd')),'GPT sampleSD all missing')
            ck(r['measured_time_s']==r['measured_api_cost']=='','GPT time/API fees missing')
        continue
    condition='full_nocache' if p['method'].startswith('Full') else 'exact_dimension_exact_cache'
    ck(p['run_n']==t['run_n']=='3','Canonical checkpoint sample n3')
    for target,which in ((p,0),(t,1)):
        for k in target:
            if k.endswith('_mean'):
                key=k[:-5]
                values=[actual[s,condition,p['group']][which][key] for s in (20260904,20260905,20260906)]
                values=[v for v in values if v is not None]
                ck(close(statistics.mean(values) if values else None,target[k]),'Raw canonical mean '+condition+'/'+p['group']+'/'+key)
                if key+'_sample_sd' in target:ck(close(statistics.stdev(values) if len(values)>1 else None,target[key+'_sample_sd']),'Raw canonical checkpoint SD '+condition+'/'+p['group']+'/'+key)
for name,digest in json.loads((O/'output_sha256.json').read_text()).items():ck(hashlib.sha256((O/name).read_bytes()).hexdigest()==digest,'First-pass artifact hash remains '+name)
result={'status':'passed','checks':len(checks),'independent_method':'standard library raw JSONL + current source IDs/labels; gzip canonical raw repeat0 decisions/ranks; scalar counters and statistics.mean/stdev','new_model_or_gpu_calls':False,'source_and_existing_outputs_modified':False,'coverage':{'gpt_raw_pairs':6600,'canonical_raw_blocks':6,'matched_pair_rows':18,'matched_actual_top3_rows':18},'gpt_primary218_f1':next(r['f1'] for r in pair if r['group']=='primary218'),'gpt_locked100_f1':next(r['f1'] for r in pair if r['group']=='locked100'),'gpt_lockedhard_f1':next(r['f1'] for r in pair if r['group']=='locked100_hard_pairs'),'gpt_external80_f1':next(r['f1'] for r in pair if r['group']=='external80')}
(O/'second_pass_independent_qa.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
