"""Freeze a label-free standalone LLM comparison input; no answers accessed."""
import csv
import hashlib
import json
from pathlib import Path

ROOT=Path('research_workspace/output')
SOURCE=ROOT/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_challenge600.csv'
OUT=ROOT/'router_research_20261005/challenge600_blind_gpt6'
OUT.mkdir(exist_ok=True)
with SOURCE.open(encoding='utf-8-sig',newline='') as stream:
    rows=list(csv.DictReader(stream))
assert len(rows)==600
assert not {'label','final_label','provisional_label','difficulty','generation_rule'} & set(rows[0])
fields=('description','normalized_description','normalized_unit','category','spec_tokens')
records=[{'pair_id':r['pair_id'],**{side:{field:r[f'{side}_{field}'] for field in fields} for side in ('query','candidate')}} for r in rows]
path=OUT/'blind_inputs.json'
path.write_text(json.dumps(records,ensure_ascii=False,separators=(',',':'))+'\n')
manifest={'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'blind_input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
          'pairs':600,'labels_read':False,'ids_unique':len({r['pair_id'] for r in records})==600,
          'baseline':'GPT-6 Sol via explicitly selected Codex subagent, no OpenAI API call',
          'protocol':'All 600 candidate pairs independently judged before construction labels are joined for evaluation; no rule/model scores, construction metadata or answers supplied',
          'timing':'Agent response wall time is not API latency or resident local GPU latency; no API cost measured'}
(OUT/'input_freeze_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print({'pairs':600,'bytes':path.stat().st_size,'sha256':manifest['blind_input_sha256']})
