#!/usr/bin/env python3
"""Independent CPU validation-only recomputation of LoRA epoch/threshold selection."""
import hashlib,json,math
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'results_seed20261005'
PLAN=json.loads((ROOT/'frozen_training_plan.json').read_text())
checks=[];rows=[]
def h(path):
    v=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):v.update(b)
    return v.hexdigest()
def check(name,result,detail=None):
    checks.append({'check':name,'passed':bool(result),'detail':detail})
    if not result:raise AssertionError((name,detail))
def same(a,b):
    if isinstance(a,dict):return isinstance(b,dict) and set(a)==set(b) and all(same(a[k],b[k]) for k in a)
    if a is None:return b is None
    if isinstance(a,(int,float)):return isinstance(b,(int,float)) and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12)
    return a==b

def summary(y,p):
    t=int(np.count_nonzero(p & y));f=int(np.count_nonzero(p & ~y));n=int(np.count_nonzero(~p & y));z=int(np.count_nonzero(~p & ~y))
    return {'tp':t,'fp':f,'fn':n,'tn':z,'precision':t/(t+f) if t+f else None,'recall':t/(t+n) if t+n else None,'f1':2*t/(2*t+f+n) if 2*t+f+n else 0.0}

def recompute(frame,selector):
    scores=frame.score.to_numpy(float);y=frame.final_label.to_numpy(int)==1;hard=frame.difficulty.eq('hard').to_numpy()
    thresholds=np.r_[np.unique(scores),np.nextafter(scores.max(),math.inf)]
    matrix=scores[:,None]>=thresholds[None,:]
    tp=(matrix&y[:,None]).sum(axis=0);fp=(matrix&~y[:,None]).sum(axis=0);fn=y.sum()-tp
    f1=np.divide(2*tp,2*tp+fp+fn,out=np.zeros(len(tp),float),where=(2*tp+fp+fn)>0)
    hp=(matrix[hard]&y[hard,None]).sum(axis=0);hf=(matrix[hard]&~y[hard,None]).sum(axis=0);hn=y[hard].sum()-hp
    h_f1=np.divide(2*hp,2*hp+hf+hn,out=np.zeros(len(hp),float),where=(2*hp+hf+hn)>0)
    obj=f1 if selector=='overall_f1' else .6*f1+.4*h_f1
    precision=np.divide(tp,tp+fp,out=np.zeros(len(tp),float),where=(tp+fp)>0)
    hrec=hp/y[hard].sum();rec=tp/y.sum()
    winner=int(np.lexsort((thresholds,rec,hrec,precision,obj))[-1]);threshold=float(thresholds[winner]);pred=matrix[:,winner]
    return {'selector':selector,'threshold':threshold,'objective':float(obj[winner]),'overall':summary(y,pred),'hard':summary(y[hard],pred[hard])}

execution=json.loads((DATA/'execution_manifest.json').read_text())
check('completed_three_runs',execution['status']=='complete' and len(execution['runs'])==3)
check('no_heldout_data_access_recorded',execution['test_files_read']==[] and not execution['test_gold_used_for_training_or_selection'])
check('plan_and_script_hashes',execution['plan_sha256']==h(ROOT/'frozen_training_plan.json') and execution['script_sha256']==h(ROOT/'train_bge_robust_lora.py'))
for key in ('train_data_unchanged','validation_data_unchanged','base_files_unchanged'):check(key,execution[key])
localval=Path('output/revise3_full_20260920/supplementary/data/evaluation/validation_pairs.csv')
localtrain=Path('output/revise3_full_20260920/supplementary/data/training/training_pairs_semantic_deduplicated.csv')
check('local_canonical_validation_hash',h(localval)==PLAN['validation_sha256'])
check('local_canonical_training_hash',h(localtrain)==PLAN['train_sha256'])
val=pd.read_csv(localval,dtype=str,keep_default_na=False).set_index('pair_id')
train=pd.read_csv(localtrain,dtype=str,keep_default_na=False)
check('input_sizes',len(val)==900 and len(train)==2278)
check('query_split_disjoint',not set(train.query_id)&set(val.query_id))
check('unordered_pair_split_disjoint',not set(train.unordered_pair_key)&set(val.unordered_pair_key))
train_time=val_time=0.0;all_adapters=[]
for run in execution['runs']:
    scheme=run['scheme'];folder=DATA/scheme
    history=json.loads((folder/'training_history.json').read_text());selected=json.loads((folder/'selected_adapters.json').read_text())
    check(scheme+'_history_hash',h(folder/'training_history.json')==run['history_sha256'])
    check(scheme+'_score_hash',h(folder/'validation_epoch_scores.csv')==run['validation_scores_sha256'])
    check(scheme+'_selected_manifest',selected==run['selected'])
    scores=pd.read_csv(folder/'validation_epoch_scores.csv')
    # Stored logits were BF16, then a float32 CSV decimal abbreviation. Restore that original grid.
    decimal=scores.score.to_numpy(np.float32);bits=decimal.view(np.uint32)
    recovered=((bits+np.uint32(0x7fff)+((bits>>np.uint32(16))&np.uint32(1)))&np.uint32(0xffff0000)).view(np.float32)
    check(scheme+'_bf16_csv_recovery_small',bool(np.max(np.abs(decimal-recovered))<1e-6))
    scores['score']=recovered.astype(float)
    check(scheme+'_2700rows',len(scores)==2700 and scores.epoch.nunique()==3)
    parameter=json.loads((folder/'trainable_parameter_manifest.json').read_text())
    check(scheme+'_trainable_only_lora_classifier',parameter['base_frozen'] and all('lora_' in n or '.modules_to_save.' in n for n in parameter['names']))
    check(scheme+'_weights',abs(parameter['class_positive_weight']-(len(train)-train.final_label.astype(int).sum())/train.final_label.astype(int).sum())<1e-6 and parameter['hard_positive_multiplier']==3)
    best={}
    for record in history:
        epoch=record['epoch'];frame=scores[scores.epoch.eq(epoch)].reset_index(drop=True)
        check(f'{scheme}_{epoch}_900ids',len(frame)==900 and frame.pair_id.nunique()==900 and set(frame.pair_id)==set(val.index))
        aligned=val.loc[frame.pair_id]
        check(f'{scheme}_{epoch}_canonical_labels',np.array_equal(frame.final_label.to_numpy(int),aligned.final_label.to_numpy(int)) and np.array_equal(frame.difficulty.to_numpy(str),aligned.difficulty.to_numpy(str)))
        check(f'{scheme}_{epoch}_finite_scores',np.isfinite(frame.score).all())
        adapter=folder/f'adapter_epoch_{epoch}'
        check(f'{scheme}_{epoch}_adapter_only',not (adapter/'model.safetensors').exists() and (adapter/'adapter_model.safetensors').is_file())
        check(f'{scheme}_{epoch}_all_adapter_hashes',all(h(adapter/n)==v for n,v in record['adapter_files_sha256'].items()))
        all_adapters.append(str(adapter));train_time+=record['training_seconds'];val_time+=record['validation_seconds']
        for selector in ('overall_f1','balanced_f1'):
            s=recompute(frame,selector);check(f'{scheme}_{epoch}_{selector}_threshold_objective',same(s,record['selected_thresholds'][selector]))
            check(f'{scheme}_{epoch}_{selector}_predictions',np.array_equal(frame[f'prediction_{selector}'].to_numpy(int),(frame.score>=s['threshold']).to_numpy(int)))
            key=(s['objective'],s['overall']['precision'] or 0,s['hard']['recall'] or 0,-epoch)
            if selector not in best or key>best[selector][0]:best[selector]=(key,epoch,s)
    for selector,(key,epoch,s) in best.items():
        check(scheme+'_'+selector+'_checkpoint_selection',selected[selector]['epoch']==epoch and same(selected[selector]['selection'],s))
        rows.append({'scheme':scheme,'selector':selector,'epoch':epoch,'threshold':s['threshold'],'objective':s['objective'],'overall_precision':s['overall']['precision'],'overall_recall':s['overall']['recall'],'overall_f1':s['overall']['f1'],'hard_precision':s['hard']['precision'],'hard_recall':s['hard']['recall'],'hard_f1':s['hard']['f1'],'tp':s['overall']['tp'],'fp':s['overall']['fp'],'fn':s['overall']['fn'],'hard_tp':s['hard']['tp'],'hard_fp':s['hard']['fp'],'hard_fn':s['hard']['fn'],'trainable_parameters':parameter['parameters'],'adapter_model_sha256':selected[selector]['adapter_files_sha256']['adapter_model.safetensors']})
check('nine_saved_adapters',len(all_adapters)==9)
report={'all_passed':all(c['passed'] for c in checks),'checks':checks,'selected_records':rows,'unique_selected_checkpoints':len({(r['scheme'],r['epoch']) for r in rows}),'training_seconds_sum':train_time,'validation_seconds_sum':val_time,'gpu_rent_cny_per_hour':2.88,'amortized_training_gpu_cny':(train_time+val_time)*2.88/3600,'pricing_scope':'Only observed epoch train+validation GPU sections; load/IO/idle and actual rental invoice excluded.','heldout_data_used':False,'score_csv_numeric_note':'Training logits were BF16 converted to float32. pandas float32 decimal shorthand is recovered to original BF16 grid before independently recomputing thresholds and predictions; no threshold changes.','limitations':['One seed; no uncertainty across new training seeds.','Three schemes tie at selected overall/hard validation metrics; no improvement over old frozen BGE validation point.','Validation hard positives21 cover five concepts; thresholds/checkpoints remain validation-dependent.','Original main test previously viewed; only this new checkpoint selection avoids heldout labels.']}
pd.DataFrame(rows).to_csv(ROOT/'validation_selected_models.csv',index=False)
(ROOT/'training_independent_qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('checks','selected_records')},ensure_ascii=False,indent=2))
