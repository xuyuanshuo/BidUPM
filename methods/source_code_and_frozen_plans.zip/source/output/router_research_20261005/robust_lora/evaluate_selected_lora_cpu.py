#!/usr/bin/env python3
"""Audit all validation-selected LoRA output, then separately evaluate all fixed selectors."""
from pathlib import Path
import argparse,hashlib,json,importlib.util,math
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent
WORK=HERE.parents[2]
FORBIDDEN={'label','final_label','provisional_label','difficulty','final_relevance','final_conflict_type','reference_label','reference_uncertain'}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,obj):Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def require(condition,reason):assert bool(condition),reason

def restore_saved_bf16(values):
    """Restore BF16 grid after legacy float32 CSV decimal abbreviation, CPU only."""
    array=np.asarray(values,dtype=np.float32)
    require(np.isfinite(array).all(),'Nonfinite saved validation score')
    bits=array.view(np.uint32)
    rounded=(bits+np.uint32(0x7fff)+((bits>>np.uint32(16))&np.uint32(1)))&np.uint32(0xffff0000)
    return rounded.view(np.float32).astype(np.float64)

def pure_rank(frame,scores,threshold):
    ranks=np.zeros(len(frame),int)
    if 'query_id' not in frame:return ranks
    for indices in frame.groupby(['evaluation_split','query_id'],sort=False).indices.values():
        eligible=[i for i in indices if scores[i]>=threshold]
        ordered=sorted(eligible,key=lambda i:(-scores[i],str(frame.iloc[i].candidate_id)))[:3]
        ranks[ordered]=np.arange(1,len(ordered)+1)
    return ranks

def main(a):
    prepared=json.loads((HERE/'frozen_cpu_evaluation_plan.json').read_text())
    require(sha(__file__)==prepared['script_sha256'],'Evaluator code changed after freeze')
    infer=json.loads((HERE/'frozen_inference_plan.json').read_text())
    require(sha(HERE/'frozen_inference_plan.json')==prepared['infer_plan_sha256'],'Inference plan changed')
    require(not a.output.exists(),'Do not overwrite earlier evaluation')
    a.output.mkdir(parents=True)
    record={str(Path(__file__).resolve()):sha(__file__),str(HERE/'frozen_inference_plan.json'):sha(HERE/'frozen_inference_plan.json')}
    def protect(path,expected=None):
        value=sha(path);require(expected is None or value==expected,'Unexpected source SHA: '+str(path));record[str(path)]=value
    # Independently selected checkpoint pointers were fixed from900validation before inference.
    training=HERE/'results_seed20261005';run=json.loads((training/'execution_manifest.json').read_text());protect(training/'execution_manifest.json',prepared['training_execution_sha256'])
    groups={}
    for r in run['runs']:
        for selector,v in r['selected'].items():
            key=(r['scheme'],v['epoch']);groups.setdefault(key,{})[selector]=v['selection']
            for name,h in v['adapter_files_sha256'].items():protect(training/r['scheme']/f"adapter_epoch_{v['epoch']}"/name,h)
    require(len(groups)==3,'Unexpected selected unique checkpoint count')
    paths={'main6600':a.source/'inputs.csv','challenge600':a.supplement/'model_inputs_challenge600.csv','alberta_scope_core':a.supplement/'model_inputs_alberta_scope_core.csv'}
    frames={}
    for dataset,path in paths.items():
        protect(path,infer['input_sha256'][dataset]);f=pd.read_csv(path,dtype=str,keep_default_na=False)
        require(not FORBIDDEN&set(f) and not any(c.startswith(('annotator_','adjudicator_')) for c in f),'Answer field in inputs')
        if dataset=='main6600':f=f[f.evaluation_split.ne('validation')].reset_index(drop=True)
        require(len(f)==prepared['dataset_rows'][dataset] and f.pair_id.nunique()==len(f),'Input coverage')
        frames[dataset]=f
    execution=json.loads((a.actual/'execution_manifest.json').read_text());protect(a.actual/'execution_manifest.json')
    require(execution['status']=='complete' and execution['labels_read_for_inference'] is False and execution['thresholds_retuned'] is False and execution['no_test_model_selection'] is True,'Inference not completed label-free/frozen')
    require(execution['script_sha256']==infer['script_sha256'] and execution['infer_plan_sha256']==prepared['infer_plan_sha256'] and execution['settings']==infer['settings'],'Actual runner/plan/settings mismatch')
    require(execution['training_execution_manifest_sha256']==prepared['training_execution_sha256'] and execution['input_sha256']==infer['input_sha256'],'Input/training manifest mismatch')
    require(execution['dataset_rows']==prepared['dataset_rows'] and execution['alberta_core_description_slot_alignment']==infer['alberta_core_description_slot_alignment'],'Scope/slot alignment mismatch')
    outputs={};nrecords=[];seen=set()
    require(len(execution['completed_outputs'])==9,'Expected nine raw score CSV files')
    for item in execution['completed_outputs']:
        group=(item['scheme'],int(item['epoch']));dataset=item['dataset'];modelid=f'{group[0]}_epoch_{group[1]}'
        require(group in groups and dataset in frames and item['selectors']==groups[group],'Changed checkpoint or selector')
        require(item['model_id']==modelid and item['output']==f'scores_{modelid}_{dataset}.csv','Unexpected score filename')
        require((group,dataset) not in seen,'Duplicate model/dataset');seen.add((group,dataset))
        path=a.actual/item['output'];protect(path,item['sha256']);f=pd.read_csv(path,dtype=str,keep_default_na=False)
        source=frames[dataset]
        require(not FORBIDDEN&set(f) and len(f)==len(source)==item['rows'] and f.pair_id.nunique()==len(f) and f.pair_id.tolist()==source.pair_id.tolist(),'Score ID/order/schema coverage')
        for key in ('evaluation_split','query_id','candidate_id','source_year'):
            if key in source:require(f[key].tolist()==source[key].tolist(),'Score identity mismatch: '+key)
        score=f.score.to_numpy(float);require(np.isfinite(score).all(),'Nonfinite exhaustive raw score')
        require(f.model_id.eq(modelid).all() and f.scheme.eq(group[0]).all() and f.epoch.astype(int).eq(group[1]).all(),'Score model identity mismatch')
        for selector,sel in groups[group].items():
            threshold=sel['threshold'];require(f['threshold_'+selector].astype(float).eq(threshold).all(),'Frozen threshold changed')
            require(f['prediction_'+selector].isin(['0','1']).all() and np.array_equal(f['prediction_'+selector].to_numpy(int),(score>=threshold).astype(int)),'Actual prediction not score>=threshold')
            rank=pure_rank(source,score,threshold)
            if 'query_id' in source:require(np.array_equal(f['returned_rank_'+selector].to_numpy(int),rank),'Actual pure score top3 mismatch')
            else:require(not any(c.startswith('returned_rank_') for c in f),'600 unexpectedly has query list ranks')
            o=f[[c for c in ('pair_id','evaluation_split','query_id','candidate_id','source_year') if c in f]].copy();o['prediction']=(score>=threshold).astype(int);o['returned_rank']=rank;o['score']=score
            outputs[(modelid,dataset,selector)]=o
    require(len(seen)==len(groups)*len(frames),'Incomplete unique output grid')
    require(len(execution['numeric_preflight'])==3,'Three numerical preflights expected')
    trainplanpath=HERE/'frozen_training_plan.json';protect(trainplanpath,infer['training_plan_sha256']);trainplan=json.loads(trainplanpath.read_text())
    validationpath=WORK/'output/revise3_full_20260920/supplementary/data/evaluation/validation_pairs.csv';protect(validationpath,trainplan['validation_sha256'])
    validation_ids=pd.read_csv(validationpath,usecols=['pair_id']).pair_id.head(infer['settings']['merge_preflight_rows']).tolist()
    numeric_models=set()
    for q in execution['numeric_preflight']:
        modelid=q['model_id'];matched=[g for g in groups if modelid==f'{g[0]}_epoch_{g[1]}'];require(len(matched)==1,'Unknown merge checkpoint')
        require(modelid not in numeric_models,'Duplicate numerical checkpoint audit');numeric_models.add(modelid)
        group=matched[0];path=a.actual/f'validation_merge_preflight_{modelid}.csv';protect(path);n=pd.read_csv(path)
        require(n.pair_id.tolist()==validation_ids and len(n)==q['rows']==256,'Numerical QA ID/sample contract')
        arrays={c:n[c].to_numpy(float) for c in ['saved_validation_score','reloaded_unmerged_score','merged_score']}
        require(all(np.isfinite(v).all() for v in arrays.values()),'Nonfinite numerical QA')
        saved=restore_saved_bf16(arrays['saved_validation_score']);raw=arrays['reloaded_unmerged_score'];merged=arrays['merged_score']
        delta=float(np.max(np.abs(raw-merged)));dec={k:int(np.sum((raw>=v['threshold'])!=(merged>=v['threshold']))) for k,v in groups[group].items()}
        reloaddec={k:int(np.sum((saved>=v['threshold'])!=(raw>=v['threshold']))) for k,v in groups[group].items()}
        require(all(n==0 for n in reloaddec.values()) and reloaddec==q['saved_vs_reload_decision_differences'],'Reload changed frozen validation decisions')
        require(math.isclose(float(np.max(np.abs(saved-raw))),q['saved_vs_reload_max_abs_difference'],rel_tol=1e-12,abs_tol=1e-12),'Saved/reload score difference mismatch')
        require(math.isclose(delta,q['merge_max_abs_score_difference'],rel_tol=1e-12,abs_tol=1e-12) and dec==q['merge_threshold_decision_differences'],'Numeric merge QA mismatch')
        usable=delta<=infer['settings']['merge_score_max_abs_tolerance'] and all(n==0 for n in dec.values())
        require(q['execution_mode']==('merged_in_memory' if usable else 'unmerged_adapter_fallback') and q['merged_full_base_saved'] is False,'Wrong merge/fallback mode or full base saved')
        nrecords.append(q)
    require(numeric_models=={f'{s}_epoch_{e}' for s,e in groups},'Incomplete numerical checkpoint audit')
    timingpath=a.actual/'timing.csv';protect(timingpath,execution['timing_sha256']);timing=pd.read_csv(timingpath)
    expected={(f'{s}_epoch_{e}',dataset,repeat) for s,e in groups for dataset in frames for repeat in range(3 if dataset=='main6600' else 1)}
    require(len(timing)==15 and not timing[['model_id','dataset','repeat']].duplicated().any() and set(map(tuple,timing[['model_id','dataset','repeat']].to_numpy()))==expected,'15 actual timing rows/grid expected')
    require(np.isfinite(timing.seconds).all() and timing.seconds.gt(0).all(),'Invalid actual timing')
    mode_by_model={row['model_id']:row['execution_mode'] for row in nrecords}
    for t in timing.to_dict('records'):
        require(t['rows']==prepared['dataset_rows'][t['dataset']]==t['model_candidate_calls'],'Exhaustive actual calls/counts differ')
        require(t['execution_mode']==mode_by_model[t['model_id']],'Actual timing mode differs from numerical merge audit')
    audit={'all_passed':True,'phase':'all_nine_actual_output_files_and_raw_ranks_verified_before_label_access','labels_read':False,'selected_unique_checkpoints':3,'score_csv_files':9,'actual_timing_rows':15,'numeric_preflight':nrecords,'source_hashes':record,'test_selection':False,'limits':['Single training seed; two selectors share same checkpoint/threshold in all three schemes and are not independent replications.','Merged/unmerged equality is checked on256validation inputs only; scores on all evaluation rows are actual runtime values.','Main three global batch64 repetitions; supplemental one per model. Timing excludes imports/load/merge QA/retrieval; no API cost or interactive latency.']}
    dump(a.output/'prelabel_integrity.json',audit)
    if not a.evaluate_labels:print('ALL_OUTPUT_AUDIT_PASS_NO_LABEL_READ');return
    generic=HERE.parent/'generic_unit_gate/evaluate_all_source_actual_cpu.py';protect(generic,prepared['metric_definitions_script_sha256'])
    spec=importlib.util.spec_from_file_location('generic_metrics',generic);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    labelpaths={'main6600':a.source/'labels.csv','challenge600':WORK/'output/internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv','alberta_scope_core':HERE.parent/'rule_verification/alberta_reference_index.csv'}
    labels={}
    for name,path in labelpaths.items():
        protect(path,prepared['reference_sha256'][name])
        cols={'main6600':['pair_id','final_label','difficulty'],'challenge600':['pair_id','provisional_label'],'alberta_scope_core':['pair_id','reference_label','reference_uncertain']}[name]
        label=pd.read_csv(path,dtype=str,keep_default_na=False,usecols=cols);label=label[label.pair_id.isin(set(frames[name].pair_id))]
        require(len(label)==len(frames[name]) and label.pair_id.nunique()==len(label),'Reference incomplete or duplicated')
        field={'main6600':'final_label','challenge600':'provisional_label','alberta_scope_core':'reference_label'}[name];require(label[field].isin(['0','1']).all(),'Nonbinary reference')
        label['label']=label[field].astype(int);label['uncertain']=label.reference_uncertain.eq('1') if 'reference_uncertain' in label else False
        if 'difficulty' not in label:label['difficulty']=''
        if name=='alberta_scope_core':require(label.uncertain.sum()==56,'Alberta56uncertain changed')
        labels[name]=label[['pair_id','label','uncertain','difficulty']]
    pair=[];top=[]
    for (modelid,dataset,selector),out in outputs.items():
        joined=out.merge(labels[dataset],on='pair_id',how='left',validate='one_to_one');require(len(joined)==len(out) and joined.label.notna().all(),'Reference join changed coverage')
        alias={'main6600':'main220','challenge600':'challenge600','alberta_scope_core':'alberta_scope_core'}[dataset]
        for scope,subset in m.evaluation_views(alias,joined):
            identity={'model_id':modelid,'dataset':dataset,'selector':selector,'scope':scope,'label_source':prepared['label_source'][dataset]}
            pair.append({**identity,**m.pair_metrics(subset)});tm=m.top3_metrics(subset)
            if scope=='locked100_hard_pairs':
                for key in ('completely_known_no_reference_query_n','no_reference_rejected_n','no_reference_rejection_rate'):tm[key]=None
                tm['scope_note']='Frozen hard pairs retain actual full-pool ranks; easy/other slots never refilled.'
            top.append({**identity,**tm})
    pd.DataFrame(pair).to_csv(a.output/'pair_metrics_all_frozen_selectors.csv',index=False);pd.DataFrame(top).to_csv(a.output/'actual_pure_top3_metrics_all_frozen_selectors.csv',index=False)
    trows=[]
    for (modelid,dataset),part in timing.groupby(['model_id','dataset'],sort=False):
        seconds=float(part.seconds.median());f=frames[dataset];queries=f.groupby(['evaluation_split','query_id']).ngroups if 'query_id' in f else 0
        trows.append({'model_id':modelid,'dataset':dataset,'actual_repeats':len(part),'full_batch_seconds_median':seconds,'full_batch_cny_2_88_per_hour':seconds*2.88/3600,'rows':len(f),'query_pools':queries,'model_candidate_calls':len(f),'cny_per1000queries_throughput':seconds/queries*1000*2.88/3600 if queries else None,'execution_mode':part.execution_mode.iloc[0]})
    pd.DataFrame(trows).to_csv(a.output/'actual_full_batch_timing_by_model.csv',index=False)
    for path,h in record.items():require(sha(Path(path))==h,'Protected source changed during evaluation')
    dump(a.output/'evaluation_integrity.json',{'all_passed':True,'labels_joined_after_output_audit':True,'test_selection':False,'source_hashes_unchanged':True,'source_hashes':record,'selected_models_all_reported':3,'training_seeds':1,'selectors_not_independent_replicates':True,'label_source':prepared['label_source'],'known_alberta_uncertain_rows_preserved_in_list_slots':56,'pair_metric_rows':len(pair),'list_metric_rows':len(top),'timing_summary_rows':len(trows)})
    print('ALL_METRICS_COMPLETE_ALL_FROZEN_MODELS_NO_TEST_SELECTION')

def self_test():
    threshold=-1.0546875
    saved=restore_saved_bf16(np.asarray([-1.0546875,0.29882812,5.34375,-0.98046875]))
    require(np.array_equal(saved,np.asarray([-1.0546875,0.298828125,5.34375,-0.98046875])),'Saved BF16 grid reconstruction')
    f=pd.DataFrame({'evaluation_split':['x']*4+['y']*2,'query_id':['q']*6,'candidate_id':['d','a','b','c','a','b']})
    rank=pure_rank(f,np.asarray([1.,1.,1.,1.,2.,-2.]),0.)
    require(rank.tolist()==[0,1,2,3,1,0],'Pure score tie, threshold and split grouping')
    require(not pure_rank(pd.DataFrame({'pair_id':['a','b']}),np.asarray([1.,2.]),0.).any(),'600 no pool no ranking')
    generic=HERE.parent/'generic_unit_gate/evaluate_all_source_actual_cpu.py'
    spec=importlib.util.spec_from_file_location('generic_metrics_synthetic',generic);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    x=f.copy();x['prediction']=1;x['returned_rank']=rank;x['label']=[1,0,1,1,1,0];x['uncertain']=[False,True,False,False,False,False]
    pm=m.pair_metrics(x);tm=m.top3_metrics(x)
    require(pm['tp']==4 and pm['fp']==1 and pm['uncertain_excluded']==1,'Synthetic known-only pair counts')
    require(tm['returned_uncertain_n']==1 and tm['returned_tp']==3 and tm['micro_recall_at3']==.75,'Uncertain slot stays occupied')
    require(tm['macro_recall_at3']==(2/3+1)/2 and tm['hit_at3']==1,'Macro query recall differs from micro recall')
    for t in [-1.0546875,-0.98046875,5.34375]:require(np.array_equal(saved>=t,restore_saved_bf16(saved)>=t),'Frozen threshold grid unchanged')
    print(json.dumps({'self_tests_passed':8,'actual_outputs_read':False,'real_reference_labels_read':False}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--actual',type=Path,default=HERE/'blind_inference_seed20261005');p.add_argument('--source',type=Path,default=WORK/'output/rule_first_system_20261004/results/server');p.add_argument('--supplement',type=Path,default=WORK/'output/paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs');p.add_argument('--output',type=Path,default=HERE/'blind_inference_cpu_evaluation');p.add_argument('--evaluate-labels',action='store_true');p.add_argument('--self-test',action='store_true');args=p.parse_args()
    if args.self_test:self_test()
    else:main(args)
