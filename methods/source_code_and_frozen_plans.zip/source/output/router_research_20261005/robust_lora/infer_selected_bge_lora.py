#!/usr/bin/env python3
"""Exhaustive label-free inference of validation-selected BGE LoRA checkpoints."""
from __future__ import annotations
import argparse,gc,json,os,time
from pathlib import Path
os.environ.setdefault('HF_HUB_OFFLINE','1');os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np
import pandas as pd
import torch
from transformers import AutoModelForSequenceClassification,AutoTokenizer
from peft import PeftModel
from train_bge_robust_lora import render,sha,dump,SCHEMES,SUFFIXES

FORBIDDEN={'final_label','label','training_label','difficulty','final_relevance','final_conflict_type',
           'provisional_label','proposed_label','annotator_a_label','annotator_b_label','adjudicator_label'}
FIELDS=[f'{side}_{suffix}' for side in ('query','candidate') for suffix in SUFFIXES]

def read_selections(training,trainplan):
    execution=json.loads((training/'execution_manifest.json').read_text())
    assert execution['status']=='complete' and execution['test_files_read']==[]
    assert execution['plan_sha256']==sha(trainplan)
    assert execution['script_sha256']==sha(Path(__file__).parent/'train_bge_robust_lora.py')
    groups={}
    for run in execution['runs']:
        scheme=run['scheme'];assert scheme in SCHEMES
        selected=json.loads((training/scheme/'selected_adapters.json').read_text())
        assert selected==run['selected']
        assert sha(training/scheme/'validation_epoch_scores.csv')==run['validation_scores_sha256']
        assert sha(training/scheme/'training_history.json')==run['history_sha256']
        for selector,selection in selected.items():
            checkpoint=Path(selection['adapter_directory']);epoch=selection['epoch']
            for name,h in selection['adapter_files_sha256'].items():assert sha(checkpoint/name)==h
            key=(scheme,epoch)
            if key not in groups:groups[key]={'scheme':scheme,'epoch':epoch,'checkpoint':checkpoint,
                'adapter_files_sha256':selection['adapter_files_sha256'],'selectors':{}}
            groups[key]['selectors'][selector]=selection['selection']
    assert len(execution['runs'])==3 and 3<=len(groups)<=6
    return execution,[groups[k] for k in sorted(groups)]

def pure_rank(frame,scores,threshold):
    rank=np.zeros(len(frame),dtype=np.int8)
    if 'query_id' not in frame or 'candidate_id' not in frame:return rank
    keys=['evaluation_split','query_id'] if 'evaluation_split' in frame else ['query_id']
    ids=frame.candidate_id.to_numpy(str)
    for _,ix in frame[keys].groupby(keys,sort=False).indices.items():
        eligible=ix[scores[ix]>=threshold]
        ordering=np.lexsort((ids[eligible],-scores[eligible]))
        winners=eligible[ordering][:3];rank[winners]=np.arange(1,len(winners)+1)
    return rank

@torch.inference_mode()
def scores_only(model,tok,frame,scheme,settings):
    rows=frame.to_dict('records')
    q=[render(r,'query',scheme) for r in rows];c=[render(r,'candidate',scheme) for r in rows]
    chunks=[];tokens=0;bs=settings['batch_size']
    for lo in range(0,len(frame),bs):
        enc=tok(q[lo:lo+bs],c[lo:lo+bs],padding=True,truncation=True,
                max_length=settings['max_length'],return_tensors='pt')
        tokens+=int(enc['attention_mask'].sum());enc={k:v.to('cuda') for k,v in enc.items()}
        with torch.autocast('cuda',dtype=torch.bfloat16):z=model(**enc).logits.reshape(-1)
        chunks.append(z.float().cpu().numpy())
    scores=np.concatenate(chunks);assert len(scores)==len(frame) and np.isfinite(scores).all()
    return scores,tokens

def load_adapter(basepath,checkpoint):
    base=AutoModelForSequenceClassification.from_pretrained(basepath,local_files_only=True,
                torch_dtype=torch.float32,low_cpu_mem_usage=True).to('cuda')
    return PeftModel.from_pretrained(base,checkpoint,is_trainable=False).eval()

def prepare_model(group,basepath,tok,validation_inputs,training,settings):
    model=load_adapter(basepath,group['checkpoint'])
    sample=validation_inputs.head(settings['merge_preflight_rows']).reset_index(drop=True)
    unmerged,_=scores_only(model,tok,sample,group['scheme'],settings)
    reference=pd.read_csv(training/group['scheme']/'validation_epoch_scores.csv',
            usecols=['pair_id','epoch','score'])
    reference=reference[reference.epoch.eq(group['epoch'])].set_index('pair_id').loc[sample.pair_id,'score'].to_numpy(float)
    # Float32 CSV shorthand can truncate BF16 decimal digits at a selected threshold.
    # Recover the originally measured BF16 logit grid; never change the threshold.
    reference=torch.as_tensor(reference,dtype=torch.float32).to(torch.bfloat16).float().numpy()
    calibration_checks={name:int(np.sum((unmerged>=sel['threshold'])!=(reference>=sel['threshold']))) for name,sel in group['selectors'].items()}
    assert all(n==0 for n in calibration_checks.values()),('Adapter reload changed frozen validation decisions',calibration_checks)
    merged=model.merge_and_unload(safe_merge=True).eval()
    merged_scores,_=scores_only(merged,tok,sample,group['scheme'],settings)
    maxdiff=float(np.max(np.abs(unmerged-merged_scores)))
    merged_decision_difference={name:int(np.sum((unmerged>=sel['threshold'])!=(merged_scores>=sel['threshold']))) for name,sel in group['selectors'].items()}
    use_merged=maxdiff<=settings['merge_score_max_abs_tolerance'] and all(n==0 for n in merged_decision_difference.values())
    mode='merged_in_memory' if use_merged else 'unmerged_adapter_fallback'
    comparison=pd.DataFrame({'pair_id':sample.pair_id,'saved_validation_score':reference,
            'reloaded_unmerged_score':unmerged.astype(np.float64),'merged_score':merged_scores.astype(np.float64)})
    if not use_merged:
        del merged,model;gc.collect();torch.cuda.empty_cache()
        model=load_adapter(basepath,group['checkpoint'])
    else:model=merged
    qa={'rows':len(sample),'sample_selection':'first256 original validation input rows; no gold-conditioned selection',
        'saved_vs_reload_max_abs_difference':float(np.max(np.abs(unmerged-reference))),
        'saved_vs_reload_decision_differences':calibration_checks,'merge_max_abs_score_difference':maxdiff,
        'merge_threshold_decision_differences':merged_decision_difference,
        'tolerance_frozen_before_inference':settings['merge_score_max_abs_tolerance'],'execution_mode':mode,
        'merged_full_base_saved':False,'equivalence_scope':'256 validation rows only; not a proof of identical scores for every unseen input'}
    return model,qa,comparison

def main(a):
    inferplan=json.loads(a.plan.read_text());trainplan=json.loads(a.training_plan.read_text())
    settings=inferplan['settings']
    assert sha(__file__)==inferplan['script_sha256']
    assert sha(Path(__file__).parent/'train_bge_robust_lora.py')==inferplan['training_script_sha256']
    assert sha(a.training_plan)==inferplan['training_plan_sha256']
    execution,groups=read_selections(a.training_output,a.training_plan)
    datasets={};inputhash={}
    for name,path,n in [('main6600',a.source/'inputs.csv',6600),
                        ('challenge600',a.supplemental_inputs/'model_inputs_challenge600.csv',600),
                        ('alberta_scope_core',a.supplemental_inputs/'model_inputs_alberta_scope_core.csv',67635)]:
        assert sha(path)==inferplan['input_sha256'][name]
        frame=pd.read_csv(path,dtype=str,keep_default_na=False)
        assert not set(frame)&FORBIDDEN
        assert not any(col.startswith(('annotator_','adjudicator_')) for col in frame)
        assert set(FIELDS)<=set(frame)
        if name=='main6600':frame=frame[frame.evaluation_split.ne('validation')].reset_index(drop=True)
        assert len(frame)==n and frame.pair_id.nunique()==n
        if name=='alberta_scope_core':
            # Match the preregistered core slots used by old BGE and Qwen baselines.
            # This only harmonizes punctuation/formatting; main600 and training remain unchanged.
            for side in ('query','candidate'):
                frame[f'{side}_description']=frame[f'{side}_normalized_description']
        datasets[name]=frame;inputhash[name]=sha(path)
    valpath=Path(trainplan['validation_path'])
    assert sha(valpath)==trainplan['validation_sha256']
    validation_inputs=pd.read_csv(valpath,dtype=str,keep_default_na=False,usecols=['pair_id',*FIELDS])
    assert not set(validation_inputs)&FORBIDDEN and len(validation_inputs)==900
    preflight={'training_execution_manifest_sha256':sha(a.training_output/'execution_manifest.json'),
               'unique_selected_checkpoints':len(groups),'selected_models':[{'scheme':g['scheme'],'epoch':g['epoch'],
               'selectors':g['selectors'],'adapter_files_sha256':g['adapter_files_sha256']} for g in groups],
               'input_sha256':inputhash,'dataset_rows':{name:len(f) for name,f in datasets.items()},
               'labels_read_for_inference':False,'thresholds_retuned':False,'no_test_model_selection':True,
               'alberta_core_description_slot_alignment':inferplan['alberta_core_description_slot_alignment']}
    if a.check_inputs:print(json.dumps(preflight,ensure_ascii=False,indent=2));return
    assert not a.output.exists(),'Refusing to overwrite earlier output'
    a.output.mkdir(parents=True)
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    for name,h in trainplan['base_files_sha256'].items():assert sha(Path(trainplan['base_model_path'])/name)==h
    tok=AutoTokenizer.from_pretrained(trainplan['base_model_path'],local_files_only=True)
    manifest={**preflight,'status':'running','script_sha256':sha(__file__),'infer_plan_sha256':sha(a.plan),
        'gpu':torch.cuda.get_device_name(0),'settings':settings,'completed_outputs':[],'numeric_preflight':[],
        'timing_scope':'Synchronized resident model: serialize/tokenize/GPU/CPU transfer/threshold/pure-BGE top3 ranking. Excludes model loading/merge QA, CSV IO, candidate retrieval, source preprocessing. Main repeats3, supplements1.',
        'routing':'No rule/gate; exhaustive raw logits for all pairs; system compositions occur later without selecting thresholds.',
        'rank_policy':'Pure model score descending then candidate ID; main and Alberta max3 per query pool; challenge600 has no query pools.'}
    dump(a.output/'execution_manifest.json',manifest);timing=[]
    for group in groups:
        model_id=f"{group['scheme']}_epoch_{group['epoch']}"
        started=time.perf_counter()
        model,numeric,comparison=prepare_model(group,trainplan['base_model_path'],tok,validation_inputs,a.training_output,settings)
        torch.cuda.synchronize();numeric['load_and_numerical_preflight_seconds']=time.perf_counter()-started
        numeric['model_id']=model_id;comparison.to_csv(a.output/f'validation_merge_preflight_{model_id}.csv',index=False)
        manifest['numeric_preflight'].append(numeric);dump(a.output/'execution_manifest.json',manifest)
        scores_only(model,tok,datasets['main6600'].head(64),group['scheme'],settings)
        for name,frame in datasets.items():
            repeats=settings['main_repeats'] if name=='main6600' else settings['supplement_repeats']
            reference=None
            for repeat in range(repeats):
                torch.cuda.synchronize();start=time.perf_counter()
                scores,tokens=scores_only(model,tok,frame,group['scheme'],settings)
                metadata=[key for key in ['pair_id','evaluation_split','query_id','source_year','candidate_id'] if key in frame]
                out=frame[metadata].copy();out['model_id']=model_id;out['scheme']=group['scheme'];out['epoch']=group['epoch'];out['score']=scores.astype(np.float64)
                for selector,selection in group['selectors'].items():
                    threshold=selection['threshold'];out[f'threshold_{selector}']=threshold
                    out[f'prediction_{selector}']=(scores>=threshold).astype(int)
                    if 'query_id' in frame:out[f'returned_rank_{selector}']=pure_rank(frame,scores,threshold)
                torch.cuda.synchronize();seconds=time.perf_counter()-start
                timing.append({'model_id':model_id,'scheme':group['scheme'],'epoch':group['epoch'],'dataset':name,
                    'repeat':repeat,'rows':len(frame),'seconds':seconds,'prompt_tokens':tokens,'model_candidate_calls':len(frame),
                    'execution_mode':numeric['execution_mode']})
                decisioncols=[c for c in out if c.startswith(('prediction_','returned_rank_'))]
                if reference is None:
                    reference=out[decisioncols].to_numpy().copy()
                    path=a.output/f'scores_{model_id}_{name}.csv';out.to_csv(path,index=False)
                    manifest['completed_outputs'].append({'model_id':model_id,'scheme':group['scheme'],'epoch':group['epoch'],
                        'dataset':name,'selectors':group['selectors'],'rows':len(frame),'output':path.name,'sha256':sha(path)})
                else:assert np.array_equal(reference,out[decisioncols].to_numpy()),'Repeat decisions/ranks changed'
                pd.DataFrame(timing).to_csv(a.output/'timing.csv',index=False);dump(a.output/'execution_manifest.json',manifest)
                print('FINISH',model_id,name,repeat,round(seconds,3),numeric['execution_mode'],flush=True)
        del model;gc.collect();torch.cuda.empty_cache()
    assert len(manifest['completed_outputs'])==len(groups)*3
    assert len(timing)==len(groups)*(settings['main_repeats']+2*settings['supplement_repeats'])
    manifest['status']='complete';manifest['timing_sha256']=sha(a.output/'timing.csv')
    dump(a.output/'execution_manifest.json',manifest);print('ALL_COMPLETE',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--plan',required=True,type=Path)
    p.add_argument('--training-plan',required=True,type=Path);p.add_argument('--training-output',required=True,type=Path)
    p.add_argument('--source',required=True,type=Path);p.add_argument('--supplemental-inputs',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path);p.add_argument('--check-inputs',action='store_true')
    main(p.parse_args())
