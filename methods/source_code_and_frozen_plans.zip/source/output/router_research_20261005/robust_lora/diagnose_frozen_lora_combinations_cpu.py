#!/usr/bin/env python3
"""Separately frozen, score-reuse diagnostics; no GPU routing/time claim."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
GENERIC = HERE.parent / 'generic_unit_gate'
POLICIES = ('pure_lora', 'exact_accept_lora', 'exact_accept_dimension_veto_lora')
ROWS = {'main6600': 6600, 'challenge600': 600, 'alberta_scope_core': 67635}


def require(condition, message):
    if not bool(condition):
        raise AssertionError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def combined(exact, dimension, score, threshold, policy):
    rule = np.asarray(exact, bool) if policy != 'pure_lora' else np.zeros(len(score), bool)
    reject = ~rule & np.asarray(dimension, bool) if policy.endswith('dimension_veto_lora') else np.zeros(len(score), bool)
    called = ~rule & ~reject
    passed_score = np.where(called, score, np.nan)
    prediction = rule | (called & (score >= threshold))
    return rule, reject, called, passed_score, prediction


def main(args):
    plan_path = HERE / 'frozen_cpu_combination_diagnostic_plan.json'
    if args.freeze_plan:
        require(not plan_path.exists(), 'Never overwrite previous frozen diagnostic plan')
        pure = json.loads((HERE / 'frozen_cpu_evaluation_plan.json').read_text())
        dump(plan_path, {'status': 'frozen_before_LoRA_unseen_score_or_reference_evaluation',
                        'created_utc': datetime.now(timezone.utc).isoformat(),
                        'script_sha256': sha(__file__),
                        'pure_cpu_evaluation_plan_sha256': sha(HERE / 'frozen_cpu_evaluation_plan.json'),
                        'generic_metric_sha256': sha(GENERIC / 'evaluate_all_source_actual_cpu.py'),
                        'generic_dimension_sha256': sha(GENERIC / 'generic_unit_gate.py'),
                        'ontology_sha256': sha(GENERIC / 'unit_dimension_ontology.json'),
                        'policies': list(POLICIES), 'dataset_rows': ROWS,
                        'all_three_schemes_and_both_frozen_selectors': True,
                        'new_threshold_or_checkpoint_selection': False,
                        'original_reference_sha256': pure['reference_sha256'],
                        'limits': ['CPU reuse of already measured exhaustive scores; not new routed GPU execution.',
                                   'Different routed batches may change BF16 numerical scores; actual routed quality and timing are not measured here.',
                                   'All schemes and selectors reported, no test winner selected.',
                                   'No GPU timing, monetary savings or speedup claimed from call-count diagnostics.']})
        print('COMBINATION_PLAN_FROZEN_NO_ACTUAL_OR_LABEL_READ')
        return
    plan = json.loads(plan_path.read_text())
    require(sha(__file__) == plan['script_sha256'], 'Diagnostic script changed after freeze')
    require(sha(HERE / 'frozen_cpu_evaluation_plan.json') == plan['pure_cpu_evaluation_plan_sha256'], 'Pure evaluation plan changed')
    for filename, field in [('evaluate_all_source_actual_cpu.py', 'generic_metric_sha256'),
                            ('generic_unit_gate.py', 'generic_dimension_sha256'),
                            ('unit_dimension_ontology.json', 'ontology_sha256')]:
        require(sha(GENERIC / filename) == plan[field], 'Frozen generic helper changed: ' + filename)
    require(not args.output.exists(), 'Do not overwrite diagnostic output')
    require((args.pure_evaluation / 'evaluation_integrity.json').is_file(), 'First finish full pure-model integrity/evaluation')
    prior = json.loads((args.pure_evaluation / 'prelabel_integrity.json').read_text())
    completed = json.loads((args.pure_evaluation / 'evaluation_integrity.json').read_text())
    require(prior['all_passed'] and prior['score_csv_files'] == 9 and prior['actual_timing_rows'] == 15,
            'Pure actual output audit incomplete')
    require(completed['all_passed'] and completed['test_selection'] is False and completed['selected_models_all_reported'] == 3,
            'Pure-model evaluation incomplete/selected on test')
    protected = dict(prior['source_hashes'])
    for path, digest in protected.items():
        require(sha(path) == digest, 'Prior protected prelabel source changed')
    metric = module('lora_combination_frozen_metrics', GENERIC / 'evaluate_all_source_actual_cpu.py')
    gate = module('lora_combination_frozen_dimensions', GENERIC / 'generic_unit_gate.py')
    pure_plan = json.loads((HERE / 'frozen_cpu_evaluation_plan.json').read_text())
    execution = json.loads((args.actual / 'execution_manifest.json').read_text())
    paths = {'main6600': args.source / 'inputs.csv', 'challenge600': args.supplement / 'model_inputs_challenge600.csv',
             'alberta_scope_core': args.supplement / 'model_inputs_alberta_scope_core.csv'}
    frames, masks, outputs, call_rows = {}, {}, [], []
    for dataset, path in paths.items():
        require(str(path) in protected and sha(path) == protected[str(path)], 'Input not in prior complete audit')
        frame = pd.read_csv(path, dtype=str, keep_default_na=False)
        if dataset == 'main6600':
            frame = frame.loc[frame.evaluation_split.ne('validation')].reset_index(drop=True)
        require(len(frame) == ROWS[dataset] and frame.pair_id.nunique() == len(frame), 'Diagnostic input coverage')
        frames[dataset] = frame
        exact, dimension = metric.independent_exact(frame), np.asarray(gate.dimension_conflict_mask(frame), bool)
        require(not (exact & dimension).any(), 'Exact/dimension conflict')
        masks[dataset] = exact, dimension
    for item in execution['completed_outputs']:
        dataset, model_id = item['dataset'], item['model_id']
        path = args.actual / item['output']
        require(sha(path) == item['sha256'] and str(path) in protected, 'Raw actual score was not independently audited')
        raw = pd.read_csv(path, dtype=str, keep_default_na=False)
        frame = frames[dataset]
        require(raw.pair_id.tolist() == frame.pair_id.tolist(), 'Output identity changed')
        score = raw.score.to_numpy(float)
        require(np.isfinite(score).all(), 'Invalid raw score')
        for selector, selected in item['selectors'].items():
            threshold = selected['threshold']
            for policy in POLICIES:
                rule, reject, called, rank_score, prediction = combined(*masks[dataset], score, threshold, policy)
                rank = metric.independent_rank(frame, rule, rank_score, threshold)
                out = raw[[field for field in ['pair_id', 'evaluation_split', 'query_id', 'candidate_id', 'source_year'] if field in raw]].copy()
                for field, value in {'model_id': model_id, 'dataset': dataset, 'selector': selector,
                                     'policy': policy, 'threshold': threshold}.items():
                    out[field] = value
                out['prediction'], out['returned_rank'] = prediction.astype(int), rank
                out['exact_match'], out['dimension_rejected'], out['model_called'] = rule.astype(int), reject.astype(int), called.astype(int)
                outputs.append(out)
                call_rows.append({'model_id': model_id, 'dataset': dataset, 'selector': selector, 'policy': policy,
                                  'input_rows': len(frame), 'exact_accepted_pairs': int(rule.sum()),
                                  'dimension_rejected_pairs': int(reject.sum()), 'candidate_calls_if_reused_scores_route': int(called.sum()),
                                  'actual_new_routed_GPU_inference': False, 'timing_measured': False})
    require(len(outputs) == 54 and sum(len(out) for out in outputs) == sum(ROWS.values()) * 3 * 2 * 3,
            'Incomplete all-model/dataset/selector/policy output grid')
    args.output.mkdir(parents=True)
    predictions_path = args.output / 'all_fixed_combination_predictions_before_reference.csv.gz'
    pd.concat(outputs, ignore_index=True).to_csv(predictions_path, index=False, compression='gzip')
    dump(args.output / 'predictions_frozen_before_reference.json', {'predictions_sha256': sha(predictions_path),
         'combination_plan_sha256': sha(plan_path), 'method_blocks': len(outputs),
         'rows': sum(len(out) for out in outputs), 'labels_read_in_this_diagnostic': False, 'no_test_selection': True})
    pd.DataFrame(call_rows).to_csv(args.output / 'candidate_call_count_diagnostic_no_timing.csv', index=False)
    # Only after all predeclared combinations have been frozen, read reference values.
    reference_paths = {'main6600': args.source / 'labels.csv',
                       'challenge600': WORK / 'output/internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv',
                       'alberta_scope_core': HERE.parent / 'rule_verification/alberta_reference_index.csv'}
    labels = {}
    for dataset, path in reference_paths.items():
        require(sha(path) == plan['original_reference_sha256'][dataset], 'Reference version changed')
        columns = {'main6600': ['pair_id', 'final_label', 'difficulty'], 'challenge600': ['pair_id', 'provisional_label'],
                   'alberta_scope_core': ['pair_id', 'reference_label', 'reference_uncertain']}[dataset]
        label = pd.read_csv(path, dtype=str, keep_default_na=False, usecols=columns)
        label = label.loc[label.pair_id.isin(set(frames[dataset].pair_id))].copy()
        require(len(label) == ROWS[dataset] and label.pair_id.nunique() == len(label), 'Reference coverage')
        field = {'main6600': 'final_label', 'challenge600': 'provisional_label', 'alberta_scope_core': 'reference_label'}[dataset]
        require(label[field].isin(['0', '1']).all(), 'Reference must be binary')
        label['label'] = label[field].astype(int)
        label['uncertain'] = label.reference_uncertain.eq('1') if 'reference_uncertain' in label else False
        if 'difficulty' not in label:
            label['difficulty'] = ''
        if dataset == 'alberta_scope_core':
            require(int(label.uncertain.sum()) == 56, 'Unknown reference count changed')
        labels[dataset] = label[['pair_id', 'label', 'uncertain', 'difficulty']]
    pair_rows, list_rows = [], []
    for out in outputs:
        first = out.iloc[0]
        dataset = first.dataset
        joined = out.merge(labels[dataset], on='pair_id', how='left', validate='one_to_one')
        require(len(joined) == len(out) and joined.label.notna().all(), 'Reference join failed')
        alias = 'main220' if dataset == 'main6600' else dataset
        for scope, subset in metric.evaluation_views(alias, joined):
            identity = {key: first[key] for key in ['model_id', 'dataset', 'selector', 'policy', 'threshold']}
            identity.update(scope=scope, label_source=pure_plan['label_source'][dataset], analysis='fixed_CPU_score_reuse_diagnostic')
            pair_rows.append({**identity, **metric.pair_metrics(subset)})
            list_metric = metric.top3_metrics(subset)
            if scope == 'locked100_hard_pairs':
                for field in ['completely_known_no_reference_query_n', 'no_reference_rejected_n', 'no_reference_rejection_rate']:
                    list_metric[field] = None
                list_metric['scope_note'] = 'Ranks remain full pool; no refill after hard filtering.'
            list_rows.append({**identity, **list_metric})
    pd.DataFrame(pair_rows).to_csv(args.output / 'pair_metrics_all_fixed_combinations.csv', index=False)
    pd.DataFrame(list_rows).to_csv(args.output / 'top3_metrics_all_fixed_combinations.csv', index=False)
    for path, digest in protected.items():
        require(sha(path) == digest, 'Protected source changed during diagnostic')
    dump(args.output / 'completed_diagnostic_qa.json', {'all_passed': True, 'model_schemes_reported': 3,
         'selectors_reported': 2, 'policies_reported': 3, 'method_blocks': 54,
         'predictions_frozen_before_reference': True, 'new_GPU_inference': False,
         'no_test_selection': True, 'no_new_threshold': True, 'pair_metric_rows': len(pair_rows),
         'list_metric_rows': len(list_rows), 'limits': plan['limits']})
    print('ALL_FIXED_COMBINATIONS_REPORTED_NO_TEST_SELECTION_NO_ROUTED_TIMING')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--freeze-plan', action='store_true')
    parser.add_argument('--actual', type=Path, default=HERE / 'blind_inference_seed20261005')
    parser.add_argument('--pure-evaluation', type=Path, default=HERE / 'blind_inference_cpu_evaluation')
    parser.add_argument('--source', type=Path, default=WORK / 'output/rule_first_system_20261004/results/server')
    parser.add_argument('--supplement', type=Path, default=WORK / 'output/paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs')
    parser.add_argument('--output', type=Path, default=HERE / 'fixed_combination_cpu_diagnostic')
    main(parser.parse_args())
