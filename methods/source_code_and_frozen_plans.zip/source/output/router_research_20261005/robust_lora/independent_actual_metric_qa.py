#!/usr/bin/env python3
"""Second-pass metric arithmetic with independently implemented references/scopes."""
from pathlib import Path
import hashlib
import json
import math

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
checks = []


def require(condition, message):
    if not bool(condition):
        raise AssertionError(message)
    checks.append(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def close(expected, actual):
    return pd.isna(actual) if expected is None else math.isclose(float(expected), float(actual), rel_tol=1e-12, abs_tol=1e-12)


def views(dataset, f):
    if dataset == 'main6600':
        locked = f.loc[f.evaluation_split.eq('locked')]
        hard_queries = set(locked.loc[locked.difficulty.eq('hard') & locked.y.eq(1), 'query_id'])
        return {'all220_diagnostic': f,
                'primary218': f.loc[f.evaluation_split.isin(['locked', 'external', 'no_reference'])],
                'locked100': locked, 'locked100_hard_pairs': locked.loc[locked.difficulty.eq('hard')],
                'locked100_hard_positive_full_queries': locked.loc[locked.query_id.isin(hard_queries)],
                'external80': f.loc[f.evaluation_split.eq('external')]}
    if dataset == 'challenge600':
        return {'all600_construction_reference': f}
    return {'both_years_pooled': f, **{year: f.loc[f.source_year.eq(year)] for year in sorted(f.source_year.unique())}}


labels = {}
for dataset, path, field in [
    ('main6600', WORK / 'output/rule_first_system_20261004/results/server/labels.csv', 'final_label'),
    ('challenge600', WORK / 'output/internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv', 'provisional_label'),
    ('alberta_scope_core', HERE.parent / 'rule_verification/alberta_reference_index.csv', 'reference_label')]:
    raw = pd.read_csv(path, dtype=str, keep_default_na=False)
    columns = ['pair_id'] + [column for column in ['difficulty', 'reference_uncertain'] if column in raw]
    f = raw[columns].copy()
    f['y'] = raw[field].astype(int)
    f['uncertain'] = raw.reference_uncertain.eq('1') if 'reference_uncertain' in raw else False
    if 'difficulty' not in f:
        f['difficulty'] = ''
    labels[dataset] = f
actual = HERE / 'blind_inference_seed20261005'
pure_eval = HERE / 'blind_inference_cpu_evaluation'
combo_eval = HERE / 'fixed_combination_cpu_diagnostic'
audit = json.loads((pure_eval / 'evaluation_integrity.json').read_text())
for path, digest in audit['source_hashes'].items():
    require(sha(path) == digest, 'Protected file SHA: ' + Path(path).name)
manifest = json.loads((actual / 'execution_manifest.json').read_text())
pure_pair = pd.read_csv(pure_eval / 'pair_metrics_all_frozen_selectors.csv')
pure_top = pd.read_csv(pure_eval / 'actual_pure_top3_metrics_all_frozen_selectors.csv')
combo_pair = pd.read_csv(combo_eval / 'pair_metrics_all_fixed_combinations.csv')
combo_top = pd.read_csv(combo_eval / 'top3_metrics_all_fixed_combinations.csv')
combo_frozen = json.loads((combo_eval / 'predictions_frozen_before_reference.json').read_text())
combo_path = combo_eval / 'all_fixed_combination_predictions_before_reference.csv.gz'
require(sha(combo_path) == combo_frozen['predictions_sha256'], 'All frozen combination predictions SHA')
combo_all = pd.read_csv(combo_path, dtype=str, keep_default_na=False)
require(len(combo_all) == combo_frozen['rows'] == 1347030, 'All 54 combination blocks and 1,347,030 rows')
combo_by_key = {key: part.reset_index(drop=True) for key, part in combo_all.groupby(['model_id', 'dataset', 'selector', 'policy'], sort=False)}
require(len(combo_by_key) == 54, 'All model/dataset/selector/policy combinations')


def inspect_metrics(frame, dataset, identity, pair_table, top_table):
    frame = frame.merge(labels[dataset], on='pair_id', how='left', validate='one_to_one')
    require(frame.y.notna().all(), 'Independent references join: ' + str(identity))
    for scope, part in views(dataset, frame).items():
        key = {**identity, 'scope': scope}
        selector = np.ones(len(pair_table), bool)
        for field, value in key.items():
            selector &= pair_table[field].eq(value).to_numpy()
        require(int(selector.sum()) == 1, 'Unique pair metric: ' + str(key))
        pair = pair_table.loc[selector].iloc[0]
        known = part.loc[~part.uncertain]
        y = known.y.to_numpy(int)
        p = known.prediction.to_numpy(int)
        tp, fp = int(((y == 1) & (p == 1)).sum()), int(((y == 0) & (p == 1)).sum())
        fn, tn = int(((y == 1) & (p == 0)).sum()), int(((y == 0) & (p == 0)).sum())
        computed = {'input_pairs': len(part), 'known_pairs': len(known), 'uncertain_excluded': int(part.uncertain.sum()),
                    'positive_n': int((y == 1).sum()), 'tp': tp, 'fp': fp, 'fn': fn, 'tn': tn,
                    'precision': tp / (tp + fp) if tp + fp else None,
                    'recall': tp / (tp + fn) if tp + fn else None,
                    'f1': 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0,
                    'accuracy': (tp + tn) / len(known) if len(known) else None}
        require(all(close(value, pair[field]) for field, value in computed.items()), 'Independent pair arithmetic: ' + str(key))
        selector = np.ones(len(top_table), bool)
        for field, value in key.items():
            selector &= top_table[field].eq(value).to_numpy()
        require(int(selector.sum()) == 1, 'Unique list metric: ' + str(key))
        top = top_table.loc[selector].iloc[0]
        if dataset == 'challenge600':
            require(top.top3_available == False and part.returned_rank.astype(int).eq(0).all(), '600 cannot imply Top3: ' + str(key))
            continue
        returned = part.returned_rank.astype(int).gt(0)
        returned_known = part.loc[returned & ~part.uncertain]
        returned_tp = int(returned_known.y.sum())
        returned_fp = len(returned_known) - returned_tp
        recalls, hits = [], []
        for _, group in part.groupby(['evaluation_split', 'query_id'], sort=False):
            known_group = group.loc[~group.uncertain]
            npos = int(known_group.y.sum())
            if npos:
                rtp = int(known_group.loc[known_group.returned_rank.astype(int).gt(0), 'y'].sum())
                recalls.append(rtp / npos)
                hits.append(int(rtp > 0))
        computed = {'query_n': part.groupby(['evaluation_split', 'query_id']).ngroups,
                    'positive_query_n': len(recalls), 'returned_total_n': int(returned.sum()),
                    'returned_known_n': len(returned_known), 'returned_uncertain_n': int((returned & part.uncertain).sum()),
                    'returned_tp': returned_tp, 'returned_fp': returned_fp,
                    'returned_precision_known': returned_tp / len(returned_known) if len(returned_known) else None,
                    'micro_recall_at3': returned_tp / int(known.y.sum()) if known.y.sum() else None,
                    'macro_recall_at3': float(np.mean(recalls)) if recalls else None,
                    'hit_at3': float(np.mean(hits)) if hits else None}
        require(all(close(value, top[field]) for field, value in computed.items()), 'Independent actual-list arithmetic: ' + str(key))


for item in manifest['completed_outputs']:
    raw = pd.read_csv(actual / item['output'], dtype=str, keep_default_na=False)
    for selector in item['selectors']:
        threshold = item['selectors'][selector]['threshold']
        f = raw[[column for column in ['pair_id', 'evaluation_split', 'query_id', 'candidate_id', 'source_year'] if column in raw]].copy()
        score = raw.score.to_numpy(float)
        f['prediction'] = (score >= threshold).astype(int)
        ranks = np.zeros(len(f), int)
        if 'query_id' in f:
            for positions in f.groupby(['evaluation_split', 'query_id'], sort=False).indices.values():
                selected = sorted([int(i) for i in positions if score[i] >= threshold], key=lambda i: (-score[i], f.iloc[i].candidate_id))[:3]
                ranks[selected] = np.arange(1, len(selected) + 1)
            require(np.array_equal(ranks, raw['returned_rank_' + selector].astype(int)), 'Independent raw-score Top3: ' + item['model_id'] + '/' + item['dataset'] + '/' + selector)
        f['returned_rank'] = ranks
        identity = {'model_id': item['model_id'], 'dataset': item['dataset'], 'selector': selector}
        inspect_metrics(f, item['dataset'], identity, pure_pair, pure_top)
        pure_combo = combo_by_key[(item['model_id'], item['dataset'], selector, 'pure_lora')]
        require(pure_combo.pair_id.tolist() == raw.pair_id.tolist() and np.array_equal(pure_combo.prediction.astype(int), f.prediction)
                and np.array_equal(pure_combo.returned_rank.astype(int), ranks), 'CPU pure-combination parity with actual: ' + str(identity))

for (model_id, dataset, selector, policy), part in combo_by_key.items():
    part = part.copy()
    part['prediction'] = part.prediction.astype(int)
    part['returned_rank'] = part.returned_rank.astype(int)
    inspect_metrics(part, dataset, {'model_id': model_id, 'dataset': dataset, 'selector': selector, 'policy': policy}, combo_pair, combo_top)

timing = pd.read_csv(actual / 'timing.csv')
timing_summary = pd.read_csv(pure_eval / 'actual_full_batch_timing_by_model.csv')
for row in timing_summary.to_dict('records'):
    subset = timing.loc[timing.model_id.eq(row['model_id']) & timing.dataset.eq(row['dataset'])]
    median = float(np.median(subset.seconds))
    require(len(subset) == row['actual_repeats'] and close(median, row['full_batch_seconds_median'])
            and close(median * 2.88 / 3600, row['full_batch_cny_2_88_per_hour']), 'Independent timing median/rental arithmetic: ' + row['model_id'] + '/' + row['dataset'])
require(len(pure_pair) == len(pure_top) == 60 and len(combo_pair) == len(combo_top) == 180, 'All 240 pair and 240 list metric rows reported')
report = {'all_passed': True, 'check_count': len(checks), 'checks': checks,
          'GPU_used': False, 'new_threshold_or_checkpoint_selected': False,
          'all_selected_models': 3, 'training_seeds': 1, 'selectors_independent': False,
          'pure_pair_rows': 60, 'pure_list_rows': 60, 'combination_pair_rows': 180, 'combination_list_rows': 180,
          'labels_authorized_after_complete_prelabel_output_integrity': True,
          'CPU_combinations_are_cached_score_diagnostic_not_actual_routed_inference': True}
(HERE / 'independent_actual_metric_qa.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'all_passed': True, 'check_count': len(checks)}))
