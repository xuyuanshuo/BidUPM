#!/usr/bin/env python3
"""Finite train/validation-only BGE LoRA experiment. No held-out data loader."""
from __future__ import annotations
import argparse, gc, hashlib, json, math, os, random, time
from pathlib import Path
from collections import Counter

os.environ.setdefault('HF_HUB_OFFLINE','1')
os.environ.setdefault('TRANSFORMERS_OFFLINE','1')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset
from transformers import (AutoModelForSequenceClassification, AutoTokenizer,
                          XLMRobertaConfig, get_linear_schedule_with_warmup)
from peft import LoraConfig, TaskType, get_peft_model

SCHEMES=('full_control','drop_meta_p50_one_side','description_unit')
SIDES=('query','candidate')
SUFFIXES=('description','normalized_description','normalized_unit','category','spec_tokens')

def sha(p):
    digest=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()

def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def normalized(s):return ' '.join(str(s).strip().lower().split())

def masked_side(scheme,seed,epoch,index):
    """No label-dependent masking. A fixed pair/epoch chooses at most one side."""
    if scheme!='drop_meta_p50_one_side':return None
    rng=random.Random(seed+1000003*epoch+10007*index)
    return SIDES[rng.randrange(2)] if rng.random()<0.5 else None

def render(row,side,scheme,mask=None):
    d,n,u,c,s=(normalized(row[f'{side}_{x}']) for x in SUFFIXES)
    if scheme=='description_unit':
        return f'Description: {d}. Normalized: {n}. Pay unit: {u}.'
    if side==mask:c=s=''
    return f'Description: {d}. Normalized: {n}. Pay unit: {u}. Category: {c}. Specs: {s}.'

def symmetric_rows(frame):
    reverse=frame.copy()
    for x in SUFFIXES:
        reverse[f'query_{x}']=frame[f'candidate_{x}'].to_numpy()
        reverse[f'candidate_{x}']=frame[f'query_{x}'].to_numpy()
    return pd.concat([frame,reverse],ignore_index=True)

def metrics(y,p):
    y=np.asarray(y,dtype=int);p=np.asarray(p,dtype=bool)
    tp=int(((y==1)&p).sum());fp=int(((y==0)&p).sum())
    fn=int(((y==1)&~p).sum());tn=int(((y==0)&~p).sum())
    return dict(tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else None,
                recall=tp/(tp+fn) if tp+fn else None,
                f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.0)

def select_thresholds(y,scores,hard):
    """Optimize each frozen validation objective; no arbitrary score-grid tuning."""
    scores=np.asarray(scores,dtype=float);assert np.isfinite(scores).all()
    candidates=np.r_[np.unique(scores),np.nextafter(scores.max(),math.inf)]
    selected={}
    for selector in ('overall_f1','balanced_f1'):
        best=None
        for t in candidates:
            p=scores>=t;whole=metrics(y,p);hm=metrics(y[hard],p[hard])
            objective=whole['f1'] if selector=='overall_f1' else 0.6*whole['f1']+0.4*hm['f1']
            key=(objective,whole['precision'] if whole['precision'] is not None else 0.0,
                 hm['recall'] if hm['recall'] is not None else 0.0,whole['recall'],float(t))
            record=dict(selector=selector,threshold=float(t),objective=float(objective),overall=whole,hard=hm)
            if best is None or key>best[0]:best=(key,record)
        selected[selector]=best[1]
    return selected

class PairRows(Dataset):
    def __init__(self,frame,scheme,seed,epoch):
        self.rows=frame.to_dict('records');self.scheme=scheme;self.seed=seed;self.epoch=epoch
    def __len__(self):return len(self.rows)
    def __getitem__(self,index):
        r=self.rows[index];mask=masked_side(self.scheme,self.seed,self.epoch,index)
        return (render(r,'query',self.scheme,mask),render(r,'candidate',self.scheme,mask),
                float(r['final_label']),float(r['difficulty']=='hard'))

def collate_with(tok,max_length):
    def collate(rows):
        q,c,y,h=zip(*rows)
        enc=tok(list(q),list(c),padding=True,truncation=True,max_length=max_length,return_tensors='pt')
        enc['labels_local']=torch.tensor(y,dtype=torch.float32)
        enc['hard_local']=torch.tensor(h,dtype=torch.float32)
        return enc
    return collate

@torch.inference_mode()
def predict_validation(model,tok,frame,scheme,settings):
    """Validation scoring sees input text only; labels are accessed after scoring."""
    model.eval()
    q=[render(r,'query',scheme) for r in frame.to_dict('records')]
    c=[render(r,'candidate',scheme) for r in frame.to_dict('records')]
    scores=[]
    torch.cuda.synchronize();started=time.perf_counter()
    for lo in range(0,len(q),settings['validation_batch_size']):
        enc=tok(q[lo:lo+settings['validation_batch_size']],c[lo:lo+settings['validation_batch_size']],
                padding=True,truncation=True,max_length=settings['max_length'],return_tensors='pt')
        enc={k:v.to('cuda') for k,v in enc.items()}
        with torch.autocast('cuda',dtype=torch.bfloat16):z=model(**enc).logits.reshape(-1)
        scores.append(z.float().cpu().numpy())
    torch.cuda.synchronize()
    return np.concatenate(scores),time.perf_counter()-started

def lora_model(base,settings):
    names=dict(base.named_modules())
    for target in ('query','value'):
        assert any(k.endswith('.attention.self.'+target) for k in names),target
    assert 'classifier' in names and int(base.config.num_labels)==1
    config=LoraConfig(task_type=TaskType.SEQ_CLS,r=settings['lora_rank'],
                      lora_alpha=settings['lora_alpha'],lora_dropout=settings['lora_dropout'],
                      target_modules=['query','value'],modules_to_save=['classifier'],bias='none')
    model=get_peft_model(base,config)
    trainable=[n for n,p in model.named_parameters() if p.requires_grad]
    assert trainable and all('lora_' in n or '.modules_to_save.' in n for n in trainable),trainable
    assert any('classifier' in n for n in trainable)
    return model

def cpu_smoke(plan,output):
    """Tiny random CPU model proves PEFT compatibility; never touches full/GPU model."""
    output.mkdir(parents=True,exist_ok=True)
    cfg=XLMRobertaConfig(vocab_size=32,hidden_size=8,intermediate_size=16,
                         num_hidden_layers=1,num_attention_heads=2,num_labels=1,max_position_embeddings=32)
    base=AutoModelForSequenceClassification.from_config(cfg)
    model=lora_model(base,plan['settings']);model.train()
    x=torch.tensor([[0,5,6,2],[0,7,8,2]])
    z=model(input_ids=x,attention_mask=torch.ones_like(x)).logits.reshape(-1)
    loss=nn.BCEWithLogitsLoss()(z,torch.tensor([1.,0.]));loss.backward()
    assert any(p.grad is not None for n,p in model.named_parameters() if 'lora_' in n)
    assert any(p.grad is not None for n,p in model.named_parameters() if 'classifier' in n and p.requires_grad)
    temporary=output/'tiny_adapter_cpu_smoke';model.save_pretrained(temporary,safe_serialization=True)
    assert not (temporary/'model.safetensors').exists()
    row={f'{side}_{suffix}':f'{side}-{suffix}' for side in SIDES for suffix in SUFFIXES}
    counts=Counter(masked_side('drop_meta_p50_one_side',plan['settings']['seed'],1,i) for i in range(10000))
    assert 0.45<(counts['query']+counts['candidate'])/10000<0.55
    assert render(row,'query','full_control')==render(row,'query','drop_meta_p50_one_side',None)
    assert 'Category: . Specs: .' in render(row,'query','drop_meta_p50_one_side','query')
    assert 'candidate-category' in render(row,'candidate','drop_meta_p50_one_side','query')
    assert 'Category:' not in render(row,'query','description_unit')
    selections=select_thresholds(np.array([1,1,0,0]),np.array([.9,.4,.6,.1]),np.array([False,True,True,False]))
    out={'passed':True,'model':'tiny random XLMRoberta CPU only','cuda_model_loaded':False,
         'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),
         'classifier_saved':any('classifier' in k for k in model.state_dict()),
         'adapter_only_files':[p.name for p in temporary.iterdir()],
         'mask_counts_10000':{str(k):v for k,v in counts.items()},'threshold_selection_smoke':selections,
         'script_sha256':sha(__file__)}
    dump(output/'cpu_smoke_qa.json',out);print(json.dumps(out,ensure_ascii=False),flush=True)

def run(plan_path,output,schemes):
    plan=json.loads(plan_path.read_text());s=plan['settings']
    assert tuple(plan['schemes'])==SCHEMES and set(schemes)<=set(SCHEMES)
    assert sha(__file__)==plan['script_sha256']
    assert not output.exists(),'Preserve earlier outputs; choose a fresh results directory'
    output.mkdir(parents=True)
    trainpath=Path(plan['train_path']);valpath=Path(plan['validation_path'])
    for path,key in [(trainpath,'train_sha256'),(valpath,'validation_sha256')]:assert sha(path)==plan[key]
    train=pd.read_csv(trainpath,dtype=str,keep_default_na=False)
    val=pd.read_csv(valpath,dtype=str,keep_default_na=False)
    assert len(train)==2278 and len(val)==900
    assert train.training_eligibility.eq('1').all()
    assert not set(train.query_id)&set(val.query_id)
    assert not set(train.unordered_pair_key)&set(val.unordered_pair_key)
    assert train.final_label.isin(['0','1']).all() and val.final_label.isin(['0','1']).all()
    assert train['final_label'].astype(int).sum()==248
    assert ((train.final_label=='1')&(train.difficulty=='hard')).sum()==101
    assert val['final_label'].astype(int).sum()==107
    assert ((val.final_label=='1')&(val.difficulty=='hard')).sum()==21
    modelpath=Path(plan['base_model_path'])
    for name,h in plan['base_files_sha256'].items():assert sha(modelpath/name)==h,name
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    effective=symmetric_rows(train)
    assert len(effective)==4556 and effective['final_label'].astype(int).sum()==496
    tok=AutoTokenizer.from_pretrained(modelpath,local_files_only=True)
    tok.save_pretrained(output/'tokenizer')
    y=val.final_label.to_numpy(dtype=int);hard=val.difficulty.eq('hard').to_numpy()
    report={'status':'running','plan_sha256':sha(plan_path),'script_sha256':sha(__file__),
            'train_sha256':sha(trainpath),'validation_sha256':sha(valpath),'train_rows':2278,
            'effective_training_rows':4556,'validation_rows':900,'test_files_read':[],
            'test_gold_used_for_training_or_selection':False,'gpu':torch.cuda.get_device_name(0),
            'settings':s,'schemes':schemes,'runs':[]}
    dump(output/'execution_manifest.json',report)
    for scheme in schemes:
        random.seed(s['seed']);np.random.seed(s['seed']);torch.manual_seed(s['seed']);torch.cuda.manual_seed_all(s['seed'])
        base=AutoModelForSequenceClassification.from_pretrained(modelpath,local_files_only=True,
                    torch_dtype=torch.float32,low_cpu_mem_usage=True).to('cuda')
        model=lora_model(base,s)
        runout=output/scheme;runout.mkdir()
        positives=int(effective.final_label.astype(int).sum());negatives=len(effective)-positives
        positive_weight=torch.tensor([negatives/positives],dtype=torch.float32,device='cuda')
        criterion=nn.BCEWithLogitsLoss(pos_weight=positive_weight,reduction='none')
        parameters=[p for p in model.parameters() if p.requires_grad]
        optimizer=AdamW(parameters,lr=s['learning_rate'],weight_decay=s['weight_decay'])
        steps_per_epoch=math.ceil(len(effective)/s['training_batch_size'])
        schedule=get_linear_schedule_with_warmup(optimizer,
            num_warmup_steps=max(1,round(steps_per_epoch*s['epochs']*s['warmup_ratio'])),
            num_training_steps=steps_per_epoch*s['epochs'])
        history=[];best={};validation_outputs=[]
        trainable_names=[n for n,p in model.named_parameters() if p.requires_grad]
        dump(runout/'trainable_parameter_manifest.json',{'names':trainable_names,
             'parameters':sum(p.numel() for p in parameters),'class_positive_weight':float(positive_weight.item()),
             'hard_positive_multiplier':3.0,'base_frozen':True,'seed':s['seed']})
        for epoch in range(1,s['epochs']+1):
            dataset=PairRows(effective,scheme,s['seed'],epoch)
            loader=DataLoader(dataset,batch_size=s['training_batch_size'],shuffle=True,num_workers=0,
                generator=torch.Generator().manual_seed(s['seed']+epoch),collate_fn=collate_with(tok,s['max_length']),pin_memory=True)
            masks=Counter(masked_side(scheme,s['seed'],epoch,i) for i in range(len(effective)))
            model.train();losses=[]
            torch.cuda.synchronize();started=time.perf_counter()
            for batch in loader:
                labels=batch.pop('labels_local').to('cuda');difficult=batch.pop('hard_local').to('cuda')
                enc={k:v.to('cuda') for k,v in batch.items()};optimizer.zero_grad(set_to_none=True)
                with torch.autocast('cuda',dtype=torch.bfloat16):z=model(**enc).logits.reshape(-1)
                loss=(criterion(z.float(),labels)*(1+2*difficult*labels)).mean()
                if not torch.isfinite(loss):raise FloatingPointError((scheme,epoch,len(losses)))
                loss.backward();torch.nn.utils.clip_grad_norm_(parameters,s['gradient_clip'])
                optimizer.step();schedule.step();losses.append(float(loss.detach().cpu()))
            torch.cuda.synchronize();trainsecs=time.perf_counter()-started
            scores,valsecs=predict_validation(model,tok,val,scheme,s)
            selected=select_thresholds(y,scores,hard)
            adapter=runout/f'adapter_epoch_{epoch}'
            model.save_pretrained(adapter,safe_serialization=True)
            assert not (adapter/'model.safetensors').exists(),'Must save adapter only'
            adapterhash={p.name:sha(p) for p in adapter.iterdir() if p.is_file()}
            rec={'scheme':scheme,'epoch':epoch,'seed':s['seed'],'mean_training_loss':float(np.mean(losses)),
                 'training_seconds':trainsecs,'validation_seconds':valsecs,'mask_counts':{str(k):v for k,v in masks.items()},
                 'selected_thresholds':selected,'adapter_directory':str(adapter),'adapter_files_sha256':adapterhash}
            history.append(rec)
            vo=val[['pair_id','query_id','candidate_id','final_label','difficulty']].copy()
            vo['epoch']=epoch;vo['scheme']=scheme;vo['score']=scores
            for selector,sel in selected.items():
                vo[f'prediction_{selector}']=(scores>=sel['threshold']).astype(int)
                vo[f'threshold_{selector}']=sel['threshold']
                # Earliest epoch wins exact ties; a fixed rule avoids checkpoint picking after test.
                key=(sel['objective'],sel['overall']['precision'] or 0,sel['hard']['recall'] or 0,-epoch)
                if selector not in best or key>best[selector]['key']:
                    best[selector]={'key':key,'epoch':epoch,'selection':sel,'adapter_directory':str(adapter),
                                    'adapter_files_sha256':adapterhash,'inference_input_scheme':scheme}
            validation_outputs.append(vo)
            pd.concat(validation_outputs,ignore_index=True).to_csv(runout/'validation_epoch_scores.csv',index=False)
            dump(runout/'training_history.json',history);dump(runout/'selected_adapters.json',best)
            print('EPOCH_COMPLETE',scheme,epoch,json.dumps(selected),round(trainsecs,3),flush=True)
        report['runs'].append({'scheme':scheme,'seed':s['seed'],'epochs':s['epochs'],'selected':best,
              'history_sha256':sha(runout/'training_history.json'),'validation_scores_sha256':sha(runout/'validation_epoch_scores.csv')})
        dump(output/'execution_manifest.json',report)
        del model,base,optimizer,schedule,parameters,loader,dataset;gc.collect();torch.cuda.empty_cache()
    report['status']='complete'
    report['train_data_unchanged']=sha(trainpath)==plan['train_sha256']
    report['validation_data_unchanged']=sha(valpath)==plan['validation_sha256']
    report['base_files_unchanged']=all(sha(modelpath/n)==h for n,h in plan['base_files_sha256'].items())
    dump(output/'execution_manifest.json',report);print('ALL_COMPLETE',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--plan',required=True,type=Path)
    ap.add_argument('--output',required=True,type=Path);ap.add_argument('--schemes',nargs='+',choices=SCHEMES,default=list(SCHEMES))
    ap.add_argument('--cpu-smoke',action='store_true');args=ap.parse_args()
    if args.cpu_smoke:cpu_smoke(json.loads(args.plan.read_text()),args.output)
    else:run(args.plan,args.output,args.schemes)
