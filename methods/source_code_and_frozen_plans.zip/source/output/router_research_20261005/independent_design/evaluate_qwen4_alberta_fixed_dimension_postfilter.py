#!/usr/bin/env python3
"""Apply the already frozen dimension veto to all original Qwen4 predictions.

No score, seed, or threshold selection. This is CPU filtering AFTER full model
inference, and its quality cannot imply that the model inference cost was saved.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import numpy as np
import pandas as pd
from evaluate_qwen4_alberta_frozen_outputs import (
    ROOT, OWN, SEEDS, SOURCE, sha, dump, pair_metrics, last3_metrics)

def rank3(d):
    accepted = d[d.prediction == 1].sort_values(
        ['source_year', 'query_id', 'score', 'candidate_id'],
        ascending=[True, True, False, True]).copy()
    accepted['new_rank'] = accepted.groupby(['source_year', 'query_id']).cumcount()+1
    accepted = accepted[accepted.new_rank <= 3]
    ranks = dict(zip(accepted.pair_id, accepted.new_rank))
    return d.pair_id.map(ranks).fillna(0).to_numpy(int)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--results', type=Path, required=True)
    ap.add_argument('--original-qa', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    a = ap.parse_args(); a.output.mkdir(parents=True, exist_ok=True)
    assert not (a.output/'predictions_frozen_before_reference.csv').exists(), 'Preserve prior result'
    qa = json.loads(a.original_qa.read_text()); assert qa['passed'] and qa['all_three_seeds_reported']
    gate_dir = ROOT/'router_research_20261005/generic_unit_gate'
    gp = json.loads((gate_dir/'frozen_generic_gate_plan.json').read_text())
    helper = gate_dir/'generic_unit_gate.py'; ontology = gate_dir/'unit_dimension_ontology.json'
    assert sha(helper) == gp['helper_sha256'] and sha(ontology) == gp['ontology_sha256']
    spec = importlib.util.spec_from_file_location('unchanged_generic_unit_dimension_gate', helper)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    plan_path = OWN/'qwen4_alberta_scope_core_frozen_inference_plan.json'
    plan = json.loads(plan_path.read_text())
    ip = Path(plan['local_identical_input_csv']); assert sha(ip) == plan['input_sha256']
    inp = pd.read_csv(ip, dtype=str, keep_default_na=False)
    assert not {'label', 'reference_label', 'reference_uncertain', 'provisional_label', 'difficulty'} & set(inp)
    assert len(inp) == inp.pair_id.nunique() == 67635
    veto = np.asarray(mod.dimension_conflict_mask(inp), bool)
    manifest = json.loads((a.results/'execution_manifest.json').read_text())
    assert manifest['status'] == 'complete' and len(manifest['completed_runs']) == 3
    outputs = []; source_hashes = {}; originals = {}
    for seed in SEEDS:
        run = next(r for r in manifest['completed_runs'] if r['seed'] == seed)
        path = a.results/run['output_file']; assert sha(path) == run['output_sha256']
        source_hashes[str(path)] = sha(path)
        d = pd.read_csv(path, dtype={k:str for k in ['pair_id','source_year','query_id','candidate_id']})
        assert d.pair_id.tolist() == inp.pair_id.tolist()
        originals[seed] = d.copy()
        d['original_prediction'] = d.prediction
        d['dimension_reject'] = veto.astype(int)
        d['prediction'] = (d.prediction.to_numpy(bool) & ~veto).astype(int)
        d['returned_rank'] = rank3(d)
        outputs.append(d)
    pred = pd.concat(outputs, ignore_index=True)
    pp = a.output/'predictions_frozen_before_reference.csv'; pred.to_csv(pp, index=False)
    dump(a.output/'prediction_freeze_manifest.json', dict(
        status='all_three_output_postfilters_frozen_before_reference_join', labels_read_by_filter=False,
        gate_constructed_without_labels=gp['gold_used_to_construct_aliases'] is False,
        thresholds_unchanged=True, no_seed_or_threshold_or_method_selection=True,
        all_seeds_reported=True, source_hashes=source_hashes, output_sha256=sha(pp),
        input_sha256=sha(ip), helper_sha256=sha(helper), ontology_sha256=sha(ontology),
        gate_scope='fixed generic dimension veto only; no new exact acceptance or semantic fallback',
        timing_scope='CPU filtering after complete Qwen4 inference; cannot claim GPU inference saved',
        script_sha256=sha(__file__), original_qa_sha256=sha(a.original_qa),
        dimension_rejected_input_rows=int(veto.sum())))
    # References enter only after all unchanged-source postfilters are frozen.
    rp = ROOT/'router_research_20261005/rule_verification/alberta_reference_index.csv'
    assert sha(rp) == qa['reference_sha256']
    ref = pd.read_csv(rp, dtype={'pair_id':str})
    rulepath = ROOT/'router_research_20261005/rule_verification/alberta_rule_predictions_all_stages.csv'
    oldqa = json.loads((OWN/'small_dataset_comparison/reference_and_output_integrity_qa.json').read_text())
    assert sha(rulepath) == oldqa['source_hashes']['output/router_research_20261005/rule_verification/alberta_rule_predictions_all_stages.csv']
    rules = pd.read_csv(rulepath, usecols=['pair_id','policy','prediction'], dtype={'pair_id':str})
    rules = rules[rules.policy == 'normalized_exact_plus_unit']
    exact_by_id = dict(zip(rules.pair_id, rules.prediction.astype(bool)))
    metrics = []; lists = []; events = []
    for seed in SEEDS:
        z = pred[pred.seed == seed].merge(ref[['pair_id','reference_label','reference_uncertain']], on='pair_id', validate='one_to_one')
        z['input_nonexact'] = ~z.pair_id.map(exact_by_id).to_numpy(bool)
        changed = (z.original_prediction == 1) & (z.prediction == 0)
        for _, row in z[changed].iterrows():
            events.append(dict(seed=seed, pair_id=row.pair_id, source_year=row.source_year,
                               reference_label=int(row.reference_label), reference_uncertain=int(row.reference_uncertain),
                               event='uncertain_deleted' if row.reference_uncertain else ('correct_acceptance_deleted' if row.reference_label else 'false_acceptance_removed')))
        for group, g in [('both',z), *[(year,z[z.source_year == year]) for year in ['2024','2026']]]:
            for subset, s in [('all_pairs',g), ('input_nonexact_normalized',g[g.input_nonexact])]:
                known = s[s.reference_uncertain == 0]
                c = (known.original_prediction == 1) & (known.prediction == 0)
                metrics.append(dict(model='qwen4_original_lora_plus_fixed_dimension_postfilter', seed=seed,
                    label_source=SOURCE, group=group, subset=subset, rows=len(known),
                    positive_n=int(known.reference_label.sum()), uncertain_excluded_n=len(s)-len(known),
                    correct_acceptances_deleted=int((c & (known.reference_label == 1)).sum()),
                    false_acceptances_removed=int((c & (known.reference_label == 0)).sum()),
                    **pair_metrics(known.reference_label.to_numpy(int), known.prediction.to_numpy(bool))))
            lists.append(dict(model='qwen4_original_lora_plus_fixed_dimension_postfilter',seed=seed,
                              label_source=SOURCE,group=group, **last3_metrics(g)))
    metrics = pd.DataFrame(metrics); lists = pd.DataFrame(lists)
    metrics.to_csv(a.output/'pair_metrics_each_seed.csv',index=False)
    lists.to_csv(a.output/'final3_metrics_each_seed.csv',index=False)
    pd.DataFrame(events).to_csv(a.output/'changed_acceptance_events.csv',index=False)
    metrics.groupby(['model','label_source','group','subset'])[
        ['precision','recall','f1','tp','fp','fn','correct_acceptances_deleted','false_acceptances_removed']
    ].agg(['mean','std']).to_csv(a.output/'pair_metrics_aggregate.csv')
    lists.groupby(['model','label_source','group'])[
        ['returned_precision','macro_recall_at3','hit_at3','no_reference_rejection','returned_uncertain_n']
    ].agg(['mean','std']).to_csv(a.output/'final3_metrics_aggregate.csv')
    assert all(sha(path) == h for path,h in source_hashes.items())
    freeze = json.loads((a.output/'prediction_freeze_manifest.json').read_text())
    assert sha(pp) == freeze['output_sha256']
    dump(a.output/'postfilter_qa.json', dict(passed=True, labels_joined_after_all_postfilter_predictions_frozen=True,
        all_three_seeds_preserved=True, unknown_or_project_scope_units_defer=True, thresholds_unchanged=True,
        no_new_exact_acceptance=True, no_semantic_fallback=True, no_additional_gpu_inference=True,
        original_predictions_unchanged=True, dimension_rejected_input_rows=int(veto.sum()),
        uncertain_candidates_preserve_ranking_slots=True, no_reference_query_requires_every_candidate_known=True,
        label_source=SOURCE, human_gold=False, actual_qwen4_full_inference_time_must_be_retained=True,
        helper_sha256=sha(helper), ontology_sha256=sha(ontology), reference_sha256=sha(rp)))
    print(metrics[(metrics.group == 'both') & (metrics.subset == 'all_pairs')].to_string(index=False))

if __name__ == '__main__': main()
