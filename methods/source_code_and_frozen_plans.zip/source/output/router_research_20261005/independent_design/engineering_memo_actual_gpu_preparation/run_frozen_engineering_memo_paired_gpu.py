#!/usr/bin/env python3
"""Frozen parser-only optimization: paired real scoring, never read labels.

Derives the resident-model timer from the preserved generic all-source runner.
Only exact intermediate memoization differs between the two policies. Original
files, inputs, checkpoint weights, thresholds, acceptance and Top3 stay frozen.
"""
import argparse
import dataclasses
import gc
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

os.environ.setdefault('HF_HUB_OFFLINE', '1')
os.environ.setdefault('TRANSFORMERS_OFFLINE', '1')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REMOTE_ROOT = Path('experiment_runtime')
POLICIES = ('dimension_size_gate_bge_original', 'dimension_size_gate_bge_memo')
KEYS = ['pair_id', 'evaluation_split', 'query_id', 'candidate_id']
ITEM = [f'{side}_{field}' for side in ('query', 'candidate') for field in
        ('description', 'normalized_description', 'normalized_unit', 'category', 'spec_tokens')]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def json_field(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def item(row, side):
    return {key: row.get(f'{side}_{key}', '') for key in
            ('description', 'normalized_description', 'unit', 'category', 'spec_tokens')}


def parse_size(gate, frame):
    # Keep the preserved runner's dataframe-to-record conversion and row order.
    results = [gate.contradiction_gate(item(row, 'query'), item(row, 'candidate'),
               enabled_rules=('physical_size',)) for row in frame.to_dict('records')]
    return np.asarray([r.decision == 'reject' for r in results], bool), results


def evidence_fields(results):
    return [dataclasses.asdict(result) for result in results]


def evidence_hash(fields):
    return hashlib.sha256(json_field(fields).encode()).hexdigest()


def array_byte_hash(value):
    value = np.ascontiguousarray(value)
    # Include dtype/shape; NaN payload bytes are compared, not discarded.
    return hashlib.sha256(str(value.dtype).encode() + json_field(value.shape).encode()
                          + value.tobytes()).hexdigest()


def assert_empty(gate):
    assert all(v['currsize'] == v['hits'] == v['misses'] == 0
               for v in gate.cache_stats().values()), 'Memo cache was not cold'


def read_frozen_inputs(args, plan):
    gate_directory = args.gate_directory
    source_manifest_path = args.source / 'source_manifest.json'
    assert sha(source_manifest_path) == plan['source_manifest_sha256']
    source_manifest = json.loads(source_manifest_path.read_text())
    assert source_manifest['runs'] == plan['runs']
    assert sha(args.shared_policy) == plan['shared_policy_sha256']
    assert sha(HERE / plan['memo_helper_file']) == plan['memo_helper_sha256']
    assert sha(__file__) == plan['runner_sha256']
    for name, digest in plan['gate_file_sha256'].items():
        assert sha(gate_directory / name) == digest, f'Frozen gate source changed: {name}'
    paths = {'main220': args.source / 'inputs.csv',
             'challenge600': args.supplement / 'model_inputs_challenge600.csv',
             'alberta_scope_core': args.supplement / 'model_inputs_alberta_scope_core.csv'}
    frames = {}
    for name, path in paths.items():
        assert sha(path) == plan['input_sha256'][name], f'Frozen input changed: {name}'
        frame = pd.read_csv(path, dtype=str, keep_default_na=False)
        if name == 'main220':
            frame = frame[frame.evaluation_split.ne('validation')].reset_index(drop=True)
        frames[name] = frame
    metadata = pd.read_csv(gate_directory / 'raw_units_metadata.csv', dtype=str, keep_default_na=False)
    assert set(metadata) == {'dataset', 'pair_id', 'query_unit', 'candidate_unit'}
    for name in ('main220', 'challenge600'):
        units = metadata[metadata.dataset.eq(name)].drop(columns='dataset')
        frames[name] = frames[name].merge(units, on='pair_id', how='left', validate='one_to_one')
        assert frames[name][['query_unit', 'candidate_unit']].notna().all().all()
    # Same pre-frozen Alberta inference slot transformation as original runner.
    for side in ('query', 'candidate'):
        frames['alberta_scope_core'][f'{side}_description'] = frames['alberta_scope_core'][f'{side}_normalized_description']
    assert {name: len(frame) for name, frame in frames.items()} == plan['input_rows']
    for name, frame in frames.items():
        assert not {'label', 'final_label', 'provisional_label', 'difficulty', 'reference_label'} & set(frame)
        assert frame.pair_id.nunique() == len(frame)
        assert set(['pair_id'] + ITEM) <= set(frame)
        if name != 'challenge600':
            assert set(KEYS) <= set(frame)
    return frames, source_manifest, paths


def cpu_evidence_preflight(frames, gate_directory, Gate, dimension, exact_mask):
    rows, frozen_evidence, outputs = [], {}, {}
    for dataset, frame in frames.items():
        records = frame.to_dict('records')
        results_by_policy = {}
        mask_by_policy = {}
        candidate_by_policy = {}
        for policy in POLICIES:
            gate = Gate(gate_directory, memoize=policy == POLICIES[1])
            assert_empty(gate)
            mask, results = parse_size(gate, frame)
            results_by_policy[policy] = evidence_fields(results)
            mask_by_policy[policy] = mask
            candidate_by_policy[policy] = evidence_fields([
                gate.candidate_gate(item(row, 'query'), item(row, 'candidate'), 'physical_size')
                for row in records])
        assert results_by_policy[POLICIES[0]] == results_by_policy[POLICIES[1]], dataset
        assert candidate_by_policy[POLICIES[0]] == candidate_by_policy[POLICIES[1]], dataset
        assert np.array_equal(mask_by_policy[POLICIES[0]], mask_by_policy[POLICIES[1]]), dataset
        combined = results_by_policy[POLICIES[0]]
        candidate = candidate_by_policy[POLICIES[0]]
        frozen_evidence[dataset] = combined
        exact = np.asarray(exact_mask(frame), bool)
        dim = np.asarray(dimension(frame), bool)
        size = mask_by_policy[POLICIES[0]]
        out = frame[[key for key in KEYS + ['source_year'] if key in frame]].copy()
        for field in ('decision', 'rule', 'reason', 'evidence'):
            out['size_combined_' + field] = [json_field(value.get(field)) for value in combined]
            out['size_candidate_' + field] = [json_field(value.get(field)) for value in candidate]
        out['exact_match'] = exact.astype(int)
        out['dimension_rejected'] = dim.astype(int)
        out['size_rejected'] = size.astype(int)
        out['bge_called'] = (~exact & ~(dim | size)).astype(int)
        outputs[dataset] = out
        rows.append(dict(dataset=dataset, rows=len(frame), all_rows_equal=True,
                         combined_full_fields_sha256=evidence_hash(combined),
                         candidate_full_fields_sha256=evidence_hash(candidate),
                         input_order_pair_id_sha256=hashlib.sha256(json_field(frame.pair_id.tolist()).encode()).hexdigest(),
                         size_rejected=int(size.sum()), bge_called=int((~exact & ~(dim | size)).sum())))
    return dict(status='preflight_pass', labels_accessed=False, GPU_used=False,
                planned_timing_rows=30, full_gate_evidence_and_decisions_identical=True,
                input_rows={name: len(frame) for name, frame in frames.items()}, datasets=rows), frozen_evidence, outputs


def compare_values(left, right, ids):
    checks, mismatches = {}, []
    for name in left:
        a, b = np.ascontiguousarray(left[name]), np.ascontiguousarray(right[name])
        equal = a.dtype == b.dtype and a.shape == b.shape and a.tobytes() == b.tobytes()
        checks[name] = bool(equal)
        if not equal:
            if a.shape == b.shape and a.dtype == b.dtype:
                byte_equal = a.view(np.uint8).reshape(len(a), -1) == b.view(np.uint8).reshape(len(b), -1)
                changed = np.flatnonzero(~byte_equal.all(axis=1))
                info = dict(field=name, changed_rows=len(changed), first_pair_ids=ids[changed[:20]].tolist())
                if name == 'score':
                    both = np.isfinite(a) & np.isfinite(b)
                    info['max_finite_abs_diff'] = float(np.max(np.abs(a[both] - b[both]))) if both.any() else None
                mismatches.append(info)
            else:
                mismatches.append(dict(field=name, shape_or_dtype_mismatch=True))
    return dict(all_fields_byte_identical=all(checks.values()), checks=checks, mismatches=mismatches)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--supplement', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--gate-directory', type=Path, default=REMOTE_ROOT / 'router_research_20261005/generic_unit_gate')
    parser.add_argument('--shared-policy', type=Path, default=REMOTE_ROOT / 'system_validation_20261005/scripts/system_policy.py')
    parser.add_argument('--plan', type=Path, default=HERE / 'frozen_paired_memo_inference_plan.json')
    parser.add_argument('--check-inputs', action='store_true')
    parser.add_argument('--preflight-output', type=Path)
    args = parser.parse_args()
    startup_start = time.perf_counter()
    plan = json.loads(args.plan.read_text())
    frames, source_manifest, input_paths = read_frozen_inputs(args, plan)
    helper = load_module('_paired_memo_helper', HERE / plan['memo_helper_file'])
    policy_module = load_module('_paired_shared_policy', args.shared_policy)
    dimension_module = load_module('_paired_generic_unit_gate', args.gate_directory / 'generic_unit_gate.py')
    exact_mask, serialize, rank_returned = policy_module.exact_mask, policy_module.serialize, policy_module.rank_returned
    dimension = dimension_module.dimension_conflict_mask
    # Parser imports and their empty cache allocation belong to startup only.
    gate_initialization = []
    gates = {}
    for policy in POLICIES:
        start = time.perf_counter()
        gates[policy] = helper.FreshEngineeringGate(args.gate_directory, memoize=policy == POLICIES[1])
        gate_initialization.append(dict(policy=policy, seconds=time.perf_counter() - start))
        assert_empty(gates[policy])
    startup_seconds = time.perf_counter() - startup_start
    preflight, expected_evidence, preflight_outputs = cpu_evidence_preflight(
        frames, args.gate_directory, helper.FreshEngineeringGate, dimension, exact_mask)
    preflight['frozen_plan_sha256'] = sha(args.plan)
    preflight['startup_initialization_seconds'] = startup_seconds
    preflight['gate_instance_initialization_seconds'] = gate_initialization
    if args.preflight_output:
        assert not args.preflight_output.exists()
        args.preflight_output.mkdir(parents=True)
        for name, frame in preflight_outputs.items():
            frame.to_csv(args.preflight_output / f'gate_evidence_{name}.csv.gz', index=False, compression={'method': 'gzip', 'mtime': 0})
        dump(args.preflight_output / 'preflight.json', preflight)
    if args.check_inputs:
        print(json.dumps(preflight, ensure_ascii=False)); return
    assert args.output is not None
    assert not args.output.exists(); args.output.mkdir(parents=True)
    import torch
    from transformers import AutoTokenizer, AutoModelForSequenceClassification
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    manifest = dict(status='running', labels_accessed=False, new_training=False, thresholds_retuned=False,
                    frozen_plan_sha256=sha(args.plan), runner_sha256=sha(__file__),
                    memo_helper_sha256=sha(HERE / plan['memo_helper_file']),
                    input_hashes={name: sha(path) for name, path in input_paths.items()},
                    input_rows={name: len(frame) for name, frame in frames.items()},
                    startup_initialization_seconds=startup_seconds,
                    gate_instance_initialization_seconds=gate_initialization,
                    input_loading_and_imports_separate=True, startup_includes_model_load=False,
                    evidence_preflight=preflight, GPU=torch.cuda.get_device_name(0),
                    torch_version=torch.__version__, batch_size=64, max_length=256,
                    timing=plan['timing_scope'], optimization_only=True,
                    measured_runs=[], paired_equivalence_checks=[], repeated_equivalence_checks=[])
    dump(args.output / 'execution_manifest.json', manifest)
    for name, frame in preflight_outputs.items():
        path = args.output / f'gate_evidence_{name}.csv.gz'
        frame.to_csv(path, index=False, compression={'method': 'gzip', 'mtime': 0})
    timings = []

    @torch.inference_mode()
    def execute(model, tokenizer, threshold, policy, frame):
        torch.cuda.synchronize(); start = time.perf_counter()
        gate = gates[policy]
        gate.clear()  # Clear on every measured pass; include this tiny overhead.
        assert_empty(gate)
        exact = np.asarray(exact_mask(frame), bool)
        dim = np.asarray(dimension(frame), bool)
        size, size_results = parse_size(gate, frame)
        conflict = dim | size
        called = ~exact & ~conflict
        indices = np.flatnonzero(called)
        scores = np.full(len(frame), np.nan)
        queries, candidates = serialize(frame.iloc[indices], 'query'), serialize(frame.iloc[indices], 'candidate')
        for lo in range(0, len(indices), 64):
            encoded = tokenizer(queries[lo:lo+64], candidates[lo:lo+64], padding=True,
                                truncation=True, max_length=256, return_tensors='pt')
            encoded = {key: value.to('cuda') for key, value in encoded.items()}
            with torch.autocast('cuda', dtype=torch.bfloat16):
                logits = model(**encoded).logits.reshape(-1)
            scores[indices[lo:lo+64]] = logits.float().cpu().numpy()
        assert np.isfinite(scores[called]).all(), 'Nonfinite called-model logits'
        kept = np.isfinite(scores) & (scores >= threshold)
        prediction = (exact | kept).astype(int)
        rank = rank_returned(frame, exact, np.where(kept, scores, np.nan), float('-inf')) if 'query_id' in frame else np.zeros(len(frame), dtype=int)
        torch.cuda.synchronize(); seconds = time.perf_counter() - start
        values = dict(score=scores, prediction=prediction, returned_rank=rank,
                      exact_match=exact.astype(int), dimension_rejected=dim.astype(int),
                      size_rejected=size.astype(int), any_gate_rejected=conflict.astype(int),
                      bge_called=called.astype(int))
        timing = dict(seconds=seconds, rows=len(frame), bge_pairs=int(called.sum()),
                      exact_pairs=int(exact.sum()), dimension_rejected_pairs=int(dim.sum()),
                      size_rejected_pairs=int(size.sum()), any_gate_rejected_pairs=int(conflict.sum()),
                      cache_cold_at_start=True, cache_stats=gate.cache_stats())
        return values, timing, evidence_fields(size_results)

    for run in source_manifest['runs']:
        seed = int(run['seed']); threshold = float(run['threshold']); checkpoint = Path(run['checkpoint'])
        for name, digest in run['checkpoint_files'].items():
            assert sha(checkpoint / name) == digest
        torch.manual_seed(seed)
        model_start = time.perf_counter()
        tokenizer = AutoTokenizer.from_pretrained(checkpoint, local_files_only=True)
        model = AutoModelForSequenceClassification.from_pretrained(checkpoint, local_files_only=True).to('cuda').eval()
        torch.cuda.synchronize()
        model_load_seconds = time.perf_counter() - model_start
        for dataset_index, (dataset, frame) in enumerate(frames.items()):
            # Identical warmup rows for each policy, cleared before measured pass.
            for policy in POLICIES:
                execute(model, tokenizer, threshold, policy, frame.head(128).reset_index(drop=True))
            first_by_policy = {}
            repeats = 3 if dataset == 'main220' else 1
            for repeat in range(repeats):
                paired = {}
                # Counterbalance consecutive pairs deterministically, without labels.
                order = POLICIES if (seed + dataset_index + repeat) % 2 == 0 else POLICIES[::-1]
                for position, policy in enumerate(order):
                    values, timing, actual_evidence = execute(model, tokenizer, threshold, policy, frame)
                    evidence_identical = actual_evidence == expected_evidence[dataset]
                    prefix = f'{dataset}_seed_{seed}_repeat_{repeat}_{policy}'
                    path = args.output / f'predictions_{prefix}.csv.gz'
                    output = frame[[key for key in KEYS + ['source_year'] if key in frame]].copy()
                    output['dataset'] = dataset; output['seed'] = seed; output['repeat'] = repeat
                    output['policy'] = policy; output['threshold'] = threshold
                    for name, value in values.items(): output[name] = value
                    for field in ('decision', 'rule', 'reason', 'evidence'):
                        output['size_combined_' + field] = [json_field(value.get(field)) for value in actual_evidence]
                    output.to_csv(path, index=False, compression={'method': 'gzip', 'mtime': 0})
                    # Raw float64 score file preserves every NaN/logit payload byte.
                    score_path = args.output / f'raw_score_{prefix}.npy'
                    np.save(score_path, values['score'], allow_pickle=False)
                    summary = dict(dataset=dataset, seed=seed, repeat=repeat, policy=policy,
                                   paired_execution_position=position, threshold=threshold,
                                   output=path.name, output_sha256=sha(path),
                                   raw_score_output=score_path.name, raw_score_file_sha256=sha(score_path),
                                   array_byte_sha256={name: array_byte_hash(value) for name, value in values.items()},
                                   gate_full_evidence_identical=evidence_identical,
                                   gate_full_evidence_sha256=evidence_hash(actual_evidence),
                                   cache_stats_after_run=timing.pop('cache_stats'))
                    manifest['measured_runs'].append(summary)
                    timings.append(dict(dataset=dataset, seed=seed, repeat=repeat, policy=policy,
                                        paired_execution_position=position, model_load_seconds=model_load_seconds,
                                        query_pools=frame.groupby(['evaluation_split','query_id']).ngroups if 'query_id' in frame else 0,
                                        **timing))
                    if not evidence_identical:
                        changed = [i for i, (a,b) in enumerate(zip(actual_evidence, expected_evidence[dataset])) if a != b]
                        dump(args.output / f'gate_equivalence_failure_{prefix}.json',
                             dict(changed_rows=len(changed), examples=[dict(pair_id=frame.pair_id.iloc[i],
                                  expected=expected_evidence[dataset][i],actual=actual_evidence[i]) for i in changed[:20]]))
                    if policy in first_by_policy:
                        check = compare_values(first_by_policy[policy], values, frame.pair_id.to_numpy(str))
                        manifest['repeated_equivalence_checks'].append(dict(dataset=dataset,seed=seed,
                            repeat=repeat,policy=policy,**check))
                    else:
                        first_by_policy[policy] = {name: value.copy() for name, value in values.items()}
                    paired[policy] = values
                    pd.DataFrame(timings).to_csv(args.output / 'timing.csv', index=False)
                    dump(args.output / 'execution_manifest.json', manifest)
                    print('FINISH', dataset, seed, repeat, policy, round(timing['seconds'], 6), timing['bge_pairs'], flush=True)
                check = compare_values(paired[POLICIES[0]], paired[POLICIES[1]], frame.pair_id.to_numpy(str))
                manifest['paired_equivalence_checks'].append(dict(dataset=dataset,seed=seed,repeat=repeat,**check))
                dump(args.output / 'execution_manifest.json', manifest)
        del model, tokenizer; gc.collect(); torch.cuda.empty_cache()
    assert len(timings) == plan['expected_timing_rows'] == 30
    assert len(manifest['paired_equivalence_checks']) == 15
    passed = all(run['gate_full_evidence_identical'] for run in manifest['measured_runs'])
    passed = passed and all(check['all_fields_byte_identical'] for check in
                           manifest['paired_equivalence_checks'] + manifest['repeated_equivalence_checks'])
    manifest['all_score_bytes_gate_evidence_acceptance_and_top3_identical'] = passed
    manifest['status'] = 'complete' if passed else 'complete_with_equivalence_failures'
    manifest['timing_sha256'] = sha(args.output / 'timing.csv')
    for name, path in input_paths.items(): assert sha(path) == plan['input_sha256'][name]
    for name, digest in plan['gate_file_sha256'].items(): assert sha(args.gate_directory / name) == digest
    assert sha(args.shared_policy) == plan['shared_policy_sha256']
    dump(args.output / 'execution_manifest.json', manifest)
    print('ALL_COMPLETE', manifest['status'], flush=True)


if __name__ == '__main__':
    main()
