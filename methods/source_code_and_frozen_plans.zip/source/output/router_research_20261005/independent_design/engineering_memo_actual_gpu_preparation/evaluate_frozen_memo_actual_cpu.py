#!/usr/bin/env python3
"""Independent CPU audit then fixed-reference evaluation of all 30 runs."""
import argparse
import dataclasses
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
GATE = HERE.parents[1] / 'generic_unit_gate'
WORKSPACE = HERE.parents[3]
POLICIES = ('dimension_size_gate_bge_original', 'dimension_size_gate_bge_memo')
KEYS = ('pair_id', 'evaluation_split', 'query_id', 'candidate_id', 'source_year')
MASKS = ('prediction','exact_match','dimension_rejected','size_rejected','any_gate_rejected','bge_called')


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path, value): Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
def require(condition, message):
    if not bool(condition): raise AssertionError(message)
def json_field(value): return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def evidence_hash(value): return hashlib.sha256(json_field(value).encode()).hexdigest()
def byte_hash(value):
    value=np.ascontiguousarray(value)
    return hashlib.sha256(str(value.dtype).encode()+json_field(value.shape).encode()+value.tobytes()).hexdigest()
def load_module(name, path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module
def item(row,side): return {key:row.get(f'{side}_{key}','') for key in ('description','normalized_description','unit','category','spec_tokens')}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--actual',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--evaluate-labels',action='store_true')
    args=parser.parse_args()
    require(not args.output.exists(),'Independent output directory already exists')
    args.output.mkdir(parents=True)
    evaluation_plan=json.loads((HERE/'frozen_cpu_evaluation_plan.json').read_text())
    inference_plan=json.loads((HERE/'frozen_paired_memo_inference_plan.json').read_text())
    record={str(Path(__file__).resolve()):sha(__file__)}
    require(record[str(Path(__file__).resolve())]==evaluation_plan['evaluator_sha256'],'Evaluator freeze differs')
    require(sha(HERE/'frozen_paired_memo_inference_plan.json')==evaluation_plan['paired_inference_plan_sha256'],'Inference plan freeze differs')
    for path,digest in evaluation_plan['protected_source_sha256'].items():
        require(sha(path)==digest,'Protected CPU source differs: '+path);record[path]=digest
    generic=load_module('_memo_independent_metrics',GATE/'evaluate_all_source_actual_cpu.py')
    source=WORKSPACE/'output/rule_first_system_20261004/results/server'
    supplement=WORKSPACE/'output/paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs'
    source_args=SimpleNamespace(source=source,supplement=supplement)
    oldplan=json.loads((GATE/'frozen_all_source_inference_plan.json').read_text())
    sm,frames=generic.input_frames(source_args,oldplan,record)
    require(sm['runs']==inference_plan['runs'],'Checkpoint or threshold source changed')
    sys.path.insert(0,str(GATE))
    import engineering_gate_v2
    from generic_unit_gate import dimension_conflict_mask
    masks,evidence,candidate_evidence={},{},{}
    for dataset,frame in frames.items():
        results=[engineering_gate_v2.contradiction_gate(item(row,'query'),item(row,'candidate'),('physical_size',))
                 for row in frame.to_dict('records')]
        candidate=[engineering_gate_v2.candidate_gate(item(row,'query'),item(row,'candidate'),'physical_size')
                   for row in frame.to_dict('records')]
        evidence[dataset]=[dataclasses.asdict(row) for row in results]
        candidate_evidence[dataset]=[dataclasses.asdict(row) for row in candidate]
        masks[dataset]=dict(exact_match=generic.independent_exact(frame),
                            dimension_rejected=np.asarray(dimension_conflict_mask(frame),bool),
                            size_rejected=np.asarray([row.decision=='reject' for row in results],bool))
        masks[dataset]['any_gate_rejected']=masks[dataset]['dimension_rejected']|masks[dataset]['size_rejected']
        masks[dataset]['bge_called']=~masks[dataset]['exact_match']&~masks[dataset]['any_gate_rejected']
    manifest_path=args.actual/'execution_manifest.json';manifest=json.loads(manifest_path.read_text())
    record[str(manifest_path)]=sha(manifest_path)
    require(manifest['status'] in ('complete','complete_with_equivalence_failures'),'All actual runs are not complete')
    require(not manifest['labels_accessed'] and not manifest['new_training'] and not manifest['thresholds_retuned'],'Actual run was not frozen label-free')
    require(manifest['runner_sha256']==inference_plan['runner_sha256'],'Actual runner SHA differs')
    require(manifest['frozen_plan_sha256']==evaluation_plan['paired_inference_plan_sha256'],'Actual inference plan SHA differs')
    require(manifest['memo_helper_sha256']==inference_plan['memo_helper_sha256'],'Actual memo helper differs')
    require(manifest['input_hashes']==inference_plan['input_sha256'],'Actual input hashes differ')
    require(len(manifest['measured_runs'])==30,'Actual condition coverage differs')
    expected_grid={tuple(row[key] for key in ('dataset','seed','repeat','policy')) for row in inference_plan['conditions']}
    actual_grid={tuple(row[key] for key in ('dataset','seed','repeat','policy')) for row in manifest['measured_runs']}
    require(actual_grid==expected_grid and len(actual_grid)==30,'Actual grid differs from frozen schedule')
    thresholds={int(row['seed']):float(row['threshold']) for row in sm['runs']}
    outputs,arrays={},{}
    audit_rows=[]
    for run in manifest['measured_runs']:
        identity=tuple(run[key] for key in ('dataset','seed','repeat','policy'))
        dataset,seed,repeat,policy=identity;frame=frames[dataset]
        csvpath=args.actual/run['output'];rawpath=args.actual/run['raw_score_output']
        require(sha(csvpath)==run['output_sha256'] and sha(rawpath)==run['raw_score_file_sha256'],'Actual output transfer SHA differs')
        record[str(csvpath)]=sha(csvpath);record[str(rawpath)]=sha(rawpath)
        out=pd.read_csv(csvpath,dtype=str,keep_default_na=False)
        require(len(out)==len(frame) and out.pair_id.tolist()==frame.pair_id.tolist(),'Actual row IDs/order differ')
        require(not generic.FORBIDDEN & set(out),'Answer fields in actual output')
        for key in KEYS:
            if key in frame: require(out[key].tolist()==frame[key].tolist(),'Input identity differs: '+key)
        for key,value in [('dataset',dataset),('seed',str(seed)),('repeat',str(repeat)),('policy',policy)]:
            require(out[key].eq(value).all(),'Output condition identity differs: '+key)
        require(out.threshold.astype(float).eq(thresholds[seed]).all(),'Threshold differs')
        raw=np.load(rawpath,allow_pickle=False)
        require(raw.dtype==np.dtype('float64') and raw.shape==(len(frame),),'Raw score contract differs')
        score=np.asarray([float(value) if value else np.nan for value in out.score],dtype=np.float64)
        require(score.tobytes()==raw.tobytes(),'CSV score bytes do not reproduce saved float64 score')
        values={'score':raw}
        for key in MASKS:
            require(out[key].isin(['0','1']).all(),'Nonbinary field: '+key)
            values[key]=out[key].astype(np.int64).to_numpy()
            if key!='prediction':require(np.array_equal(values[key].astype(bool),masks[dataset][key]),'Frozen mask differs: '+key)
        called=masks[dataset]['bge_called'];exact=masks[dataset]['exact_match']
        require(np.isfinite(raw[called]).all() and np.isnan(raw[~called]).all(),'Missing/extra model scores')
        expected=(exact|(called&(raw>=thresholds[seed]))).astype(int)
        require(np.array_equal(expected,values['prediction']),'Acceptance does not match actual scores and inherited threshold')
        values['returned_rank']=out.returned_rank.astype(np.int8 if 'query_id' in frame else np.int64).to_numpy()
        rank=generic.independent_rank(frame,exact,raw,thresholds[seed])
        require(np.array_equal(rank,values['returned_rank']),'Full-pool Top3 is wrong')
        require(run['array_byte_sha256']=={key:byte_hash(values[key]) for key in run['array_byte_sha256']},'Raw array byte hash differs')
        for field in ('decision','rule','reason','evidence'):
            expected_field=[json_field(value.get(field)) for value in evidence[dataset]]
            require(out['size_combined_'+field].tolist()==expected_field,'Gate full-field evidence differs: '+field)
        require(run['gate_full_evidence_sha256']==evidence_hash(evidence[dataset]),'Gate evidence digest differs')
        out['score']=raw;out['threshold']=thresholds[seed];out['returned_rank']=rank
        for key in MASKS:out[key]=values[key]
        outputs[identity]=out;arrays[identity]=values
        audit_rows.append(dict(dataset=dataset,seed=seed,repeat=repeat,policy=policy,rows=len(out),
            bge_called=int(called.sum()),size_rejected=int(masks[dataset]['size_rejected'].sum()),
            all_input_ids_masks_evidence_scores_acceptance_and_top3_valid=True))
    for dataset,frame in frames.items():
        ep=args.actual/f'gate_evidence_{dataset}.csv.gz';record[str(ep)]=sha(ep)
        ef=pd.read_csv(ep,dtype=str,keep_default_na=False)
        require(ef.pair_id.tolist()==frame.pair_id.tolist(),'Evidence IDs differ')
        for prefix,rows in [('size_combined_',evidence[dataset]),('size_candidate_',candidate_evidence[dataset])]:
            for field in ('decision','rule','reason','evidence'):
                require(ef[prefix+field].tolist()==[json_field(value.get(field)) for value in rows],'Underlying/combined evidence differs')
    equivalence=[]
    for dataset,seed,repeat,policy in sorted(expected_grid):
        if policy!=POLICIES[0]:continue
        a,b=arrays[(dataset,seed,repeat,POLICIES[0])],arrays[(dataset,seed,repeat,POLICIES[1])]
        checks={key:np.ascontiguousarray(a[key]).tobytes()==np.ascontiguousarray(b[key]).tobytes() for key in a}
        equivalence.append(dict(dataset=dataset,seed=seed,repeat=repeat,all_array_bytes_identical=all(checks.values()),checks=checks))
    repeated=[]
    for dataset,seed,repeat,policy in sorted(expected_grid):
        if repeat==0:continue
        a,b=arrays[(dataset,seed,0,policy)],arrays[(dataset,seed,repeat,policy)]
        checks={key:np.ascontiguousarray(a[key]).tobytes()==np.ascontiguousarray(b[key]).tobytes() for key in a}
        repeated.append(dict(dataset=dataset,seed=seed,repeat=repeat,policy=policy,all_array_bytes_identical=all(checks.values()),checks=checks))
    previous=[]
    previous_root=GATE/'all_source_actual'
    for dataset in frames:
        for seed in generic.SEEDS:
            oldpath=previous_root/f'predictions_{dataset}_seed_{seed}.csv';record[str(oldpath)]=sha(oldpath)
            old=pd.read_csv(oldpath,dtype=str,keep_default_na=False)
            old=old.loc[old.policy.eq('dimension_size_gate_bge')].reset_index(drop=True)
            new=outputs[(dataset,seed,0,POLICIES[0])]
            require(old.pair_id.tolist()==new.pair_id.tolist(),'Previous-run comparison IDs differ')
            old_score=np.asarray([float(v) if v else np.nan for v in old.score],dtype=float)
            quality_cols=(*MASKS,'returned_rank')
            differences={key:int((old[key].astype(int).to_numpy()!=new[key].to_numpy(int)).sum()) for key in quality_cols}
            previous.append(dict(dataset=dataset,seed=seed,previous_policy='dimension_size_gate_bge',
                previous_scores_numerically_equal=np.array_equal(old_score,new.score.to_numpy(float),equal_nan=True),
                quality_outputs_identical=not any(differences.values()),changed_rows_by_field=differences,
                previous_timing_never_used_in_this_paired_comparison=True))
    timing_path=args.actual/'timing.csv';require(sha(timing_path)==manifest['timing_sha256'],'Timing transfer SHA differs')
    record[str(timing_path)]=sha(timing_path);timing=pd.read_csv(timing_path)
    require(set(map(tuple,timing[['dataset','seed','repeat','policy']].to_numpy()))==expected_grid and len(timing)==30,'Timing grid differs')
    require(timing.seconds.gt(0).all() and np.isfinite(timing.seconds.to_numpy()).all(),'Invalid actual timing')
    paired=timing.pivot(index=['dataset','seed','repeat'],columns='policy',values='seconds').reset_index()
    paired['seconds_reduction_vs_paired_original']=1-paired[POLICIES[1]]/paired[POLICIES[0]]
    paired['speedup_vs_paired_original']=paired[POLICIES[0]]/paired[POLICIES[1]]
    paired.to_csv(args.output/'timing_each_paired_repeat.csv',index=False)
    med=timing.groupby(['dataset','seed','policy']).seconds.median().unstack('policy').reset_index()
    med['seconds_reduction_vs_same_seed_original_median']=1-med[POLICIES[1]]/med[POLICIES[0]]
    med['speedup_vs_same_seed_original_median']=med[POLICIES[0]]/med[POLICIES[1]]
    med['original_full_batch_cost_cny_2_88_per_hour']=med[POLICIES[0]]*2.88/3600
    med['memo_full_batch_cost_cny_2_88_per_hour']=med[POLICIES[1]]*2.88/3600
    med['same_model_call_count_no_additional_pruning']=True
    med.to_csv(args.output/'timing_seed_medians_and_paired_reduction.csv',index=False)
    generic.seed_aggregate(med,['dataset'],['seed']).to_csv(args.output/'timing_seed_mean_sample_sd.csv',index=False)
    pd.DataFrame(audit_rows).to_csv(args.output/'independent_condition_audit.csv',index=False)
    bytepass=all(row['all_array_bytes_identical'] for row in equivalence+repeated)
    audit=dict(passed=True,phase='independent_all_outputs_audited_before_this_experiment_label_join',
        labels_read=False,all_actual_output_integrity_checks_pass=True,
        all_paired_and_repeated_array_bytes_identical=bytepass,paired_checks=equivalence,repeated_checks=repeated,
        previous_generic_same_policy_quality_checks=previous,
        actual_status=manifest['status'],conditions=30,rows_total=sum(len(o) for o in outputs.values()),
        startup_initialization_seconds=manifest['startup_initialization_seconds'],
        gate_instance_initialization_seconds=manifest['gate_instance_initialization_seconds'],
        preserved_failed_equivalence_not_selected=True,source_hashes=record)
    dump(args.output/'prelabel_independent_integrity.json',audit)
    if args.evaluate_labels:
        label_args=SimpleNamespace(source=source,supplement=supplement,challenge_labels=None,alberta_labels=None,
            reference600=generic.DEFAULT_REFERENCE600,alberta_reference=generic.DEFAULT_ALBERTA_REFERENCE)
        labels,sources,details=generic.label_join(label_args,sm,frames,record)
        pair_rows,top_rows=[],[]
        for (dataset,seed,repeat,policy),out in outputs.items():
            joined=out.merge(labels[dataset],on='pair_id',validate='one_to_one')
            for group,part in generic.evaluation_views(dataset,joined):
                identity=dict(dataset=dataset,seed=seed,repeat=repeat,policy=policy,group=group,label_source=sources[dataset])
                pair_rows.append({**identity,**generic.pair_metrics(part)})
                top=generic.top3_metrics(part)
                if group=='locked100_hard_pairs':
                    for key in ('completely_known_no_reference_query_n','no_reference_rejected_n','no_reference_rejection_rate'):top[key]=None
                    top['scope_note']='Stored full-pool ranks retained on frozen hard-pair subset; no refill.'
                top_rows.append({**identity,**top})
        pm,tm=pd.DataFrame(pair_rows),pd.DataFrame(top_rows)
        pm.to_csv(args.output/'pair_metrics_every_actual_condition.csv',index=False)
        tm.to_csv(args.output/'actual_top3_metrics_every_actual_condition.csv',index=False)
        # Repeat0 is predeclared; never choose the best score/repetition.
        for frame,name in [(pm,'pair_metrics'),(tm,'actual_top3_metrics')]:
            first=frame.loc[frame.repeat.eq(0)].copy();first.to_csv(args.output/f'{name}_each_seed_predeclared_repeat0.csv',index=False)
            if name=='actual_top3_metrics':first=first.loc[first.top3_available.eq(True)].copy()
            for column in first:
                if column not in ('dataset','seed','policy','group','label_source','scope_note','reason'):
                    first[column]=pd.to_numeric(first[column],errors='coerce')
            generic.seed_aggregate(first,['dataset','policy','group','label_source'],['seed','repeat']).to_csv(args.output/f'{name}_seed_mean_sample_sd.csv',index=False)
        dump(args.output/'evaluation_integrity.json',dict(passed=True,labels_joined_after_all_output_checks=True,
            references=details,label_source=sources,all_array_bytes_identical=bytepass,
            no_test_selection_no_threshold_changes=True,seed_n=3,sample_sd_ddof=1,
            primary_quality_repeat0_predeclared=True,other_repetitions_all_reported=True,
            uncertainty_removed_from_quality_after_actual_ranking_only=True,
            same_session_original_memo_timing_only=True,source_hashes=record))
    for path,digest in record.items():require(sha(path)==digest,'Read source changed during audit/evaluation: '+path)
    print(json.dumps(dict(status='completed_independent_CPU_QA_and_evaluation' if args.evaluate_labels else 'completed_prelabel_independent_CPU_QA',
                         byte_equivalence_pass=bytepass,all_previous_quality_outputs_identical=all(r['quality_outputs_identical'] for r in previous),output=str(args.output))))


if __name__=='__main__':main()
