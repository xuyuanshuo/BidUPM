"""CPU diagnostic: isolated frozen parser with exact intermediate memoization.

Original files and the caller's module globals remain unchanged. Each instance
owns fresh empty caches. No IDs, data labels, learned rules, model calls or disk
cache keys are used. This has not been deployed in the GPU system.
"""
from pathlib import Path
from functools import lru_cache
import importlib.util
import sys
import uuid

class FreshEngineeringGate:
    def __init__(self, directory: Path, memoize: bool):
        tag=uuid.uuid4().hex
        def load(name,path):
            spec=importlib.util.spec_from_file_location(name,path)
            m=importlib.util.module_from_spec(spec);sys.modules[name]=m
            spec.loader.exec_module(m);return m
        self.v1=load('_diagnostic_engineering_v1_'+tag,directory/'engineering_gate.py')
        self.caches={}
        if memoize:
            for name in ['_prepare','_normalize','size_evidence','_residual_has_work']:
                cached=lru_cache(maxsize=None)(getattr(self.v1,name))
                setattr(self.v1,name,cached);self.caches[name]=cached
            original_description=self.v1._description
            @lru_cache(maxsize=None)
            def description_strings(raw,normalized):
                return original_description({'description':raw,'normalized_description':normalized})
            def description_record(record):
                # _text has exactly the same conversion/whitespace semantics.
                return description_strings(self.v1._text(record.get('description')),
                                           self.v1._text(record.get('normalized_description')))
            self.v1._description=description_record
            self.caches['_description']=description_strings
        # v2's frozen import binds only to this isolated v1 instance, then the
        # previous normal module mapping is restored even after import failure.
        previous=sys.modules.get('engineering_gate')
        try:
            sys.modules['engineering_gate']=self.v1
            self.v2=load('_diagnostic_engineering_v2_'+tag,directory/'engineering_gate_v2.py')
        finally:
            if previous is None:sys.modules.pop('engineering_gate',None)
            else:sys.modules['engineering_gate']=previous
        if memoize:
            self.v2._size_guard=lru_cache(maxsize=None)(self.v2._size_guard)
            self.caches['_size_guard']=self.v2._size_guard
        self.candidate_gate=self.v2.candidate_gate
        self.contradiction_gate=self.v2.contradiction_gate
    def cache_stats(self):
        return {name:dict(zip(['hits','misses','maxsize','currsize'],f.cache_info()))
                for name,f in self.caches.items()}
    def clear(self):
        for f in self.caches.values():f.cache_clear()
