#!/usr/bin/env python3
"""Training/validation-only lexical probes. Never opens held-out test labels."""
import hashlib, json, sys, time
from pathlib import Path
from dataclasses import asdict
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler

BASE=Path(__file__).resolve().parents[2]
DATA=BASE/'revise3_full_20260920/supplementary/data'
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(DATA.parent/'scripts/original'))
from bidupm_vfinal_common import canonical_text, canonical_unit, pair_features

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
FEATURES=['unit_match','category_match','item_code_match','exact_description','token_jaccard','token_containment','sequence_ratio','action_conflict','material_conflict','dimension_conflict','class_conflict','type_conflict','spec_conflict']
def arrays(d, vecs):
    rows=[]
    for r in d.to_dict('records'):
        q=dict(description=r['query_description'],normalized_description=r['query_normalized_description'],unit=r['query_unit'],normalized_unit=r['query_normalized_unit'],category=r['query_category'],item_code=r['query_item_code'])
        c=dict(description=r['candidate_description'],normalized_description=r['candidate_normalized_description'],unit=r['candidate_unit'],normalized_unit=r['candidate_normalized_unit'],category=r['candidate_category'],item_code=r['candidate_item_code'])
        f=asdict(pair_features(q,c));rows.append([f[k] for k in FEATURES])
    num=np.asarray(rows,float)
    q=d.query_normalized_description.map(canonical_text)
    c=d.candidate_normalized_description.map(canonical_text)
    mats={}; cos=[]
    for name,v in vecs.items():
        qm=v.transform(q);cm=v.transform(c)
        prod=qm.multiply(cm)
        cos.append(np.asarray(prod.sum(axis=1)).ravel())
        diff=qm-cm;diff.data=np.abs(diff.data)
        mats[name]=hstack([prod,diff],format='csr')
    lexical=np.column_stack([num,*cos])
    return num,lexical,hstack([*mats.values(),csr_matrix(lexical)],format='csr')

def metric(y,p):
    tp=int(np.sum((y==1)&p));fp=int(np.sum((y==0)&p));fn=int(np.sum((y==1)&~p))
    return dict(tp=tp,fp=fp,fn=fn,precision=tp/(tp+fp) if tp+fp else 0,recall=tp/(tp+fn) if tp+fn else 0,f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0)
def choose(y,s,ex,mode):
    # Residual membership is an input-derived exact rule, never difficulty labels.
    thresholds=np.unique(np.r_[0,1,np.quantile(s,np.linspace(0,1,501))])
    choices=[]
    for t in thresholds:
        p=ex|(s>=t)
        m=metric(y,p);n=metric(y[~ex],p[~ex])
        if mode=='overall_f1': key=(m['f1'],m['precision'],t)
        elif mode=='residual_f1': key=(n['f1'],m['f1'],t)
        else: key=(n['precision'] if n['recall']>=.9 else -1,n['recall'],t)
        choices.append((key,float(t)))
    return max(choices)[1]

def main():
    trp=DATA/'training/training_pairs_semantic_deduplicated.csv';vp=DATA/'evaluation/validation_pairs.csv'
    tr=pd.read_csv(trp).fillna('');va=pd.read_csv(vp).fillna('')
    y=tr.final_label.to_numpy(int);vy=va.final_label.to_numpy(int)
    exact=((tr.exact_description==1)&(tr.unit_match==1)).to_numpy();vex=((va.exact_description==1)&(va.unit_match==1)).to_numpy()
    plan=dict(source_files={str(trp):sha(trp),str(vp):sha(vp)},feature_definition=FEATURES,vectorizer_corpus='training query and candidate descriptions only',folds='5 StratifiedGroupKFold grouped by query_semantic_key',hyperparameters=dict(families=['engineering_numeric','char_word_cosine','symmetric_sparse'],C=[.1,1.,10.],positive_weight=[1.,4.,16.]),threshold_objectives=['overall_f1','residual_f1','residual_recall90'],holdout_test_opened=False,training_rows=len(tr),validation_rows=len(va))
    (OUT/'probe_plan_before_execution.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
    corpus=list(dict.fromkeys(tr.query_normalized_description.map(canonical_text).tolist()+tr.candidate_normalized_description.map(canonical_text).tolist()))
    vecs=dict(char=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=1,sublinear_tf=True),word=TfidfVectorizer(analyzer='word',ngram_range=(1,2),min_df=1,sublinear_tf=True,token_pattern=r'(?u)\b[a-z0-9]+\b'))
    for v in vecs.values():v.fit(corpus)
    ta=arrays(tr,vecs);va_arrays=arrays(va,vecs)
    folds=list(StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=20261005).split(np.zeros(len(y)),y,tr.query_semantic_key))
    frozen=[];scores=[]; models=[]
    for fi,family in enumerate(plan['hyperparameters']['families']):
        for c in plan['hyperparameters']['C']:
            for w in plan['hyperparameters']['positive_weight']:
                name=f'{family}_C{c:g}_PW{w:g}'
                oof=np.zeros(len(y)); X=ta[fi];VX=va_arrays[fi]
                start=time.perf_counter()
                for it,iv in folds:
                    scale=StandardScaler(with_mean=False);tx=scale.fit_transform(X[it]);ix=scale.transform(X[iv])
                    model=LogisticRegression(C=c,class_weight={0:1.,1:w},max_iter=2000,random_state=20261005,solver='liblinear')
                    model.fit(tx,y[it]);oof[iv]=model.predict_proba(ix)[:,1]
                # All objectives fixed from grouped out-of-fold training scores.
                thresholds={m:choose(y,oof,exact,m) for m in plan['threshold_objectives']}
                frozen.append(dict(model=name,thresholds=thresholds))
                scale=StandardScaler(with_mean=False);tx=scale.fit_transform(X);vx=scale.transform(VX)
                model=LogisticRegression(C=c,class_weight={0:1.,1:w},max_iter=2000,random_state=20261005,solver='liblinear');model.fit(tx,y)
                vs=model.predict_proba(vx)[:,1];elapsed=time.perf_counter()-start
                for split,d,ys,ss,ex in [('train_oof',tr,y,oof,exact),('validation',va,vy,vs,vex)]:
                    for mode,t in thresholds.items():
                        pp=ex|(ss>=t)
                        record=dict(model=name,split=split,threshold_objective=mode,threshold=t,fit_score_seconds=elapsed,**metric(ys,pp))
                        record.update({f'residual_{k}':v for k,v in metric(ys[~ex],pp[~ex]).items()})
                        scores.append(record)
                    for pid,s in zip(d.pair_id,ss):models.append(dict(model=name,split=split,pair_id=pid,score=float(s)))
                print(name,flush=True)
    (OUT/'training_only_frozen_thresholds.json').write_text(json.dumps(frozen,indent=2))
    pd.DataFrame(scores).to_csv(OUT/'training_validation_only_metrics.csv',index=False)
    pd.DataFrame(models).to_csv(OUT/'training_validation_only_scores.csv',index=False)
    # Generic features can be joined by pair_id to server model scores for stacking.
    for split,d,a in [('training',tr,ta[1]),('validation',va,va_arrays[1])]:
        out=pd.DataFrame(a,columns=FEATURES+['char_cosine','word_cosine']);out.insert(0,'pair_id',d.pair_id)
        out.to_csv(OUT/f'{split}_input_features.csv',index=False)
    (OUT/'probe_completion.json').write_text(json.dumps(dict(completed=True,models=27,threshold_policies=81,read_test_labels=False,training_sha=sha(trp),validation_sha=sha(vp)),indent=2))

if __name__=='__main__':main()
