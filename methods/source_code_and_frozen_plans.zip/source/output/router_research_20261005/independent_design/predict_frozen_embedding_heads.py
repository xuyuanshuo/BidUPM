#!/usr/bin/env python3
"""Score frozen head candidates on input fields only, before evaluator opens gold."""
import argparse,json,time
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from dataclasses import asdict
from sklearn.feature_extraction.text import TfidfVectorizer
from threadpoolctl import threadpool_limits
import run_training_validation_probe as p
import run_frozen_embedding_heads as h

FIELDS=['pair_id','query_id','candidate_id','query_description','query_unit','query_normalized_description','query_normalized_unit','candidate_description','candidate_unit','candidate_normalized_description','candidate_normalized_unit']
def input_numeric(d,vecs):
    records=[]
    for r in d.to_dict('records'):
        q=dict(description=r['query_description'],normalized_description=r['query_normalized_description'],unit=r['query_unit'],normalized_unit=r['query_normalized_unit'])
        c=dict(description=r['candidate_description'],normalized_description=r['candidate_normalized_description'],unit=r['candidate_unit'],normalized_unit=r['candidate_normalized_unit'])
        records.append(asdict(p.pair_features(q,c)))
    ft=pd.DataFrame(records)
    for name,v in vecs.items():
        q=v.transform(d.query_normalized_description.map(p.canonical_text));c=v.transform(d.candidate_normalized_description.map(p.canonical_text));ft[f'{name}_cosine']=np.asarray(q.multiply(c).sum(axis=1)).ravel()
    return ft
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--head-directory',type=Path,required=True);ap.add_argument('--embedding-array',type=Path,required=True);ap.add_argument('--item-map',type=Path,required=True);ap.add_argument('--pairs',type=Path,nargs='+',required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--selected-only',action='store_true');a=ap.parse_args()
    frozen=json.loads((a.head_directory/'all_models_and_thresholds_frozen.json').read_text());selected=json.loads((a.head_directory/'selected_before_test.json').read_text())
    training=pd.read_csv(p.DATA/'training/training_pairs_semantic_deduplicated.csv',usecols=['query_normalized_description','candidate_normalized_description']).fillna('')
    corpus=list(dict.fromkeys(training.query_normalized_description.map(p.canonical_text).tolist()+training.candidate_normalized_description.map(p.canonical_text).tolist()))
    vecs=dict(char=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=1,sublinear_tf=True),word=TfidfVectorizer(analyzer='word',ngram_range=(1,2),min_df=1,sublinear_tf=True,token_pattern=r'(?u)\b[a-z0-9]+\b'))
    for v in vecs.values():v.fit(corpus)
    emb,index=h.load_embeddings(a.embedding_array,a.item_map)
    inputs=[]
    for path in a.pairs:
        header=pd.read_csv(path,nrows=0).columns
        f=pd.read_csv(path,usecols=[c for c in FIELDS if c in header]).fillna('')
        for role in ['query','candidate']:
            if f'{role}_id' not in f:f[f'{role}_id']=f.pair_id.astype(str)+f':{role}'
        inputs.append(f)
    frame=pd.concat(inputs,ignore_index=True)
    duplicate_rows=int(frame.pair_id.duplicated().sum())
    if duplicate_rows:
        for pid,g in frame[frame.pair_id.duplicated(keep=False)].groupby('pair_id'):
            if len(g.drop_duplicates())!=1:raise ValueError(f'inconsistent duplicate inputs for {pid}')
        frame=frame.drop_duplicates('pair_id',keep='first').reset_index(drop=True)
    start=time.perf_counter();ft=input_numeric(frame,vecs)
    qr=h.item_row_indices(frame.query_normalized_description,frame.query_normalized_unit,index)
    cr=h.item_row_indices(frame.candidate_normalized_description,frame.candidate_normalized_unit,index)
    q=emb[qr];c=emb[cr];cos=np.sum(q*c,axis=1)
    numeric=ft[h.NUMERIC_NAMES].to_numpy(float);x=np.column_stack([np.abs(q-c),q*c,cos,cos*numeric[:,0],numeric]);ex=((ft.exact_description==1)&(ft.unit_match==1)).to_numpy()
    a.output.mkdir(exist_ok=True,parents=True);score_records=[];decision_records=[]
    with threadpool_limits(limits=1):
      for f in frozen:
        name=f['model'];model_path=a.head_directory/'fitted_models'/f'{name}.joblib'
        if a.selected_only and name not in {z['model'] for z in selected.values()}:continue
        if h.sha(model_path)!=f['model_sha']:raise ValueError(f'model hash mismatch {name}')
        fit=joblib.load(model_path);score=fit['classifier'].predict_proba(fit['scaler'].transform(x))[:,1]
        for row,s in zip(frame[['pair_id','query_id','candidate_id']].to_dict('records'),score):score_records.append(dict(model=name,score=float(s),**row))
        for mode,z in f['validation_policies'].items():
            if a.selected_only and selected[mode]['model']!=name:continue
            accepted=ex|(score>=z['threshold'])
            for pid,sc,ac,is_ex in zip(frame.pair_id,score,accepted,ex):decision_records.append(dict(model=name,policy=mode,pair_id=pid,score=float(sc),threshold=z['threshold'],exact_rule_accept=bool(is_ex),accepted=bool(ac),selected_before_test=selected[mode]['model']==name))
    pd.DataFrame(score_records).to_csv(a.output/'scores_before_gold.csv',index=False);pd.DataFrame(decision_records).to_csv(a.output/'decisions_before_gold.csv',index=False)
    manifest=dict(rows=len(frame),duplicate_input_rows_removed=duplicate_rows,models_scored=len({r['model'] for r in score_records}),models_frozen=len(frozen),selected_only=a.selected_only,input_files={str(pth):h.sha(pth) for pth in a.pairs},only_input_columns_read=FIELDS,label_columns_read=False,frozen_models_sha=h.sha(a.head_directory/'all_models_and_thresholds_frozen.json'),selected_sha=h.sha(a.head_directory/'selected_before_test.json'),embedding_array_sha=h.sha(a.embedding_array),item_map_sha=h.sha(a.item_map),predict_script_sha=h.sha(Path(__file__)),cpu_feature_and_heads_seconds=time.perf_counter()-start,timing_limitation='cached item embeddings; not full GPU preprocessing/query embedding latency')
    (a.output/'prediction_manifest_before_gold.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(manifest),flush=True)

if __name__=='__main__':main()
