#!/usr/bin/env python3
"""Last-stage QA/evaluation of all three frozen Alberta Qwen4 passes.

Run only after the GPU execution manifest is complete. All three old validation
thresholds are retained; no seed, threshold, or route is selected from Alberta.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

OWN = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[2]
SEEDS = [20260904, 20260905, 20260906]
SOURCE = "GPT6Sol_blind_AI_reference_not_human"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dump(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def pair_metrics(y, pred):
    tp = int(np.sum((y == 1) & pred)); fp = int(np.sum((y == 0) & pred))
    fn = int(np.sum((y == 1) & ~pred)); tn = int(np.sum((y == 0) & ~pred))
    return dict(tp=tp, fp=fp, fn=fn, tn=tn,
                precision=tp/(tp+fp) if tp+fp else np.nan,
                recall=tp/(tp+fn) if tp+fn else np.nan,
                f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,
                accuracy=(tp+tn)/len(y) if len(y) else np.nan)

def last3_metrics(z):
    known = z[z.reference_uncertain == 0]
    returned = known[known.returned_rank > 0]
    tp = int(returned.reference_label.sum()); fp = len(returned)-tp
    recalls = []; hit = 0; zero = 0; reject = 0
    for _, g in z.groupby(["source_year", "query_id"]):
        kg = g[g.reference_uncertain == 0]
        n = int(kg.reference_label.sum())
        t = int(kg.loc[kg.returned_rank > 0, "reference_label"].sum())
        if n:
            recalls.append(t/n); hit += int(t > 0)
        elif not g.reference_uncertain.any():
            zero += 1; reject += int(not (g.returned_rank > 0).any())
    return dict(returned_tp=tp, returned_fp=fp,
                returned_precision=tp/(tp+fp) if tp+fp else np.nan,
                macro_recall_at3=float(np.mean(recalls)) if recalls else np.nan,
                hit_at3=hit/len(recalls) if recalls else np.nan,
                known_positive_query_n=len(recalls),
                no_reference_rejection=reject/zero if zero else np.nan,
                completely_known_no_reference_query_n=zero,
                returned_uncertain_n=int(((z.returned_rank > 0) & (z.reference_uncertain == 1)).sum()))

def bf16_round(values):
    a = np.asarray(values, dtype=np.float32).copy()
    u = a.view(np.uint32)
    u = (u + np.uint32(0x7fff) + ((u >> 16) & 1)) & np.uint32(0xffff0000)
    return u.view(np.float32)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    ap.add_argument("--plan", type=Path, default=OWN/"qwen4_alberta_scope_core_frozen_inference_plan.json")
    a = ap.parse_args(); a.output.mkdir(parents=True, exist_ok=True)
    plan = json.loads(a.plan.read_text())
    manifest_path = a.results/"execution_manifest.json"
    m = json.loads(manifest_path.read_text())
    assert m["status"] == "complete" and len(m["completed_runs"]) == 3
    assert m["input_sha256"] == plan["input_sha256"]
    assert m["old_frozen_plan_sha256"] == sha(a.plan)
    assert m["script_sha256"] == plan["source_sha256"]
    assert m["labels_accessed"] is False and m["reference_available_to_runner"] is False
    assert m["old_thresholds_frozen"] and not m["new_training"] and not m["method_selected_from_alberta"]
    source_input = Path(plan["local_identical_input_csv"])
    assert sha(source_input) == plan["input_sha256"]
    inp = pd.read_csv(source_input, usecols=["pair_id", "source_year", "query_id", "candidate_id"], dtype=str)[["pair_id", "source_year", "query_id", "candidate_id"]]
    timing_path = a.results/"timing.csv"
    assert sha(timing_path) == m["timing_sha256"]
    timing = pd.read_csv(timing_path)
    assert sorted(timing.seed.tolist()) == SEEDS and len(timing) == 3
    assert timing.rows.eq(67635).all() and timing.actual_full_pass.all() and timing.seconds.gt(0).all()
    checks = []; frames = {}; frozen_outputs = {}
    prior600_path = ROOT/"paper_experiment_completion_20261005/results/challenge600_gpu/execution_manifest.json"
    prior600 = json.loads(prior600_path.read_text())
    for seed in SEEDS:
        r = next(r for r in plan["runs"] if r["seed"] == seed)
        run = next(r for r in m["completed_runs"] if r["seed"] == seed)
        prior_run = next(prior for prior in prior600["completed_runs"] if prior["run_id"] == run["run_id"])
        assert run["checkpoint"] == prior_run["checkpoint"]
        assert run["threshold"] == prior_run["threshold"] == r["threshold"]
        assert run["adapter_weight_sha256"] == prior_run["checkpoint_weight_sha256"]
        path = a.results/run["output_file"]
        assert sha(path) == run["output_sha256"]
        frozen_outputs[str(path)] = sha(path)
        d = pd.read_csv(path, dtype={"pair_id": str, "source_year": str, "query_id": str, "candidate_id": str})
        assert len(d) == 67635 and d.pair_id.nunique() == 67635
        assert d[["pair_id", "source_year", "query_id", "candidate_id"]].equals(inp)
        assert d.seed.eq(seed).all() and d.threshold.eq(r["threshold"]).all()
        assert np.isfinite(d[["logit_yes", "logit_no", "score"]].to_numpy()).all()
        assert np.array_equal(d.prediction.to_numpy(), (d.score >= r["threshold"]).astype(int))
        # Native returned dtype is preserved in GPU subtraction. Accept its
        # exact float32 value, or exact BF16 rounding of float32 subtraction.
        delta = d.logit_yes.to_numpy(np.float32) - d.logit_no.to_numpy(np.float32)
        score = d.score.to_numpy(np.float32)
        assert np.all((score == delta) | (score == bf16_round(delta)))
        accepted = d[d.prediction == 1].sort_values(["source_year", "query_id", "score", "candidate_id"], ascending=[True, True, False, True]).copy()
        accepted["expected_rank"] = accepted.groupby(["source_year", "query_id"]).cumcount()+1
        ranks = dict(zip(accepted.loc[accepted.expected_rank <= 3, "pair_id"], accepted.loc[accepted.expected_rank <= 3, "expected_rank"]))
        assert np.array_equal(d.returned_rank.to_numpy(), d.pair_id.map(ranks).fillna(0).to_numpy(int))
        parity = pd.read_csv(a.results/f"parity_seed_{seed}.csv")
        pj = json.loads((a.results/f"parity_seed_{seed}.json").read_text())
        assert len(parity) >= 256 and parity.pair_id.tolist() == d.pair_id.head(len(parity)).tolist()
        if pj["optimized_enabled"]:
            assert pj["decision_changed_n"] == 0 and pj["score_max_abs_diff"] <= m["allowed_score_atol"]
            assert np.array_equal(parity.all_logits_prediction, parity.last_logits_prediction)
        frames[seed] = d
        checks.append(dict(seed=seed, full_rows_complete=True, threshold_unchanged=True,
                           decisions_reproduced=True, top3_rank_reproduced=True,
                           score_native_subtraction_reproduced=True, parity=pj,
                           checkpoint_weights_and_threshold_match_original600=True,
                           threshold=r["threshold"], positive_n=int(d.prediction.sum())))
    dump(a.output/"predictions_frozen_before_reference_evaluation.json",
         dict(status="all_predictions_validated_before_reference_read", no_alberta_selection=True,
              source_input_sha256=sha(source_input), plan_sha256=sha(a.plan),
              execution_manifest_sha256=sha(manifest_path), output_hashes=frozen_outputs))
    # First reference access is here, after all predictions/hashes are frozen.
    refpath = ROOT/"router_research_20261005/rule_verification/alberta_reference_index.csv"
    rulepath = ROOT/"router_research_20261005/rule_verification/alberta_rule_predictions_all_stages.csv"
    old_qa = json.loads((OWN/"small_dataset_comparison/reference_and_output_integrity_qa.json").read_text())
    assert sha(refpath) == old_qa["source_hashes"]["output/router_research_20261005/rule_verification/alberta_reference_index.csv"]
    assert sha(rulepath) == old_qa["source_hashes"]["output/router_research_20261005/rule_verification/alberta_rule_predictions_all_stages.csv"]
    reference = pd.read_csv(refpath, dtype={"pair_id": str})
    assert len(reference) == 67635 and reference.reference_label.sum() == 142 and reference.reference_uncertain.sum() == 56
    exact = pd.read_csv(rulepath, usecols=["pair_id", "policy", "prediction"], dtype={"pair_id": str})
    exact = exact[exact.policy == "normalized_exact_plus_unit"]
    exact_by_id = dict(zip(exact.pair_id, exact.prediction.astype(bool)))
    rows = []; listrows = []
    for seed, d in frames.items():
        z = d.merge(reference[["pair_id", "reference_label", "reference_uncertain"]], on="pair_id", validate="one_to_one")
        z["input_nonexact"] = ~z.pair_id.map(exact_by_id).to_numpy(bool)
        for group, g in [("both", z), *[(year, z[z.source_year == year]) for year in ["2024", "2026"]]]:
            for subset, s in [("all_pairs", g), ("input_nonexact_normalized", g[g.input_nonexact])]:
                known = s[s.reference_uncertain == 0]
                rows.append(dict(model="qwen4_original_lora_scope_core", seed=seed, label_source=SOURCE,
                                 group=group, subset=subset, rows=len(known), positive_n=int(known.reference_label.sum()),
                                 uncertain_excluded_n=len(s)-len(known),
                                 **pair_metrics(known.reference_label.to_numpy(int), known.prediction.to_numpy(bool))))
            listrows.append(dict(model="qwen4_original_lora_scope_core", seed=seed, label_source=SOURCE,
                                 group=group, **last3_metrics(g)))
    pairs = pd.DataFrame(rows); lists = pd.DataFrame(listrows)
    pairs.to_csv(a.output/"pair_metrics_each_seed.csv", index=False)
    lists.to_csv(a.output/"final3_metrics_each_seed.csv", index=False)
    pairs.groupby(["model", "label_source", "group", "subset"]).agg(
        seeds=("seed", "size"), precision_mean=("precision", "mean"), precision_std=("precision", "std"),
        recall_mean=("recall", "mean"), recall_std=("recall", "std"), f1_mean=("f1", "mean"), f1_std=("f1", "std"),
        tp_mean=("tp", "mean"), fp_mean=("fp", "mean"), fn_mean=("fn", "mean")
    ).reset_index().to_csv(a.output/"pair_metrics_aggregate.csv", index=False)
    ls = ["returned_precision", "macro_recall_at3", "hit_at3", "no_reference_rejection"]
    lists.groupby(["model", "label_source", "group"])[ls].agg(["mean", "std"]).to_csv(a.output/"final3_metrics_aggregate.csv")
    timing["seconds_per_pair"] = timing.seconds/timing.rows
    timing["resident_inference_rmb_at_2_88_per_hour"] = timing.seconds*2.88/3600
    timing["model_load_rmb_at_2_88_per_hour"] = timing.model_load_seconds*2.88/3600
    timing.to_csv(a.output/"actual_timing_and_gpu_cost_each_seed.csv", index=False)
    assert all(sha(Path(path)) == digest for path, digest in frozen_outputs.items())
    dump(a.output/"full_output_qa.json", dict(passed=True, all_three_seeds_reported=True,
         all_prediction_files_unchanged_after_evaluation=True, rows_per_seed=67635,
         total_model_pairs=202905, no_alberta_threshold_or_seed_selection=True,
         human_gold_available=False, label_source=SOURCE, reference_sha256=sha(refpath),
         reference_and_rule_definitions_unchanged_from_prior_frozen_comparison=True,
         uncertain_pairs_excluded=56, no_reference_query_requires_all_candidates_known=True,
         uncertain_returned_candidates_keep_original_top3_slots=True,
         timing_excludes_model_loading_and_reference_evaluation=True,
         timing_actual_scope="Resident-model synchronized item serialization/tokenization/GPU scoring pass; threshold, ranking, file I/O, loading and A/B verification are outside the measured interval.",
         runner_manifest_timing_scope_correction="Runner manifest mentions threshold inside timing, but its implementation thresholds only after infer() returns. Preserve immutable source/manifest and use this audited actual scope in reports.",
         monetary_cost_is_gpu_rental_estimate_not_api_measurement=True,
         current600_and_alberta_use_identical_checkpoint_weights_and_original_thresholds=True,
         current600_gpu_manifest_sha256=sha(prior600_path),
         checks=checks, source_hashes=frozen_outputs))
    print(pairs[(pairs.group == "both") & (pairs.subset == "all_pairs")].to_string(index=False))

if __name__ == "__main__":
    main()
