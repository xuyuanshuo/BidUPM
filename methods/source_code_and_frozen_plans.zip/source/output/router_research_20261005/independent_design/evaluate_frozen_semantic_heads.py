#!/usr/bin/env python3
"""Last-stage quality evaluator. Reads gold only after predictions are frozen."""
import json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import run_training_validation_probe as p

OUT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def metrics(y,pp):
    m=p.metric(y,pp)
    if m['tp']+m['fp']==0:m['precision']=np.nan
    m['tn']=int(np.sum((y==0)&~pp));m['accuracy']=float(np.mean(y==pp.astype(int)));return m
def main():
    predpath=OUT/'semantic_head_test_inputs_predictions/decisions_before_gold.csv'
    cpredpath=OUT/'semantic_head_600_inputs_predictions/decisions_before_gold.csv'
    manifest={'frozen_prediction_files':{str(predpath):sha(predpath),str(cpredpath):sha(cpredpath)},'selected_before_test_sha':sha(OUT/'semantic_head_results/selected_before_test.json'),'evaluation_note':'Original held-out gold and construction intent labels first opened for this branch only after all selected predictions were saved. No refitting or reselection.'}
    (OUT/'last_stage_evaluation_before_gold_manifest.json').write_text(json.dumps(manifest,indent=2))
    files=[p.DATA/'evaluation/locked_pairs.csv',p.DATA/'evaluation/no_reference_top30_pairs.csv',p.DATA/'evaluation/external_mixed_pairs.csv']
    gold=pd.concat([pd.read_csv(f,usecols=['pair_id','query_id','final_label','difficulty','split_final','initial_rank']).fillna('') for f in files]).drop_duplicates('pair_id')
    pred=pd.read_csv(predpath);merged=pred.merge(gold,on='pair_id',validate='many_to_one')
    if len(merged)!=len(pred):raise ValueError('gold merge failed')
    rows=[];list_rows=[]
    for (model,policy),d in merged.groupby(['model','policy']):
        for name,mask in [('primary218',np.ones(len(d),bool)),('locked100',d.split_final.eq('locked')),('internal138',d.split_final.isin(['locked','no_reference'])),('WSDOT80',d.split_final.eq('external'))]:
            for subset,s in [('all',d.loc[mask]),('hard',d.loc[mask&d.difficulty.eq('hard')]),('nonexact_input',d.loc[mask&~d.exact_rule_accept])]:
                y=s.final_label.to_numpy(int);pp=s.accepted.to_numpy(bool)
                rows.append(dict(model=model,policy=policy,group=name,subset=subset,rows=len(s),positive_n=int(y.sum()),label_source='original_double_human_gold',**metrics(y,pp)))
            # Rank by exact rule first, then frozen head score, then original rank.
            ranked=d.loc[mask].sort_values(['query_id','exact_rule_accept','score','initial_rank','pair_id'],ascending=[True,False,False,True,True]).copy()
            rr={}
            for q,g in ranked.groupby('query_id'):
                keep=g[g.accepted].head(3)
                rr.update({pid:i+1 for i,pid in enumerate(keep.pair_id)})
            ranked['returned_rank']=ranked.pair_id.map(rr).fillna(0).astype(int)
            returned=ranked[ranked.returned_rank>0]
            tp=int(returned.final_label.sum());fp=len(returned)-tp;positive_queries=0;hit=0;macro=[];no_ref=0;no_ref_reject=0
            for q,g in ranked.groupby('query_id'):
                denom=int(g.final_label.sum());num=int(g.loc[g.returned_rank>0,'final_label'].sum())
                if denom:positive_queries+=1;hit+=int(num>0);macro.append(num/denom)
                else:no_ref+=1;no_ref_reject+=int(not (g.returned_rank>0).any())
            hard=ranked[ranked.difficulty=='hard'];hret=hard[hard.returned_rank>0]
            list_rows.append(dict(model=model,policy=policy,group=name,ranking='exact-first cap3, no test reranking',returned_tp=tp,returned_fp=fp,returned_precision=tp/(tp+fp) if tp+fp else np.nan,macro_recall_at3=np.mean(macro),hit_at3=hit/positive_queries,hard_returned_tp=int(hret.final_label.sum()),hard_returned_fp=len(hret)-int(hret.final_label.sum()),hard_micro_recall_at3=int(hret.final_label.sum())/int(hard.final_label.sum()),no_reference_rejection=no_ref_reject/no_ref if no_ref else np.nan))
    pd.DataFrame(rows).to_csv(OUT/'semantic_head_heldout_metrics.csv',index=False);pd.DataFrame(list_rows).to_csv(OUT/'semantic_head_heldout_list_metrics.csv',index=False)
    intentpath=Path('output/internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv')
    intent=pd.read_csv(intentpath,usecols=['pair_id','provisional_label','label_status']).fillna('')
    cd=pd.read_csv(cpredpath).merge(intent,on='pair_id',validate='many_to_one')
    crows=[]
    for (model,policy),d in cd.groupby(['model','policy']):
        y=d.provisional_label.to_numpy(int);pp=d.accepted.to_numpy(bool)
        crows.append(dict(model=model,policy=policy,rows=len(d),positive_n=int(y.sum()),label_source='construction_intent_not_human',use_for_method_selection=False,**metrics(y,pp)))
    pd.DataFrame(crows).to_csv(OUT/'semantic_head_600_construction_intent_metrics.csv',index=False)
    after={str(path):sha(path) for path in [predpath,cpredpath]}
    assert after==manifest['frozen_prediction_files']
    qa=dict(passed=True,heldout_rows_per_policy=gold.shape[0],heldout_queries=gold.query_id.nunique(),construction_rows_per_policy=600,original_gold_modified=False,frozen_prediction_files_unchanged=True,method_reselected_from_test=False,construction_labels_are_human=False)
    (OUT/'semantic_head_last_stage_evaluation_qa.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa))

if __name__=='__main__':main()
