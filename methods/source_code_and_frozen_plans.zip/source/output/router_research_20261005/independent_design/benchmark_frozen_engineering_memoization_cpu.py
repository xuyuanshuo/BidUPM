#!/usr/bin/env python3
"""Label-free all-source exact parser-equivalence and cold-cache CPU diagnostic."""
from pathlib import Path
import dataclasses,hashlib,json,time
import numpy as np,pandas as pd
from memoized_frozen_engineering_gate import FreshEngineeringGate
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
G=ROOT/'router_research_20261005/generic_unit_gate'
O=HERE/'engineering_parser_memoization_cpu_full_evidence';O.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,z):Path(p).write_text(json.dumps(z,ensure_ascii=False,indent=2)+'\n')
def item(row,side):
    return {key:row.get(side+'_'+key,'') for key in ['description','normalized_description','unit','category','spec_tokens']}
def run(gate,records):
    start=time.perf_counter()
    results=[gate.contradiction_gate(item(r,'query'),item(r,'candidate'),('physical_size',)) for r in records]
    sec=time.perf_counter()-start
    return results,sec
def main():
    plan=json.loads((G/'frozen_all_source_inference_plan.json').read_text());hashes={}
    for file in ['engineering_gate.py','engineering_gate_v2.py','raw_units_metadata.csv']:
        assert sha(G/file)==plan['file_sha256'][file];hashes[str(G/file)]=sha(G/file)
    paths={'main220':ROOT/'rule_first_system_20261004/results/server/inputs.csv',
           'challenge600':ROOT/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_challenge600.csv',
           'alberta_scope_core':ROOT/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_alberta_scope_core.csv'}
    frames={}
    for name,path in paths.items():
        assert sha(path)==plan['input_sha256'][name];hashes[str(path)]=sha(path)
        f=pd.read_csv(path,dtype=str,keep_default_na=False)
        assert not {'label','final_label','difficulty','reference_label','provisional_label'} & set(f)
        if name=='main220':f=f[f.evaluation_split!='validation'].reset_index(drop=True)
        frames[name]=f
    meta=pd.read_csv(G/'raw_units_metadata.csv',dtype=str,keep_default_na=False)
    for name in ['main220','challenge600']:
        frames[name]=frames[name].merge(meta[meta.dataset==name].drop(columns='dataset'),on='pair_id',how='left',validate='one_to_one')
        assert frames[name][['query_unit','candidate_unit']].notna().all().all()
    for side in ['query','candidate']:
        frames['alberta_scope_core'][side+'_description']=frames['alberta_scope_core'][side+'_normalized_description']
    assert {n:len(f) for n,f in frames.items()}=={'main220':6600,'challenge600':600,'alberta_scope_core':67635}
    dump(O/'diagnostic_plan_before_measurement.json',dict(labels_accessed=False,hashes=hashes,
        no_original_source_change=True,no_gate_semantics_change=True,all_rows_full_evidence_comparison=True,
        no_GPU_or_inference_plan_change=True,cache_empty_each_run=True,repeats=3,
        timing_scope='local CPU parser loops including item dict creation; input loading/to_dict/module loading/evidence JSON conversion excluded',
        cached_values=['per-text prepare/normalize/description','size_evidence','size_guard','residual_has_work'],
        no_caching_by_item_ID=True,not_a_real_full_system_timing=True))
    stats=[];timings=[];checks=[]
    for name,f in frames.items():
        records=f.to_dict('records'); baseline=None; candidate_baseline=None
        for repeat in range(3):
            for memoize in ([False,True] if repeat%2==0 else [True,False]):
                gate=FreshEngineeringGate(G,memoize)
                assert all(z['currsize']==z['hits']==z['misses']==0 for z in gate.cache_stats().values())
                results,sec=run(gate,records)
                measured_cache_stats=gate.cache_stats()
                serialized=[dataclasses.asdict(r) for r in results]
                digest=hashlib.sha256(json.dumps(serialized,sort_keys=True,separators=(',',':')).encode()).hexdigest()
                if baseline is None:baseline=serialized
                assert serialized==baseline,(name,repeat,memoize)
                # A combined defer hides the candidate-specific reason/evidence.
                # Check the complete underlying physical-size predicate once
                # per method/row, outside the actual measured pipeline timer.
                if repeat==0:
                    candidate_fields=[dataclasses.asdict(gate.candidate_gate(item(r,'query'),item(r,'candidate'),'physical_size')) for r in records]
                    if candidate_baseline is None:candidate_baseline=candidate_fields
                    assert candidate_fields==candidate_baseline,(name,'candidate evidence',memoize)
                timings.append(dict(dataset=name,repeat=repeat,memoized=memoize,rows=len(f),seconds=sec,
                    reject_n=sum(r.decision=='reject' for r in results),result_full_fields_sha256=digest,
                    cache_empty_at_start=True,label_free=True,GPU_used=False))
                stats.append(dict(dataset=name,repeat=repeat,memoized=memoize,caches_after_measured_loop=measured_cache_stats))
        checks.append(dict(dataset=name,rows=len(f),all_6_passes_identical_decisions_rules_reasons_and_evidence=True,
                           full_result_sha256=digest,reject_n=timings[-1]['reject_n']))
        checks[-1]['underlying_candidate_full_reason_and_evidence_identical_every_row']=True
        checks[-1]['candidate_full_field_sha256']=hashlib.sha256(json.dumps(candidate_baseline,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    t=pd.DataFrame(timings);t.to_csv(O/'cold_cpu_timing_each_run.csv',index=False)
    z=t.groupby(['dataset','memoized']).seconds.agg(['median','mean','std']).reset_index()
    z.to_csv(O/'cold_cpu_timing_summary.csv',index=False)
    for path,h in hashes.items():assert sha(path)==h
    dump(O/'cache_hit_stats_each_run.json',stats)
    dump(O/'independent_full_field_equivalence_qa.json',dict(passed=True,source_hashes_unchanged=True,
         labels_accessed=False,full_rows_per_pass=checks,all_decisions_reasons_evidence_identical=True,
         no_GPU_execution=True,no_original_module_files_or_existing_job_changed=True,
         fresh_empty_cache_each_pass=True,no_persisted_label_or_identifier_cache=True,
         no_end_to_end_speed_or_rental_saving_claim=True))
    print(z.to_string(index=False))
if __name__=='__main__':main()
