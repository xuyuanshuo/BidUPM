#!/usr/bin/env python3
"""Catalog completed matched-reference quality; never choose a test winner.

Cache decisions, score ensembles, actual routed executions and fixed output
filters retain distinct provenance. Unexecuted new GPU jobs are excluded.
"""
from pathlib import Path
import re,json,hashlib
import numpy as np,pandas as pd

HERE=Path(__file__).resolve().parent; OUT=HERE/'completed_matched_cpu_comparison'
ROOT=HERE.parents[1]; OUT.mkdir(exist_ok=True)
SOURCES={}; ROWS=[]
CANON='canonical_existing_reference'
CONST='construction_intent_not_human'
AI='GPT6Sol_blind_AI_reference_not_human'
def read(path,**kwargs):
    p=Path(path);SOURCES[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest();return pd.read_csv(p,**kwargs)
def add(dataset,group,subset,method,kind,seed,n,tp,fp,fn,tn,label,source,**kw):
    tp,fp,fn,tn=map(int,[tp,fp,fn,tn]); n=int(n)
    assert n==tp+fp+fn+tn
    ROWS.append(dict(dataset=dataset,group=group,subset=subset,method=method,
        method_kind=kind,seed=str(int(float(seed))) if pd.notna(seed) else '',
        rows=n,positive_n=tp+fn,tp=tp,fp=fp,fn=fn,tn=tn,
        precision=tp/(tp+fp) if tp+fp else np.nan,recall=tp/(tp+fn) if tp+fn else np.nan,
        f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,
        label_source=label,metric_source=str(source),timing_seconds=np.nan,
        timing_scope='',timing_rows=np.nan,rmb_inference_estimate=np.nan,**kw))
def counts(y,p):
    return (int(((y==1)&p).sum()),int(((y==0)&p).sum()),
            int(((y==1)&~p).sum()),int(((y==0)&~p).sum()))
def main():
    cp=ROOT/'revise3_full_20260920/supplementary/data/canonical/all_pairs_vfinal_12092.csv'
    canonical=read(cp,dtype=str,keep_default_na=False).set_index('pair_id')
    ap=ROOT/'paper_experiment_completion_20261005/audit/recomputed_real_pair_and_top3_metrics.csv'
    audit=read(ap); checked=0; identical_score_aliases=[]
    for (run,model),ag in audit.groupby(['run','model'],sort=False):
        ag=ag[ag.split.isin(['locked','no_reference','external'])]
        assert len(ag)==3
        thresholds=ag.threshold.unique();assert len(thresholds)==1
        seed=ag.seed.iloc[0]; threshold=float(thresholds[0])
        sp=ROOT/'remote_experiments_20260923/runs'/run/'pair_scores.csv'
        scores=read(sp,dtype={'pair_id':str}).set_index('pair_id')
        f=canonical.loc[scores.index]
        assert np.array_equal(scores.final_label.to_numpy(int),f.final_label.to_numpy(int))
        assert scores.difficulty.astype(str).tolist()==f.difficulty.astype(str).tolist()
        pred=scores['score_'+model].to_numpy(float)>=threshold
        aliases=[col[6:] for col in scores.columns if col.startswith('score_') and col!='score_'+model
                 and np.array_equal(scores[col].to_numpy(),scores['score_'+model].to_numpy())]
        if aliases:identical_score_aliases.append(dict(run=run,model=model,identical_score_columns=aliases))
        for split in ['locked','no_reference','external']:
            mask=f.split_final.eq(split).to_numpy();y=f.final_label.to_numpy(int)[mask]
            actual=counts(y,pred[mask]); old=ag[ag.split==split].iloc[0]
            assert actual==tuple(int(old[k]) for k in ['tp','fp','fn','tn'])
            checked+=1
        variant=re.sub(r'_seed_\d+$','',run)
        method=variant+'::'+model
        for group,mask in [('locked100',f.split_final.eq('locked').to_numpy()),
                           ('WSDOT80',f.split_final.eq('external').to_numpy()),
                           ('primary218',f.split_final.isin(['locked','no_reference','external']).to_numpy())]:
            assert int(mask.sum())=={'locked100':3000,'WSDOT80':2400,'primary218':6540}[group]
            for subset,sub in [('all',mask),('canonical_hard',mask&f.difficulty.eq('hard').to_numpy())]:
                add('main',group,subset,method,'original_single_cached_scores',seed,int(sub.sum()),
                    *counts(f.final_label.to_numpy(int)[sub],pred[sub]),CANON,sp,
                    threshold_source='original validation overall F1',threshold=threshold,
                    execution_status='existing true GPU scores, original threshold; CPU matched-reference recomputation',ensemble_members=1,
                    identical_score_aliases=';'.join(aliases))
    # Every fixed simple rule, with matching canonical reference scope.
    rp=ROOT/'router_research_20261005/rule_verification/simple_rule_metrics_all_sources.csv'
    rules=read(rp)
    for _,r in rules.iterrows():
        name=r.dataset
        groups={'locked100':'locked100','WSDOT80':'WSDOT80','primary218':'primary218'}
        suffix='_hard' if name.endswith('_hard') else ''
        base=name[:-5] if suffix else name
        if base=='challenge600_existing_reference':
            add('challenge600','all600','all',r.policy,'simple_rule',None,
                r.pair_n,r.tp,r.fp,r.fn,r.tn,CONST,rp,threshold_source='fixed rule, no LLM',ensemble_members=0,execution_status='completed CPU rule evaluation')
            continue
        if base not in groups:continue
        add('main',groups[base],'canonical_hard' if suffix else 'all',r.policy,'simple_rule',None,
            r.pair_n,r.tp,r.fp,r.fn,r.tn,CANON,rp,threshold_source='fixed rule, no LLM',ensemble_members=0,execution_status='completed CPU rule evaluation')
    # Original full-pool GPT predictions are evaluated on the same source labels.
    for sub,file in [('all','full_pair_metrics.csv'),('canonical_hard','hard_pair_metrics.csv')]:
        p=ROOT/'paper_experiment_completion_20261005/results/exact_pair_route_before_cap'/file
        d=read(p)
        d=d[(d.policy=='gpt6_sol_fullpool')&d.evaluation_group.isin(['locked100','WSDOT80','primary218'])]
        for _,r in d.iterrows():
            add('main',r.evaluation_group,sub,'GPT6Sol_full_pool_blind','generic_LLM_blind',None,
                r.hard_pair_n if sub=='canonical_hard' else r.pair_n,r.tp,r.fp,r.fn,r.tn,CANON,p,
                threshold_source='blind model binary judgments',ensemble_members=1,
                execution_status='Codex subagent blind judgments; no OpenAI API cost or latency measurement')
    # Distinct already evaluated calibrated single models and three-seed scores.
    p=ROOT/'router_research_20261005/holdout_report/complete_pair_metrics_all_policies.csv'
    d=read(p); groupmap={'primary_218':'primary218','locked_100':'locked100','external_80':'WSDOT80'}
    pure_ensembles={'bge_mean','bge_std_mean','bge_desc_mean','bge_nocat_mean','bge_nounit_mean','q06hard_mean','q06std_mean','q4_mean','zero_mean','prompt_mean'}
    for _,r in d.iterrows():
        if r.group not in groupmap:continue
        pol=r.policy
        single=re.fullmatch(r'(q06hard|q4)_single_(\d+)_exact0',pol)
        if pol not in pure_ensembles and not single:continue
        kind='validation_recalibrated_single' if single else 'validation_calibrated_score_ensemble'
        method=single.group(1)+'_validation_recalibrated' if single else pol
        seed=single.group(2) if single else None
        for sub,prefix,n in [('all','overall',r.rows),('canonical_hard','hard',r.hard_rows)]:
            add('main',groupmap[r.group],sub,method,kind,seed,n,
                *[r[prefix+'_'+k] for k in ['tp','fp','fn','tn']],CANON,p,
                threshold_source='frozen train/validation search; composite objective, not original threshold',
                ensemble_members=1 if single else 3,execution_status='completed CPU composition of real cached GPU scores; full deployment time unmeasured')
    # Previous actually executed full BGE and routes stay distinct from cache.
    for sub,file in [('all','full_pair_metrics.csv'),('canonical_hard','hard_pair_metrics.csv')]:
        p=ROOT/'paper_experiment_completion_20261005/results/full_pair_route_gpu/analysis'/file
        d=read(p);d=d[d.evaluation_group.isin(['locked100','WSDOT80','primary218'])]
        for _,r in d.iterrows():
            if r.policy.endswith('_nonexact_first'):continue # same pair decisions, alternative list order
            add('main',r.evaluation_group,sub,r.policy,'actual_full_system_GPU_20261005',r.seed,
                r.hard_pair_n if sub=='canonical_hard' else r.pair_n,r.tp,r.fp,r.fn,r.tn,CANON,p,
                threshold_source='original per-seed BGE/verification validation parameters',ensemble_members=1,
                execution_status='completed real GPU system; measured 6600 time cannot be substituted for 6540/3000/2400 quality groups')
    p=ROOT/'router_research_20261005/qwen06_gpu_results/analysis/main_actual_complete_pair_metrics.csv'
    d=read(p)
    for _,r in d.iterrows():
        group={'external80':'WSDOT80'}.get(r.group,r.group)
        if group not in ['locked100','WSDOT80','primary218']:continue
        ensemble=r.policy.endswith('_mean')
        for sub,pre,n in [('all','overall',r.overall_rows),('canonical_hard','hard',r.hard_rows)]:
            add('main',group,sub,r.policy,'actual_existing_route_ensemble' if ensemble else 'actual_existing_model_or_route',None if ensemble else 20260906,n,
                *[r[pre+'_'+k] for k in ['tp','fp','fn','tn']],CANON,p,
                threshold_source='previous frozen deployment validation parameters',ensemble_members=3 if ensemble else 1,
                execution_status='completed real GPU deployment; matched-subgroup time unmeasured')
    # Uniform small-source evaluation: original models, rules and existing veto.
    p=HERE/'small_dataset_comparison/complete_pair_metrics_with_pooled_alberta.csv'
    d=read(p)
    for _,r in d.iterrows():
        if r.model.startswith('LR_'):continue # failed new semantic heads are retained elsewhere
        ds='challenge600' if r.dataset=='constructed600' else 'Alberta'
        group='all600' if ds=='challenge600' else str(r.group)
        subset='all' if r.subset in ['all','all_pairs'] else 'input_nonexact_normalized'
        if r.model in set(rules.policy):kind='simple_rule'
        elif r.model in ['rule_plus_bge_candidate_accept','rule_plus_bge_plus_qwen_autoaccept']:kind='actual_existing_route'
        elif r.model in ['tfidf','bm25','feature_full','exact_unit_posthoc']:kind='original_classical'
        else:kind='original_single_real_GPU'
        add(ds,group,subset,r.model,kind,r.seed,r.rows,r.tp,r.fp,r.fn,r.tn,CONST if ds=='challenge600' else AI,p,
            threshold_source='existing fixed rule or original validation parameters',ensemble_members=1,
            uncertain_excluded_n=r.uncertain_excluded_n,execution_status='completed matched-reference evaluation')
    # Qwen0.6B actually executed small-source strict-unit systems/ensemble.
    p=ROOT/'router_research_20261005/qwen06_gpu_results/analysis/supplementary_constructed_and_ai_reference_metrics.csv'
    d=read(p)
    for _,r in d.iterrows():
        if not r.policy.startswith('unit_gate_q06hard'):continue
        ensemble=r.policy.endswith('_mean');seed=None if ensemble else int(r.policy.split('_')[-1])
        ds='challenge600' if r.dataset=='challenge600' else 'Alberta'
        add(ds,'all600' if ds=='challenge600' else 'both','all',r.policy if ensemble else 'unit_gate_q06hard_single',
            'actual_existing_route_ensemble' if ensemble else 'actual_existing_route',seed,r.rows,r.tp,r.fp,r.fn,r.tn,
            CONST if ds=='challenge600' else AI,p,threshold_source='previous frozen validation parameters',
            ensemble_members=3 if ensemble else 1,uncertain_excluded_n=r.excluded_uncertain_pairs,
            execution_status='completed real strict-unit routed GPU system, not pure all-Qwen inference')
    # The new blind600 baseline plus fixed output-filter variants (all 24 sources).
    p=ROOT/'router_research_20261005/generic_unit_gate/challenge600_all_model_cached_dimension_diagnostic/metrics_every_cached_run_and_fixed_combination.csv'
    d=read(p)
    for _,r in d.iterrows():
        if r.variant=='original_cached' and r.model!='GPT6Sol_blind':continue
        kind='generic_LLM_blind' if r.variant=='original_cached' else 'fixed_output_dimension_postfilter'
        add('challenge600','all600','all',r.model,kind,r.seed,r.rows,r.tp,r.fp,r.fn,r.tn,CONST,p,
            threshold_source='original source parameters unchanged; frozen label-free generic dimension veto if filtered',
            ensemble_members=3 if r.model.endswith('_mean') else 1,
            execution_status='blind Codex judgments' if kind=='generic_LLM_blind' else 'CPU filter of completed source predictions; no model inference saving measured')
    # Latest Qwen4 exhaustive Alberta original/fixed-output-filter, all seeds.
    for folder,kind in [('qwen4_alberta_actual_analysis','original_single_real_GPU'),('qwen4_alberta_fixed_dimension_analysis','fixed_output_dimension_postfilter')]:
        p=HERE/folder/'pair_metrics_each_seed.csv';d=read(p)
        for _,r in d.iterrows():
            add('Alberta',str(r.group),'all' if r.subset=='all_pairs' else 'input_nonexact_normalized',
                'qwen_4B_standard_scope_core',kind,r.seed,r.rows,r.tp,r.fp,r.fn,r.tn,AI,p,
                threshold_source='original per-seed validation overall F1 threshold',ensemble_members=1,
                uncertain_excluded_n=r.uncertain_excluded_n,execution_status='completed 67635 real GPU score pass; filter adds no GPU saving')
    output=pd.DataFrame(ROWS)
    keys=['dataset','group','subset','method','method_kind','seed']
    assert not output.duplicated(keys).any(),output[output.duplicated(keys,keep=False)].to_dict('records')
    # Add matched 600 model time: three repeated runs -> per-seed median.
    tp=ROOT/'paper_experiment_completion_20261005/results/challenge600_gpu/timing.csv';tim=read(tp)
    for run,g in tim.groupby('run_id',sort=False):
        model=re.sub(r'_seed_\d+$','',run);seed=str(int(g.seed.iloc[0])) if g.seed.notna().any() else ''
        assert len(g)==3 and set(g['repeat'])=={0,1,2} and g.pair_n.eq(600).all()
        mask=(output.dataset=='challenge600')&(output.group=='all600')&(output.subset=='all')&(output.method==model)&(output.seed==seed)&output.method_kind.isin(['original_single_real_GPU','fixed_output_dimension_postfilter'])
        output.loc[mask,'timing_seconds']=g.seconds.median();output.loc[mask,'timing_rows']=600
        output.loc[mask,'timing_scope']='original resident-model pure inference timer, median of 3 repeats; load excluded; output veto CPU time unmeasured and no inference saving'
        output.loc[mask,'rmb_inference_estimate']=g.seconds.median()*2.88/3600
    # Original Alberta BGE matched exhaustive scope; not the unrelated main timer.
    for dirname in ['raw_alberta_models','raw_alberta_scope_core']:
        tp=ROOT/'rule_first_system_validation_20261005/results'/dirname/'timing.csv';tim=read(tp)
        for _,t in tim.iterrows():
            assert t.pairs==67635
            model={'raw':'bge_raw','cleaned':'bge_cleaned','scope_core':'bge_scope_core'}[t.variant]
            mask=(output.dataset=='Alberta')&(output.group=='both')&(output.subset=='all')&(output.method==model)&(output.seed==str(int(t.seed)))
            output.loc[mask,'timing_seconds']=t.seconds;output.loc[mask,'timing_rows']=67635
            output.loc[mask,'timing_scope']='original exhaustive Alberta resident BGE serialization/tokenization/scoring timer; one pass, no model load or export; no common end-to-end scope assumed'
            output.loc[mask,'rmb_inference_estimate']=t.seconds*2.88/3600
    # Small-source original strict-unit Qwen06 routes, only exact matching scope.
    tp=ROOT/'router_research_20261005/qwen06_gpu_results/timing.csv';tim=read(tp)
    for _,t in tim[tim.dataset.isin(['challenge600','alberta_scope_core'])].iterrows():
        ds='challenge600' if t.dataset=='challenge600' else 'Alberta'
        mask=(output.dataset==ds)&(output.group==('all600' if ds=='challenge600' else 'both'))&(output.subset=='all')&(output.method=='unit_gate_q06hard_single')&(output.seed==str(int(t.seed)))
        output.loc[mask,'timing_seconds']=t.seconds;output.loc[mask,'timing_rows']=t.pairs
        output.loc[mask,'timing_scope']='previous actual strict-unit routed resident-model timer; load/export/evaluation excluded; not pure exhaustive Qwen06 inference'
        output.loc[mask,'rmb_inference_estimate']=t.seconds*2.88/3600
    # Only exact matching measured scope is attached; broad 6600 timers stay out.
    tp=HERE/'qwen4_alberta_actual_analysis/actual_timing_and_gpu_cost_each_seed.csv';tim=read(tp)
    for _,t in tim.iterrows():
        mask=(output.dataset=='Alberta')&(output.group=='both')&(output.subset=='all')&(output.method=='qwen_4B_standard_scope_core')&(output.seed==str(int(t.seed)))
        output.loc[mask,'timing_seconds']=t.seconds;output.loc[mask,'timing_rows']=67635
        output.loc[mask,'timing_scope']='resident item serialization/tokenization/GPU scoring only; threshold/rank/IO/load excluded; same full time retained for postfilter'
        output.loc[mask,'rmb_inference_estimate']=t.resident_inference_rmb_at_2_88_per_hour
    output.to_csv(OUT/'complete_matched_reference_metrics_each_condition.csv',index=False)
    aggregates=[]
    for key,g in output.groupby(['dataset','group','subset','method','method_kind','label_source'],sort=False):
        z=dict(zip(['dataset','group','subset','method','method_kind','label_source'],key))
        n=len(g);assert n in [1,3]
        if n==3:assert set(g.seed)=={'20260904','20260905','20260906'}
        assert g.rows.nunique()==g.positive_n.nunique()==1
        z.update(condition_n=n,rows=int(g.rows.iloc[0]),positive_n=int(g.positive_n.iloc[0]),
                 ensemble_members=int(g.ensemble_members.iloc[0]),
                 timing_scope=g.timing_scope.iloc[0],threshold_source=g.threshold_source.iloc[0],
                 execution_status=g.execution_status.iloc[0],metric_source=';'.join(g.metric_source.unique()))
        for col in ['precision','recall','f1','tp','fp','fn','tn','timing_seconds','rmb_inference_estimate']:
            a=g[col].dropna();z[col+'_mean']=a.mean() if len(a) else np.nan
            z[col+'_sample_sd']=a.std(ddof=1) if len(a)>1 else np.nan
        aggregates.append(z)
    agg=pd.DataFrame(aggregates);agg.to_csv(OUT/'complete_matched_reference_metrics_mean_sample_sd.csv',index=False)
    assert not agg.method.str.contains('canonical_cache|new_lora|generic_actual',case=False).any()
    for path,h in SOURCES.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
    qa=dict(passed=True,source_files_protected=len(SOURCES),source_hashes=SOURCES,
        condition_rows=len(output),aggregate_rows=len(agg),main_cache_audit_confusion_crosschecks=checked,
        original_predictions_recomputed_against_unchanged_canonical_reference=True,
        identical_same_run_score_alias_inventory=identical_score_aliases,
        identical_score_aliases_do_not_count_as_additional_independent_training=True,
        all_three_seeds_reported_not_best_seed=True,ensembles_not_misreported_as_seed_mean=True,
        unsupported_matched_scope_timing_empty=True,no_API_latency_or_billing_claim=True,
        unexecuted_generic_newLoRA_cache_GPU_jobs_excluded=True,
        no_test_based_winner_selected=True,
        main_hard_scope='canonical difficulty=hard rows, not a redefinition from model errors',
        Alberta_hard_scope='normalized nonexact input proxy, not human hard annotation',
        constructed600_human_gold_claim=False,Alberta_human_gold_claim=False,
        metric_units='P/R/F1 fractions 0-1; counts absolute; seconds actual measured scope only',
        aggregation='arithmetic mean of per-seed metrics, sample SD ddof1; single ensemble/blind pass has empty SD')
    (OUT/'consolidation_integrity_qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:qa[k] for k in ['passed','source_files_protected','condition_rows','aggregate_rows','main_cache_audit_confusion_crosschecks']},ensure_ascii=False))

if __name__=='__main__':main()
