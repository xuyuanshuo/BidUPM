#!/usr/bin/env python3
"""Interim reporting of a completed frozen seed; never choose or change seeds."""
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from evaluate_qwen4_alberta_frozen_outputs import OWN, ROOT, SOURCE, sha, dump, pair_metrics, last3_metrics, bf16_round

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--results',required=True,type=Path); ap.add_argument('--seed',required=True,type=int); a=ap.parse_args()
    seed=a.seed; planp=OWN/'qwen4_alberta_scope_core_frozen_inference_plan.json'; plan=json.loads(planp.read_text())
    mpath=a.results/'execution_manifest.json'; m=json.loads(mpath.read_text()); run=next(r for r in m['completed_runs'] if r['seed']==seed); old=next(r for r in plan['runs'] if r['seed']==seed)
    interim_status=f"interim_{len(m['completed_runs'])}_of_3_completed"
    assert m['input_sha256']==plan['input_sha256'] and m['script_sha256']==plan['source_sha256'] and m['old_frozen_plan_sha256']==sha(planp)
    assert m['labels_accessed'] is False and not m['reference_available_to_runner'] and not m['method_selected_from_alberta']
    p=a.results/run['output_file']; assert sha(p)==run['output_sha256']; d=pd.read_csv(p,dtype={'pair_id':str,'source_year':str,'query_id':str,'candidate_id':str})
    inp=Path(plan['local_identical_input_csv']); assert sha(inp)==plan['input_sha256']; ids=pd.read_csv(inp,usecols=['pair_id','source_year','query_id','candidate_id'],dtype=str)[['pair_id','source_year','query_id','candidate_id']]
    assert len(d)==67635 and d.pair_id.nunique()==67635 and d[['pair_id','source_year','query_id','candidate_id']].equals(ids)
    assert d.threshold.eq(old['threshold']).all() and d.seed.eq(seed).all() and np.array_equal(d.prediction,(d.score>=old['threshold']).astype(int))
    assert np.isfinite(d[['logit_yes','logit_no','score']].to_numpy()).all()
    delta=d.logit_yes.to_numpy(np.float32)-d.logit_no.to_numpy(np.float32); score=d.score.to_numpy(np.float32); assert np.all((score==delta)|(score==bf16_round(delta)))
    accepted=d[d.prediction==1].sort_values(['source_year','query_id','score','candidate_id'],ascending=[True,True,False,True]).copy(); accepted['rank']=accepted.groupby(['source_year','query_id']).cumcount()+1
    ranks=dict(zip(accepted.loc[accepted['rank']<=3,'pair_id'],accepted.loc[accepted['rank']<=3,'rank'])); assert np.array_equal(d.returned_rank,d.pair_id.map(ranks).fillna(0).astype(int))
    c600=json.loads((ROOT/'paper_experiment_completion_20261005/results/challenge600_gpu/execution_manifest.json').read_text()); c=next(r for r in c600['completed_runs'] if r['run_id']==run['run_id']); assert c['checkpoint']==run['checkpoint'] and c['threshold']==run['threshold'] and c['checkpoint_weight_sha256']==run['adapter_weight_sha256']
    dump(a.results/'partial_prediction_frozen_before_evaluation.json',dict(status='partial_single_seed_complete',completed_seed=seed,final_three_seed_comparison_incomplete=True,output_sha256=sha(p),manifest_snapshot_sha256=sha(mpath),input_sha256=sha(inp),threshold=old['threshold'],other_seeds_and_thresholds_unchanged=True,does_not_select_this_seed=True))
    # Join the same frozen AI reference only after prediction checks.
    rp=ROOT/'router_research_20261005/rule_verification/alberta_reference_index.csv'; ep=ROOT/'router_research_20261005/rule_verification/alberta_rule_predictions_all_stages.csv'; oq=json.loads((OWN/'small_dataset_comparison/reference_and_output_integrity_qa.json').read_text())
    assert sha(rp)==oq['source_hashes']['output/router_research_20261005/rule_verification/alberta_reference_index.csv']; assert sha(ep)==oq['source_hashes']['output/router_research_20261005/rule_verification/alberta_rule_predictions_all_stages.csv']
    ref=pd.read_csv(rp,usecols=['pair_id','reference_label','reference_uncertain'],dtype={'pair_id':str}); assert len(ref)==67635 and ref.reference_label.sum()==142 and ref.reference_uncertain.sum()==56
    ex=pd.read_csv(ep,usecols=['pair_id','policy','prediction']); ex=ex[ex.policy=='normalized_exact_plus_unit']; exact=dict(zip(ex.pair_id,ex.prediction.astype(bool)))
    z=d.merge(ref,on='pair_id',validate='one_to_one'); z['input_nonexact']=~z.pair_id.map(exact).to_numpy(bool); rows=[]; lists=[]
    for group,g in [('both',z),*[(year,z[z.source_year==year]) for year in ['2024','2026']]]:
        for subset,s in [('all_pairs',g),('input_nonexact_normalized',g[g.input_nonexact])]:
                known=s[s.reference_uncertain==0]; rows.append(dict(seed=seed,status=interim_status,label_source=SOURCE,group=group,subset=subset,rows=len(known),positive_n=int(known.reference_label.sum()),uncertain_excluded_n=len(s)-len(known),**pair_metrics(known.reference_label.to_numpy(int),known.prediction.to_numpy(bool))))
        lists.append(dict(seed=seed,status=interim_status,label_source=SOURCE,group=group,**last3_metrics(g)))
    pd.DataFrame(rows).to_csv(a.results/'partial_pair_metrics.csv',index=False); pd.DataFrame(lists).to_csv(a.results/'partial_final3_metrics.csv',index=False)
    dump(a.results/'partial_qa.json',dict(passed=True,seed=seed,completed_model_passes=1,planned_model_passes=3,rows=67635,output_unchanged_after_evaluation=sha(p)==run['output_sha256'],same_weights_and_original_threshold_as_current600=True,native_scores_threshold_predictions_and_top3_reproduced=True,other_seed_thresholds_not_changed=True,does_not_choose_a_seed=True,label_source=SOURCE,human_gold=False,uncertain_pairs_excluded=56,resident_model_seconds=run['seconds'],rental_estimate_rmb_at_2_88_hour=run['seconds']*2.88/3600,reference_sha256=sha(rp)))
    print(pd.DataFrame(rows).query("group=='both'").to_string(index=False)); print(pd.DataFrame(lists).query("group=='both'").to_string(index=False))
if __name__=='__main__':main()
