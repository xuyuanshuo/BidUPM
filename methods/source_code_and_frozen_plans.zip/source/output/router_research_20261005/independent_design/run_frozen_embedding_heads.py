#!/usr/bin/env python3
"""Fit 12 small heads on frozen single-item BGE embeddings; no test-label fitting.

Required map columns: item_key, embedding_row. item_key may be raw normalized
description||unit (preferred) or deterministic canonical description||unit.
The NPZ contains `embeddings` [N,D] or a plain .npy has that matrix directly.
All threshold/model selection is restricted to training OOF and validation.
"""
import argparse,hashlib,json,time,warnings
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from sklearn.exceptions import ConvergenceWarning
import run_training_validation_probe as p

warnings.filterwarnings('ignore',category=ConvergenceWarning)
NUMERIC_NAMES=['unit_match','char_cosine','word_cosine','token_jaccard','token_containment','sequence_ratio','action_conflict','material_conflict','dimension_conflict','class_conflict','type_conflict','spec_conflict']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load_embeddings(npfile,mapfile):
    arr=np.load(npfile,allow_pickle=False)
    if hasattr(arr,'files'):
        emb=arr['embeddings'].astype(np.float32)
    else:emb=np.asarray(arr,dtype=np.float32)
    if emb.ndim!=2 or not np.isfinite(emb).all():raise ValueError('embeddings must be finite [N,D]')
    emb/=np.maximum(np.linalg.norm(emb,axis=1,keepdims=True),1e-12)
    m=pd.read_csv(mapfile).fillna('')
    if 'item_key' not in m:
        m['item_key']=[p.canonical_text(d)+'||'+p.canonical_unit(u) for d,u in zip(m.description,m.unit)]
    if 'embedding_row' not in m:m['embedding_row']=np.arange(len(m))
    if m.item_key.duplicated().any():raise ValueError('duplicate item_key')
    return emb,dict(zip(m.item_key.astype(str),m.embedding_row.astype(int)))
def item_row_indices(descriptions,units,index):
    rows=[];missing=[]
    for d,u in zip(descriptions,units):
        raw=str(d)+'||'+str(u)
        canonical=p.canonical_text(d)+'||'+p.canonical_unit(u)
        key=raw if raw in index else canonical if canonical in index else None
        if key is None:missing.append(raw)
        else:rows.append(index[key])
    if missing:raise ValueError(f'{len(missing)} item keys missing; first={missing[:5]}')
    return rows
def get_features(d,emb,index,feature_file):
    qr=item_row_indices(d.query_normalized_description,d.query_normalized_unit,index)
    cr=item_row_indices(d.candidate_normalized_description,d.candidate_normalized_unit,index)
    q=emb[qr];c=emb[cr]
    cos=np.sum(q*c,axis=1)
    ft=pd.read_csv(feature_file).set_index('pair_id')
    numeric=ft.loc[d.pair_id,NUMERIC_NAMES].to_numpy(float)
    unit=numeric[:,0]
    x=np.column_stack([np.abs(q-c),q*c,cos,cos*unit,numeric])
    exact=((d.exact_description==1)&(d.unit_match==1)).to_numpy()
    return x,exact
def model_for(spec):
    if spec['family']=='logistic':
        return LogisticRegression(C=spec['C'],class_weight={0:1.,1:spec['positive_weight']},solver='liblinear',max_iter=2500,random_state=20261005)
    return MLPClassifier(hidden_layer_sizes=(32,),activation='relu',alpha=spec['alpha'],learning_rate_init=.001,max_iter=350,early_stopping=True,validation_fraction=.15,n_iter_no_change=20,random_state=20261005)
def fit(m,x,y,spec):
    if spec['family']=='mlp':m.fit(x,y,sample_weight=np.where(y==1,spec['positive_weight'],1.))
    else:m.fit(x,y)
def thresholds_validation(y,s,ex):
    cand=np.unique(np.r_[0.,1.,s,np.quantile(s,np.linspace(0,1,501))])
    candidates=[]
    for t in cand:
        pp=ex|(s>=t);m=p.metric(y,pp);r=p.metric(y[~ex],pp[~ex])
        candidates.append((float(t),m,r))
    chosen={}
    for mode in ['overall_f1','balanced_residual','residual_f1']:
        def key(z):
            t,m,r=z
            objective=m['f1'] if mode=='overall_f1' else r['f1'] if mode=='residual_f1' else .6*m['f1']+.4*r['f1']
            return objective,m['precision'],r['precision'],t
        t,m,r=max(candidates,key=key);chosen[mode]=dict(threshold=t,overall=m,residual=r,selection_objective=key((t,m,r))[0])
    return chosen
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--embedding-array',required=True,type=Path);ap.add_argument('--item-map',required=True,type=Path);ap.add_argument('--output',required=True,type=Path);ap.add_argument('--embedding-manifest',type=Path);args=ap.parse_args()
    out=args.output;out.mkdir(parents=True,exist_ok=True);(out/'fitted_models').mkdir(exist_ok=True)
    trp=p.DATA/'training/training_pairs_semantic_deduplicated.csv';vp=p.DATA/'evaluation/validation_pairs.csv'
    train=pd.read_csv(trp).fillna('');val=pd.read_csv(vp).fillna('')
    y=train.final_label.to_numpy(int);vy=val.final_label.to_numpy(int)
    specs=[dict(name=f'LR_C{C:g}_PW{w:g}',family='logistic',C=C,positive_weight=w) for C in [.01,.1,1.] for w in [1.,4.,16.]]+[dict(name=f'MLP32_alpha{a:g}_PW4',family='mlp',alpha=a,positive_weight=4.) for a in [.01,.1,1.]]
    plan=dict(embedding_array_sha=sha(args.embedding_array),item_map_sha=sha(args.item_map),embedding_manifest_sha=sha(args.embedding_manifest) if args.embedding_manifest else None,source_sha={str(trp):sha(trp),str(vp):sha(vp)},specifications=specs,feature_definition='symmetric absdiff/product; cosine, cosine*same_unit; 12 generic input-only lexical/unit/conflict features',excluded_input=['pair_id','item_code','price','quantity','difficulty','gold','annotation_notes','category','source_agency'],selection='5 query_semantic_key-grouped OOF for head-layer diagnostics; select 3 objective policies on unchanged validation only, freeze all before held-out evaluation',encoder_limitation='frozen domain-adapted encoder was trained on full training set, so OOF applies to head only and does not establish encoder out-of-fold generalization',test_labels_opened=False,script_sha=sha(Path(__file__)))
    (out/'plan_before_fitting.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
    emb,index=load_embeddings(args.embedding_array,args.item_map)
    X,ex=get_features(train,emb,index,p.OUT/'training_input_features.csv');VX,vex=get_features(val,emb,index,p.OUT/'validation_input_features.csv')
    folds=list(StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=20261005).split(np.zeros(len(y)),y,train.query_semantic_key))
    metrics=[];score_records=[];frozen=[]
    with threadpool_limits(limits=1):
      for spec in specs:
        start=time.perf_counter();oof=np.zeros(len(y))
        for it,iv in folds:
            scale=StandardScaler();tx=scale.fit_transform(X[it]);ix=scale.transform(X[iv]);model=model_for(spec);fit(model,tx,y[it],spec);oof[iv]=model.predict_proba(ix)[:,1]
        oof_th={mode:p.choose(y,oof,ex,mode) for mode in ['overall_f1','residual_f1','residual_recall90']}
        scale=StandardScaler();tx=scale.fit_transform(X);vx=scale.transform(VX);model=model_for(spec);fit(model,tx,y,spec);vs=model.predict_proba(vx)[:,1]
        model_path=out/'fitted_models'/f"{spec['name']}.joblib";joblib.dump(dict(scaler=scale,classifier=model,spec=spec,feature_dim=X.shape[1]),model_path,compress=3)
        val_th=thresholds_validation(vy,vs,vex);frozen.append(dict(model=spec['name'],specification=spec,model_sha=sha(model_path),oof_thresholds=oof_th,validation_policies=val_th))
        for split,d,ys,ss,exact in [('train_head_oof',train,y,oof,ex),('validation',val,vy,vs,vex)]:
            policies=oof_th if split=='train_head_oof' else {k:z['threshold'] for k,z in val_th.items()}
            for mode,t in policies.items():
                pp=exact|(ss>=t);r=dict(model=spec['name'],split=split,selection_policy=mode,threshold=t,fit_seconds=time.perf_counter()-start,**p.metric(ys,pp));r.update({f'residual_{k}':v for k,v in p.metric(ys[~exact],pp[~exact]).items()});metrics.append(r)
            for pid,s in zip(d.pair_id,ss):score_records.append(dict(model=spec['name'],split=split,pair_id=pid,score=float(s)))
        print(json.dumps(dict(model=spec['name'],validation=val_th,seconds=time.perf_counter()-start)),flush=True)
    winners={}
    for mode in ['overall_f1','balanced_residual','residual_f1']:
        winner=max(frozen,key=lambda z:(z['validation_policies'][mode]['selection_objective'],z['validation_policies'][mode]['overall']['precision'],-next(i for i,s in enumerate(specs) if s['name']==z['model'])))
        winners[mode]=dict(model=winner['model'],threshold=winner['validation_policies'][mode]['threshold'],model_sha=winner['model_sha'],validation=winner['validation_policies'][mode])
    (out/'all_models_and_thresholds_frozen.json').write_text(json.dumps(frozen,indent=2));(out/'selected_before_test.json').write_text(json.dumps(winners,indent=2))
    pd.DataFrame(metrics).to_csv(out/'training_validation_metrics.csv',index=False);pd.DataFrame(score_records).to_csv(out/'training_validation_scores.csv',index=False)
    (out/'completion.json').write_text(json.dumps(dict(completed=True,models=len(specs),train_rows=len(train),validation_rows=len(val),test_labels_opened=False,embedding_dim=emb.shape[1],feature_dim=X.shape[1]),indent=2))

if __name__=='__main__':main()
