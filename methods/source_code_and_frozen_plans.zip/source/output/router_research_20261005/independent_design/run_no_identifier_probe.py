#!/usr/bin/env python3
"""Second predeclared family: omit agency-specific item codes and categories."""
import json,time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.feature_extraction.text import TfidfVectorizer
import run_training_validation_probe as p

OUT=Path(__file__).resolve().parent/'no_identifier_probe';OUT.mkdir(exist_ok=True)
trp=p.DATA/'training/training_pairs_semantic_deduplicated.csv';vp=p.DATA/'evaluation/validation_pairs.csv'
tr=pd.read_csv(trp).fillna('');va=pd.read_csv(vp).fillna('')
y=tr.final_label.to_numpy(int);vy=va.final_label.to_numpy(int)
ex=((tr.exact_description==1)&(tr.unit_match==1)).to_numpy();vex=((va.exact_description==1)&(va.unit_match==1)).to_numpy()
plan=dict(source_sha={str(trp):p.sha(trp),str(vp):p.sha(vp)},read_test_labels=False,models=18,families=['engineering_no_identifiers','char_word_no_identifiers'],drop_features=['item_code_match','category_match'],C=[.1,1.,10.],positive_weight=[1.,4.,16.],thresholds='training grouped OOF only',script_sha=p.sha(Path(__file__)),parent_script_sha=p.sha(Path(p.__file__)))
(OUT/'plan_before_execution.json').write_text(json.dumps(plan,indent=2))
corpus=list(dict.fromkeys(tr.query_normalized_description.map(p.canonical_text).tolist()+tr.candidate_normalized_description.map(p.canonical_text).tolist()))
vecs=dict(char=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),sublinear_tf=True),word=TfidfVectorizer(analyzer='word',ngram_range=(1,2),sublinear_tf=True,token_pattern=r'(?u)\b[a-z0-9]+\b'))
for v in vecs.values():v.fit(corpus)
ta=p.arrays(tr,vecs);vxa=p.arrays(va,vecs)
keep=[i for i,n in enumerate(p.FEATURES) if n not in plan['drop_features']]
Xs=[ta[0][:,keep],ta[1][:,keep+[13,14]]];Vs=[vxa[0][:,keep],vxa[1][:,keep+[13,14]]]
folds=list(StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=20261005).split(np.zeros(len(y)),y,tr.query_semantic_key))
rows=[];score_rows=[];frozen=[]
for fi,family in enumerate(plan['families']):
 for C in plan['C']:
  for w in plan['positive_weight']:
   name=f'{family}_C{C:g}_PW{w:g}';X=Xs[fi];VX=Vs[fi];oof=np.zeros(len(y));start=time.perf_counter()
   for it,iv in folds:
    scaler=StandardScaler();tx=scaler.fit_transform(X[it]);ix=scaler.transform(X[iv])
    m=LogisticRegression(C=C,class_weight={0:1,1:w},solver='liblinear',max_iter=2000,random_state=20261005);m.fit(tx,y[it]);oof[iv]=m.predict_proba(ix)[:,1]
   th={mode:p.choose(y,oof,ex,mode) for mode in ['overall_f1','residual_f1','residual_recall90']};frozen.append(dict(model=name,thresholds=th))
   scaler=StandardScaler();tx=scaler.fit_transform(X);vx=scaler.transform(VX)
   m=LogisticRegression(C=C,class_weight={0:1,1:w},solver='liblinear',max_iter=2000,random_state=20261005);m.fit(tx,y);vs=m.predict_proba(vx)[:,1]
   elapsed=time.perf_counter()-start
   for split,d,ys,ss,exact in [('train_oof',tr,y,oof,ex),('validation',va,vy,vs,vex)]:
    for mode,t in th.items():
     pp=exact|(ss>=t);r=dict(model=name,split=split,threshold_objective=mode,threshold=t,fit_score_seconds=elapsed,**p.metric(ys,pp));r.update({f'residual_{k}':v for k,v in p.metric(ys[~exact],pp[~exact]).items()});rows.append(r)
    for pid,s in zip(d.pair_id,ss):score_rows.append(dict(model=name,split=split,pair_id=pid,score=float(s)))
   print(name,flush=True)
pd.DataFrame(rows).to_csv(OUT/'metrics.csv',index=False);pd.DataFrame(score_rows).to_csv(OUT/'scores.csv',index=False)
(OUT/'training_only_frozen_thresholds.json').write_text(json.dumps(frozen,indent=2))
(OUT/'completion.json').write_text(json.dumps(dict(completed=True,models=18,threshold_policies=54,read_test_labels=False),indent=2))
