#!/usr/bin/env python3
"""Frozen 3-seed Qwen3-Reranker-4B LoRA inference on all Alberta scope-core pairs.

No reference/gold file is accepted by this runner. Only a source-input CSV and
the old frozen checkpoint plan are read. Official logits_to_keep=1 is guarded by
an all-logits A/B score and decision comparison on the same first 256 inputs.
"""
import argparse,gc,hashlib,inspect,json,os,sys,time
from pathlib import Path
os.environ.setdefault('HF_HUB_OFFLINE','1');os.environ.setdefault('TRANSFORMERS_OFFLINE','1');os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np
import pandas as pd
import torch
from peft import PeftModel
from transformers import AutoTokenizer
ROOT=Path('experiment_runtime')
sys.path.insert(0,str(ROOT/'scripts'))
from local_experiment_utils import item_text
from run_qwen_reranker import QwenPairCollator,load_base_model,label_token_ids

ITEM_COLUMNS=['description','normalized_description','normalized_unit','category','spec_tokens']
INPUT_COLUMNS=['pair_id','evaluation_split','query_id','candidate_id','source_year']+[f'{side}_{c}' for side in ['query','candidate'] for c in ITEM_COLUMNS]
def sha(path):
    d=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):d.update(block)
    return d.hexdigest()
def dump(path,data):Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input-csv',required=True,type=Path);ap.add_argument('--frozen-plan',required=True,type=Path);ap.add_argument('--output',required=True,type=Path);ap.add_argument('--allowed-score-atol',type=float,default=0.0);ap.add_argument('--verification-n',type=int,default=256);a=ap.parse_args()
    assert a.verification_n>=256,'At least 256 score/decision parity rows required'
    frozen=json.loads(a.frozen_plan.read_text());runs=[r for r in frozen['runs'] if r['kind']=='qwen' and r['run_id'].startswith('qwen_4B_standard_seed_')]
    assert len(runs)==3 and {r['seed'] for r in runs}=={20260904,20260905,20260906}
    actual_input_sha=sha(a.input_csv)
    assert frozen.get('input_sha256'), 'Input hash must be frozen before inference'
    assert actual_input_sha==frozen['input_sha256'], 'Actual Alberta input differs from frozen plan'
    assert sha(__file__)==frozen['source_sha256'], 'Actual runner differs from frozen source'
    frame=pd.read_csv(a.input_csv,dtype=str,keep_default_na=False,usecols=INPUT_COLUMNS)
    assert len(frame)==67635 and frame.pair_id.nunique()==67635
    assert frame.groupby('source_year').size().to_dict()=={'2024':31995,'2026':35640}
    assert frame.query_id.nunique()==135 and frame.groupby(['source_year','query_id']).ngroups==270
    changed={}
    for side in ['query','candidate']:
        assert frame[f'{side}_category'].eq('').all() and frame[f'{side}_spec_tokens'].eq('').all(),'Unknown attributes must not be imputed'
        changed[side]=int(frame[f'{side}_description'].ne(frame[f'{side}_normalized_description']).sum())
        frame[f'{side}_description']=frame[f'{side}_normalized_description']
    assert not a.output.exists() or not any(a.output.iterdir()),'Do not overwrite inference results'
    a.output.mkdir(exist_ok=True,parents=True)
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    manifest=dict(status='running',input_sha256=sha(a.input_csv),old_frozen_plan_sha256=sha(a.frozen_plan),script_sha256=sha(__file__),labels_accessed=False,reference_available_to_runner=False,source_input_columns=INPUT_COLUMNS,input_transformation='Description := normalized_description; same cleaned normalized units; category/specs unknown; no strict unit gate',description_slots_changed=changed,rows=67635,year_pools=270,old_thresholds_frozen=True,new_training=False,method_selected_from_alberta=False,gpu=torch.cuda.get_device_name(0),torch_version=torch.__version__,all_logits_parity_n=a.verification_n,allowed_score_atol=a.allowed_score_atol,timing_scope='one resident-model synchronized full inference pass per seed including item serialization/tokenization/scoring/threshold; excludes model loading/file IO/A-B verification/warmup',completed_runs=[])
    dump(a.output/'execution_manifest.json',manifest);timings=[]
    for run in sorted(runs,key=lambda x:x['seed']):
        seed=run['seed'];cp=Path(run['checkpoint']);base=Path(run['base_model_path']);threshold=float(run['threshold']);bs=int(run['batch_size']);max_length=int(run['max_length'])
        assert run['input_variant']=='full'
        tpath=ROOT/Path(run['threshold_file']).relative_to('output/remote_experiments_20260923')
        assert sha(tpath)==run['threshold_file_sha256'] and sha(tpath.parent/'manifest.json')==run['original_manifest_sha256']
        threshold_csv=pd.read_csv(tpath);old=threshold_csv[(threshold_csv.model==run['threshold_model_key'])&(threshold_csv.policy=='f1_opt')]
        assert len(old)==1 and float(old.threshold.iloc[0])==threshold
        weights={p.name:sha(p) for p in sorted(cp.glob('*.safetensors'))};assert weights
        torch.manual_seed(seed);torch.cuda.synchronize();started=time.perf_counter()
        tokenizer=AutoTokenizer.from_pretrained(base,local_files_only=True,padding_side='left');tokenizer.pad_token=tokenizer.pad_token or tokenizer.eos_token
        model=PeftModel.from_pretrained(load_base_model(str(base),torch.device('cuda')),cp).eval()
        collator=QwenPairCollator(tokenizer,max_length,run['instruction']);no_id,yes_id=label_token_ids(tokenizer)
        torch.cuda.synchronize();loading=time.perf_counter()-started
        @torch.inference_mode()
        def infer(data,keep_last):
            torch.cuda.synchronize();started=time.perf_counter();q=item_text(data,'query','full');c=item_text(data,'candidate','full');ys=[];ns=[];margins=[]
            for lo in range(0,len(data),bs):
                enc=collator([(qi,ci,0,0.0) for qi,ci in zip(q[lo:lo+bs],c[lo:lo+bs])]);enc.pop('labels_local');enc.pop('hard_local');enc={k:v.to('cuda') for k,v in enc.items()}
                with torch.autocast('cuda',dtype=torch.bfloat16):
                    kwargs=dict(logits_to_keep=1) if keep_last else {}
                    logits=model(**enc,**kwargs).logits[:,-1,:]
                    # Preserve subtraction in the returned logit dtype before casting.
                    score=logits[:,yes_id]-logits[:,no_id]
                ys.extend(logits[:,yes_id].float().cpu().tolist());ns.extend(logits[:,no_id].float().cpu().tolist());margins.extend(score.float().cpu().tolist())
                del logits
            torch.cuda.synchronize();secs=time.perf_counter()-started
            yes=np.asarray(ys,dtype=np.float32);no=np.asarray(ns,dtype=np.float32)
            margin=np.asarray(margins,dtype=np.float32)
            assert np.isfinite(margin).all()
            return yes,no,margin,secs
        check=frame.head(a.verification_n)
        infer(check.head(bs),False)
        by,bn,baseline,tbase=infer(check,False)
        supports='logits_to_keep' in inspect.signature(model.get_base_model().forward).parameters
        if supports:
            oy,on,optimized,topt=infer(check,True)
            maxdiff=float(np.max(np.abs(baseline-optimized)));changed_n=int(np.sum((baseline>=threshold)!=(optimized>=threshold)))
            keep_last=maxdiff<=a.allowed_score_atol and changed_n==0
            optqa=dict(supported=True,score_max_abs_diff=maxdiff,scores_bitwise_equal=bool(np.array_equal(baseline,optimized)),decision_changed_n=changed_n,baseline_seconds=tbase,optimized_seconds=topt,optimized_enabled=bool(keep_last))
        else:
            keep_last=False;optqa=dict(supported=False,optimized_enabled=False,reason='Official forward signature does not expose logits_to_keep')
        pd.DataFrame(dict(pair_id=check.pair_id,all_logits_score=baseline,all_logits_prediction=(baseline>=threshold).astype(int),**(dict(last_logits_score=optimized,last_logits_prediction=(optimized>=threshold).astype(int)) if supports else {}))).to_csv(a.output/f'parity_seed_{seed}.csv',index=False)
        dump(a.output/f'parity_seed_{seed}.json',optqa)
        infer(frame.head(bs),keep_last)
        yes,no,scores,seconds=infer(frame,keep_last)
        prediction=(scores>=threshold).astype(int)
        out=frame[['pair_id','evaluation_split','query_id','source_year','candidate_id']].copy();out['seed']=seed;out['variant']='scope_core';out['logit_yes']=yes;out['logit_no']=no;out['score']=scores;out['threshold']=threshold;out['prediction']=prediction
        accepted=out[out.prediction==1].sort_values(['source_year','query_id','score','candidate_id'],ascending=[True,True,False,True]).copy();accepted['returned_rank']=accepted.groupby(['source_year','query_id']).cumcount()+1
        ranks=dict(zip(accepted.loc[accepted.returned_rank<=3,'pair_id'],accepted.loc[accepted.returned_rank<=3,'returned_rank']));out['returned_rank']=out.pair_id.map(ranks).fillna(0).astype(int)
        path=a.output/f'predictions_scope_core_seed_{seed}.csv';out.to_csv(path,index=False)
        timings.append(dict(seed=seed,rows=len(frame),seconds=seconds,model_load_seconds=loading,batch_size=bs,max_length=max_length,logits_to_keep=1 if keep_last else 0,repeat=0,actual_full_pass=True))
        pd.DataFrame(timings).to_csv(a.output/'timing.csv',index=False)
        manifest['completed_runs'].append(dict(seed=seed,run_id=run['run_id'],checkpoint=str(cp),adapter_weight_sha256=weights,threshold=threshold,threshold_sha256=sha(tpath),original_manifest_sha256=sha(tpath.parent/'manifest.json'),score_definition='native returned logit dtype: logit_yes minus logit_no, then cast float32',yes_id=yes_id,no_id=no_id,output_file=path.name,output_sha256=sha(path),prediction_positive_n=int(prediction.sum()),last_logit_parity=optqa,seconds=seconds))
        dump(a.output/'execution_manifest.json',manifest);print('FINISH',seed,round(seconds,3),int(prediction.sum()),'last_logits',keep_last,flush=True)
        del model,tokenizer;gc.collect();torch.cuda.empty_cache()
    assert len(manifest['completed_runs'])==3
    manifest['status']='complete';manifest['timing_sha256']=sha(a.output/'timing.csv');dump(a.output/'execution_manifest.json',manifest);print('ALL_COMPLETE',flush=True)
if __name__=='__main__':main()
