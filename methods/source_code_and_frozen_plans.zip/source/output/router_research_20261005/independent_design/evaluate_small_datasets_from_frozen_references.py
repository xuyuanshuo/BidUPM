#!/usr/bin/env python3
"""Recompute frozen 600/Alberta outputs against explicitly non-human references."""
import json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import run_training_validation_probe as p

OUT=Path(__file__).resolve().parent/'small_dataset_comparison';OUT.mkdir(exist_ok=True)
ROOT=Path('output');OLD=ROOT/'rule_first_system_validation_20261005/results';NEW=ROOT/'paper_experiment_completion_20261005/results'
checks=[];evidence={};rows=[];listrows=[]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def met(y,pr):
    tp=int(np.sum((y==1)&pr));fp=int(np.sum((y==0)&pr));fn=int(np.sum((y==1)&~pr));tn=int(np.sum((y==0)&~pr))
    return dict(tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else np.nan,recall=tp/(tp+fn) if tp+fn else np.nan,f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0,accuracy=(tp+tn)/len(y) if len(y) else np.nan)
def read(path,cols=None):
    evidence[str(path)]=sha(path);return pd.read_csv(path,usecols=cols).fillna('')
def add600(path,policy,predcol='prediction',seed=None,model=None,mask=None):
    d=read(path);model=model or policy
    if mask is not None:d=d.loc[mask(d)]
    z=d.merge(intent,on='pair_id',validate='one_to_one')
    assert len(z)==600 and set(z.pair_id)==set(intent.pair_id)
    checks.append(dict(condition=policy,seed=seed,pair_ids_complete=True,rows=len(z)))
    y=z.provisional_label.to_numpy(int);pred=z[predcol].to_numpy(bool)
    rows.append(dict(dataset='constructed600',label_source='construction_intent_not_human',model=model,policy=policy,seed=seed,group='all600_intended_difficult',subset='all',rows=len(z),positive_n=int(y.sum()),uncertain_excluded_n=0,**met(y,pred)))
def addalberta(path,policy,predcol='prediction',seed=None,model=None,mask=None,returnedcol=None,scorecol='score',exactcol=None):
    d=read(path);model=model or policy
    if mask is not None:d=d.loc[mask(d)]
    # Ignore any reference fields embedded in a predictions table; join canonical frozen proxy anew.
    d=d.drop(columns=[c for c in ['reference_label','reference_uncertain','label_source'] if c in d])
    rcols=['pair_id','reference_label','reference_uncertain','label_source']
    if 'query_id' not in d:rcols.append('query_id')
    if 'candidate_id' not in d:rcols.append('candidate_id')
    if 'source_year' not in d:rcols.append('source_year')
    z=d.merge(reference[rcols],on='pair_id',validate='one_to_one')
    expected=reference[reference.source_year.isin(z.source_year.unique())]
    assert set(z.pair_id)==set(expected.pair_id)
    checks.append(dict(condition=policy,seed=seed,pair_ids_complete=True,rows=len(z)))
    z['input_nonexact']=~z.pair_id.map(exact_by_id).to_numpy(bool)
    if returnedcol:
        z['eval_returned_rank']=pd.to_numeric(z[returnedcol]).astype(int)
    else:
        # Frozen policy rank. Uncertain rows stay in actual returned slots, then are excluded from quality.
        accepted=z[z[predcol].to_numpy(bool)].copy()
        if scorecol not in accepted:accepted[scorecol]=accepted[predcol].astype(float)
        accepted[scorecol]=pd.to_numeric(accepted[scorecol])
        accepted['rank_exact']=accepted[exactcol].to_numpy(bool) if exactcol else accepted.pair_id.map(exact_by_id).to_numpy(bool)
        accepted=accepted.sort_values(['source_year','query_id','rank_exact',scorecol,'candidate_id'],ascending=[True,True,False,False,True])
        accepted['eval_returned_rank']=accepted.groupby(['source_year','query_id']).cumcount()+1
        rnk=dict(zip(accepted.loc[accepted.eval_returned_rank<=3,'pair_id'],accepted.loc[accepted.eval_returned_rank<=3,'eval_returned_rank']))
        z['eval_returned_rank']=z.pair_id.map(rnk).fillna(0).astype(int)
    year_views=[(str(y),z[z.source_year==y]) for y in sorted(z.source_year.unique())]
    if len(z.source_year.unique())>1:year_views=[('both',z),*year_views]
    for year,zz in year_views:
        for subset,s in [('all_pairs',zz),('input_nonexact_normalized',zz[zz.input_nonexact])]:
            known=s[s.reference_uncertain==0];y=known.reference_label.to_numpy(int);pred=known[predcol].to_numpy(bool)
            rows.append(dict(dataset='Alberta',label_source='GPT6Sol_blind_AI_reference_not_human',model=model,policy=policy,seed=seed,group=year,subset=subset,rows=len(known),positive_n=int(y.sum()),uncertain_excluded_n=len(s)-len(known),**met(y,pred)))
        known=zz[zz.reference_uncertain==0];ret=known[known.eval_returned_rank>0];tp=int(ret.reference_label.sum());fp=len(ret)-tp
        macro=[];hit=0;zero=0;reject=0
        for (sourceyear,q),g in zz.groupby(['source_year','query_id']):
            kg=g[g.reference_uncertain==0];n=int(kg.reference_label.sum());t=int(kg.loc[kg.eval_returned_rank>0,'reference_label'].sum())
            if n:macro.append(t/n);hit+=int(t>0)
            elif not g.reference_uncertain.any():zero+=1;reject+=int(not (g.eval_returned_rank>0).any())
        listrows.append(dict(dataset='Alberta',label_source='GPT6Sol_blind_AI_reference_not_human',model=model,policy=policy,seed=seed,group=year,returned_tp=tp,returned_fp=fp,returned_precision=tp/(tp+fp) if tp+fp else np.nan,macro_recall_at3=np.mean(macro) if macro else np.nan,hit_at3=hit/len(macro) if macro else np.nan,known_positive_query_n=len(macro),no_reference_rejection=reject/zero if zero else np.nan,completely_known_no_reference_query_n=zero,returned_uncertain_n=int(((zz.eval_returned_rank>0)&(zz.reference_uncertain==1)).sum())))

intent_path=ROOT/'internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv'
intent=read(intent_path,['pair_id','provisional_label']);assert len(intent)==600 and intent.provisional_label.sum()==300
ref_path=ROOT/'router_research_20261005/rule_verification/alberta_reference_index.csv'
reference=read(ref_path);assert len(reference)==67635 and reference.reference_label.sum()==142 and reference.reference_uncertain.sum()==56
rules_path=ROOT/'router_research_20261005/rule_verification/alberta_rule_predictions_all_stages.csv'
rulepred=read(rules_path,['pair_id','policy','prediction']);exact=rulepred[rulepred.policy=='normalized_exact_plus_unit'];exact_by_id=dict(zip(exact.pair_id,exact.prediction.astype(bool)))
# 16 real frozen GPU models, four old frozen classical models.
for file in sorted((NEW/'challenge600_gpu').glob('*.csv')):
    if file.name=='timing.csv':continue
    name=file.stem;seed=int(name.rsplit('_seed_',1)[1]) if '_seed_' in name else None
    family=name.rsplit('_seed_',1)[0]
    add600(file,family,seed=seed,model=family)
for name in ['exact_unit_posthoc','tfidf','bm25','feature_full']:
    add600(ROOT/'internal_hard_challenge_20260928/inference/classical'/f'{name}.csv',name)
for seed in [20260904,20260905,20260906]:
    cp=NEW/'deployment_verifier_600_alberta'/f'challenge600_seed_{seed}.csv'
    add600(cp,'rule_plus_bge_candidate_accept',predcol='bge_candidate_accepted',seed=seed)
    add600(cp,'rule_plus_bge_plus_qwen_autoaccept',predcol='accepted',seed=seed)
    for variant,folder in [('raw',OLD/'raw_alberta_models'),('cleaned',OLD/'raw_alberta_models'),('scope_core',OLD/'raw_alberta_scope_core')]:
        file=folder/f'predictions_{variant}_seed_{seed}.csv'
        addalberta(file,f'bge_{variant}',seed=seed,returnedcol='returned_rank')
    for year in [2024,2026]:
        file=NEW/'deployment_verifier_600_alberta'/f'alberta_scope_core_{year}_seed_{seed}.csv'
        addalberta(file,'rule_plus_bge_candidate_accept',predcol='bge_candidate_accepted',seed=seed,scorecol='bge_score',exactcol='exact_match')
        addalberta(file,'rule_plus_bge_plus_qwen_autoaccept',predcol='accepted',seed=seed,scorecol='bge_score',exactcol='exact_match')
# Already selected heads: no selection from these data.
for dataset,folder,predfunc in [('600','semantic_head_600_inputs_predictions',add600),('Alberta','semantic_head_alberta_inputs_predictions',addalberta)]:
    file=Path(__file__).resolve().parent/folder/'decisions_before_gold.csv'
    hd=pd.read_csv(file)
    for (model,policy),g in hd.groupby(['model','policy']):
        cond=f'semantic_head_{policy}'
        predfunc(file,cond,predcol='accepted',model=model,mask=lambda d,m=model,p=policy:(d.model==m)&(d.policy==p),**({'scorecol':'score','exactcol':'exact_rule_accept'} if dataset=='Alberta' else {}))
for policy in rulepred.policy.unique():
    addalberta(rules_path,policy,predcol='prediction',mask=lambda d,p=policy:d.policy==p)
pd.DataFrame(rows).to_csv(OUT/'complete_pair_metrics_each_seed.csv',index=False)
pd.DataFrame(listrows).to_csv(OUT/'alberta_final3_metrics_each_seed.csv',index=False)
# Pair-weighted pooled Alberta needs union of both catalog files for deployment instead of averaging per-year metrics.
# Reconstruct their TP/FP/FN/TN; then compute ratios, once per seed. This is not a new prediction.
all_rows=pd.DataFrame(rows);dep=all_rows[(all_rows.dataset=='Alberta')&all_rows.policy.isin(['rule_plus_bge_candidate_accept','rule_plus_bge_plus_qwen_autoaccept'])&all_rows.group.isin(['2024','2026'])]
pooled=[]
for keys,g in dep.groupby(['dataset','label_source','model','policy','seed','subset']):
    sums=g[['rows','positive_n','uncertain_excluded_n','tp','fp','fn','tn']].sum().to_dict();tp,fp,fn,tn=(int(sums[k]) for k in ['tp','fp','fn','tn'])
    pooled.append(dict(zip(['dataset','label_source','model','policy','seed','subset'],keys),group='both_pooled',**sums,precision=tp/(tp+fp) if tp+fp else np.nan,recall=tp/(tp+fn) if tp+fn else np.nan,f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0,accuracy=(tp+tn)/(tp+tn+fp+fn)))
combined=pd.concat([all_rows,pd.DataFrame(pooled)],ignore_index=True)
combined.to_csv(OUT/'complete_pair_metrics_with_pooled_alberta.csv',index=False)
groupcols=['dataset','label_source','model','policy','group','subset']
agg=combined.groupby(groupcols,dropna=False).agg(seeds_or_conditions=('seed','size'),rows=('rows','first'),positive_n=('positive_n','first'),uncertain_excluded_n=('uncertain_excluded_n','first'),tp_mean=('tp','mean'),fp_mean=('fp','mean'),fn_mean=('fn','mean'),precision_mean=('precision','mean'),recall_mean=('recall','mean'),f1_mean=('f1','mean'),f1_std=('f1','std'),accuracy_mean=('accuracy','mean')).reset_index()
agg.to_csv(OUT/'complete_pair_metrics_aggregate.csv',index=False)
after={name:sha(Path(name)) for name in evidence};assert after==evidence
qa=dict(passed=True,output_conditions=len(rows),complete_input_checks=checks,all_source_files_unchanged=True,source_hashes=evidence,construction600_is_human_gold=False,alberta_is_human_gold=False,uncertain_alberta_pairs_excluded_from_quality=56,no_test_or_external_selection=True,metrics_are_pair_classification_unless_final3_file=True,scope_core_bge_qwen_rows_are_automatic_accept_not_deletion_of_review_candidates=True)
(OUT/'reference_and_output_integrity_qa.json').write_text(json.dumps(qa,indent=2));print(json.dumps({k:v for k,v in qa.items() if k not in ['source_hashes','complete_input_checks']}))
