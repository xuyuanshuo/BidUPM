"""Independent CPU replay of frozen train-derived aliases and later heldout metrics."""
from pathlib import Path
import hashlib,json,math,re,sys,importlib.util
import numpy as np,pandas as pd
P=Path(__file__).resolve().parent
SCRIPT=P.parent/'scripts/train_abbreviation_rules.py';EVAL=P.parent/'scripts/evaluate_frozen_abbreviation_rules.py'
checks=[]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def check(n,v):checks.append({'check':n,'passed':bool(v)});assert v,n
def metric(y,p):
    y=np.asarray(y,int);p=np.asarray(p,bool)
    a=int(((y==1)&p).sum());b=int(((y==0)&p).sum());c=int(((y==1)&~p).sum());d=int(((y==0)&~p).sum())
    return dict(tp=a,fp=b,fn=c,tn=d,precision=a/(a+b) if a+b else None,recall=a/(a+c),f1=2*a/(2*a+b+c) if 2*a+b+c else 0.0)
def canonical(s):return ' '.join(re.sub('[^a-z0-9]+',' ',str(s).lower().replace('&',' and ')).split())
def prediction(frame,mapping):
    def rewrite(s):return ' '.join(mapping.get(w,w) for w in canonical(s).split())
    a=[rewrite(s) for s in frame.query_normalized_description];b=[rewrite(s) for s in frame.candidate_normalized_description]
    q=[str(s).strip().lower() for s in frame.query_normalized_unit];c=[str(s).strip().lower() for s in frame.candidate_normalized_unit]
    return np.array([bool(x) and bool(u) and x==z and u==v for x,z,u,v in zip(a,b,q,c)],bool)
def match_record(values,record):
    return all((record[k]=='' if v is None else math.isclose(float(record[k]),v,rel_tol=1e-12,abs_tol=1e-12)) for k,v in values.items())
design=json.loads((P/'design_before_training.json').read_text());frozen=json.loads((P/'parameters_frozen_before_unseen.json').read_text())
check('training_script_hash',sha(SCRIPT)==design['script_sha256']==frozen['script_sha256'])
check('finite_support_design',design['minimum_support_options']==[1,2,3] and design['test_or_supplement_files_read']==[] and not design['LLM_used'])
D=P.parents[1]/'revise3_full_20260920/supplementary/data'
paths={'train':D/'training/training_pairs_semantic_deduplicated.csv','validation':D/'evaluation/validation_pairs.csv'}
check('train_hash',sha(paths['train'])==frozen['train_sha256'])
check('validation_hash',sha(paths['validation'])==frozen['validation_sha256'])
cols=['pair_id','final_label','query_normalized_description','candidate_normalized_description','query_normalized_unit','candidate_normalized_unit']
frames={k:pd.read_csv(v,usecols=cols,dtype=str,keep_default_na=False) for k,v in paths.items()}
check('train_and_validation_size',len(frames['train'])==2278 and len(frames['validation'])==900)
# Replay the hashed discovery function; independently rewrite/predict and recompute metrics below.
spec=importlib.util.spec_from_file_location('frozen_abbreviation_discovery',SCRIPT);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
support,targets=mod.discover(frames['train'])
alias=pd.read_csv(P/'training_alias_support.csv',keep_default_na=False);reported={}
for _,r in alias.iterrows():
    key=(r['short'],r.expanded);reported[key]=set(r.training_pair_ids.split('|'))
    check(r['short']+'_'+r.expanded+'_support_source',reported[key]==support[key] and int(r.training_support)==len(support[key]))
    check(r['short']+'_'+r.expanded+'_ambiguity',str(r.ambiguous)=='False' if len(targets[r['short']])==1 else str(r.ambiguous)=='True')
    base=frames['train'].set_index('pair_id').loc[sorted(reported[key])]
    check(r['short']+'_'+r.expanded+'_positive_train_only',base.final_label.eq('1').all() and base.query_normalized_unit.eq(base.candidate_normalized_unit).all() and base.query_normalized_unit.ne('').all())
check('all_alias_supports_reproduced',set(reported)==set(support))
table=pd.read_csv(P/'train_validation_metrics.csv',keep_default_na=False).set_index(['minimum_support','dataset'])
valpred=pd.read_csv(P/'validation_predictions.csv');conditions=[]
for minimum in [1,2,3]:
    mapping={short:long for (short,long),ids in support.items() if len(ids)>=minimum and len(targets[short])==1}
    check(f'min{minimum}_numeric_tokens_never_rewritten',all(k.isalpha() and all(w.isalpha() for w in v.split()) for k,v in mapping.items()))
    for name,frame in frames.items():
        pred=prediction(frame,mapping);m=metric(frame.final_label,pred)
        check(f'min{minimum}_{name}_counts_metrics',match_record(m,table.loc[(minimum,name)]))
        check(f'min{minimum}_{name}_alias_count',int(table.loc[(minimum,name),'aliases'])==len(mapping))
        if name=='validation':
            stored=valpred[valpred.minimum_support.eq(minimum)].set_index('pair_id')
            check(f'min{minimum}_validation_decisions',len(stored)==900 and np.array_equal(stored.loc[frame.pair_id,'prediction'].to_numpy(int),pred.astype(int)))
            conditions.append((m['f1'],minimum,m,mapping))
chosen=max((x for x in conditions if x[2]['fp']==0),key=lambda x:(x[0],x[1]))
check('validation_only_selection',chosen[1]==frozen['selected']['minimum_support'] and chosen[3]==frozen['mapping'] and match_record(chosen[2],frozen['selected']))
M=json.loads((P/'unseen/decisions_frozen_before_reference_join.json').read_text())
check('parameter_freeze_hash',sha(P/'parameters_frozen_before_unseen.json')==M['frozen_plan_sha256'])
check('evaluation_script_hash',sha(EVAL)==M['script_sha256'])
check('no_unseen_fit_declared',not M['LLM_used'] and not M['threshold_retuned'] and M['decision_status']=='before_reference_join')
inputpaths={'main220':P.parents[1]/'rule_first_system_20261004/results/server/inputs.csv','challenge600':P.parents[1]/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_challenge600.csv','Alberta':P.parents[1]/'paper_experiment_completion_20261005/deployment_verifier_600_alberta/inputs/model_inputs_alberta_scope_core.csv'}
unseen={};exact_delta={}
for item in M['files']:
    name=item['dataset'];inp=inputpaths[name];check(name+'_input_hash',sha(inp)==M['input_sha256'][name]);check(name+'_prediction_hash',sha(P/'unseen'/item['output'])==item['sha256'])
    f=pd.read_csv(inp,dtype=str,keep_default_na=False)
    check(name+'_label_free_input',not {'label','final_label','provisional_label','difficulty'}&set(f))
    if name=='main220':f=f[f.evaluation_split.ne('validation')].reset_index(drop=True)
    replay=prediction(f,frozen['mapping']);saved=pd.read_csv(P/'unseen'/item['output'],dtype=str,keep_default_na=False).set_index('pair_id')
    check(name+'_complete_id_coverage',len(saved)==len(f)==item['rows'] and saved.index.nunique()==len(f) and set(saved.index)==set(f.pair_id))
    check(name+'_frozen_predictions_recomputed',np.array_equal(saved.loc[f.pair_id,'prediction'].to_numpy(int),replay.astype(int)))
    check(name+'_seven_positive_cpu_timings',len(item['prediction_seconds'])==7 and all(x>0 for x in item['prediction_seconds']))
    unseen[name]=saved.reset_index();exact_delta[name]=int(np.sum(replay!=prediction(f,{})))
# Labels first consulted by this audit after all fitting/selection/decision replay is complete.
references={'main220':pd.read_csv(D/'canonical/all_pairs_vfinal_12092.csv',dtype=str,keep_default_na=False,usecols=['pair_id','final_label','difficulty']), 'challenge600':pd.read_csv(P.parents[1]/'internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv',dtype=str,keep_default_na=False,usecols=['pair_id','provisional_label']).rename(columns={'provisional_label':'final_label'}),'Alberta':pd.read_csv(P.parent/'rule_verification/alberta_reference_index.csv',dtype=str,keep_default_na=False,usecols=['pair_id','reference_label','reference_uncertain']).rename(columns={'reference_label':'final_label'})}
result=pd.read_csv(P/'unseen/frozen_alias_rule_metrics.csv',keep_default_na=False).set_index(['dataset','subset']);recomputed=[]
for name,f in unseen.items():
    z=f.merge(references[name],on='pair_id',how='left',validate='one_to_one')
    check(name+'_reference_coverage_complete',len(z)==len(f) and z.final_label.notna().all())
    if name=='main220':views=[('primary218',z[z.evaluation_split.ne('no_reference_reclassified')]),('locked100',z[z.evaluation_split.eq('locked')]),('locked_hard',z[z.evaluation_split.eq('locked')&z.difficulty.eq('hard')]),('WSDOT80',z[z.evaluation_split.eq('external')])]
    elif name=='Alberta':views=[('known_pairs',z[z.reference_uncertain.eq('0')])];check('56_alberta_uncertain_preserved_before_filter',int(z.reference_uncertain.eq('1').sum())==56)
    else:views=[('all',z)]
    for subset,g in views:
        m=metric(g.final_label,g.prediction.astype(int).eq(1));check(name+'_'+subset+'_reference_metrics_recomputed',match_record(m,result.loc[(name,subset)]) and len(g)==int(result.loc[(name,subset),'rows']))
        recomputed.append({'dataset':name,'subset':subset,'rows':len(g),**m})
check('6_result_rows_complete',len(result)==len(recomputed)==6)
report={'all_passed':all(c['passed'] for c in checks),'checks':checks,'selected_mapping':frozen['mapping'],'selected_minimum_support':chosen[1],'validation_metrics':chosen[2],'difference_from_empty_dictionary_exact_rules':exact_delta,'recomputed_unseen_metrics':recomputed,'test_reference_used_for_fitting':False,'fixed_mapping_before_reference_join':True,'note':'The pre-training design records source-code hash and finite selection rule but not initial source-data hashes; frozen fitted parameters and current canonical source hashes match. Data unchanged across other predeclared experiments corroborates input identity. Design freeze/decision-before-label workflow is based on recorded source order/hashes, not external immutable timestamps. All support words and pair IDs arise solely from positive training pairs. 600 provisional construction labels and Alberta AI reference are distinct from original human reference; these results do not create new final human gold.'}
(P/'independent_qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':report['all_passed'],'checks':len(checks),'selected_mapping':frozen['mapping'],'validation_metrics':chosen[2],'exact_delta':exact_delta},ensure_ascii=False,indent=2))
