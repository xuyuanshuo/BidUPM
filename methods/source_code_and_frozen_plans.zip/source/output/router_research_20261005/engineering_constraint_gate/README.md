# Engineering contradiction gate deliverable

Use `engineering_gate_v2.contradiction_gate(a, b, enabled_rules=("physical_size",))`. It returns `reject` only for aligned explicit length quantities with exactly equal residual work text and equal nonempty unit/category context; every other case returns `defer`. No uncertain relation is accepted. Feed the five permitted fields. For reproducibility with this validation, map CSV `query_description`, `query_normalized_description`, `query_unit`, `query_category`, `query_spec_tokens` and corresponding `candidate_` fields; the unit field was the recorded raw `*_unit`, not `*_normalized_unit`.

## Final allowed-data counts

Gold 0 means incompatible; gold 1 means compatible. Defer does not mean a compatibility prediction. Only the size rule is enabled.

| Rule | Split | Gold 0 rejected | Gold 1 falsely rejected | Gold 0 deferred | Gold 1 deferred | Final status |
|---|---|---:|---:|---:|---:|---|
| physical_size v2 | Train, 2278 | 79 | 0 | 1951 | 248 | Enabled, limited support |
| physical_size v2 | Validation, 900 | 46 | 0 | 747 | 107 | Enabled, limited support |
| opposed_action | Train | 0 | 0 | 2030 | 248 | Unvalidated, disabled |
| opposed_action | Validation | 0 | 0 | 793 | 107 | Unvalidated, disabled |
| material | Train | 0 | 0 | 2030 | 248 | Unvalidated, disabled |
| material | Validation | 0 | 0 | 793 | 107 | Unvalidated, disabled |

The size gate rejects 3.89% of training negatives and 5.80% of validation negatives, with zero annotated-positive false rejects in these data. The gate did not use or inspect any existing model predictions, so its overlap with model mistakes and end-to-end improvement are unknown. This is a candidate for the parent's later unseen evaluation, not evidence of a model performance gain. Several pairs repeat residual work families; see `support_concentration.json`. Zero false rejects do not establish safety on unseen distributions.

## Freeze chronology and preserved failure

`FROZEN_RULE_PLAN.md`, `engineering_gate.py`, and `preread_freeze_manifest.json` preserve the original rule/source freeze before reading data rows. The v1 trial found the same 94/46 negative rejections and zero annotated-positive false rejects. Later synthetic audit identified shared-unit ranges, bounds/approximation qualifiers, area/volume/rate unit syntax, and quoted/bracket-wrapped references that v1 could incorrectly parse as exact length. Therefore **v1 is FAILED_SYNTHETIC_SAFETY_AUDIT_DISABLED**. This is a parsing safety failure, not an observed annotated-positive false reject; the original trial remains intact.

`engineering_gate_v2.py` is a separate pure wrapper with generic defer guards only. `V2_GENERIC_GUARD_PROTOCOL.md` and `v2_freeze_manifest.json` disclose that its source was frozen after the allowed trial and before any unseen data. Its revalidation is not an independent new validation trial. The v2 rejected-pair set is verified to be a subset of v1's: it conservatively defers 15 further training negatives while retaining all 46 validation negative rejections. No source exception names an item, code, agency, or dataset row. No learned table is present. Action and material rules remain disabled because no observed negative rejection supports them.

## Auditable outputs

- `v2_train_validation_report.json`: final per-rule confusion, defer reasons, source/data hashes, permitted column whitelist, split counts, and status.
- `train_validation_report.json`: preserved original v1 trial.
- `enabled_rules.json`: production module/version and enabled list; `v1_trial_enabled_rules_not_for_production.json` preserves the superseded trial configuration.
- `v2_all_rejection_examples.jsonl`: all 125 permitted-data size rejections and their exact evidence; `v2_false_reject_examples.jsonl` is empty because no permitted-data positive was rejected.
- `all_rejection_examples.jsonl`, `false_reject_examples.jsonl`: original v1 examples retained.
- `synthetic_audit.json`: generic parsing-risk examples and five v2 capability checks. The preread v1 also passed 14 basic synthetic checks covering equal-unit conversion, fractions, reference codes, naked numbers, mixed actions, and composite materials.
- `validate_train_validation.py`, `validate_v2_train_validation.py`: CPU-only standard-library evaluators that explicitly restrict access to the two authorized files and whitelisted fields plus gold labels.

Examples of detected contradictions include `15" RCP CULV CLASS IV` versus `18" RCP CULV CLASS IV`, `PAINT PVMT MARKINGS 4"` versus `PAINT PVMT MARKINGS 6"`, and `4' DIA UTILITY MANHOLE` versus `5' DIA UTILITY MANHOLE`. These are evidence illustrations only; they are not constants or lookup entries in any helper.

No test, challenge600, Alberta, other dataset, external labels, GPU, or SSH was used. Source hashes are checked by both evaluators before execution.
