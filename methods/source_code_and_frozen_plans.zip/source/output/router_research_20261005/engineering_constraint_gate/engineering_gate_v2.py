"""Generic conservative safety guard correction around preserved frozen v1.

v1 is retained byte-for-byte. This variant was created after the permitted
train/validation trial, during a synthetic parsing audit, and before reading
any test/external/challenge data. It is not a second preread source freeze.
"""
from __future__ import annotations

import re
from typing import Mapping, Sequence

from engineering_gate import (
    GateResult, REFERENCE_CUES, RULE_NAMES, SIZE_PATTERN, _description, _normalize, _text,
    candidate_gate as _v1_gate,
)

PROTOCOL_VERSION = "engineering-constraint-gate-v2-generic-guard-correction"
SIZE_QUALIFIER_AMBIGUITY = re.compile(
    r"\b(?:minimum|maximum|min|max|about|around|approximately|approx|approximate|"
    r"roughly|up\s+to|at\s+least|at\s+most|less\s+than|greater\s+than|"
    r"more\s+than|over|under|not\s+exceeding|between|from|range|ranges|"
    r"variable|varies|tolerance|tolerances)\b", re.I,
)
SHARED_UNIT_RANGE = re.compile(r"\d\s*(?:[-–—]|to\b|through\b)\s*\d+(?![\d/])", re.I)
UNKNOWN_CONTEXT_VALUES = frozenset(("", "unknown", "unk", "n/a", "na", "none", "null", "nan", "missing", "unspecified", "unclassified", "-", "?"))


def _size_guard(text: str) -> bool:
    if SIZE_QUALIFIER_AMBIGUITY.search(text) or SHARED_UNIT_RANGE.search(text):
        return False
    # Reject-only length evidence cannot be inferred from an area, volume,
    # rate, or compound unit such as m2, m^3, mm/min, or mm per metre.
    for match in SIZE_PATTERN.finditer(text):
        prefix = text[max(0, match.start() - 80):match.start()]
        suffix = text[match.end():]
        # A preceding opening quote may make the trailing quote a quotation,
        # rather than an inch/foot unit. Bracket-wrapped technical references
        # must not bypass the original local reference-cue exclusion.
        if re.search(r"['\"]\s*$", prefix):
            return False
        stripped_prefix = re.sub(r"[\s'\"()\[\]{}]+$", " ", prefix)
        if REFERENCE_CUES.search(stripped_prefix):
            return False
        if re.match(r"\s*(?:[23]|\^[23]|/|per\b)", suffix):
            return False
    return True


def candidate_gate(a: Mapping[str, object], b: Mapping[str, object], rule: str) -> GateResult:
    if rule not in RULE_NAMES:
        raise ValueError(f"Unknown frozen rule: {rule}")
    if any(_normalize(_text(record.get(key))) in UNKNOWN_CONTEXT_VALUES for record in (a, b) for key in ("unit", "category")):
        return GateResult("defer", rule, "missing_or_explicitly_unknown_context")
    if rule == "physical_size" and not all(_size_guard(_description(record)) for record in (a, b)):
        return GateResult("defer", rule, "generic_size_range_qualifier_or_compound_unit_guard")
    return _v1_gate(a, b, rule)


def contradiction_gate(a: Mapping[str, object], b: Mapping[str, object], enabled_rules: Sequence[str] = ()) -> GateResult:
    for rule in enabled_rules:
        result = candidate_gate(a, b, rule)
        if result.decision == "reject":
            return result
    return GateResult("defer", "combined", "no_enabled_rule_proves_contradiction")
