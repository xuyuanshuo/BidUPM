"""Validate the frozen candidates using the two explicitly allowed sources only.

Read only input fields, pair_id, and gold labels. Never use stored proposals,
predictions, similarity features, conflicts, notes, named-item lists, or any other
dataset. This evaluator intentionally hard-codes the permitted paths.
"""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from dataclasses import asdict
from pathlib import Path

from engineering_gate import PROTOCOL_VERSION, RULE_NAMES, candidate_gate, contradiction_gate

OUT = Path(__file__).resolve().parent
DATA_ROOT = Path("research_workspace/output/revise3_full_20260920/supplementary/data")
SOURCES = {
    "train": (DATA_ROOT / "training/training_pairs_semantic_deduplicated.csv", "training_label", 2278),
    "validation": (DATA_ROOT / "evaluation/validation_pairs.csv", "final_label", 900),
}
INPUT_FIELDS = ("description", "normalized_description", "unit", "category", "spec_tokens")


def allowed_pairs(path: Path, label_field: str):
    # The file contains unrelated columns; retain and expose only the whitelist.
    names = ["pair_id", label_field] + [prefix + key for prefix in ("query_", "candidate_") for key in INPUT_FIELDS]
    with path.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.reader(stream)
        header = next(reader)
        indices = {name: header.index(name) for name in names}
        for cells in reader:
            permitted = {name: cells[index] for name, index in indices.items()}
            label = int(permitted[label_field])
            if label not in (0, 1):
                raise ValueError("Non-binary gold label")
            a = {key: permitted["query_" + key] for key in INPUT_FIELDS}
            b = {key: permitted["candidate_" + key] for key in INPUT_FIELDS}
            yield permitted["pair_id"], label, a, b


def matrix(counts: Counter) -> dict:
    # Positive class here is incompatibility/rejection: 0 in the gold data.
    true_reject = counts[(0, "reject")]
    false_reject = counts[(1, "reject")]
    negative_defer = counts[(0, "defer")]
    positive_defer = counts[(1, "defer")]
    rejects = true_reject + false_reject
    negatives = true_reject + negative_defer
    positives = false_reject + positive_defer
    return {
        "true_reject_gold_0": true_reject,
        "false_reject_gold_1": false_reject,
        "gold_0_defer": negative_defer,
        "gold_1_defer": positive_defer,
        "incompatibility_positive_confusion": {"TP": true_reject, "FP": false_reject, "FN": negative_defer, "TN": positive_defer},
        "reject_precision": true_reject / rejects if rejects else None,
        "negative_rejection_rate": true_reject / negatives if negatives else None,
        "positive_false_rejection_rate": false_reject / positives if positives else None,
        "total_rejections": rejects,
        "total_pairs": negatives + positives,
    }


def main():
    freeze = json.loads((OUT / "preread_freeze_manifest.json").read_text())
    for name, expected in freeze["source_sha256"].items():
        actual = hashlib.sha256((OUT / name).read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError(f"Frozen preread source changed: {name}")
    report = {
        "protocol": PROTOCOL_VERSION,
        "decision_space": ["reject", "defer"],
        "label_semantics": {"0": "incompatible", "1": "compatible"},
        "confusion_semantics": "Positive class is incompatibility. Defer is a routing decision, not a model prediction of compatibility.",
        "source_hashes": freeze["source_sha256"],
        "data_sources": {}, "candidate_results": {}, "status": {},
    }
    all_pairs, all_examples, false_rejects = {}, [], []
    for split, (path, label_field, expected_n) in SOURCES.items():
        pairs = list(allowed_pairs(path, label_field))
        if len(pairs) != expected_n:
            raise RuntimeError(f"Unexpected row count for {split}: {len(pairs)}")
        all_pairs[split] = pairs
        report["data_sources"][split] = {
            "path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "label_field": label_field, "rows": len(pairs),
            "gold_counts": dict(Counter(str(p[1]) for p in pairs)),
            "read_columns": ["pair_id", label_field] + [prefix + key for prefix in ("query_", "candidate_") for key in INPUT_FIELDS],
        }
        report["candidate_results"][split] = {}
        for rule in RULE_NAMES:
            counts, reasons = Counter(), Counter()
            for pair_id, label, a, b in pairs:
                result = candidate_gate(a, b, rule)
                counts[(label, result.decision)] += 1
                reasons[result.reason] += 1
                if result.decision == "reject":
                    example = {
                        "split": split, "pair_id": pair_id, "gold_label": label,
                        "rule": rule, "query": a, "candidate": b,
                        "gate_result": asdict(result),
                    }
                    all_examples.append(example)
                    if label == 1:
                        false_rejects.append(example)
            report["candidate_results"][split][rule] = {**matrix(counts), "reason_counts": dict(reasons)}
    enabled = []
    for rule in RULE_NAMES:
        true_rejects = sum(report["candidate_results"][s][rule]["true_reject_gold_0"] for s in SOURCES)
        false_reject_count = sum(report["candidate_results"][s][rule]["false_reject_gold_1"] for s in SOURCES)
        if false_reject_count:
            status = "FAILED_DISABLED"
        elif not true_rejects:
            status = "UNVALIDATED_DISABLED"
        else:
            status = "ENABLED_LIMITED_TRAIN_VALIDATION_SUPPORT"
            enabled.append(rule)
        report["status"][rule] = {"status": status, "true_rejects": true_rejects, "false_rejects": false_reject_count}
    report["production_enabled_rules"] = enabled
    report["combined_enabled_results"] = {}
    for split, pairs in all_pairs.items():
        counts = Counter((label, contradiction_gate(a, b, enabled).decision) for _, label, a, b in pairs)
        report["combined_enabled_results"][split] = matrix(counts)
    (OUT / "train_validation_report.json").write_text(json.dumps(report, indent=2) + "\n")
    for name, rows in (("all_rejection_examples.jsonl", all_examples), ("false_reject_examples.jsonl", false_rejects)):
        (OUT / name).write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows))
    (OUT / "enabled_rules.json").write_text(json.dumps({"protocol": PROTOCOL_VERSION, "enabled_rules": enabled, "candidate_source_sha256": freeze["source_sha256"]["engineering_gate.py"]}, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "combined_enabled_results": report["combined_enabled_results"]}, indent=2))


if __name__ == "__main__":
    main()
