"""Revalidate distinct v2 guards on only the already permitted train/val files."""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from dataclasses import asdict

import engineering_gate_v2 as v2
from engineering_gate import RULE_NAMES
from validate_train_validation import OUT, SOURCES, allowed_pairs, matrix


def main():
    freeze = json.loads((OUT / "v2_freeze_manifest.json").read_text())
    for name, expected in freeze["source_sha256"].items():
        if hashlib.sha256((OUT / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"V2 source changed after freeze: {name}")
    v1_report = json.loads((OUT / "train_validation_report.json").read_text())
    v1_reject_keys = {
        (row["split"], row["pair_id"], row["rule"])
        for row in (json.loads(line) for line in (OUT / "all_rejection_examples.jsonl").read_text().splitlines())
    }
    report = {
        "protocol": v2.PROTOCOL_VERSION,
        "chronology": "V2 is a generic synthetic-audit guard correction after the allowed train/validation trial; this is revalidation, not an independent fresh validation trial.",
        "v1_status": "FAILED_SYNTHETIC_SAFETY_AUDIT_DISABLED",
        "v1_annotated_positive_false_rejects": 0,
        "source_hashes": freeze["source_sha256"],
        "decision_space": ["reject", "defer"],
        "label_semantics": {"0": "incompatible", "1": "compatible"},
        "confusion_semantics": v1_report["confusion_semantics"],
        "data_sources": v1_report["data_sources"],
        "candidate_results": {}, "status": {},
    }
    all_pairs, examples, false_rejects = {}, [], []
    for split, (path, label_field, expected_n) in SOURCES.items():
        if hashlib.sha256(path.read_bytes()).hexdigest() != v1_report["data_sources"][split]["sha256"]:
            raise RuntimeError("Allowed data changed")
        pairs = list(allowed_pairs(path, label_field))
        assert len(pairs) == expected_n
        all_pairs[split] = pairs
        report["candidate_results"][split] = {}
        for rule in RULE_NAMES:
            counts, reasons = Counter(), Counter()
            for pair_id, label, a, b in pairs:
                result = v2.candidate_gate(a, b, rule)
                counts[(label, result.decision)] += 1
                reasons[result.reason] += 1
                if result.decision == "reject":
                    if (split, pair_id, rule) not in v1_reject_keys:
                        raise AssertionError("V2 introduced a rejection rather than adding defer guards")
                    row = {"split": split, "pair_id": pair_id, "gold_label": label, "rule": rule, "query": a, "candidate": b, "gate_result": asdict(result)}
                    examples.append(row)
                    if label == 1:
                        false_rejects.append(row)
            report["candidate_results"][split][rule] = {**matrix(counts), "reason_counts": dict(reasons)}
    enabled = []
    for rule in RULE_NAMES:
        true_rejects = sum(report["candidate_results"][s][rule]["true_reject_gold_0"] for s in SOURCES)
        false_reject_count = sum(report["candidate_results"][s][rule]["false_reject_gold_1"] for s in SOURCES)
        if false_reject_count:
            status = "FAILED_DISABLED"
        elif not true_rejects:
            status = "UNVALIDATED_DISABLED"
        else:
            status = "ENABLED_LIMITED_TRAIN_VALIDATION_SUPPORT"
            enabled.append(rule)
        report["status"][rule] = {"status": status, "true_rejects": true_rejects, "false_rejects": false_reject_count}
    report["production_enabled_rules"] = enabled
    report["combined_enabled_results"] = {
        split: matrix(Counter((label, v2.contradiction_gate(a, b, enabled).decision) for _, label, a, b in pairs))
        for split, pairs in all_pairs.items()
    }
    report["v2_reject_set_subset_of_v1"] = True
    (OUT / "v2_train_validation_report.json").write_text(json.dumps(report, indent=2) + "\n")
    for name, rows in (("v2_all_rejection_examples.jsonl", examples), ("v2_false_reject_examples.jsonl", false_rejects)):
        (OUT / name).write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows))
    original_config = OUT / "v1_trial_enabled_rules_not_for_production.json"
    if not original_config.exists():
        original_config.write_text((OUT / "enabled_rules.json").read_text())
    (OUT / "enabled_rules.json").write_text(json.dumps({
        "protocol": v2.PROTOCOL_VERSION, "module": "engineering_gate_v2",
        "enabled_rules": enabled, "source_sha256": freeze["source_sha256"],
        "disabled_v1_reason": "FAILED_SYNTHETIC_SAFETY_AUDIT_DISABLED",
        "warning": "V2 corrected generic guards after permitted validation; this revalidation does not establish independent generalization.",
    }, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "combined_enabled_results": report["combined_enabled_results"], "v2_reject_set_subset_of_v1": True}, indent=2))


if __name__ == "__main__":
    main()
