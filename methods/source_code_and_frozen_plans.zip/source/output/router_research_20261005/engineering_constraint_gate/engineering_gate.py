"""Frozen generic, pure-function, reject-only engineering contradiction gates.

The constants in this file were fixed before reading allowed dataset rows.
Production callers supply an independently audited list of enabled rule names.
No labels, learned tables, model calls, files, or network access occur here.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from fractions import Fraction
from typing import Mapping, Sequence

PROTOCOL_VERSION = "engineering-constraint-gate-preread-v1"
RULE_NAMES = ("physical_size", "opposed_action", "material")
LENGTH_MM = {
    "mm": Fraction(1), "millimeter": Fraction(1), "millimeters": Fraction(1),
    "millimetre": Fraction(1), "millimetres": Fraction(1),
    "cm": Fraction(10), "centimeter": Fraction(10), "centimeters": Fraction(10),
    "centimetre": Fraction(10), "centimetres": Fraction(10),
    "m": Fraction(1000), "meter": Fraction(1000), "meters": Fraction(1000),
    "metre": Fraction(1000), "metres": Fraction(1000),
    "in": Fraction(127, 5), "inch": Fraction(127, 5), "inches": Fraction(127, 5),
    '"': Fraction(127, 5), "ft": Fraction(1524, 5), "foot": Fraction(1524, 5),
    "feet": Fraction(1524, 5), "'": Fraction(1524, 5),
    "yd": Fraction(4572, 5), "yard": Fraction(4572, 5), "yards": Fraction(4572, 5),
}
UNICODE_FRACTIONS = {
    "¼": "1/4", "½": "1/2", "¾": "3/4", "⅐": "1/7", "⅑": "1/9",
    "⅒": "1/10", "⅓": "1/3", "⅔": "2/3", "⅕": "1/5", "⅖": "2/5",
    "⅗": "3/5", "⅘": "4/5", "⅙": "1/6", "⅚": "5/6", "⅛": "1/8",
    "⅜": "3/8", "⅝": "5/8", "⅞": "7/8",
}
NUMBER_PATTERN = r"(?:\d+[ -]+\d+\s*/\s*\d+|\d+\s*/\s*\d+|\d+(?:\.\d+)?|\.\d+)"
SIZE_PATTERN = re.compile(
    r"(?<![\w./])(?P<number>" + NUMBER_PATTERN + r")\s*(?P<unit>"
    + "|".join(re.escape(k) for k in sorted(LENGTH_MM, key=len, reverse=True))
    + r")(?=$|[^a-z])", re.I,
)
REFERENCE_CUES = re.compile(
    r"\b(?:astm|csa|ansi|iso|en|bs|din|asme|aci|aisc|can/csa|"
    r"no\.?|number|type|class|schedule|sch\.?|grade|model|code|section|clause|"
    r"standard|reference|ref\.?)\s*[:#.-]?\s*(?:[a-z0-9._/-]+\s+){0,2}$", re.I,
)
SIZE_AMBIGUITY = re.compile(r"\b(?:tolerance|nominal\s+range|between|from)\b|[±<>≤≥]")
GENERAL_AMBIGUITY = re.compile(
    r"\b(?:or|either|optional|option|not|without|except|unless|if|may|might|"
    r"existing|retain|retained|temporary|temporarily)\b|[?]", re.I,
)
ACTION_TERMS = {
    "install": ("install", "installs", "installed", "installing", "installation"),
    "remove": ("remove", "removes", "removed", "removing", "removal"),
    "construct": ("construct", "constructs", "constructed", "constructing", "construction"),
    "demolish": ("demolish", "demolishes", "demolished", "demolishing", "demolition"),
}
OPPOSED_ACTIONS = frozenset((frozenset(("install", "remove")), frozenset(("construct", "demolish"))))
ACTION_AMBIGUITY = re.compile(
    r"\b(?:replace\w*|replacement\w*|relocat\w*|restor\w*|repair\w*|supply|"
    r"supplied|supplies|reuse\w*|recycl\w*|salvag\w*|reinstall\w*|"
    r"dismantl\w*|deconstruct\w*|reconstruct\w*)\b", re.I,
)
MATERIAL_TERMS = {
    "steel": ("steel",), "concrete": ("concrete",),
    "wood": ("wood", "wooden", "timber"),
    "plastic": ("plastic", "pvc", "abs", "hdpe", "polyethylene"),
    "aluminum": ("aluminum", "aluminium"), "copper": ("copper",),
    "cast_iron": ("cast iron",),
}
MATERIAL_AMBIGUITY = re.compile(
    r"\b(?:composite\w*|coat\w*|reinforc\w*|lined|lining|jacket\w*|"
    r"encas\w*|clad\w*|laminat\w*|galvaniz\w*|galvanis\w*)\b", re.I,
)
NONCONTENT_WORDS = frozenset(
    "a an the of for and with to from in on at by is are be as per work works item items "
    "material materials type unit units size sizes diameter dimension dimensions length "
    "wide width high height thick thickness specified specification general typical".split()
)


@dataclass(frozen=True)
class Evidence:
    residual: str
    values: tuple[str, ...]


@dataclass(frozen=True)
class GateResult:
    decision: str  # "reject" or "defer", never "accept"
    rule: str
    reason: str
    evidence_a: Evidence | None = None
    evidence_b: Evidence | None = None


def _text(value: object) -> str:
    return "" if value is None else str(value).strip()


def _prepare(value: str) -> str:
    for char, fraction in UNICODE_FRACTIONS.items():
        value = re.sub(r"(?<=\d)" + re.escape(char), " " + fraction, value)
        value = value.replace(char, fraction)
    value = value.translate(str.maketrans({"″": '"', "“": '"', "”": '"', "′": "'", "‘": "'", "’": "'", "⁄": "/"}))
    return unicodedata.normalize("NFKC", value).casefold()


def _normalize(value: str) -> str:
    # Punctuation is retained: a residual disagreement is evidence to defer.
    return re.sub(r"\s+", " ", _prepare(value)).strip()


def _description(record: Mapping[str, object]) -> str:
    return _prepare(_text(record.get("description")) or _text(record.get("normalized_description")))


def _context_ok(a: Mapping[str, object], b: Mapping[str, object]) -> bool:
    return all(
        bool(_normalize(_text(a.get(key)))) and bool(_normalize(_text(b.get(key))))
        and _normalize(_text(a.get(key))) == _normalize(_text(b.get(key)))
        for key in ("unit", "category")
    )


def _residual_has_work(residual: str) -> bool:
    words = re.findall(r"[a-z]+", re.sub(r"__slot__", " ", residual))
    content = [word for word in words if word not in NONCONTENT_WORDS]
    return bool(content) and sum(len(word) for word in content) >= 4


def _fraction(number: str) -> Fraction:
    number = re.sub(r"\s*/\s*", "/", number.strip())
    match = re.fullmatch(r"(\d+)[ -]+(\d+/\d+)", number)
    if match:
        return Fraction(match[1]) + Fraction(match[2])
    return Fraction(number)


def _mask(text: str, matches: Sequence[re.Match[str]]) -> str:
    pieces, cursor = [], 0
    for match in matches:
        pieces.extend((text[cursor:match.start()], "__slot__"))
        cursor = match.end()
    pieces.append(text[cursor:])
    return _normalize("".join(pieces))


def size_evidence(text: str) -> Evidence | None:
    text = _prepare(text)
    if GENERAL_AMBIGUITY.search(text) or SIZE_AMBIGUITY.search(text):
        return None
    matches = list(SIZE_PATTERN.finditer(text))
    if not matches:
        return None
    quantities = []
    for match in matches:
        prefix, suffix = text[max(0, match.start() - 80):match.start()], text[match.end():match.end() + 24]
        # Never infer a size from a technical reference or one side of a range,
        # negative quantity, feet/inches compound, or approximate/tolerance value.
        if REFERENCE_CUES.search(prefix) or re.search(r"(?:[\d/]|[+\-~≈])\s*$", prefix):
            return None
        if re.match(r"\s*(?:[-–—]|to\b|[+±])", suffix):
            return None
        try:
            quantity = _fraction(match.group("number")) * LENGTH_MM[match.group("unit").casefold()]
        except (ValueError, ZeroDivisionError):
            return None
        if quantity <= 0:
            return None
        quantities.append(str(quantity))
    # A feet+inches compound could denote one size rather than two attributes.
    for previous, following in zip(matches, matches[1:]):
        if previous.group("unit") in ("ft", "foot", "feet", "'") and following.group("unit") in ("in", "inch", "inches", '"'):
            if not text[previous.end():following.start()].strip():
                return None
    return Evidence(_mask(text, matches), tuple(quantities))


def _term_evidence(text: str, classes: Mapping[str, Sequence[str]], ambiguity: re.Pattern[str]) -> Evidence | None:
    text = _prepare(text)
    if GENERAL_AMBIGUITY.search(text) or ambiguity.search(text):
        return None
    term_to_class = {term: kind for kind, terms in classes.items() for term in terms}
    pattern = re.compile(r"\b(?:" + "|".join(re.escape(term) for term in sorted(term_to_class, key=len, reverse=True)) + r")\b")
    matches = list(pattern.finditer(text))
    if not matches:
        return None
    values = tuple(term_to_class[match.group()] for match in matches)
    if len(set(values)) != 1:
        return None
    return Evidence(_mask(text, matches), values)


def candidate_gate(a: Mapping[str, object], b: Mapping[str, object], rule: str) -> GateResult:
    if rule not in RULE_NAMES:
        raise ValueError(f"Unknown frozen rule: {rule}")
    if not _context_ok(a, b):
        return GateResult("defer", rule, "missing_or_different_unit_category_context")
    text_a, text_b = _description(a), _description(b)
    if not text_a or not text_b:
        return GateResult("defer", rule, "missing_description")
    if rule == "physical_size":
        ea, eb = size_evidence(text_a), size_evidence(text_b)
    elif rule == "opposed_action":
        ea, eb = _term_evidence(text_a, ACTION_TERMS, ACTION_AMBIGUITY), _term_evidence(text_b, ACTION_TERMS, ACTION_AMBIGUITY)
    else:
        ea, eb = _term_evidence(text_a, MATERIAL_TERMS, MATERIAL_AMBIGUITY), _term_evidence(text_b, MATERIAL_TERMS, MATERIAL_AMBIGUITY)
    if ea is None or eb is None:
        return GateResult("defer", rule, "missing_or_ambiguous_explicit_evidence", ea, eb)
    if ea.residual != eb.residual or not _residual_has_work(ea.residual) or len(ea.values) != len(eb.values):
        return GateResult("defer", rule, "residual_work_or_slots_not_identical", ea, eb)
    if ea.values == eb.values:
        return GateResult("defer", rule, "explicit_values_equal", ea, eb)
    if rule == "opposed_action" and frozenset((ea.values[0], eb.values[0])) not in OPPOSED_ACTIONS:
        return GateResult("defer", rule, "actions_not_explicitly_opposed", ea, eb)
    return GateResult("reject", rule, "explicit_aligned_contradiction", ea, eb)


def contradiction_gate(a: Mapping[str, object], b: Mapping[str, object], enabled_rules: Sequence[str] = ()) -> GateResult:
    """Reject with audited enabled rules; default safely defers all pairs."""
    for rule in enabled_rules:
        result = candidate_gate(a, b, rule)
        if result.decision == "reject":
            return result
    return GateResult("defer", "combined", "no_enabled_rule_proves_contradiction")
