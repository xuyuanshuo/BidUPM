"""Join construction labels only after GPT/16-run gate outputs are frozen."""
from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from apply_blind_gate import OUT, GATE_ROOT, PREDICTION_PATH, RAW_UNIT_PATH, EXPECTED_ORIGINAL_PREDICTION_SHA256, EXPECTED_RAW_UNIT_SHA256, sha256

REFERENCE_PATH = Path("research_workspace/output/internal_hard_challenge_20260928/constructed_600/difficult_supplement_600.csv")
EXPECTED_REFERENCE_SHA256 = "fdad3079e7abbecc4a4731b8cd3c50cf606d15bcd83228e8d362a644e594ea27"


def metrics(rows, prediction_key):
    counts = Counter((int(row["construction_reference_label"]), int(row[prediction_key])) for row in rows)
    tp, fp, fn, tn = (counts[(1,1)], counts[(0,1)], counts[(1,0)], counts[(0,0)])
    return {
        "rows":len(rows), "reference_positive_n":tp+fn, "reference_negative_n":tn+fp,
        "tp":tp,"fp":fp,"fn":fn,"tn":tn,
        "precision":tp/(tp+fp) if tp+fp else None,
        "recall":tp/(tp+fn) if tp+fn else None,
        "f1":2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0,
        "accuracy":(tp+tn)/len(rows),
    }


def write_csv(path, rows, fields):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows(rows)


def outcome(label, prediction):
    return {(1,1):"TP",(0,1):"FP",(1,0):"FN",(0,0):"TN"}[(label,prediction)]


def main():
    gate_manifest=json.loads((OUT/'blind_gate_freeze_manifest.json').read_text())
    other_manifest=json.loads((OUT/'other_predictions_freeze_manifest.json').read_text())
    for manifest in (gate_manifest,other_manifest):
        if sha256(Path(manifest['output']['path'])) != manifest['output']['sha256']:
            raise RuntimeError('Pre-gold frozen output fingerprint changed')
    if sha256(PREDICTION_PATH)!=EXPECTED_ORIGINAL_PREDICTION_SHA256:
        raise RuntimeError('Original GPT predictions changed before label join')
    for name,expected in gate_manifest['gate_sources'].items():
        if sha256(GATE_ROOT/name)!=expected:
            raise RuntimeError('Frozen gate source changed')
    for source in other_manifest['sources']:
        if sha256(Path(source['path']))!=source['sha256']:
            raise RuntimeError('Original cached GPU prediction changed')
    if sha256(REFERENCE_PATH)!=EXPECTED_REFERENCE_SHA256:
        raise RuntimeError('Construction reference source fingerprint differs')
    gate_rows=[json.loads(line) for line in Path(gate_manifest['output']['path']).read_text().splitlines()]
    ids={row['pair_id'] for row in gate_rows}
    # First actual construction-label access in this evaluation.
    gold={}
    with REFERENCE_PATH.open(newline='',encoding='utf-8-sig') as stream:
        reader=csv.reader(stream);header=next(reader)
        id_index,label_index=header.index('pair_id'),header.index('provisional_label')
        for cells in reader:
            pair_id,label=cells[id_index],int(cells[label_index])
            if pair_id in gold or label not in (0,1):raise RuntimeError('Invalid construction reference')
            gold[pair_id]=label
    if set(gold)!=ids or len(gold)!=600 or sum(gold.values())!=300:
        raise RuntimeError('Construction reference does not align as 300 positive / 300 negative pairs')
    metric_rows, gpt_rows, harmed, corrected = [], [], [], []
    for row in gate_rows:
        label=gold[row['pair_id']];prediction=row['original_prediction'];gated=row['gated_prediction']
        result={
            'pair_id':row['pair_id'],'construction_reference_label':label,
            'original_prediction':prediction,'gated_prediction':gated,
            'original_outcome':outcome(label,prediction),'gated_outcome':outcome(label,gated),
            'changed_accept_to_reject':int(prediction==1 and gated==0),
            'correct_acceptance_falsely_deleted':int(label==1 and prediction==1 and gated==0),
            'false_acceptance_corrected':int(label==0 and prediction==1 and gated==0),
            'gate_decision':row['gate']['decision'],'gate_reason':row['gate']['reason'],
            'query_description':row['query']['description'],'candidate_description':row['candidate']['description'],
            'query_unit':row['query_unit'],'candidate_unit':row['candidate_unit'],
        }
        gpt_rows.append(result)
        if result['correct_acceptance_falsely_deleted']:harmed.append(dict(run='GPT6Sol_cached',**result))
        if result['false_acceptance_corrected']:corrected.append(dict(run='GPT6Sol_cached',**result))
    for variant,key in [('original','original_prediction'),('plus_frozen_physical_size_gate','gated_prediction')]:
        metric_rows.append({'run':'GPT6Sol_cached','model':'GPT6Sol_cached','seed':'','variant':variant,**metrics(gpt_rows,key)})
    other_rows=[];by_run=defaultdict(list)
    with Path(other_manifest['output']['path']).open(newline='',encoding='utf-8') as stream:
        for row in csv.DictReader(stream):
            pair_id=row['pair_id'];label=gold[pair_id]
            row['original_prediction']=int(row['original_prediction']);row['gated_prediction']=int(row['gated_prediction'])
            row['construction_reference_label']=label
            row['original_outcome']=outcome(label,row['original_prediction']);row['gated_outcome']=outcome(label,row['gated_prediction'])
            row['correct_acceptance_falsely_deleted']=int(label==1 and row['original_prediction']==1 and row['gated_prediction']==0)
            row['false_acceptance_corrected']=int(label==0 and row['original_prediction']==1 and row['gated_prediction']==0)
            other_rows.append(row);by_run[row['run']].append(row)
            if row['correct_acceptance_falsely_deleted']:harmed.append({'run':row['run'],'pair_id':pair_id,'construction_reference_label':label,'original_prediction':row['original_prediction'],'gated_prediction':row['gated_prediction'],'gate_reason':row['gate_reason']})
            if row['false_acceptance_corrected']:corrected.append({'run':row['run'],'pair_id':pair_id,'construction_reference_label':label,'original_prediction':row['original_prediction'],'gated_prediction':row['gated_prediction'],'gate_reason':row['gate_reason']})
    for run,rows in by_run.items():
        if len(rows)!=600 or len({row['pair_id'] for row in rows})!=600:raise RuntimeError('Cached run row coverage failed')
        for variant,key in [('original','original_prediction'),('plus_frozen_physical_size_gate','gated_prediction')]:
            metric_rows.append({'run':run,'model':rows[0]['model'],'seed':rows[0]['seed'],'variant':variant,**metrics(rows,key)})
    write_csv(OUT/'gpt6sol_pair_results.csv',gpt_rows,list(gpt_rows[0]))
    write_csv(OUT/'other16_pair_results.csv',other_rows,list(other_rows[0]))
    write_csv(OUT/'metrics_each_run.csv',metric_rows,list(metric_rows[0]))
    harm_fields=['run','pair_id','construction_reference_label','original_prediction','gated_prediction','gate_reason']
    write_csv(OUT/'correct_acceptances_falsely_deleted.csv',[{key:row[key] for key in harm_fields} for row in harmed],harm_fields)
    write_csv(OUT/'false_acceptances_corrected.csv',[{key:row[key] for key in harm_fields} for row in corrected],harm_fields)
    defer_reasons=Counter(row['gate_reason'] for row in gpt_rows if row['gate_decision']=='defer')
    reason_rates={reason:{'rows':count,'fraction_of_all_600':count/600,'fraction_of_deferred':count/sum(defer_reasons.values())} for reason,count in defer_reasons.items()}
    summary={
        'comparison_type':'cached_prediction_combination_only_no_new_model_inference',
        'gate_rule_selection':'physical_size fixed before unseen labels; no rule/threshold modifications or selection from 600 results',
        'label_source':'construction_intent_provisional_label_not_human_gold',
        'reference':{'path':str(REFERENCE_PATH),'sha256':sha256(REFERENCE_PATH),'read_columns':['pair_id','provisional_label'],'positive_n':300,'negative_n':300},
        'gate_decisions':dict(Counter(row['gate_decision'] for row in gpt_rows)),
        'defer_reason_rates':reason_rates,
        'unknown_or_missing_context_defer_rows':gate_manifest['unknown_or_missing_context_defer_rows'],
        'unknown_or_missing_context_defer_fraction_of_600':gate_manifest['unknown_or_missing_context_defer_rows']/600,
        'missing_or_ambiguous_explicit_evidence_defer_rows':gate_manifest['unknown_or_missing_explicit_evidence_defer_rows'],
        'missing_or_ambiguous_explicit_evidence_defer_fraction_of_600':gate_manifest['unknown_or_missing_explicit_evidence_defer_rows']/600,
        'unknown_missing_evidence_caveat':'Frozen helper merges missing and ambiguous explicit evidence in one reason; those causes are not separately estimated.',
        'gpt6sol':{row['variant']:row for row in metric_rows if row['run']=='GPT6Sol_cached'},
        'other_frozen_runs':len(by_run),
        'correct_acceptances_falsely_deleted_across_all_runs':len(harmed),
        'false_acceptances_corrected_across_all_runs':len(corrected),
        'no_api_cost_or_speed_claim':True,
        'evaluated_utc':datetime.now(timezone.utc).isoformat(),
    }
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    sources_unchanged=sha256(PREDICTION_PATH)==EXPECTED_ORIGINAL_PREDICTION_SHA256 and all(sha256(Path(source['path']))==source['sha256'] for source in other_manifest['sources'])
    by_metrics=defaultdict(dict)
    for row in metric_rows:by_metrics[row['run']][row['variant']]=row
    unchanged_metrics=all(all(variants['original'][key]==variants['plus_frozen_physical_size_gate'][key] for key in ('tp','fp','fn','tn','precision','recall','f1','accuracy')) for variants in by_metrics.values())
    gate_sources_unchanged=all(sha256(GATE_ROOT/name)==expected for name,expected in gate_manifest['gate_sources'].items())
    raw_metadata_unchanged=sha256(RAW_UNIT_PATH)==EXPECTED_RAW_UNIT_SHA256
    construction_reference_unchanged=sha256(REFERENCE_PATH)==EXPECTED_REFERENCE_SHA256
    pre_gold_outputs_unchanged=all(sha256(Path(manifest['output']['path']))==manifest['output']['sha256'] for manifest in (gate_manifest,other_manifest))
    checks={
        'passed':True,'gate_outputs_frozen_before_gold':gate_manifest['no_gold_fields_read_by_this_stage'],
        'other16_outputs_frozen_before_gold':other_manifest['no_gold_fields_read'],
        'raw_unit_metadata_hash_matches_authorized_input':raw_metadata_unchanged,
        'all_pair_ids_unique_complete_600':True,'construction_reference_only_fields':['pair_id','provisional_label'],
        'gate_source_hashes_unchanged':gate_sources_unchanged,'original_predictions_all_hashes_unchanged':sources_unchanged,
        'construction_reference_hash_unchanged':construction_reference_unchanged,
        'pre_gold_frozen_output_hashes_unchanged':pre_gold_outputs_unchanged,
        'original_gpt_prediction_sha256_after_evaluation':sha256(PREDICTION_PATH),
        'no_0_to_1_prediction_changes':all(row['gated_prediction']<=row['original_prediction'] for row in gpt_rows+other_rows),
        'all_17_runs_gate_changes_zero':all(row['gated_prediction']==row['original_prediction'] for row in gpt_rows+other_rows),
        'all_17_runs_metrics_unchanged':unchanged_metrics,'gpt_rows':len(gpt_rows),'other_run_rows':len(other_rows),'metric_rows':len(metric_rows),
        'all_confusion_totals_equal_600':all(row['tp']+row['fp']+row['fn']+row['tn']==600 for row in metric_rows),
        'all_recalls_use_300_reference_positives':all(row['tp']+row['fn']==300 for row in metric_rows),
        'no_threshold_tuning_no_rule_edits_no_model_execution':True,
    }
    if not all(checks[key] for key in ('raw_unit_metadata_hash_matches_authorized_input','gate_source_hashes_unchanged','construction_reference_hash_unchanged','pre_gold_frozen_output_hashes_unchanged','original_predictions_all_hashes_unchanged','no_0_to_1_prediction_changes','all_17_runs_gate_changes_zero','all_17_runs_metrics_unchanged','all_confusion_totals_equal_600','all_recalls_use_300_reference_positives')):
        raise AssertionError('Evaluation verification failed')
    (OUT/'automatic_verification.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps({'gpt6sol':summary['gpt6sol'],'other_frozen_runs':len(by_run),'correct_acceptances_falsely_deleted':len(harmed),'defer_reason_rates':reason_rates,'checks_passed':checks['passed']},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
