# 冻结尺寸门控的 600 对 CPU 缓存组合评估

冻结的 `engineering_gate_v2` 尺寸规则在 600 对上全部 **defer**，没有 reject，也没有将任何接受改成拒绝。原 GPT6Sol 缓存与 GPT+gate 的指标完全相同。这里评估的是已有缓存预测与冻结门控的组合，没有重新调用模型；不能据此声称 API 费用或端到端速度。

| 固定方法 | Precision | Recall | F1 | TP | FP | FN | TN |
|---|---:|---:|---:|---:|---:|---:|---:|
| GPT6Sol 缓存 | 0.980392 | 1.000000 | 0.990099 | 300 | 6 | 0 | 294 |
| GPT6Sol 缓存 + frozen physical_size gate | 0.980392 | 1.000000 | 0.990099 | 300 | 6 | 0 | 294 |

参考标签是原 constructed600 的 `provisional_label` 构造意图，300 正、300 负，**不是人工 gold**。600 结果没有用于修改规则、常量、阈值或选择规则。动作/材料规则继续停用。对于这个集合，保守门控没有提供可见收益，也没有误删正确判断。

## 回退原因

| 冻结门控理由 | 对数 | 占 600 比例 |
|---|---:|---:|
| unit/category 上下文不同（原理由合并 missing/different） | 198 | 33.00% |
| 剩余工作文本或尺寸槽不相同 | 133 | 22.17% |
| 缺失或歧义的显式尺寸证据 | 250 | 41.67% |
| 泛化保守 guard：范围、限定词、复合单位、引用等 | 19 | 3.17% |
| 合计 defer | 600 | 100.00% |

明确缺失或 unknown 的 unit/category 上下文为 0/600。冻结函数将缺失和歧义尺寸证据合并为一个理由，因此 250/600 不能进一步拆成精确的 missing 与 ambiguous 比例。正确接受误删为 **0**；错误接受修正也为 **0**。对应逐行清单分别是 `correct_acceptances_falsely_deleted.csv` 与 `false_acceptances_corrected.csv`，二者仅有表头。

## 16 份其他冻结预测

已定位并使用 `small_dataset_comparison` 原本使用的 16 个 GPU 缓存 CSV：四个 BGE hard 变体各三种 seed、BGE zero-shot 一份、Qwen 4B standard 三种 seed。只读取 `pair_id` 和已冻结的二元 `prediction`，没有重新计算 score、阈值或模型输出。门控应用于全部 16 份，不按 600 指标挑选方法。9600 对缓存组合没有任何预测变化；32 行门控前后指标全部相同。完整结果见 `metrics_each_run.csv` 和 `other16_pair_results.csv`。

## 输入与冻结顺序

盲输入每侧字段为 `description`, `normalized_description`, `normalized_unit`, `category`, `spec_tokens`，原文件缺少 raw `unit`。正式评估使用 root 提供的无标签 `raw_units_metadata.csv`，先筛 `dataset=challenge600`，再按 `pair_id` 补回 raw unit，使输入约定与冻结 train/validation 保持一致。metadata 只有 dataset、pair_id 和双方 raw unit；没有标签或构造意图。

先应用冻结门控并保存 `blind_gate_decisions_before_gold.jsonl` / `blind_gate_freeze_manifest.json`；再将同一决策应用到全部 16 份缓存并保存 `other_frozen_predictions_before_gold.csv` / `other_predictions_freeze_manifest.json`；之后才读取原 600 CSV 的 `pair_id`、`provisional_label` 两列计算指标。逐行 GPT 结果在 `gpt6sol_pair_results.csv`，完整汇总在 `summary.json`。

最初仅用于 schema 检查的 normalized_unit 适配试运行没有接入标签，并已移到 `discarded_normalized_unit_schema_diagnostic` 标记弃用；它不属于正式评估。正式门控只补 raw unit，源码和规则均未读取检查或修改，仅校验哈希并调用冻结函数。

- 原 GPT 预测 SHA-256：`8ed2b91f66c6792f6296ae0d0c9de79c577538183c9b124be3aa8677ca8f66cb`，评估后保持不变。
- 冻结 v2 源码 SHA-256：`8c3feada94d04da2d8c59bc807802abc1890c0c3b227cb475cfb37cfea973882`，保持不变。
- raw unit metadata SHA-256：`6ecc306c36e6508cfdcc1ddf68285f99feeedf73bdaf3c19b91aebe3cc0b7e09`，保持不变。
- `automatic_verification.json` 核查双方输出冻结、600 对唯一且完整、参考标签 300/300、17 份缓存均无改判、混淆矩阵合计、各原始预测/规则/metadata/reference 与冻结输出哈希不变。

仅进行 CPU 文件组合与统计；没有 SSH、GPU、API 请求、规则重训或阈值调参。
