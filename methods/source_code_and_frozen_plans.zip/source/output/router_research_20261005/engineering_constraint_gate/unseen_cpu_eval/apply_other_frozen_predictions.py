"""Combine the same frozen 600 gate decisions with all 16 cached GPU runs.

Read only pair_id/prediction from the existing small-dataset comparison sources;
do not inspect embedded labels, scores, thresholds, or construction intent.
"""
from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path

from apply_blind_gate import OUT, sha256

WORKSPACE = Path("research_workspace")
PREDICTION_ROOT = WORKSPACE / "output/paper_experiment_completion_20261005/results/challenge600_gpu"


def binary(value: str) -> int:
    normalized = value.strip().casefold()
    if normalized in ("1", "1.0", "true"):
        return 1
    if normalized in ("0", "0.0", "false"):
        return 0
    raise ValueError(f"Nonbinary frozen prediction: {value!r}")


def main():
    manifest = json.loads((OUT / "blind_gate_freeze_manifest.json").read_text())
    decision_path = OUT / "blind_gate_decisions_before_gold.jsonl"
    if sha256(decision_path) != manifest["output"]["sha256"]:
        raise RuntimeError("Previously frozen gate outputs changed")
    gate_rows = [json.loads(line) for line in decision_path.read_text().splitlines()]
    by_id = {row["pair_id"]:row for row in gate_rows}
    files = sorted(path for path in PREDICTION_ROOT.glob("*.csv") if path.name != "timing.csv")
    if len(files) != 16:
        raise RuntimeError(f"Expected all 16 frozen GPU prediction files, found {len(files)}")
    sources, combined_rows = [], []
    for path in files:
        source_hash = sha256(path)
        model, seed = path.stem.rsplit("_seed_", 1) if "_seed_" in path.stem else (path.stem, "")
        predictions = {}
        with path.open(newline="", encoding="utf-8-sig") as stream:
            reader = csv.reader(stream)
            header = next(reader)
            id_index, prediction_index = header.index("pair_id"), header.index("prediction")
            for cells in reader:
                pair_id = cells[id_index]
                if pair_id in predictions:
                    raise RuntimeError("Duplicate frozen-prediction pair_id")
                predictions[pair_id] = binary(cells[prediction_index])
        if len(predictions) != 600 or set(predictions) != set(by_id):
            raise RuntimeError(f"Frozen run is not aligned with the same 600 inputs: {path}")
        if sha256(path) != source_hash:
            raise RuntimeError("Frozen source prediction file changed")
        changes = 0
        for gate_row in gate_rows:
            pair_id = gate_row["pair_id"]
            prediction = predictions[pair_id]
            gated_prediction = 0 if gate_row["gate"]["decision"] == "reject" else prediction
            changes += prediction != gated_prediction
            combined_rows.append({
                "run":path.stem, "model":model, "seed":seed, "pair_id":pair_id,
                "original_prediction":prediction, "gated_prediction":gated_prediction,
                "gate_decision":gate_row["gate"]["decision"], "gate_reason":gate_row["gate"]["reason"],
            })
        sources.append({"run":path.stem,"model":model,"seed":seed,"path":str(path),"sha256":source_hash,"read_columns":["pair_id","prediction"],"rows":600,"changed_accept_to_reject_rows":changes})
    output_path = OUT / "other_frozen_predictions_before_gold.csv"
    with output_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(combined_rows[0]))
        writer.writeheader();writer.writerows(combined_rows)
    report = {
        "phase":"all_16_cached_prediction_combinations_frozen_before_gold_access",
        "created_utc":datetime.now(timezone.utc).isoformat(),
        "selection":"all 16 existing GPU cache files used by small_dataset_comparison, excluding timing.csv; no score/threshold recomputation or run selection",
        "gate_decisions_sha256":sha256(decision_path),"sources":sources,
        "output":{"path":str(output_path),"sha256":sha256(output_path),"rows":len(combined_rows)},
        "no_gold_fields_read":True,"no_api_cost_or_speed_claim":True,
    }
    (OUT / "other_predictions_freeze_manifest.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"frozen_runs":len(sources),"combined_rows":len(combined_rows),"changes":sum(row["changed_accept_to_reject_rows"] for row in sources)},indent=2))


if __name__ == "__main__":
    main()
