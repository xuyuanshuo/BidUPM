"""Apply unchanged frozen v2 to authorized blind inputs before gold-label access."""
from __future__ import annotations

import hashlib
import csv
import json
import sys
from collections import Counter
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
GATE_ROOT = OUT.parent
ROOT = GATE_ROOT.parent
BLIND_PATH = ROOT / "challenge600_blind_gpt6/blind_inputs.json"
PREDICTION_PATH = ROOT / "challenge600_blind_gpt6/predictions.jsonl"
RAW_UNIT_PATH = ROOT / "generic_unit_gate/raw_units_metadata.csv"
EXPECTED_ORIGINAL_PREDICTION_SHA256 = "8ed2b91f66c6792f6296ae0d0c9de79c577538183c9b124be3aa8677ca8f66cb"
EXPECTED_RAW_UNIT_SHA256 = "6ecc306c36e6508cfdcc1ddf68285f99feeedf73bdaf3c19b91aebe3cc0b7e09"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    config = json.loads((GATE_ROOT / "enabled_rules.json").read_text())
    if config["module"] != "engineering_gate_v2" or config["enabled_rules"] != ["physical_size"]:
        raise RuntimeError("Frozen production configuration differs")
    # Hash-only check; do not inspect, rewrite, or tune gate source logic.
    for name, expected in config["source_sha256"].items():
        if sha256(GATE_ROOT / name) != expected:
            raise RuntimeError(f"Frozen source fingerprint changed: {name}")
    if sha256(PREDICTION_PATH) != EXPECTED_ORIGINAL_PREDICTION_SHA256:
        raise RuntimeError("Original GPT predictions changed")
    if sha256(RAW_UNIT_PATH) != EXPECTED_RAW_UNIT_SHA256:
        raise RuntimeError("Authorized raw-unit metadata changed")
    sys.path.insert(0, str(GATE_ROOT))
    from engineering_gate_v2 import contradiction_gate

    blind = json.loads(BLIND_PATH.read_text())
    predictions = [json.loads(line) for line in PREDICTION_PATH.read_text().splitlines()]
    pred_by_id = {row["pair_id"]: row["prediction"] for row in predictions}
    ids = [row["pair_id"] for row in blind]
    if len(blind) != 600 or len(predictions) != 600 or len(set(ids)) != 600 or len(pred_by_id) != 600 or set(ids) != set(pred_by_id):
        raise RuntimeError("Blind input/prediction rows are not exactly aligned unique 600 pairs")
    if any(value not in (0, 1) for value in pred_by_id.values()):
        raise RuntimeError("Frozen GPT prediction is nonbinary")
    raw_units = {}
    with RAW_UNIT_PATH.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.reader(stream)
        header = next(reader)
        indices = {name:header.index(name) for name in ("dataset", "pair_id", "query_unit", "candidate_unit")}
        for cells in reader:
            if cells[indices["dataset"]] != "challenge600":
                continue
            pair_id = cells[indices["pair_id"]]
            if pair_id in raw_units:
                raise RuntimeError("Duplicate challenge600 raw-unit metadata pair_id")
            raw_units[pair_id] = (cells[indices["query_unit"]], cells[indices["candidate_unit"]])
    if set(raw_units) != set(ids):
        raise RuntimeError("Authorized raw-unit metadata is not exactly aligned to the blind 600")
    results, reasons, decisions = [], Counter(), Counter()
    for row in blind:
        # Parent-authorized label-free metadata supplies the original raw units.
        # Keep the gate input convention identical to the frozen train/val trial.
        query_unit, candidate_unit = raw_units[row["pair_id"]]
        a, b = dict(row["query"], unit=query_unit), dict(row["candidate"], unit=candidate_unit)
        result = contradiction_gate(a, b, enabled_rules=("physical_size",))
        # Capture the candidate defer reason; the combined helper intentionally
        # has a generic fallback reason. No candidate/source logic is inspected.
        from engineering_gate_v2 import candidate_gate
        detail = candidate_gate(a, b, "physical_size")
        if result.decision != detail.decision:
            raise AssertionError("Single-enabled-rule combined/candidate mismatch")
        prediction = pred_by_id[row["pair_id"]]
        gated_prediction = 0 if result.decision == "reject" else prediction
        decisions[result.decision] += 1
        reasons[detail.reason] += 1
        results.append({
            "pair_id": row["pair_id"], "query": row["query"], "candidate": row["candidate"],
            "query_unit": query_unit, "candidate_unit": candidate_unit,
            "original_prediction": prediction, "gated_prediction": gated_prediction,
            "changed_accept_to_reject": prediction == 1 and gated_prediction == 0,
            "gate": asdict(detail),
        })
    result_path = OUT / "blind_gate_decisions_before_gold.jsonl"
    result_path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in results))
    manifest = {
        "phase": "gate_outputs_frozen_before_construction_reference_gold_access",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "rows": 600, "gate_module": "engineering_gate_v2", "enabled_rules": ["physical_size"],
        "input_schema_adapter": "query/candidate raw unit joined by pair_id from authorized label-free metadata filtered dataset=challenge600",
        "raw_unit_absent_in_blind_records": 600,
        "strict_unadapted_gate_expected_defer_rows": 600,
        "raw_unit_convention_matches_frozen_train_validation": True,
        "comparison_type": "fixed_cached_GPT6Sol_predictions_plus_frozen_input_gate",
        "no_api_cost_or_speed_claim": True,
        "blind_inputs": {"path": str(BLIND_PATH), "sha256": sha256(BLIND_PATH)},
        "raw_unit_metadata": {"path":str(RAW_UNIT_PATH), "sha256":sha256(RAW_UNIT_PATH), "dataset_filter":"challenge600", "joined_rows":len(raw_units), "columns":["dataset","pair_id","query_unit","candidate_unit"]},
        "original_predictions": {"path": str(PREDICTION_PATH), "sha256_before": EXPECTED_ORIGINAL_PREDICTION_SHA256, "sha256_after_gate": sha256(PREDICTION_PATH)},
        "gate_sources": config["source_sha256"],
        "output": {"path": str(result_path), "sha256": sha256(result_path)},
        "gate_decisions": dict(decisions), "gate_reason_counts": dict(reasons),
        "changed_accept_to_reject_rows": sum(row["changed_accept_to_reject"] for row in results),
        "unknown_or_missing_context_defer_rows": reasons["missing_or_explicitly_unknown_context"],
        "unknown_or_missing_explicit_evidence_defer_rows": reasons["missing_or_ambiguous_explicit_evidence"],
        "no_gold_fields_read_by_this_stage": True,
    }
    (OUT / "blind_gate_freeze_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({key:manifest[key] for key in ("rows","gate_decisions","gate_reason_counts","changed_accept_to_reject_rows","unknown_or_missing_context_defer_rows","unknown_or_missing_explicit_evidence_defer_rows")},ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
