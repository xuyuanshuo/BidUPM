import json,hashlib,math
from pathlib import Path
import pandas as pd
import numpy as np
p=Path(__file__).resolve().parent
checks=[]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def check(name,ok):
    checks.append({'check':name,'passed':bool(ok)})
    assert ok,name
s=json.loads((p/'summary.json').read_text());a=json.loads((p/'blind_gate_freeze_manifest.json').read_text());b=json.loads((p/'other_predictions_freeze_manifest.json').read_text())
check('construction_reference_source_hash',sha(s['reference']['path'])==s['reference']['sha256'])
gold=pd.read_csv(s['reference']['path'],usecols=['pair_id','provisional_label'],dtype={'pair_id':str}).set_index('pair_id').provisional_label
check('600_unique_300_positive_reference',len(gold)==600 and gold.index.nunique()==600 and gold.sum()==300)
check('reference_not_human_gold_disclosed',s['label_source']=='construction_intent_provisional_label_not_human_gold')
check('gpt_before_after_source_hash',sha(a['original_predictions']['path'])==a['original_predictions']['sha256_before']==a['original_predictions']['sha256_after_gate'])
check('gate_before_gold_output_hash',sha(a['output']['path'])==a['output']['sha256'])
check('other_before_gold_output_hash',sha(b['output']['path'])==b['output']['sha256'])
check('input_metadata_hash',sha(a['raw_unit_metadata']['path'])==a['raw_unit_metadata']['sha256'])
for source in b['sources']:check(source['run']+'_original_cache_hash',sha(source['path'])==source['sha256'])
for n,h in a['gate_sources'].items():check(n+'_source_hash',sha(p.parent/n)==h)
check('freeze_chronology_logged',a['created_utc']<b['created_utc']<s['evaluated_utc'])
metric=pd.read_csv(p/'metrics_each_run.csv',keep_default_na=False).set_index(['run','variant'])
gpt=pd.read_csv(p/'gpt6sol_pair_results.csv',usecols=['pair_id','construction_reference_label','original_prediction','gated_prediction','gate_decision'])
gpt['run']='GPT6Sol_cached'
other=pd.read_csv(p/'other16_pair_results.csv',usecols=['run','pair_id','construction_reference_label','original_prediction','gated_prediction','gate_decision'])
frame=pd.concat([gpt,other],ignore_index=True)
check('17runs_10200rows',len(frame)==10200 and frame.run.nunique()==17)
check('physical_size_defer_all',frame.gate_decision.eq('defer').all())
check('predictions_all_unchanged',frame.original_prediction.eq(frame.gated_prediction).all())
rows=[]
for run,f in frame.groupby('run',sort=False):
    check(run+'_600_unique_ids',len(f)==600 and f.pair_id.nunique()==600 and set(f.pair_id)==set(gold.index))
    check(run+'_original_reference_alignment',np.array_equal(f.construction_reference_label.to_numpy(),gold.loc[f.pair_id].to_numpy()))
    y=f.construction_reference_label.to_numpy(int)
    for variant,col in [('original','original_prediction'),('plus_frozen_physical_size_gate','gated_prediction')]:
        pr=f[col].to_numpy(int);check(run+'_'+variant+'_binary',set(pr)<={0,1})
        tp=int(((y==1)&(pr==1)).sum());fp=int(((y==0)&(pr==1)).sum());fn=int(((y==1)&(pr==0)).sum());tn=int(((y==0)&(pr==0)).sum())
        values={'rows':len(f),'reference_positive_n':tp+fn,'reference_negative_n':tn+fp,'tp':tp,'fp':fp,'fn':fn,'tn':tn,'precision':tp/(tp+fp) if tp+fp else None,'recall':tp/(tp+fn),'f1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,'accuracy':(tp+tn)/len(f)}
        recorded=metric.loc[(run,variant)]
        check(run+'_'+variant+'_all_metrics_recomputed',all((recorded[k]=='' if v is None else math.isclose(float(recorded[k]),v,rel_tol=1e-12,abs_tol=1e-12)) for k,v in values.items()))
        rows.append({'run':run,'variant':variant,**values})
check('34_complete_metrics',len(rows)==len(metric)==34)
report={'all_passed':all(x['passed'] for x in checks),'checks':checks,'recomputed_gpt_original':rows[0],'correct_acceptances_falsely_deleted':0,'false_acceptances_corrected':0,'changes_in_17_methods':0,'no_gpu_model_or_api_execution':True,'limitation':'All600 labels are construction-intent provisional reference labels, not two-human-annotator gold. This is CPU combination of existing predictions with a frozen gate; no real timing/cost inference or independent final human-gold efficacy claim. Freeze hashes/chronology/code order support workflow, but chronology is not independently witnessed immutable timestamping.'}
(p/'independent_recomputed_qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':report['all_passed'],'checks':len(checks),'gpt':rows[0],'all_17_changes':0},ensure_ascii=False,indent=2))
