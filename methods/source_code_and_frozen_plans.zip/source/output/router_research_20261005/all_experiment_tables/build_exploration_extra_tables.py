from pathlib import Path
import hashlib
import json
import re
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
paths = {
    "cheap": ROOT / "independent_design/training_validation_only_metrics.csv",
    "noid": ROOT / "independent_design/no_identifier_probe/metrics.csv",
    "alias": ROOT / "training_abbreviation_rules/train_validation_metrics.csv",
    "oldgate": ROOT / "engineering_constraint_gate/unseen_cpu_eval/metrics_each_run.csv",
    "abtime": ROOT / "qwen_last_token_ab_results/analysis/same_session_ab_timing.csv",
    "abquality": ROOT / "qwen_last_token_ab_results/analysis/candidate_logit_decision_rank_comparison.csv",
    "q4time": ROOT / "independent_design/qwen4_alberta_actual_analysis/actual_timing_and_gpu_cost_each_seed.csv",
    "memo": ROOT / "independent_design/engineering_parser_memoization_cpu_full_evidence/cold_cpu_timing_summary.csv",
}
data = {key: pd.read_csv(path) for key, path in paths.items()}
frames = pd.concat([data["cheap"], data["noid"]], ignore_index=True)
assert len(frames) == 270
assert frames.model.nunique() == 45
assert frames.groupby(["model", "split"]).size().eq(3).all()
assert len(frames[frames.split.eq("validation")]) == 135
assert frames.loc[frames.split.eq("validation"), "residual_tp"].add(frames.loc[frames.split.eq("validation"), "residual_fn"]).eq(21).all()

def fmt(value, places=2, pct=False):
    if pd.isna(value):
        return "未测"
    return f"{float(value) * (100 if pct else 1):.{places}f}"

def rates(row, prefix=""):
    return "/".join(fmt(row[prefix + field], pct=True) for field in ("precision", "recall", "f1"))

def mean_sd(values, pct=False):
    values = pd.Series(values).dropna().astype(float)
    if values.empty:
        return "未测"
    if len(values) == 1:
        return fmt(values.iloc[0], pct=pct)
    return f"{fmt(values.mean(), pct=pct)} ± {fmt(values.std(ddof=1), pct=pct)}"

def table(headers, rows):
    return "\n".join(["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"] + ["| " + " | ".join(str(v) for v in row) + " |" for row in rows])

objectives = ["overall_f1", "residual_f1", "residual_recall90"]
objective_labels = {"overall_f1": "整体F1", "residual_f1": "残余F1", "residual_recall90": "训练残余R≥90%"}
families = [
    ("engineering_numeric", "工程数值特征，9种配置"),
    ("char_word_cosine", "字符与词语相似度特征，9种配置"),
    ("symmetric_sparse", "对称稀疏交互特征，9种配置"),
    ("engineering_no_identifiers", "去标识符工程特征，9种配置"),
    ("char_word_no_identifiers", "去标识符字符与词语特征，9种配置"),
]

def family_subset(family, split):
    df = frames[frames.model.str.startswith(family + "_C") & frames.split.eq(split)].copy()
    df["C"] = df.model.str.extract(r"_C([0-9.]+)_")[0].astype(float)
    df["PW"] = df.model.str.extract(r"_PW([0-9.]+)$")[0].astype(float)
    df["obj_order"] = df.threshold_objective.map({v: i for i, v in enumerate(objectives)})
    return df.sort_values(["C", "PW", "obj_order"])

chunks = [
    "# 补充探索实验完整数值",
    "所有P、R、F1和准确率均以百分数表示。P是精确率，R是召回率；数值顺序为P/R/F1。三seed的汇总采用各seed指标的均值与样本标准差，单次模型不虚构标准差。",
    "## 1. 45种廉价分类器的验证结果",
    "共有27种原特征配置与18种去标识符配置，每种均测三种训练阈值目标。阈值从训练查询分组的5折OOF预测确定，验证集只用于检查泛化；本表列出135个验证条件，未把它们称为135个独立模型。整体预测为精确规则接受结果与分类器接受结果的并集。残余指输入精确规则未接受的配对，验证残余有21个正例；它不等同于论文预先定义的困难子集。",
    "C为逻辑回归正则参数，PW为正例训练权重。原27配置包含条目编码和类别相同特征，后18配置删去这两项；两类探索应保留区别。‘训练残余R≥90%’只是选阈值时的训练目标，不代表验证召回已达到90%。无接受项时，源程序将P定义为0，本表保留该约定。",
]
for family, title in families:
    rows = []
    for _, row in family_subset(family, "validation").iterrows():
        rows.append([f"C{row.C:g} / PW{row.PW:g}", objective_labels[row.threshold_objective], fmt(row.threshold, 6), *(fmt(row[field], pct=True) for field in ["precision", "recall", "f1", "residual_precision", "residual_recall", "residual_f1"])])
    chunks += [f"### {title}", table(["配置", "阈值目标", "阈值", "P", "R", "F1", "残余P", "残余R", "残余F1"], rows)]

chunks += ["## 2. 对应训练OOF结果", "以下保留另外135个训练OOF条件，压成45行。每格先列整体P/R/F1，再列残余P/R/F1；这是训练OOF阈值选择结果，不能当作外部测试结果。"]
for family, title in families:
    rows = []
    df = family_subset(family, "train_oof")
    for (_, _), sub in df.groupby(["C", "PW"], sort=True):
        first = sub.iloc[0]
        row = [f"C{first.C:g} / PW{first.PW:g}"]
        for objective in objectives:
            obj = sub.loc[sub.threshold_objective.eq(objective)].iloc[0]
            row.append(f"{rates(obj)}；{rates(obj, 'residual_')}")
        rows.append(row)
    chunks += [f"### {title}", table(["配置", "整体F1目标：整体；残余", "残余F1目标：整体；残余", "训练残余R≥90%目标：整体；残余"], rows)]

chunks += ["## 3. 从训练资料得到的缩写别名规则", "别名仅从训练资料提取。验证三个支持度配置均没有补回21个非精确正例；这项探索没有获得验证收益。"]
rows = []
for _, row in data["alias"].iterrows():
    rows.append([int(row.minimum_support), "训练" if row.dataset == "train" else "验证", int(row.aliases), int(row.tp), int(row.fp), int(row.fn), *(fmt(row[field], pct=True) for field in ["precision", "recall", "f1"])])
chunks.append(table(["最小支持度", "数据", "别名数", "TP", "FP", "FN", "P", "R", "F1"], rows))

chunks += ["## 4. 旧物理尺寸工程约束的600对检查", "标签按原构造意图计算，尚未双人人工确认。34个逐运行条件由17个原预测与17个固定物理尺寸后过滤结果组成；所有运行的混淆矩阵和指标都未发生变化。此表合并seed，保留前后相同的结果，并列出条件数；计时未在这项纯输出过滤中测量。"]
gate = data["oldgate"]
assert len(gate) == 34
original = gate[gate.variant.eq("original")].copy()
filtered = gate[gate.variant.eq("plus_frozen_physical_size_gate")].copy()
checked = original.merge(filtered, on="run", suffixes=("_original", "_filtered"), validate="one_to_one")
for field in ["tp", "fp", "fn", "tn", "precision", "recall", "f1", "accuracy"]:
    assert checked[field + "_original"].eq(checked[field + "_filtered"]).all()
labels = {
    "GPT6Sol_cached": "GPT-6 Sol盲判",
    "bge_hard_description_only": "BGE专项微调，仅描述",
    "bge_hard_no_category_specs": "BGE专项微调，去类别与规格",
    "bge_hard_no_unit": "BGE专项微调，去单位",
    "bge_hard": "BGE专项微调，完整输入",
    "bge_zero_shot": "BGE零样本",
    "qwen_4B_standard": "Qwen3-Reranker-4B微调",
}
rows = []
for model, subset in original.groupby("model", sort=False):
    rows.append([labels[model], len(subset), *(mean_sd(subset[field], pct=True) for field in ["precision", "recall", "f1", "accuracy"]), "同左", "0", "未测"])
chunks.append(table(["方法", "seed/运行数", "原P", "原R", "原F1", "原准确率", "过滤后各指标", "预测变化数", "耗时"], rows))

chunks += ["## 5. Qwen最后token实现的同场A/B", "每种实现各计时3次，以下使用中位数。全量实现有3个logit字节不同并导致1个查询的顺序变化，所以不能宣称全量严格等价；两种策略都没有接受决策或返回集合变化。单位门控条件的已评分行严格一致。"]
ab = data["abtime"].merge(data["abquality"], on="policy", validate="one_to_one")
rows = []
for _, row in ab.iterrows():
    rows.append(["全量" if row.policy == "full" else "单位门控", int(row.rows), int(row.scored_rows), int(row.scored_rows - row.score_identical_rows), fmt(row.max_abs_logit_difference, 6), int(row.changed_decisions), int(row.changed_ranks), int(row.changed_returned_memberships), int(row.changed_ordered_queries)])
chunks.append(table(["策略", "候选总数", "实际评分数", "不同比分行", "最大logit差", "接受变化", "候选排名变化", "返回成员变化", "查询排序变化"], rows))
rows = []
for _, row in ab.iterrows():
    rows.append(["全量" if row.policy == "full" else "单位门控", int(row.repeats_each), fmt(row.old_median_seconds, 6), fmt(row.last_token_median_seconds, 6), fmt(row.seconds_reduction, pct=True), fmt(row.speedup, 4), fmt(row.cny_per_1000_queries_old_2_88, 6), fmt(row.cny_per_1000_queries_optimized_2_88, 6)])
chunks.append(table(["策略", "每实现重复数", "原实现秒", "最后token秒", "耗时减少%", "加速倍数", "原元/千查询", "优化元/千查询"], rows))
chunks.append("费用仅按2.88元/小时乘实际驻留计时推算，不是API实扣。两个策略有不同模型调用量，A/B收益只比较同一策略的原实现与最后token实现。")

chunks += ["## 6. Qwen4B在Alberta全候选池的三seed实际时间", "每seed实际处理67,635对，各完成1次全池盲推理；阈值保留各检查点原验证阈值。计时包含输入序列化、分词和GPU评分，不含阈值应用与排名，因此不能把本表当作与系统完整耗时完全相同的口径。模型加载单列。seed05在首256行的logit等价检查不通过后使用原全logit实现；seed04与06通过检查，使用最后token实现。"]
rows = []
for _, row in data["q4time"].iterrows():
    rows.append([int(row.seed), int(row.rows), fmt(row.seconds, 6), fmt(row.model_load_seconds, 6), "最后token" if row.logits_to_keep == 1 else "原全logit", fmt(row.resident_inference_rmb_at_2_88_per_hour, 6), fmt(row.model_load_rmb_at_2_88_per_hour, 6)])
q4 = data["q4time"]
rows.append(["三seed均值±样本SD", "各67,635", mean_sd(q4.seconds), mean_sd(q4.model_load_seconds), "按各自等价检查", mean_sd(q4.resident_inference_rmb_at_2_88_per_hour), mean_sd(q4.model_load_rmb_at_2_88_per_hour)])
chunks.append(table(["seed", "对数", "推理秒", "加载秒", "实际实现", "推理元（2.88/小时）", "加载元（2.88/小时）"], rows))
chunks.append(f"三seed驻留推理累计{fmt(q4.seconds.sum(), 6)}秒，按2.88元/小时约{fmt(q4.resident_inference_rmb_at_2_88_per_hour.sum(), 6)}元；API费用和API延迟未测。")

chunks += ["## 7. 纯CPU工程解析冷缓存诊断", "每个数据集、每个实现各测3次，每次清空缓存。以下6行只测工程解析循环和条目字典创建，不包括输入加载、模块初始化、GPU推理、阈值与排名。缓存只复用同输入的精确中间结果，所有门控理由、证据及决定均逐行一致；这个CPU节省比例不等于整个系统节省比例。"]
dataset_labels = {"main220": "主数据220查询/6,600对", "challenge600": "构造600对", "alberta_scope_core": "Alberta 67,635对"}
rows = []
for dataset in ["main220", "challenge600", "alberta_scope_core"]:
    subset = data["memo"][data["memo"].dataset.eq(dataset)]
    old = subset[~subset.memoized].iloc[0]
    for _, row in subset.sort_values("memoized").iterrows():
        rows.append([dataset_labels[dataset], "精确缓存" if row.memoized else "原解析", 3, fmt(row["median"], 6), fmt(row["mean"], 6), fmt(row["std"], 6), fmt(1 - row["median"] / old["median"], pct=True), fmt(old["median"] / row["median"], 4)])
chunks.append(table(["数据", "实现", "冷运行次数", "中位数秒", "均值秒", "样本SD秒", "中位耗时减少%", "中位加速倍数"], rows))

output = OUT / "exploration_extra_tables.md"
output.write_text("\n\n".join(chunks) + "\n", encoding="utf-8")

# Independently reconcile rates from raw confusion counts in every source that has counts.
quality_checks = []
for key in ["cheap", "noid", "alias", "oldgate"]:
    df = data[key]
    for prefix in (["", "residual_"] if key in ["cheap", "noid"] else [""]):
        tp, fp, fn = (df[prefix + field].to_numpy(float) for field in ["tp", "fp", "fn"])
        calculations = {
            "precision": np.divide(tp, tp + fp, out=np.zeros_like(tp), where=tp + fp != 0),
            "recall": np.divide(tp, tp + fn, out=np.zeros_like(tp), where=tp + fn != 0),
            "f1": np.divide(2 * tp, 2 * tp + fp + fn, out=np.zeros_like(tp), where=2 * tp + fp + fn != 0),
        }
        for field, actual in calculations.items():
            discrepancy = float(np.max(np.abs(actual - df[prefix + field].to_numpy(float))))
            assert discrepancy < 1e-12, (key, prefix, field, discrepancy)
            quality_checks.append({"source": key, "metric": prefix + field, "rows": len(df), "max_abs_error": discrepancy})
qa = {
    "read_only_source_analysis": True,
    "source_rows": {key: len(frame) for key, frame in data.items()},
    "classifier_models": 45,
    "validation_conditions_fully_present": 135,
    "training_oof_conditions_fully_present": 135,
    "validation_nonexact_positive_denominator": 21,
    "old_gate_seed_runs": len(original),
    "old_gate_confusion_or_rate_changes": 0,
    "source_sha256": {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths.values()},
    "metric_recalculations": quality_checks,
    "output_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
}
(OUT / "exploration_extra_tables_read_only_qa.json").write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"output": str(output), "lines": len(output.read_text().splitlines()), "bytes": output.stat().st_size, "qa": "PASS", "models": 45, "validation_conditions": 135, "training_oof_conditions": 135, "oldgate_changes": 0}, ensure_ascii=False))
