#!/usr/bin/env python3
"""CPU-only checks of the ablation logic against the untouched original runner."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import pandas as pd
import torch

import run_cross_encoder_local as revised


def main():
    root = Path(__file__).resolve().parents[3]
    original_path = root / "output/revise3_full_20260920/supplementary/scripts/original/run_cross_encoder_local.py"
    spec = importlib.util.spec_from_file_location("original_runner", original_path)
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    checks = []
    # Existing argument defaults, including the regime default, must remain equal.
    with patch.object(sys, "argv", ["runner", "--data-dir", "data", "--output-dir", "out", "--model", "base", "--label", "test"]):
        old_args = vars(original.parse_args())
        new_args = vars(revised.parse_args())
    assert all(new_args[k] == v for k, v in old_args.items())
    assert new_args["audit_checkpoint_rules"] is False
    checks.append("all original CLI defaults preserved; audit opt-in")

    labels = torch.tensor([1., 1., 0., 0.])
    hard = torch.tensor([1., 0., 1., 0.])
    for regime in ["hard_refined", "hard_weight_only"]:
        assert torch.equal(revised.sample_weights(labels, hard, regime), torch.tensor([3., 1., 1., 1.]))
    for regime in ["standard", "hard_selection_only"]:
        assert torch.equal(revised.sample_weights(labels, hard, regime), torch.ones(4))
    checks.append("only hard positives get 3x weight; hard negatives/easy pairs remain 1x")

    validation = pd.DataFrame({"final_label": [1, 1, 1, 1, 0, 0, 0, 0],
                               "difficulty": ["hard", "easy", "easy", "easy", "hard", "easy", "easy", "easy"]})
    epoch_a = np.array([.1, .9, .8, .7, .6, .5, .4, .3])
    epoch_b = np.array([.9, .8, .7, .1, .85, .6, .5, .4])
    for regime in ["standard", "hard_refined"]:
        for scores in [epoch_a, epoch_b]:
            old = original.validation_objective(validation, scores, regime)
            new = revised.validation_objective(validation, scores, regime)
            assert old == new
    checks.append("original validation objectives and threshold tie-breaking unchanged")

    for scores in [epoch_a, epoch_b]:
        standard = revised.validation_objective(validation, scores, "standard")
        hard = revised.validation_objective(validation, scores, "hard_refined")
        assert revised.validation_objective(validation, scores, "hard_weight_only") == standard
        assert revised.validation_objective(validation, scores, "hard_selection_only") == hard
        # Changing the checkpoint rule never changes threshold selection.
        assert standard[1:] == hard[1:]
    checks.append("factorial regimes vary only the intended weighting or checkpoint-selection factor")

    selected_epochs = {}
    for regime in ["standard", "hard_refined", "hard_weight_only", "hard_selection_only"]:
        objectives = [revised.validation_objective(validation, s, regime)[0] for s in [epoch_a, epoch_b]]
        selected_epochs[regime] = max(range(2), key=lambda i: (objectives[i], -i)) + 1
    assert selected_epochs == {"standard": 1, "hard_refined": 2, "hard_weight_only": 1, "hard_selection_only": 2}
    checks.append("constructed competing epochs select overall-best epoch 1 and mixed-best epoch 2")
    assert revised.alternate_regime(revised.alternate_regime("hard_refined")) == "hard_refined"
    assert max([1, 2], key=lambda e: (0.8, -e)) == 1
    checks.append("alternate mapping is reversible; equal objective keeps earlier epoch")

    # Exercise the training loop on CPU, using a tiny model and competing
    # validation epochs. This checks that saving the audit checkpoint does not
    # alter optimization, and that each saved checkpoint actually corresponds
    # to its selected epoch.
    class TinyTokenizer:
        def __call__(self, queries, candidates, **kwargs):
            return {"input_ids": torch.tensor([[len(q) / 100., len(c) / 100.] for q, c in zip(queries, candidates)])}

        def save_pretrained(self, destination):
            Path(destination).mkdir(parents=True, exist_ok=True)
            (Path(destination) / "tokenizer.json").write_text("{}")

    class TinyModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.layer = torch.nn.Linear(2, 1)

        def forward(self, input_ids):
            return SimpleNamespace(logits=self.layer(input_ids))

        def save_pretrained(self, destination):
            Path(destination).mkdir(parents=True, exist_ok=True)
            torch.save(self.state_dict(), Path(destination) / "tiny_weights.pt")

    train = pd.DataFrame({"final_label": [1, 1, 0, 0], "difficulty": ["hard", "easy", "hard", "easy"]})
    for side in ["query", "candidate"]:
        for suffix in ["description", "normalized_description", "normalized_unit", "category", "spec_tokens"]:
            train[f"{side}_{suffix}"] = ["pavement", "concrete", "steel", "asphalt"]
    with tempfile.TemporaryDirectory(prefix="bidupm_runner_logic_") as temp:
        captures = {}
        for name, module, audit_on in [("original", original, False), ("revised", revised, True)]:
            args = SimpleNamespace(**new_args)
            args.output_dir = Path(temp) / name
            args.output_dir.mkdir()
            args.epochs = 2
            args.train_batch_size = 2
            args.audit_checkpoint_rules = audit_on
            with patch.object(module.AutoTokenizer, "from_pretrained", side_effect=lambda *a, **kw: TinyTokenizer()), \
                 patch.object(module.AutoModelForSequenceClassification, "from_pretrained", side_effect=lambda *a, **kw: TinyModel()), \
                 patch.object(module, "predict", side_effect=[(epoch_a.copy(), 0.0), (epoch_b.copy(), 0.0)]):
                checkpoint, history, summary = module.train_regime(args, "hard_refined", train, validation, torch.device("cpu"), None)
            captures[name] = (checkpoint, history, summary)
        old_path, old_history, old_summary = captures["original"]
        new_path, new_history, new_summary = captures["revised"]
        assert [row["train_loss"] for row in old_history] == [row["train_loss"] for row in new_history]
        assert old_summary["selected_epoch"] == new_summary["selected_epoch"] == 2
        for key, value in torch.load(old_path / "tiny_weights.pt", weights_only=True).items():
            assert torch.equal(value, torch.load(new_path / "tiny_weights.pt", weights_only=True)[key])
        audit = new_summary["checkpoint_rule_audit"]
        assert audit["selected_epoch"] == 1 and not audit["same_epoch_as_primary"]
        audit_weights = torch.load(Path(audit["checkpoint"]) / "tiny_weights.pt", weights_only=True)
        final_weights = torch.load(new_path / "tiny_weights.pt", weights_only=True)
        assert any(not torch.equal(audit_weights[k], final_weights[k]) for k in audit_weights)
    checks.append("CPU tiny-model audit preserves original training losses/weights and retains distinct selected epoch weights")
    report = {"status": "passed", "checks": checks, "fixture_selected_epochs": selected_epochs}
    report_path = Path(__file__).with_name("factorial_logic_check.json")
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
