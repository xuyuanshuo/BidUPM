"""Archive only complete run evidence; leave model checkpoints on the server."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    inventory = []
    with tarfile.open(args.out, 'w:gz') as archive:
        for run in sorted((args.root / 'runs').iterdir()):
            manifest = run / 'manifest.json'
            if not manifest.exists():
                continue
            state = json.loads(manifest.read_text())
            if state.get('status') != 'complete' or state.get('paper_eligible') is not True:
                continue
            files = []
            for path in sorted(run.iterdir()):
                if path.is_file() and path.name != 'download_source.json':
                    archive.add(path, arcname=str(Path('runs') / run.name / path.name))
                    files.append({'name': path.name, 'size': path.stat().st_size, 'sha256': sha(path)})
            inventory.append({'run': run.name, 'files': files})
        data = json.dumps({'runs': inventory}, indent=2).encode()
        import io
        info = tarfile.TarInfo('inventory.json')
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
    print(json.dumps({'archive': str(args.out), 'complete_runs': len(inventory),
                      'size': args.out.stat().st_size}, indent=2))


if __name__ == '__main__':
    main()
