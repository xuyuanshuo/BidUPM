#!/usr/bin/env python3
"""Dependency-free AST/CLI checks; no model downloads, PEFT install, or GPU needed."""
import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch


def main():
    here = Path(__file__).resolve().parent
    root = here.parents[2]
    original_path = root / "output/revise3_full_20260920/supplementary/scripts/original/run_qwen_reranker.py"
    revised_path = here / "run_qwen_reranker.py"
    original_tree = ast.parse(original_path.read_text())
    revised_tree = ast.parse(revised_path.read_text())
    original_defs = {node.name: node for node in original_tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    revised_defs = {node.name: node for node in revised_tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    checks = []

    def cli(tree):
        selected = [node for node in tree.body if (isinstance(node, ast.FunctionDef) and node.name == "parse_args") or
                    (isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "DEFAULT_INSTRUCTION" for t in node.targets))]
        scope = {"argparse": argparse, "Path": Path, "SEED": 20260904}
        exec(compile(ast.Module(body=selected, type_ignores=[]), "cli", "exec"), scope)
        with patch.object(sys, "argv", ["runner", "--data-dir", "data", "--output-dir", "out", "--label", "qwen"]):
            defaults = vars(scope["parse_args"]())
        return scope, defaults

    _, old_defaults = cli(original_tree)
    new_scope, new_defaults = cli(revised_tree)
    assert all(new_defaults[k] == v for k, v in old_defaults.items())
    assert set(new_defaults) - set(old_defaults) == {"model_revision", "base_model_id"}
    with patch.object(sys, "argv", ["runner", "--data-dir", "data", "--output-dir", "out", "--label", "qwen",
                                  "--model", "/local/qwen", "--base-model-id", "Qwen/Qwen3-Reranker-4B", "--model-revision", "fixed-sha"]):
        args = new_scope["parse_args"]()
        assert (args.model, args.base_model_id, args.model_revision) == ("/local/qwen", "Qwen/Qwen3-Reranker-4B", "fixed-sha")
    checks.append("all original argument defaults unchanged; new local-model metadata arguments parse correctly")

    exact = ["set_seed", "swapped_training_pairs", "PairDataset", "QwenPairCollator", "label_token_ids", "pair_logits", "predict", "validation_objective"]
    for name in exact:
        assert ast.dump(original_defs[name]) == ast.dump(revised_defs[name]), name
    checks.append("dataset, prompt collator, scoring, prediction and validation objective ASTs are unchanged")

    class RemoveInstrumentation(ast.NodeTransformer):
        def visit_Expr(self, node):
            if isinstance(node.value, ast.Call):
                f = node.value.func
                if (isinstance(f, ast.Name) and f.id == "log_stage") or (isinstance(f, ast.Attribute) and f.attr == "to_csv"):
                    return None
            return self.generic_visit(node)

        def visit_If(self, node):
            if "isfinite" in ast.dump(node.test):
                return None
            return self.generic_visit(node)

        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id == "load_base_model" and len(node.args) == 3:
                node.args = node.args[:2]
            return self.generic_visit(node)

    for name in ["train_regime", "make_lora_model", "load_adapter"]:
        cleaned = RemoveInstrumentation().visit(copy.deepcopy(revised_defs[name]))
        assert ast.dump(original_defs[name]) == ast.dump(cleaned), name
    checks.append("training loss, optimizer, scheduler, accumulation, LoRA and checkpoint selection unchanged after removing logs/finite check")

    support_scope = {"Path": Path}
    exec(compile(ast.Module(body=[revised_defs["base_model_kwargs"]], type_ignores=[]), "support", "exec"), support_scope)
    kwargs = support_scope["base_model_kwargs"]
    with tempfile.TemporaryDirectory() as model_dir:
        assert kwargs(model_dir, "sha") == {"local_files_only": True}
    assert kwargs("Qwen/Qwen3-Reranker-4B", "sha") == {"revision": "sha"}
    assert kwargs("Qwen/Qwen3-Reranker-4B") == {}
    checks.append("local directory forces local_files_only; repository load uses explicit revision")
    assert "model_info" not in revised_path.read_text()
    checks.append("no model_info import or network revision lookup remains")

    report = {"status": "passed", "checks": checks,
              "original_sha256": hashlib.sha256(original_path.read_bytes()).hexdigest(),
              "modified_sha256": hashlib.sha256(revised_path.read_bytes()).hexdigest()}
    (here / "qwen_local_support_check.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
