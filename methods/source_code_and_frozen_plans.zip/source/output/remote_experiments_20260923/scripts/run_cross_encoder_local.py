#!/usr/bin/env python3
"""Run zero-shot and locally fine-tuned open cross-encoder experiments."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
import random
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    get_linear_schedule_with_warmup,
)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import (  # noqa: E402
    SEED,
    conflict_gate,
    evaluate_scores,
    f1_counts,
    item_text,
    load_data,
    select_threshold,
    write_json,
)


class PairDataset(Dataset):
    def __init__(self, frame: pd.DataFrame, variant: str = "full") -> None:
        self.queries = item_text(frame, "query", variant)
        self.candidates = item_text(frame, "candidate", variant)
        self.labels = frame["final_label"].to_numpy(dtype=np.float32)
        self.hard = frame["difficulty"].eq("hard").to_numpy(dtype=np.float32)

    def __len__(self) -> int:
        return len(self.labels)

    def __getitem__(self, index: int) -> tuple[str, str, float, float]:
        return (
            self.queries[index],
            self.candidates[index],
            float(self.labels[index]),
            float(self.hard[index]),
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--model", required=True)
    parser.add_argument("--model-revision", default=None,
                        help="Pinned base-model revision; recorded without a network lookup")
    parser.add_argument("--base-model-id", default=None,
                        help="Original model repository ID when --model is a local directory")
    parser.add_argument("--label", required=True)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--train-batch-size", type=int, default=16)
    parser.add_argument("--max-length", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=2e-5)
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument(
        "--input-variant",
        choices=["full", "description_only", "no_unit", "no_category_specs"],
        default="full",
    )
    parser.add_argument(
        "--regimes",
        nargs="+",
        choices=["standard", "hard_refined", "hard_weight_only", "hard_selection_only"],
        default=["standard"],
    )
    parser.add_argument("--skip-zero-shot", action="store_true")
    parser.add_argument("--audit-checkpoint-rules", action="store_true",
                        help="Evaluate both validation checkpoint rules from each training run")
    parser.add_argument("--symmetric-train", action="store_true")
    parser.add_argument(
        "--device",
        choices=["auto", "cuda", "mps", "cpu"],
        default="auto",
    )
    parser.add_argument(
        "--amp-dtype",
        choices=["auto", "bf16", "fp16", "fp32"],
        default="auto",
    )
    return parser.parse_args()


def log_stage(message: str) -> None:
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}", flush=True)


def base_model_kwargs(args: argparse.Namespace) -> dict[str, object]:
    if Path(args.model).is_dir():
        return {"local_files_only": True}
    return {"revision": args.model_revision} if args.model_revision else {}


def sample_weights(labels: torch.Tensor, hard: torch.Tensor, regime: str) -> torch.Tensor:
    if regime in {"hard_refined", "hard_weight_only"}:
        return 1.0 + 2.0 * hard * labels
    return torch.ones_like(labels)


def alternate_regime(regime: str) -> str:
    return {"standard": "hard_selection_only", "hard_selection_only": "standard",
            "hard_refined": "hard_weight_only", "hard_weight_only": "hard_refined"}[regime]


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_device(name: str) -> torch.device:
    if name == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        if torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    device = torch.device(name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    if device.type == "mps" and not torch.backends.mps.is_available():
        raise RuntimeError("MPS was requested but is unavailable")
    return device


def resolve_amp_dtype(device: torch.device, name: str) -> torch.dtype | None:
    if device.type != "cuda" or name == "fp32":
        return None
    if name in {"auto", "bf16"}:
        if torch.cuda.is_bf16_supported():
            return torch.bfloat16
        if name == "bf16":
            raise RuntimeError("BF16 was requested but is unsupported")
    return torch.float16


def autocast_context(device: torch.device, amp_dtype: torch.dtype | None):
    return torch.autocast(
        device_type=device.type,
        dtype=amp_dtype if amp_dtype is not None else torch.float32,
        enabled=amp_dtype is not None,
    )


def swapped_training_pairs(frame: pd.DataFrame) -> pd.DataFrame:
    swapped = frame.copy()
    suffixes = [
        "description",
        "normalized_description",
        "normalized_unit",
        "category",
        "spec_tokens",
    ]
    for suffix in suffixes:
        query = f"query_{suffix}"
        candidate = f"candidate_{suffix}"
        swapped[query] = frame[candidate].to_numpy()
        swapped[candidate] = frame[query].to_numpy()
    return pd.concat([frame, swapped], ignore_index=True)


def make_collate(tokenizer, max_length: int):
    def collate(batch: list[tuple[str, str, float, float]]) -> dict[str, torch.Tensor]:
        queries, candidates, labels, hard = zip(*batch)
        encoded = tokenizer(
            list(queries),
            list(candidates),
            padding=True,
            truncation=True,
            max_length=max_length,
            return_tensors="pt",
        )
        encoded["labels_local"] = torch.tensor(labels, dtype=torch.float32)
        encoded["hard_local"] = torch.tensor(hard, dtype=torch.float32)
        return encoded

    return collate


@torch.inference_mode()
def predict(
    model,
    tokenizer,
    frame: pd.DataFrame,
    device: torch.device,
    batch_size: int,
    max_length: int,
    variant: str = "full",
    amp_dtype: torch.dtype | None = None,
) -> tuple[np.ndarray, float]:
    model.eval()
    dataset = PairDataset(frame, variant)
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=device.type == "cuda",
        collate_fn=make_collate(tokenizer, max_length),
    )
    scores: list[np.ndarray] = []
    started = time.perf_counter()
    for batch in loader:
        batch.pop("labels_local")
        batch.pop("hard_local")
        encoded = {key: value.to(device) for key, value in batch.items()}
        with autocast_context(device, amp_dtype):
            logits = model(**encoded).logits.reshape(-1)
        scores.append(logits.float().cpu().numpy())
    elapsed = time.perf_counter() - started
    return np.concatenate(scores), elapsed


def validation_objective(
    validation: pd.DataFrame,
    scores: np.ndarray,
    regime: str,
) -> tuple[float, float, dict[str, float | int], dict[str, float | int]]:
    threshold, overall = select_threshold(
        validation["final_label"].to_numpy(dtype=int), scores, "f1_opt"
    )
    hard = validation["difficulty"].eq("hard").to_numpy()
    hard_metrics = f1_counts(
        validation.loc[hard, "final_label"].to_numpy(dtype=int), scores[hard], threshold
    )
    if regime in {"hard_refined", "hard_selection_only"}:
        objective = 0.60 * float(overall["pair_f1"]) + 0.40 * float(hard_metrics["pair_f1"])
    else:
        objective = float(overall["pair_f1"])
    return objective, threshold, overall, hard_metrics


def train_regime(
    args: argparse.Namespace,
    regime: str,
    train: pd.DataFrame,
    validation: pd.DataFrame,
    device: torch.device,
    amp_dtype: torch.dtype | None,
) -> tuple[Path, list[dict[str, object]], dict[str, object]]:
    set_seed(args.seed)
    log_stage(f"{regime}: loading base model; seed={args.seed}")
    tokenizer = AutoTokenizer.from_pretrained(args.model, **base_model_kwargs(args))
    model = AutoModelForSequenceClassification.from_pretrained(args.model, **base_model_kwargs(args)).to(device)
    dataset = PairDataset(train, args.input_variant)
    generator = torch.Generator().manual_seed(args.seed)
    loader = DataLoader(
        dataset,
        batch_size=args.train_batch_size,
        shuffle=True,
        generator=generator,
        num_workers=0,
        pin_memory=device.type == "cuda",
        collate_fn=make_collate(tokenizer, args.max_length),
    )
    positives = max(int(train["final_label"].sum()), 1)
    negatives = max(len(train) - positives, 1)
    positive_weight = torch.tensor([negatives / positives], dtype=torch.float32, device=device)
    criterion = nn.BCEWithLogitsLoss(pos_weight=positive_weight, reduction="none")
    optimizer = AdamW(model.parameters(), lr=args.learning_rate, weight_decay=0.01)
    total_steps = len(loader) * args.epochs
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=max(1, round(total_steps * 0.10)),
        num_training_steps=total_steps,
    )
    checkpoint = args.output_dir / f"checkpoint_{regime}"
    if checkpoint.exists():
        shutil.rmtree(checkpoint)
    history: list[dict[str, object]] = []
    best: tuple[float, int] | None = None
    audit_best: tuple[float, int] | None = None
    audit_regime = alternate_regime(regime)
    audit_checkpoint = args.output_dir / f"checkpoint_{regime}_audit_{audit_regime}"
    if args.audit_checkpoint_rules and audit_checkpoint.exists():
        shutil.rmtree(audit_checkpoint)
    train_started = time.perf_counter()
    for epoch in range(1, args.epochs + 1):
        log_stage(f"{regime}: epoch {epoch}/{args.epochs}, training {len(loader)} batches")
        model.train()
        losses: list[float] = []
        epoch_started = time.perf_counter()
        for batch in loader:
            labels = batch.pop("labels_local").to(device)
            hard = batch.pop("hard_local").to(device)
            encoded = {key: value.to(device) for key, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with autocast_context(device, amp_dtype):
                logits = model(**encoded).logits.reshape(-1)
                loss_values = criterion(logits.float(), labels)
            if regime in {"hard_refined", "hard_weight_only"}:
                loss_values = loss_values * sample_weights(labels, hard, regime)
            loss = loss_values.mean()
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Non-finite loss: regime={regime}, epoch={epoch}, batch={len(losses) + 1}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            losses.append(float(loss.detach().cpu()))
        log_stage(f"{regime}: epoch {epoch}, validation")
        validation_scores, validation_seconds = predict(
            model,
            tokenizer,
            validation,
            device,
            args.batch_size,
            args.max_length,
            args.input_variant,
            amp_dtype,
        )
        objective, threshold, overall, hard_metrics = validation_objective(
            validation, validation_scores, regime
        )
        history.append(
            {
                "regime": regime,
                "epoch": epoch,
                "train_loss": float(np.mean(losses)),
                "selection_objective": objective,
                "validation_threshold": threshold,
                "validation_pair_f1": overall["pair_f1"],
                "validation_pair_precision": overall["pair_precision"],
                "validation_pair_recall": overall["pair_recall"],
                "validation_hard_pair_f1": hard_metrics["pair_f1"],
                "epoch_seconds": time.perf_counter() - epoch_started,
                "validation_seconds": validation_seconds,
            }
        )
        key = (objective, -epoch)
        if best is None or key > (best[0], -best[1]):
            best = (objective, epoch)
            model.save_pretrained(checkpoint)
            tokenizer.save_pretrained(checkpoint)
        if args.audit_checkpoint_rules:
            audit_objective = (0.60 * float(overall["pair_f1"]) + 0.40 * float(hard_metrics["pair_f1"])
                               if audit_regime in {"hard_refined", "hard_selection_only"}
                               else float(overall["pair_f1"]))
            history[-1]["audit_regime"] = audit_regime
            history[-1]["audit_selection_objective"] = audit_objective
            if audit_best is None or (audit_objective, -epoch) > (audit_best[0], -audit_best[1]):
                audit_best = (audit_objective, epoch)
                model.save_pretrained(audit_checkpoint)
                tokenizer.save_pretrained(audit_checkpoint)
        pd.DataFrame(history).to_csv(args.output_dir / f"training_history_{regime}.csv", index=False)
        log_stage(f"{regime}: epoch {epoch} complete; loss={history[-1]['train_loss']:.6f}, "
                  f"validation_F1={overall['pair_f1']:.6f}, hard_F1={hard_metrics['pair_f1']:.6f}, selected_epoch={best[1]}")
    assert best is not None
    summary = {
        "regime": regime,
        "selected_epoch": best[1],
        "selected_validation_objective": best[0],
        "training_seconds": time.perf_counter() - train_started,
        "positive_class_weight": float(positive_weight.item()),
        "hard_positive_sample_weight": 3.0 if regime in {"hard_refined", "hard_weight_only"} else 1.0,
    }
    if args.audit_checkpoint_rules:
        assert audit_best is not None
        if audit_best[1] == best[1]:
            # The same epoch has identical weights under both selection rules.
            shutil.rmtree(audit_checkpoint)
            audit_checkpoint = checkpoint
        summary["checkpoint_rule_audit"] = {
            "regime": audit_regime,
            "selected_epoch": audit_best[1],
            "selected_validation_objective": audit_best[0],
            "checkpoint": str(audit_checkpoint),
            "same_epoch_as_primary": audit_best[1] == best[1],
            "training_reused": True,
        }
    del model
    if device.type == "mps":
        torch.mps.empty_cache()
    elif device.type == "cuda":
        torch.cuda.empty_cache()
    return checkpoint, history, summary


def main() -> None:
    args = parse_args()
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    log_stage("Loading and checking canonical data")
    set_seed(args.seed)
    _, train_source, evaluation, hashes = load_data(args.data_dir)
    train = swapped_training_pairs(train_source) if args.symmetric_train else train_source
    validation = evaluation[evaluation["evaluation_split"].eq("validation")].copy()
    device = resolve_device(args.device)
    amp_dtype = resolve_amp_dtype(device, args.amp_dtype)
    score_columns: dict[str, str] = {}
    timing: dict[str, float] = {}
    history_rows: list[dict[str, object]] = []
    training_summaries: list[dict[str, object]] = []
    total_started = time.perf_counter()

    if not args.skip_zero_shot:
        log_stage("Zero-shot evaluation")
        tokenizer = AutoTokenizer.from_pretrained(args.model, **base_model_kwargs(args))
        model = AutoModelForSequenceClassification.from_pretrained(args.model, **base_model_kwargs(args)).to(device)
        scores, seconds = predict(
            model,
            tokenizer,
            evaluation,
            device,
            args.batch_size,
            args.max_length,
            args.input_variant,
            amp_dtype,
        )
        name = f"{args.label}_zero_shot"
        column = f"score_{name}"
        evaluation[column] = scores
        score_columns[name] = column
        gated_name = f"{name}_conflict_refined"
        gated_column = f"score_{gated_name}"
        evaluation[gated_column] = conflict_gate(evaluation, scores, strength=1.0)
        score_columns[gated_name] = gated_column
        timing[f"{name}_evaluation_seconds"] = seconds
        del model
        if device.type == "mps":
            torch.mps.empty_cache()
        elif device.type == "cuda":
            torch.cuda.empty_cache()

    for regime in args.regimes:
        checkpoint, history, training_summary = train_regime(
            args, regime, train, validation, device, amp_dtype
        )
        history_rows.extend(history)
        training_summaries.append(training_summary)
        log_stage(f"{regime}: evaluating selected epoch {training_summary['selected_epoch']}")
        tokenizer = AutoTokenizer.from_pretrained(checkpoint)
        model = AutoModelForSequenceClassification.from_pretrained(checkpoint).to(device)
        scores, seconds = predict(
            model,
            tokenizer,
            evaluation,
            device,
            args.batch_size,
            args.max_length,
            args.input_variant,
            amp_dtype,
        )
        name = f"{args.label}_{regime}"
        column = f"score_{name}"
        evaluation[column] = scores
        score_columns[name] = column
        gated_name = f"{name}_conflict_refined"
        gated_column = f"score_{gated_name}"
        evaluation[gated_column] = conflict_gate(evaluation, scores, strength=1.0)
        score_columns[gated_name] = gated_column
        timing[f"{name}_evaluation_seconds"] = seconds
        del model
        if device.type == "mps":
            torch.mps.empty_cache()
        elif device.type == "cuda":
            torch.cuda.empty_cache()

        if args.audit_checkpoint_rules:
            audit = training_summary["checkpoint_rule_audit"]
            if audit["same_epoch_as_primary"]:
                audit_scores, audit_seconds = scores.copy(), 0.0
                log_stage(f"{audit['regime']}: same selected epoch; reusing identical predictions")
            else:
                log_stage(f"{audit['regime']}: evaluating audit epoch {audit['selected_epoch']}")
                audit_tokenizer = AutoTokenizer.from_pretrained(audit["checkpoint"], local_files_only=True)
                audit_model = AutoModelForSequenceClassification.from_pretrained(audit["checkpoint"], local_files_only=True).to(device)
                audit_scores, audit_seconds = predict(audit_model, audit_tokenizer, evaluation,
                    device, args.batch_size, args.max_length, args.input_variant, amp_dtype)
                del audit_model
                if device.type == "mps":
                    torch.mps.empty_cache()
                elif device.type == "cuda":
                    torch.cuda.empty_cache()
            audit_name = f"{args.label}_{audit['regime']}"
            audit_column = f"score_{audit_name}"
            if audit_name in score_columns:
                raise ValueError(f"Duplicate model label {audit_name}; use separate outputs for overlapping audited regimes")
            evaluation[audit_column] = audit_scores
            score_columns[audit_name] = audit_column
            gated_name = f"{audit_name}_conflict_refined"
            gated_column = f"score_{gated_name}"
            evaluation[gated_column] = conflict_gate(evaluation, audit_scores, strength=1.0)
            score_columns[gated_name] = gated_column
            timing[f"{audit_name}_evaluation_seconds"] = audit_seconds

    log_stage("Computing metrics and query bootstrap")
    _, metrics, _, _ = evaluate_scores(
        evaluation,
        score_columns,
        args.output_dir,
        bootstrap_samples=args.bootstrap,
        seed=args.seed,
    )
    pd.DataFrame(history_rows).to_csv(args.output_dir / "training_history.csv", index=False)
    keep = [
        "pair_id",
        "evaluation_split",
        "query_id",
        "candidate_id",
        "final_label",
        "final_relevance",
        "difficulty",
        "final_conflict_type",
        *score_columns.values(),
    ]
    evaluation[keep].to_csv(args.output_dir / "pair_scores.csv", index=False)
    revision = args.model_revision or "not supplied; no network revision lookup"
    manifest = {
        "status": "complete",
        "paper_eligible": True,
        "base_model": args.base_model_id or args.model,
        "base_model_load_path": args.model,
        "base_model_revision": revision,
        "base_model_revision_provenance": "explicit CLI argument" if args.model_revision else "unavailable",
        "label": args.label,
        "device": str(device),
        "amp_dtype": str(amp_dtype) if amp_dtype is not None else "fp32",
        "gpu_name": torch.cuda.get_device_name(0) if device.type == "cuda" else None,
        "input_hashes": hashes,
        "training_source_rows_semantic_deduplicated": len(train_source),
        "training_effective_rows": len(train),
        "symmetric_training_augmentation": args.symmetric_train,
        "training_positive": int(train["final_label"].sum()),
        "training_hard_positive": int(
            (train["difficulty"].eq("hard") & train["final_label"].eq(1)).sum()
        ),
        "evaluation_rows": len(evaluation),
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "training_batch_size": args.train_batch_size,
        "max_length": args.max_length,
        "input_variant": args.input_variant,
        "learning_rate": args.learning_rate,
        "regimes": args.regimes,
        "training_summaries": training_summaries,
        "threshold_selection": "validation only",
        "checkpoint_selection": (
            "standard: validation pair F1; hard_refined: 0.60 validation pair F1 + "
            "0.40 validation hard-pair F1; hard_weight_only: validation pair F1; "
            "hard_selection_only: 0.60 validation pair F1 + 0.40 validation hard-pair F1"
        ),
        "audit_checkpoint_rules": args.audit_checkpoint_rules,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "bootstrap_samples": args.bootstrap,
        "timing": timing,
        "total_runtime_seconds": time.perf_counter() - total_started,
        "packages": {
            name: importlib.metadata.version(name)
            for name in ["torch", "transformers"]
        },
        "seed": args.seed,
    }
    write_json(args.output_dir / "manifest.json", manifest)
    log_stage("Run complete")
    print(json.dumps(manifest, indent=2))
    print(
        metrics[(metrics["split"].eq("locked")) & (metrics["policy"].eq("f1_opt"))][
            ["model", "top1", "recall_at_5", "mrr", "ndcg_at_5_graded", "pair_f1", "hard_pair_f1"]
        ].to_string(index=False)
    )


if __name__ == "__main__":
    main()
