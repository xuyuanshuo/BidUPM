#!/usr/bin/env python3
"""Run a reproducible prompt-only open-LLM verifier on BidUPM-vFinal.

The model receives the same structured query/candidate evidence for every split.
It is asked for a binary yes/no judgment, and the continuous compatibility score
is the next-token logit difference logit(yes) - logit(no). Threshold selection is
performed on validation only before locked, no-reference, and external scoring.
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
import random
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from huggingface_hub import model_info
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer

sys.path.insert(0, str(Path(__file__).resolve().parent))
from local_experiment_utils import (  # noqa: E402
    SEED,
    conflict_gate,
    evaluate_scores,
    item_text,
    load_data,
    write_json,
)


SYSTEM_PROMPT = (
    "You verify construction bid-item compatibility for historical unit-price "
    "reference selection. A candidate is valid only when the construction action, "
    "material, specification, type or class, scope, and pay unit are compatible. "
    "Shared words alone are insufficient. Answer only yes or no."
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--model", default="Qwen/Qwen3-4B-Instruct-2507")
    parser.add_argument("--base-model-id", default="Qwen/Qwen3-4B-Instruct-2507")
    parser.add_argument("--model-revision", default="cdbee75f17c01a7cc42f958dc650907174af0554")
    parser.add_argument("--label", default="qwen3_4b_instruct_verifier")
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--max-length", type=int, default=256)
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=SEED)
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def render_prompt(tokenizer, query: str, candidate: str) -> str:
    user = (
        "Query bid item:\n"
        f"{query}\n\n"
        "Historical candidate:\n"
        f"{candidate}\n\n"
        "Can this candidate safely serve as a unit-price reference for the query?"
    )
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]
    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
    except TypeError:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )


class PromptDataset(Dataset):
    def __init__(self, frame: pd.DataFrame, tokenizer) -> None:
        queries = item_text(frame, "query", "full")
        candidates = item_text(frame, "candidate", "full")
        self.prompts = [
            render_prompt(tokenizer, query, candidate)
            for query, candidate in zip(queries, candidates)
        ]

    def __len__(self) -> int:
        return len(self.prompts)

    def __getitem__(self, index: int) -> str:
        return self.prompts[index]


class PromptCollator:
    def __init__(self, tokenizer, max_length: int) -> None:
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __call__(self, prompts: list[str]) -> dict[str, torch.Tensor]:
        return self.tokenizer(
            prompts,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            pad_to_multiple_of=8,
            return_tensors="pt",
        )


def answer_token_id(tokenizer, answer: str) -> int:
    ids = tokenizer.encode(answer, add_special_tokens=False)
    if len(ids) != 1:
        raise RuntimeError(f"Expected one token for {answer!r}; observed token IDs {ids}")
    return int(ids[0])


@torch.inference_mode()
def predict(
    model,
    tokenizer,
    frame: pd.DataFrame,
    device: torch.device,
    batch_size: int,
    max_length: int,
) -> tuple[np.ndarray, float, int]:
    loader = DataLoader(
        PromptDataset(frame, tokenizer),
        batch_size=batch_size,
        shuffle=False,
        num_workers=2,
        pin_memory=True,
        collate_fn=PromptCollator(tokenizer, max_length),
    )
    yes_id = answer_token_id(tokenizer, "yes")
    no_id = answer_token_id(tokenizer, "no")
    model.eval()
    scores: list[np.ndarray] = []
    prompt_tokens = 0
    started = time.perf_counter()
    for batch in loader:
        prompt_tokens += int(batch["attention_mask"].sum().item())
        encoded = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
        with torch.autocast("cuda", dtype=torch.bfloat16):
            logits = model(**encoded).logits[:, -1, :]
        score = logits[:, yes_id] - logits[:, no_id]
        scores.append(score.float().cpu().numpy())
    return np.concatenate(scores), time.perf_counter() - started, prompt_tokens


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("The open-LLM verifier requires CUDA")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    torch.backends.cuda.matmul.allow_tf32 = True
    set_seed(args.seed)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    _, _, evaluation, hashes = load_data(args.data_dir)
    tokenizer = AutoTokenizer.from_pretrained(args.model, padding_side="left")
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    device = torch.device("cuda")
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.bfloat16,
        low_cpu_mem_usage=True,
        attn_implementation="sdpa",
    ).to(device)
    model.config.use_cache = False

    total_started = time.perf_counter()
    scores, inference_seconds, prompt_tokens = predict(
        model,
        tokenizer,
        evaluation,
        device,
        args.batch_size,
        args.max_length,
    )
    raw_name = args.label
    raw_column = f"score_{raw_name}"
    refined_name = f"{raw_name}_conflict_refined"
    refined_column = f"score_{refined_name}"
    evaluation[raw_column] = scores
    evaluation[refined_column] = conflict_gate(evaluation, scores, strength=1.0)

    score_columns = {raw_name: raw_column, refined_name: refined_column}
    _, metrics, _, _ = evaluate_scores(
        evaluation,
        score_columns,
        args.output_dir,
        bootstrap_samples=args.bootstrap,
        seed=args.seed,
    )
    keep = [
        "pair_id",
        "evaluation_split",
        "query_id",
        "candidate_id",
        "final_label",
        "final_relevance",
        "difficulty",
        "final_conflict_type",
        raw_column,
        refined_column,
    ]
    evaluation[keep].to_csv(args.output_dir / "pair_scores.csv", index=False)
    if Path(args.model).is_dir():
        complete = json.loads((Path(args.model) / "DOWNLOAD_COMPLETE.json").read_text())
        if complete.get("repo") != args.base_model_id or complete.get("revision") != args.model_revision:
            raise RuntimeError("Local verifier snapshot does not match pinned model revision")
        revision = args.model_revision
        source = json.loads((Path(args.model) / "download_source.json").read_text())
        weight_hashes = {entry["Path"]: entry["Sha256"] for entry in source["files"]
                         if entry["Path"].endswith(".safetensors")}
    else:
        revision = model_info(args.model, revision=args.model_revision).sha
        weight_hashes = {}
    manifest = {
        "status": "complete",
        "paper_eligible": True,
        "experiment_type": "prompt-only open-LLM verifier",
        "base_model": args.base_model_id,
        "base_model_load_path": args.model,
        "base_model_revision": revision,
        "base_model_revision_provenance": "Locally loaded pinned snapshot; ModelScope weight SHA-256 verified against official Hugging Face LFS metadata",
        "base_model_weight_sha256": weight_hashes,
        "label": args.label,
        "device": "cuda",
        "gpu_name": torch.cuda.get_device_name(0),
        "gpu_memory_bytes": torch.cuda.get_device_properties(0).total_memory,
        "dtype": "bfloat16",
        "system_prompt": SYSTEM_PROMPT,
        "answer_constraint": "lowercase yes or no",
        "score_definition": "next-token logit(yes) minus logit(no)",
        "input_hashes": hashes,
        "evaluation_rows": len(evaluation),
        "batch_size": args.batch_size,
        "max_length": args.max_length,
        "threshold_selection": "validation only",
        "bootstrap_samples": args.bootstrap,
        "inference_seconds": inference_seconds,
        "pairs_per_second": len(evaluation) / max(inference_seconds, 1e-12),
        "prompt_tokens": prompt_tokens,
        "mean_prompt_tokens_per_pair": prompt_tokens / len(evaluation),
        "peak_gpu_memory_bytes": torch.cuda.max_memory_allocated(),
        "total_runtime_seconds": time.perf_counter() - total_started,
        "packages": {
            name: importlib.metadata.version(name)
            for name in ["torch", "transformers"]
        },
        "seed": args.seed,
    }
    write_json(args.output_dir / "manifest.json", manifest)
    print(json.dumps(manifest, indent=2))
    print(
        metrics[(metrics["split"].eq("locked")) & (metrics["policy"].eq("f1_opt"))][
            [
                "model",
                "top1",
                "recall_at_5",
                "mrr",
                "ndcg_at_5_graded",
                "pair_f1",
                "hard_pair_f1",
            ]
        ].to_string(index=False)
    )


if __name__ == "__main__":
    main()
