# BidUPM runner extension, 2026-09-23

The original files remain untouched in `output/revise3_full_20260920/supplementary/scripts/original/`. `local_experiment_utils.py` was copied byte for byte. `original_source_sha256.json` records original and modified SHA-256 digests; `runner_changes.patch` records the full change.

## Additional arguments

- `--model-revision REVISION`: record the known base-model revision; when loading a repository rather than a local folder, pass this revision to Transformers. No network `model_info` lookup occurs.
- `--base-model-id BAAI/bge-reranker-v2-m3`: preserve the repository identity when `--model` points at a local model folder.
- `--audit-checkpoint-rules`: select a second checkpoint from the same training trajectory using the other validation rule, then evaluate both. This flag defaults to false.

All previous argument defaults remain unchanged. Data loading, split membership, input text, train augmentation, thresholds, and metrics come from the unchanged utility copy.

## Four configurations

| Regime | Hard positive sample multiplier | Checkpoint objective |
|---|---:|---|
| standard | 1 | Validation overall F1 |
| hard_selection_only | 1 | 0.60 validation overall F1 + 0.40 validation hard F1 |
| hard_weight_only | 3 | Validation overall F1 |
| hard_refined | 3 | 0.60 validation overall F1 + 0.40 validation hard F1 |

The existing positive-class BCE weight remains in all four configurations. The additional sample multiplier affects hard positives only. The acceptance threshold continues to maximize validation overall F1 with the original tie-breaking algorithm, regardless of the checkpoint objective.

## Audit output

For `--regimes hard_refined --audit-checkpoint-rules --label bge_v2_m3_hard`, primary predictions retain the model label `bge_v2_m3_hard_hard_refined`. The audited overall-F1 checkpoint receives `bge_v2_m3_hard_hard_weight_only`. These labels appear in metrics and pair scores. Their conflict-refined diagnostic variants retain the pre-existing suffix convention.

The manifest stores the second selection under `training_summaries[].checkpoint_rule_audit`, including selected epoch, validation objective, checkpoint path, and whether the two rules selected the same epoch. If they selected the same epoch, scores are copied exactly and the duplicate checkpoint is removed. If they selected different epochs, both checkpoints are retained and independently evaluated.

For `standard`, the alternate is `hard_selection_only`; for either ablation, the reverse mapping applies. Do not request both members of one audit pair in the same output directory with auditing enabled.

Training/validation/completion stages are flushed to the log. `training_history_<regime>.csv` is refreshed after each epoch. Non-finite training loss raises an error immediately; no completed manifest is then written.

## Validation performed

`check_factorial_logic.py` runs on CPU and passed seven checks, recorded in `factorial_logic_check.json`. It compares every original CLI default and the original threshold/objective outputs, verifies weighting for all four label/difficulty combinations, and constructs two epochs on which the competing checkpoint criteria disagree. A tiny neural model further confirms that the audit extension leaves the original training losses and final weights exactly unchanged while retaining the correct alternate epoch weights. Python compilation also passed.
