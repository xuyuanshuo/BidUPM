"""Download pinned public weights on the server; verify every file by SHA-256."""
import argparse
import concurrent.futures as cf
import hashlib
import json
import os
from pathlib import Path
import time
import requests


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        while b := f.read(16 * 1024 * 1024):
            h.update(b)
    return h.hexdigest()


def download(repo, revision, root, expected_bge=False):
    session = requests.Session()
    session.trust_env = False  # ModelScope uses a direct domestic connection.
    meta = session.get(f'https://modelscope.cn/api/v1/models/{repo}/repo/files',
                       params={'Revision': 'master', 'Recursive': 'true'}, timeout=45).json()
    files = [f for f in meta['Data']['Files'] if f.get('Type') != 'tree' and
             (f['Path'].endswith(('.safetensors', '.json', '.model')) and '/' not in f['Path'])]
    dest = root / repo.split('/')[-1]
    dest.mkdir(parents=True, exist_ok=True)
    if expected_bge:
        expected = {'model.safetensors': 'd9e3e081faff1eefb84019509b2f5558fd74c1a05a2c7db22f74174fcedb5286'}
    else:
        # The official pinned HF revision is checked through AutoDL's proxy.
        from huggingface_hub import HfApi
        info = HfApi(endpoint='https://huggingface.co').model_info(repo, revision=revision, files_metadata=True)
        expected = {f.rfilename: f.lfs.sha256 for f in info.siblings if f.lfs}
    for f in files:
        if f['Path'].endswith('.safetensors'):
            assert expected.get(f['Path']) == f['Sha256'], (repo, f['Path'], 'revision mismatch')
    (dest / 'download_source.json').write_text(json.dumps({'repo': repo, 'revision': revision, 'files': files}, indent=2))
    for entry in files:
        name, size, digest = entry['Path'], entry['Size'], entry['Sha256']
        target = dest / name
        if target.exists() and target.stat().st_size == size and sha(target) == digest:
            print('VERIFIED existing', repo, name, flush=True)
            continue
        url = f'https://modelscope.cn/models/{repo}/resolve/master/{name}'
        chunk = 16 * 1024 * 1024
        parts = dest / ('.parts_' + name)
        parts.mkdir(exist_ok=True)
        def get_part(i):
            start, end = i * chunk, min(size, (i + 1) * chunk) - 1
            part = parts / f'{i:05d}'
            if part.exists() and part.stat().st_size == end - start + 1:
                return part
            for attempt in range(5):
                try:
                    s = requests.Session(); s.trust_env = False
                    with s.get(url, headers={'Range': f'bytes={start}-{end}'}, stream=True, timeout=(30, 120)) as r:
                        r.raise_for_status()
                        if size > chunk:
                            assert r.status_code == 206 and r.headers.get('Content-Range', '').startswith(f'bytes {start}-{end}/')
                        tmp = part.with_suffix('.tmp')
                        with tmp.open('wb') as w:
                            for b in r.iter_content(1024 * 1024):
                                w.write(b)
                        assert tmp.stat().st_size == end - start + 1
                        tmp.replace(part)
                    return part
                except Exception:
                    if attempt == 4: raise
                    time.sleep(2 ** attempt)
        count = (size + chunk - 1) // chunk
        print('START', repo, name, size, count, flush=True)
        with cf.ThreadPoolExecutor(max_workers=8) as pool:
            futures = [pool.submit(get_part, i) for i in range(count)]
            for j, fut in enumerate(cf.as_completed(futures), 1):
                fut.result()
                if j % 16 == 0 or j == count: print('PARTS', name, j, '/', count, flush=True)
        tmp = target.with_suffix(target.suffix + '.assembling')
        with tmp.open('wb') as w:
            for i in range(count):
                with (parts / f'{i:05d}').open('rb') as f:
                    while b := f.read(8 * 1024 * 1024): w.write(b)
        assert tmp.stat().st_size == size and sha(tmp) == digest, f'Hash mismatch: {name}'
        tmp.replace(target)
        for p in parts.iterdir(): p.unlink()
        parts.rmdir()
        print('VERIFIED', repo, name, digest, flush=True)
    (dest / 'DOWNLOAD_COMPLETE.json').write_text(json.dumps({'repo': repo, 'revision': revision, 'verified': True}))
    print('MODEL_COMPLETE', repo, flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--models', nargs='+', choices=['bge', 'qwen06', 'qwen4', 'verifier'], required=True)
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    cfg = {'bge': ('BAAI/bge-reranker-v2-m3', '953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e'),
           'qwen06': ('Qwen/Qwen3-Reranker-0.6B', 'e61197ed45024b0ed8a2d74b80b4d909f1255473'),
           'qwen4': ('Qwen/Qwen3-Reranker-4B', '22e683669bc0f0bd69640a1354a6d0aebcfeede5'),
           'verifier': ('Qwen/Qwen3-4B-Instruct-2507', 'cdbee75f17c01a7cc42f958dc650907174af0554')}
    for key in a.models:
        download(*cfg[key], a.root, expected_bge=(key == 'bge'))
