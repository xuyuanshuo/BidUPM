#!/usr/bin/env python3
"""Secondary prespecified replay of the existing validation-selected verifier."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parent))
from evaluate_expanded_system import BASE,OLD,SOURCE,OUT,DESIGN,SEEDS,m,require,sha,dump

def main():
    out=BASE/'results/qwen_gate_components';out.mkdir(parents=True,exist_ok=True)
    src=BASE.parent/'remote_experiments_20260923/runs/qwen3_4b_instruct_verifier'
    thresholds=pd.read_csv(src/'validation_thresholds.csv');threshold=float(thresholds.loc[thresholds.policy.eq('f1_opt'),'threshold'].iloc[0])
    require(threshold==12.75,'Verifier frozen threshold changed')
    plan={'study':'secondary retrospective component comparison; not test-selected threshold','verifier_threshold':threshold,'threshold_source':'old validation-only f1_opt','policies':['rule_bge_top10_qwen','expanded_gpt_and_qwen','threshold_bge_and_qwen','rule_qwen_no_bge'],'prediction_source':'cached real full-pool GPU yes-minus-no scores, no new inference','input_hashes':{str(p):sha(p) for p in [src/'pair_scores.csv',src/'validation_thresholds.csv',DESIGN/'private_eligibility.csv',OUT/'all_verifier_decisions.csv']},'gold_used_for_policy_selection':False}
    dump(out/'plan_before_reconstruction.json',plan)
    eligibility=pd.read_csv(DESIGN/'private_eligibility.csv')
    verify=pd.read_csv(src/'pair_scores.csv',usecols=['pair_id','score_qwen3_4b_instruct_verifier']).rename(columns={'score_qwen3_4b_instruct_verifier':'qwen_score'})
    judgments=pd.read_csv(OUT/'all_verifier_decisions.csv',usecols=['pair_id','verifier_accept'])
    basic=pd.read_csv(OUT/'reconstructed_predictions_before_gold.csv');inputs=pd.read_csv(SOURCE/'inputs.csv',dtype=str,keep_default_na=False)
    inputs=inputs[inputs.evaluation_split.ne('validation')]
    frames=[]
    for seed in SEEDS:
        raw=pd.read_csv(OLD/f'results/runtime/predictions_seed_{seed}.csv',float_precision='round_trip')
        core=raw[raw.policy.eq('system_top3')&raw.batch_size.eq(64)].merge(inputs.drop(columns=['query_id','evaluation_split']),on='pair_id',validate='one_to_one').merge(verify,on='pair_id',validate='one_to_one').merge(judgments,on='pair_id',how='left',validate='one_to_one')
        allowed=set(eligibility.loc[eligibility[f'eligible_k10_seed_{seed}'].eq(1),'pair_id'])
        for policy in plan['policies']:
            f=core.copy();keep=f.exact_match.eq(0)&f.qwen_score.ge(threshold)
            if policy!='rule_qwen_no_bge':keep&=f.pair_id.isin(allowed)
            if policy=='expanded_gpt_and_qwen':keep&=f.verifier_accept.eq(1)
            if policy=='threshold_bge_and_qwen':keep&=f.prediction.eq(1)
            if policy=='rule_qwen_no_bge':f['score']=f.qwen_score
            f['prediction']=f.exact_match.astype(int);f.loc[keep,'prediction']=1;f['returned_rank']=m.rank_pandas(f,keep)
            pure=m.rank_python(f.to_dict('records'),set(f.loc[keep,'pair_id']));require(f.pair_id.map(pure).eq(f.returned_rank).all(),'Independent rank mismatch')
            f['source']='cached_qwen_component';f['policy']=policy;frames.append(f)
    cols=m.META+['pair_id','evaluation_split','query_id','candidate_id','exact_match','prediction','returned_rank']
    pred=pd.concat([f[cols] for f in frames]);pred.to_csv(out/'predictions_before_gold.csv',index=False)
    labels=pd.read_csv(SOURCE/'labels.csv');pred=pred.merge(labels,on='pair_id',validate='many_to_one')
    queries=m.query_frame(pred);summary=m.summary_frame(pred,queries);check=m.independent_count_crosscheck(pred,summary)
    summary.to_csv(out/'summary_per_seed.csv',index=False);queries.to_csv(out/'per_query.csv',index=False);check.to_csv(out/'independent_metric_checks.csv',index=False)
    met=['returned_precision_pct','macro_recall_at3_pct','hit_at3_pct','no_reference_pool_rejection_pct','returned_tp_n','returned_fp_n']
    agg=summary.groupby(['evaluation_group','policy'])[met].agg(['mean','std']);agg.columns=['_'.join(c) for c in agg.columns];agg.reset_index().to_csv(out/'summary_aggregate.csv',index=False)
    dump(out/'qa.json',{'status':'passed','independent_metric_checks':len(check),'threshold_retuned':False,'gold_modified':False,'prediction_sha256_before_gold':sha(out/'predictions_before_gold.csv'),'script_sha256':sha(__file__),'timing_scope':'no new GPU timing; do not estimate end-to-end latency from cached replay'})
    print(agg.reset_index().query("evaluation_group=='all_formal'").to_string(index=False))
if __name__=='__main__':main()
