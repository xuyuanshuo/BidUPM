#!/usr/bin/env python3
"""Independent evaluation of delivered actual local GPU policies; no inference."""
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE.parent / 'rule_first_system_20261004/results/server'
OLD = BASE.parent / 'rule_first_system_validation_20261005'
RUN = BASE / 'results/local_verifier_system'
OUT = RUN / 'analysis'
spec = importlib.util.spec_from_file_location('independent_own_record_loops', BASE / 'qa/audit_expanded_independent.py')
own = importlib.util.module_from_spec(spec)
spec.loader.exec_module(own)
SEEDS = (20260904, 20260905, 20260906)
THRESHOLDS = {20260904: 9.1875, 20260905: -1.453125, 20260906: 8.4375}
POLICIES = ('all_bge', 'rule_bge', 'rule_bge_qwen_threshold', 'rule_bge_qwen_top10')
CHECKS, HASHES = [], {}


def check(name, condition, details=None):
    CHECKS.append({'check': name, 'passed': bool(condition), 'details': details})
    if not condition:
        raise ValueError(name)


def sha(path):
    h = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    HASHES.setdefault(str(Path(path).resolve()), h)
    return h


def jread(path):
    sha(path)
    return json.loads(Path(path).read_text())


def read(path, **kwargs):
    sha(path)
    return pd.read_csv(path, **kwargs)


def safe(v):
    if isinstance(v, dict):
        return {str(k): safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [safe(x) for x in v]
    if isinstance(v, (np.integer, np.bool_)):
        return v.item()
    if isinstance(v, (float, np.floating)):
        return float(v) if np.isfinite(v) else None
    if isinstance(v, set):
        return sorted(v)
    return v


def write_json(path, value):
    path.write_text(json.dumps(safe(value), ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def evaluate():
    OUT.mkdir(parents=True, exist_ok=True)
    manifest = jread(RUN / 'execution_manifest.json')
    source = jread(SOURCE / 'source_manifest.json')
    check('complete frozen local execution', manifest['status'] == 'complete' and not manifest['labels_accessed'] and not manifest['thresholds_retuned'] and not manifest['new_training'])
    check('exact planned conditions', tuple(manifest['policies']) == POLICIES and manifest['repeats'] == 3 and manifest['pair_n'] == 6600 and manifest['query_n'] == 220)
    check('executed runner bytes', sha(BASE / 'scripts/run_local_verifier_system.py') == manifest['script_sha256'])
    check('authoritative input hash', sha(SOURCE / 'inputs.csv') == manifest['source_sha256'] == source['inputs_sha256'])
    qthresholdpath = BASE.parent / 'remote_experiments_20260923/runs/qwen3_4b_instruct_verifier/validation_thresholds.csv'
    check('original validation Qwen threshold file hash', sha(qthresholdpath) == manifest['qwen_threshold_sha256'])
    qt = read(qthresholdpath)
    check('original Qwen threshold value', float(qt.loc[qt.policy.eq('f1_opt'), 'threshold'].iloc[0]) == manifest['qwen_threshold'] == 12.75)
    check('BGE original threshold plan', {int(r['seed']): float(r['threshold']) for r in source['runs']} == THRESHOLDS)
    inputs = read(SOURCE / 'inputs.csv', dtype=str, keep_default_na=False)
    inputs = inputs[inputs.evaluation_split.isin(own.GROUPS['all_formal'])]
    rows, pools = {}, defaultdict(list)
    for r in inputs.to_dict('records'):
        qd, cd = own.canonical(r['query_normalized_description']), own.canonical(r['candidate_normalized_description'])
        qu, cu = own.unit(r['query_normalized_unit']), own.unit(r['candidate_normalized_unit'])
        r['exact'] = int(bool(qd and qu and qd == cd and qu == cu))
        rows[r['pair_id']] = r
        pools[r['evaluation_split'], r['query_id']].append(r)
    check('source full scope', len(rows) == 6600 and len(pools) == 220 and all(len(g) == 30 for g in pools.values()))
    expected, rawframes, routing = {}, {}, []
    check('all three completed original seeds', len(manifest['completed_runs']) == 3 and {int(r['seed']) for r in manifest['completed_runs']} == set(SEEDS))
    for run in manifest['completed_runs']:
        seed = int(run['seed'])
        p = RUN / run['output']
        check('saved prediction file SHA ' + str(seed), p.parent.resolve() == RUN.resolve() and sha(p) == run['sha256'])
        check('frozen BGE threshold metadata ' + str(seed), run['threshold'] == THRESHOLDS[seed])
        frame = read(p, float_precision='round_trip')
        check('four policies x6600 ' + str(seed), len(frame) == 26400 and not frame.duplicated(['policy', 'pair_id']).any() and set(frame.policy) == set(POLICIES) and frame.seed.eq(seed).all() and frame.threshold.eq(THRESHOLDS[seed]).all())
        rawframes[seed] = {}
        for name, part in frame.groupby('policy'):
            part = part.set_index('pair_id')
            check('IDs and frozen source metadata ' + str((seed, name)), part.index.is_unique and set(part.index) == set(rows) and all(part.loc[pid, c] == rows[pid][c] for pid in rows for c in ('evaluation_split', 'query_id', 'candidate_id')))
            scores, qscores = part.score.to_dict(), part.qwen_score.to_dict()
            decisions, selected = {}, set()
            for pool in pools.values():
                exact_count = sum(r['exact'] for r in pool)
                called = {r['pair_id'] for r in pool if name == 'all_bge' or (not r['exact'] and exact_count < 3)}
                bgeaccept = {pid for pid in called if scores[pid] >= THRESHOLDS[seed]}
                if name == 'rule_bge_qwen_threshold':
                    qselect = bgeaccept
                elif name == 'rule_bge_qwen_top10':
                    ordered = sorted((r for r in pool if r['pair_id'] in called), key=lambda r: (-scores[r['pair_id']], r['candidate_id']))
                    qselect = {r['pair_id'] for r in ordered[:10]}
                else:
                    qselect = set()
                keep = {pid for pid in qselect if qscores[pid] >= 12.75} if name.startswith('rule_bge_qwen') else bgeaccept
                if name == 'all_bge':
                    ranked = sorted((r for r in pool if r['pair_id'] in keep), key=lambda r: (-scores[r['pair_id']], r['candidate_id']))[:3]
                    ranks = {r['pair_id']: i for i, r in enumerate(ranked, 1)}
                else:
                    ranks = own.choose(pool, keep, scores)
                for r in pool:
                    pid = r['pair_id']
                    expected_exact = 0 if name == 'all_bge' else r['exact']
                    check_values = (int(part.loc[pid, 'bge_called']) == int(pid in called),
                                    int(part.loc[pid, 'qwen_called']) == int(pid in qselect),
                                    int(part.loc[pid, 'exact_match']) == expected_exact,
                                    np.isfinite(scores[pid]) == (pid in called),
                                    np.isfinite(qscores[pid]) == (pid in qselect))
                    if not all(check_values):
                        raise ValueError('independent gate/model-score visibility mismatch ' + str((seed, name, pid)))
                    pred = int(pid in keep or (name != 'all_bge' and r['exact']))
                    decisions[pid] = pred, ranks.get(pid, 0)
                    if decisions[pid] != (int(part.loc[pid, 'prediction']), int(part.loc[pid, 'returned_rank'])):
                        raise ValueError('independent threshold/rank mismatch ' + str((seed, name, pid)))
                selected |= qselect
            expected[seed, name] = decisions
            rawframes[seed][name] = part
            routing.append({'seed': seed, 'policy': name, 'pair_n': len(part), 'query_n': 220,
                            'bge_pairs': int(part.bge_called.sum()), 'qwen_pairs': len(selected),
                            'qwen_passed_pairs': int((part.qwen_called.eq(1) & part.qwen_score.ge(12.75)).sum()),
                            'source_exact_pairs_independently_computed': sum(r['exact'] for r in rows.values()),
                            'saved_exact_mask_zero_by_design': name == 'all_bge'})
            check('independent route/threshold/cap3 ' + str((seed, name)), True, routing[-1])
    reconstruction_utc = datetime.now(timezone.utc).isoformat()
    check('timing SHA', sha(RUN / 'timing.csv') == manifest['timing_sha256'])
    timing = read(RUN / 'timing.csv', float_precision='round_trip')
    check('36 unique timing conditions', len(timing) == 36 and not timing.duplicated(['seed', 'policy', 'repeat']).any() and set(zip(timing.seed, timing.policy, timing.repeat)) == {(s, p, r) for s in SEEDS for p in POLICIES for r in range(3)})
    check('timing finite and220 query scope', np.isfinite(timing.seconds).all() and timing.seconds.gt(0).all() and timing.pairs.eq(6600).all() and timing.queries.eq(220).all())
    route_lookup = {(r['seed'], r['policy']): r for r in routing}
    for t in timing.to_dict('records'):
        routed = route_lookup[int(t['seed']), t['policy']]
        if t['bge_pairs'] != routed['bge_pairs'] or t['qwen_pairs'] != routed['qwen_pairs']:
            raise ValueError('timing vs prediction call count mismatch')
    check('actual timing model-call counts reproduce saved predictions', True)
    cached = read(BASE / 'results/qwen_gate_components/predictions_before_gold.csv')
    cachedqa = jread(BASE / 'results/qwen_gate_components/qa.json')
    check('cached replay integrity', sha(BASE / 'results/qwen_gate_components/predictions_before_gold.csv') == cachedqa['prediction_sha256_before_gold'])
    replay = []
    oldqscore = read(BASE.parent / 'remote_experiments_20260923/runs/qwen3_4b_instruct_verifier/pair_scores.csv', usecols=['pair_id', 'score_qwen3_4b_instruct_verifier']).set_index('pair_id')['score_qwen3_4b_instruct_verifier'].to_dict()
    original_runtime_manifest = jread(OLD / 'results/runtime/execution_manifest.json')
    for seed in SEEDS:
        reference = cached[cached.seed.eq(seed) & cached.policy.eq('threshold_bge_and_qwen')].set_index('pair_id')
        actual = rawframes[seed]['rule_bge_qwen_threshold']
        diffs = actual[['prediction', 'returned_rank']].join(reference[['prediction', 'returned_rank']], rsuffix='_cached')
        oldpath = OLD / f'results/runtime/predictions_seed_{seed}.csv'
        priorrun = next(r for r in original_runtime_manifest['completed_runs'] if int(r['seed']) == seed)
        check('old GPU runtime integrity ' + str(seed), sha(oldpath) == priorrun['prediction_sha256'])
        oldraw = read(oldpath, float_precision='round_trip')
        oldgate = oldraw[oldraw.batch_size.eq(64) & oldraw.policy.eq('system_top3')].set_index('pair_id')
        called = actual[actual.bge_called.eq(1)].index
        qcalled = actual[actual.qwen_called.eq(1)].index
        bdiff = np.array([actual.loc[pid, 'score'] - oldgate.loc[pid, 'score'] for pid in called])
        qdiff = np.array([actual.loc[pid, 'qwen_score'] - oldqscore[pid] for pid in qcalled])
        replay.append({'seed': seed, 'actual_policy': 'rule_bge_qwen_threshold', 'cached_policy': 'threshold_bge_and_qwen',
                       'candidate_n': len(actual), 'prediction_disagreements': int(diffs.prediction.ne(diffs.prediction_cached).sum()),
                       'returned_rank_disagreements': int(diffs.returned_rank.ne(diffs.returned_rank_cached).sum()),
                       'returned_membership_disagreements': int(diffs.returned_rank.gt(0).ne(diffs.returned_rank_cached.gt(0)).sum()),
                       'actual_minus_cached_bge_score_nonzero_n': int((bdiff != 0).sum()),
                       'actual_minus_cached_bge_max_abs': float(np.abs(bdiff).max()) if len(bdiff) else 0,
                       'actual_minus_cached_qwen_score_nonzero_n': int((qdiff != 0).sum()),
                       'actual_minus_cached_qwen_max_abs': float(np.abs(qdiff).max()) if len(qdiff) else 0,
                       'different_bf16_batch_context_possible': True,
                       'actual_metrics_kept_distinct_from_cached': True})
    check('authoritative label hash after decision verification', sha(SOURCE / 'labels.csv') == source['labels_sha256'])
    labels = read(SOURCE / 'labels.csv')
    first_gold_utc = datetime.now(timezone.utc).isoformat()
    check('labels unique and binary', labels.pair_id.is_unique and labels.final_label.isin([0, 1]).all())
    gold = labels.set_index('pair_id').final_label.astype(int).to_dict()
    queries = own.query_metrics(expected, rows, gold)
    summary = own.summarize(expected, queries, rows, gold)
    queryrows = [{'seed': s, 'policy': p, 'evaluation_split': split, 'query_id': q, **safe(value)} for (s, p, split, q), value in queries.items()]
    for r in queryrows:
        r['returned_pairs'] = json.dumps(r['returned_pairs'])
        r['missing_positive_pairs'] = json.dumps(r['missing_positive_pairs'])
    summaryrows = [{'seed': s, 'policy': p, 'evaluation_group': g, **safe(value)} for (s, p, g), value in summary.items()]
    qdf, sdf = pd.DataFrame(queryrows), pd.DataFrame(summaryrows)
    check('independent direct confusion closes', all(r['returned_tp_n'] + r['returned_fn_n'] == r['gold_positive_n'] and r['returned_tp_n'] + r['returned_fp_n'] == r['returned_n'] for r in summaryrows))
    check('primary/internal/external/supplementary scope', all(summary[SEEDS[0], p, 'primary_heldout']['query_n'] == 218 and summary[SEEDS[0], p, 'internal_primary']['query_n'] == 138 and summary[SEEDS[0], p, 'external']['query_n'] == 80 and summary[SEEDS[0], p, 'all_formal']['query_n'] == 220 for p in POLICIES))
    # Distinct vectorized crosscheck of key loop-based returned counts and macro metrics.
    counter = []
    for (seed, name), decisions in expected.items():
        identity = pd.DataFrame([{'pair_id': pid, 'evaluation_split': rows[pid]['evaluation_split'], 'query_id': rows[pid]['query_id'], 'rank': rank, 'gold': gold[pid]} for pid, (_, rank) in decisions.items()])
        identity['tp'] = identity['gold'].eq(1) & identity['rank'].gt(0)
        identity['fp'] = identity['gold'].eq(0) & identity['rank'].gt(0)
        for group, splits in own.GROUPS.items():
            part = identity[identity.evaluation_split.isin(splits)]
            g = part.groupby(['evaluation_split', 'query_id']).agg(pos=('gold', 'sum'), tp=('tp', 'sum'), fp=('fp', 'sum'))
            positive = g[g.pos.gt(0)]
            vals = {'returned_tp_n': int(part.tp.sum()), 'returned_fp_n': int(part.fp.sum()), 'macro_recall_at3_pct': float((positive.tp / positive.pos).mean() * 100) if len(positive) else np.nan}
            sm = summary[seed, name, group]
            for metric, value in vals.items():
                check('direct count crosscheck ' + str((seed, name, group, metric)), own.eqnum(value, sm[metric]))
                counter.append({'seed': seed, 'policy': name, 'evaluation_group': group, 'metric': metric, 'loop_value': sm[metric], 'vector_value': value, 'passed': True})
    aggregate = []
    metrics = ['returned_precision_pct', 'macro_recall_at3_pct', 'hit_at3_pct', 'no_reference_pool_rejection_pct', 'returned_tp_n', 'returned_fp_n', 'returned_fn_n', 'returned_nonexact_tp_n']
    for group in own.GROUPS:
        for name in POLICIES:
            vals = [summary[s, name, group] for s in SEEDS]
            aggregate.append({'evaluation_group': group, 'policy': name, 'query_n': vals[0]['query_n'],
                              **{k + '_mean': float(np.mean([v[k] for v in vals])) for k in metrics},
                              **{k + '_sd': float(np.std([v[k] for v in vals], ddof=1)) for k in metrics}})
    qdf.to_csv(OUT / 'actual_per_query.csv', index=False)
    sdf.to_csv(OUT / 'actual_summary_per_seed.csv', index=False)
    pd.DataFrame(aggregate).to_csv(OUT / 'actual_summary_aggregate.csv', index=False)
    pd.DataFrame(counter).to_csv(OUT / 'actual_metric_crosschecks.csv', index=False)
    pd.DataFrame(routing).to_csv(OUT / 'actual_model_call_counts.csv', index=False)
    pd.DataFrame(replay).to_csv(OUT / 'actual_vs_cached_threshold_replay.csv', index=False)
    write_json(OUT / 'actual_evaluation_qa.json', {
        'status': 'passed', 'checks': CHECKS, 'source_and_prediction_hashes': HASHES,
        'created_utc': datetime.now(timezone.utc).isoformat(), 'decisions_verified_before_gold_utc': reconstruction_utc,
        'first_gold_read_utc': first_gold_utc, 'script_sha256': sha(__file__), 'no_inference_by_evaluator': True,
        'original_thresholds_preserved': THRESHOLDS, 'qwen_threshold_preserved': 12.75,
        'all_bge_saved_exact_mask': 'zero intentionally; semantic exact diagnostic recomputed independently from source for nonexact metrics',
        'source_exact_pair_n': sum(r['exact'] for r in rows.values()),
        'all_source_files_rehashed_unchanged': all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in HASHES.items()),
        'actual_vs_cached_threshold_replay': replay,
        'limitations': ['Only repeat0 predictions were saved; repeat-rank equality is asserted by the hashed executed runner and execution manifest, not independently recomputed from three prediction files.',
                        'Real GPU subset Qwen batches can produce BF16 score differences from old cached full-pool Qwen inference; reported metrics use actual new predictions.',
                        'Metric scope218 differs from actual timed batch scope220; no query-specific primary-only times were recorded.',
                        'Resident model inference time excludes checkpoint loading, retrieval and CSV import.',
                        'No GPT API latency/cost or GPT hybrid total latency was measured.']})
    print(json.dumps(safe({'status': 'passed', 'output': str(OUT), 'primary_metrics': [r for r in aggregate if r['evaluation_group'] == 'primary_heldout'], 'cached_comparison': replay}), ensure_ascii=False))


if __name__ == '__main__':
    evaluate()
