#!/usr/bin/env python3
"""Compose frozen threshold proposals with NEW blind compatibility judgments."""
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
DESIGN = BASE / 'results/exact_pair_route_before_cap'
BLIND = BASE / 'blind_fullpair_selective_gpt6_sol'
OUT = BASE / 'results/exact_pair_route_with_blind_gpt'
SOURCE = BASE.parent / 'rule_first_system_20261004/results/server'
spec = importlib.util.spec_from_file_location('frozen_pair_route', BASE / 'scripts/evaluate_exact_pair_route_before_cap.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def dump(p, v):
    Path(p).write_text(json.dumps(v, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def freeze():
    assert not OUT.exists(), 'Refuse to overwrite component freeze'
    OUT.mkdir(parents=True)
    dump(OUT / 'frozen_composition.json', {
        'status': 'fixed_boolean_veto_and_both_original_rankings_before_new_judgment_read',
        'utc': datetime.now(timezone.utc).isoformat(),
        'proposal_manifest_sha256': sha(DESIGN / 'frozen_manifest.json'),
        'input_sha256': sha(BLIND / 'inputs/query_pools.jsonl'),
        'prompt_sha256': sha(BLIND / 'inputs/system_prompt.txt'),
        'composition': 'Accept exact pairs unconditionally. For each seed, accept a nonexact pair iff its original BGE score passes its frozen original validation threshold AND the NEW shared blind compatibility judgment is true. Never add a BGE-rejected or unsubmitted pair. All other pairs explicitly reject.',
        'rankings': 'Report both previously frozen exact-priority and nonexact-first cap3 rankings, with unchanged BGE score/candidate-ID ordering. Verifier top3 does not determine either policy. No selection of the test-result winner.',
        'judgment_sharing': 'One new blind judgment shared by three original BGE seeds; not three independent GPT runs.',
        'selection_scope': '54 union proposals from19 queries, derived from all6195 nonexact pairs regardless exact count, frozen previously without labels or old judgments.',
        'retrospective_limitation': 'Original test already studied. This component is exploratory, not a new confirmatory test or SOTA claim.',
        'preparation_script_sha256': sha(__file__), 'new_outputs_read': False,
        'no_600_construction_gold': True, 'no_threshold_tuning': True,
    })
    print(str(OUT / 'frozen_composition.json'))


def evaluate():
    plan = json.loads((OUT / 'frozen_composition.json').read_text())
    assert sha(__file__) == plan['preparation_script_sha256']
    assert sha(DESIGN / 'frozen_manifest.json') == plan['proposal_manifest_sha256']
    freeze = json.loads((DESIGN / 'frozen_manifest.json').read_text())
    assert all(sha(BASE / p) == h for p, h in freeze['frozen_file_sha256'].items())
    assert all(sha(p) == h for p, h in freeze['source_sha256'].items())
    poolfile, outputfile = BLIND / 'inputs/query_pools.jsonl', BLIND / 'outputs/predictions.jsonl'
    assert sha(poolfile) == plan['input_sha256'] and sha(BLIND / 'inputs/system_prompt.txt') == plan['prompt_sha256']
    pools = [json.loads(l) for l in poolfile.read_text().splitlines() if l.strip()]
    out = [json.loads(l) for l in outputfile.read_text().splitlines() if l.strip()]
    pidx = {p['query_key']: p for p in pools}
    oidx = {o.get('query_id', o.get('query_key')): o for o in out}
    assert len(pidx) == len(oidx) == 19 and set(pidx) == set(oidx)
    accepted, decisions = set(), []
    for qkey, pool in pidx.items():
        o = oidx[qkey]
        candidates = {c['candidate_key'] for c in pool['candidates']}
        assert len(candidates) == len(pool['candidates'])
        yes = o.get('accepted', o.get('compatible_candidate_ids'))
        top3 = o.get('top3', o.get('top3_candidate_ids'))
        assert isinstance(yes, list) and isinstance(top3, list) and len(yes) == len(set(yes)) and set(yes) <= candidates
        assert len(top3) == min(3, len(yes)) and len(top3) == len(set(top3)) and set(top3) <= set(yes)
        notes = {j['candidate_id']: j for j in o.get('judgments', [])}
        if notes:
            assert set(notes) == candidates and len(notes) == len(o['judgments'])
            assert {c for c, j in notes.items() if j['compatible'] is True} == set(yes)
        accepted |= {(qkey, c) for c in yes}
        decisions += [{'query_key': qkey, 'candidate_key': c, 'verifier_accept': int(c in yes)} for c in candidates]
    mapping = pd.read_csv(DESIGN / 'private_mapping.csv')
    assert len(mapping) == 54 and mapping.pair_id.is_unique and set(zip(mapping.query_key, mapping.candidate_key)) == {(r['query_key'], r['candidate_key']) for r in decisions}
    decisions = mapping.merge(pd.DataFrame(decisions), on=['query_key', 'candidate_key'], validate='one_to_one')
    decisions.to_csv(OUT / 'new_blind_pair_decisions.csv', index=False)
    yesids = set(decisions[decisions.verifier_accept.eq(1)].pair_id)
    f = m.inputs()
    rows, q = f.to_dict('records'), defaultdict(list)
    for r in rows:
        q[r['evaluation_split'], r['query_id']].append(r)
    eligibility = pd.read_csv(DESIGN / 'private_eligibility.csv')
    frames = []
    for seed in m.SEEDS:
        scores = eligibility.set_index('pair_id')[f'score_seed_{seed}'].to_dict()
        eligible = set(eligibility[eligibility[f'eligible_seed_{seed}'].eq(1)].pair_id)
        keep = eligible & yesids
        for policy, ordering in [('exact_pair_bge_gpt_exact_priority', 'exact_first'), ('exact_pair_bge_gpt_nonexact_first', 'nonexact_first')]:
            ranks = {}
            for pool in q.values():
                ranks.update(m.ranked(pool, scores, keep, ordering))
            for r in rows:
                frames.append({'seed': seed, 'policy': policy, 'pair_id': r['pair_id'], 'evaluation_split': r['evaluation_split'],
                               'query_id': r['query_id'], 'candidate_id': r['candidate_id'], 'exact_match': r['exact_match'],
                               'score': scores[r['pair_id']] if not r['exact_match'] else np.nan, 'threshold': m.THRESHOLDS[seed],
                               'prediction': int(r['exact_match'] or r['pair_id'] in keep), 'returned_rank': ranks.get(r['pair_id'], 0),
                               'shared_gpt_judgment_n': 1})
    pred = pd.DataFrame(frames)
    assert len(pred) == 39600 and not pred.duplicated(['seed', 'policy', 'pair_id']).any() and pred.prediction.isin([0, 1]).all()
    pred.to_csv(OUT / 'predictions_before_gold.csv', index=False)
    before_utc, predhash = datetime.now(timezone.utc).isoformat(), sha(OUT / 'predictions_before_gold.csv')
    sm = json.loads((SOURCE / 'source_manifest.json').read_text())
    assert sha(SOURCE / 'labels.csv') == sm['labels_sha256']
    labels = pd.read_csv(SOURCE / 'labels.csv', usecols=['pair_id', 'final_label', 'difficulty']).set_index('pair_id')
    goldutc = datetime.now(timezone.utc).isoformat()
    gold, hard = labels.final_label.astype(int).to_dict(), labels.difficulty.eq('hard').to_dict()
    rowidx = f.set_index('pair_id').to_dict('index')
    full, hp, listed = [], [], []
    for (seed, policy), g in pred.groupby(['seed', 'policy']):
        pp, ranks = g.set_index('pair_id').prediction.to_dict(), g.set_index('pair_id').returned_rank.to_dict()
        for group, splits in m.GROUPS.items():
            ids = [pid for pid, r in rowidx.items() if r['evaluation_split'] in splits]
            hids = [pid for pid in ids if hard[pid]]
            qp = defaultdict(list)
            for pid in ids:
                qp[rowidx[pid]['evaluation_split'], rowidx[pid]['query_id']].append(pid)
            meta = {'seed': int(seed), 'policy': policy, 'evaluation_group': group, 'query_n': len(qp), 'pair_n': len(ids), 'shared_gpt_judgment_n': 1}
            full.append({**meta, **m.confusion(ids, pp, gold)})
            hp.append({**meta, 'hard_pair_n': len(hids), 'hard_positive_n': sum(gold[p] for p in hids), **m.confusion(hids, pp, gold)})
            returned = [pid for pid in ids if ranks[pid] > 0]
            tp, fp = sum(gold[p] for p in returned), sum(1-gold[p] for p in returned)
            htp, hfp = sum(gold[p] for p in returned if hard[p]), sum(1-gold[p] for p in returned if hard[p])
            positive, hpositive = sum(gold[p] for p in ids), sum(gold[p] for p in hids)
            posq, noq, hardq = [], [], []
            for pool in qp.values():
                ret = [p for p in pool if ranks[p] > 0]
                assert len(ret) <= 3 and sorted(ranks[p] for p in ret) == list(range(1, len(ret)+1)) and all(pp[p] == 1 for p in ret)
                pos, hpos = sum(gold[p] for p in pool), sum(gold[p] for p in pool if hard[p])
                rt, ht = sum(gold[p] for p in ret), sum(gold[p] for p in ret if hard[p])
                if pos:
                    posq.append((rt/pos, int(rt>0)))
                else:
                    noq.append(int(not ret))
                if hpos:
                    hardq.append((ht/hpos, int(ht>0)))
            listed.append({**meta, 'returned_tp_n': tp, 'returned_fp_n': fp, 'returned_fn_n': positive-tp,
                           'returned_precision_pct': 100*tp/(tp+fp) if tp+fp else np.nan,
                           'macro_recall_at3_pct': 100*np.mean([x[0] for x in posq]), 'hit_at3_pct': 100*np.mean([x[1] for x in posq]),
                           'no_reference_pool_rejection_pct': 100*np.mean(noq) if noq else np.nan,
                           'hard_positive_n': hpositive, 'returned_hard_tp_n': htp, 'returned_hard_fp_n': hfp,
                           'hard_returned_precision_pct': 100*htp/(htp+hfp) if htp+hfp else np.nan,
                           'hard_micro_recall_at3_pct': 100*htp/hpositive if hpositive else np.nan,
                           'hard_macro_recall_at3_pct': 100*np.mean([x[0] for x in hardq]) if hardq else np.nan,
                           'hard_hit_at3_pct': 100*np.mean([x[1] for x in hardq]) if hardq else np.nan})
    for name, vals in [('full_pair_metrics', full), ('hard_pair_metrics', hp), ('list_metrics', listed)]:
        table = pd.DataFrame(vals)
        table.to_csv(OUT / f'{name}.csv', index=False)
        num = [c for c in table if c not in ['seed', 'policy', 'evaluation_group', 'shared_gpt_judgment_n'] and pd.api.types.is_numeric_dtype(table[c])]
        aggregate = table.groupby(['evaluation_group', 'policy'])[num].mean().reset_index()
        aggregate['condition_n'], aggregate['shared_gpt_judgment_n'] = 3, 1
        aggregate.to_csv(OUT / f'{name}_aggregate.csv', index=False)
    dump(OUT / 'qa.json', {'status': 'passed', 'frozen_composition_sha256': sha(OUT / 'frozen_composition.json'),
         'blind_input_sha256': sha(poolfile), 'blind_output_sha256': sha(outputfile), 'prediction_sha256_before_gold': predhash,
         'prediction_completed_before_gold_utc': before_utc, 'first_gold_join_utc': goldutc, 'gold_sha256': sha(SOURCE / 'labels.csv'),
         'new_judged_query_n': len(pools), 'new_judged_pair_n': len(mapping), 'new_compatible_pair_n': len(yesids),
         'complete_binary_prediction_n': len(pred), 'one_new_shared_judgment_not_three_gpt_runs': True,
         'no_labels_used_for_proposal_or_ranking': True, 'no_threshold_retuning': True,
         'rankings_kept_both_not_winner_selected': True, 'no_new_600_gold_used': True,
         'latency_cost_limitation': 'No GPT API service latency/cost or complete hybrid end-to-end latency inferred. Local benchmark alone is not hybrid total.'})
    print(pd.read_csv(OUT / 'full_pair_metrics_aggregate.csv').query("evaluation_group in ['locked100','primary218']").to_string(index=False))
    print(pd.read_csv(OUT / 'list_metrics_aggregate.csv').query("evaluation_group in ['locked100','primary218']").to_string(index=False))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('phase', choices=['freeze', 'evaluate'])
    a = p.parse_args()
    freeze() if a.phase == 'freeze' else evaluate()
