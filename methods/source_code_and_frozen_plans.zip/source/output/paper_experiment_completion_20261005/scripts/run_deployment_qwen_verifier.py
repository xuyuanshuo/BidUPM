#!/usr/bin/env python3
"""Actual Qwen3-4B-Instruct-only deployment; no BGE load, no labels."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
os.environ.setdefault('HF_HUB_OFFLINE','1');os.environ.setdefault('TRANSFORMERS_OFFLINE','1');os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer,AutoModelForCausalLM
ROOT=Path('experiment_runtime')
sys.path.insert(0,str(ROOT/'scripts'))
from local_experiment_utils import item_text
from run_open_llm_verifier_local import render_prompt,answer_token_id
FIELDS=tuple(f'{side}_{field}' for side in ('query','candidate') for field in ('description','normalized_description','normalized_unit','category','spec_tokens'))


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def canonical(v):return ' '.join(re.sub(r'[^a-z0-9]+',' ',str(v).lower().replace('&',' and ')).split())
def unit(v):return ' '.join(str(v).lower().split())
def exact(f):
    qd=f.query_normalized_description.map(canonical);cd=f.candidate_normalized_description.map(canonical)
    qu=f.query_normalized_unit.map(unit);cu=f.candidate_normalized_unit.map(unit)
    return qd.ne('')&qu.ne('')&qd.eq(cd)&qu.eq(cu)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    plan=json.loads((a.input/'input_manifest.json').read_text())
    assert plan['status']=='FROZEN_BEFORE_QWEN_ONLY_INFERENCE' and not plan['new_bge_inference'] and not plan['human_gold_read'] and not plan['construction_labels_read']
    assert sha(__file__)==plan['runner_sha256']
    for rel,h in plan['input_file_sha256'].items():assert sha(a.input/rel)==h,rel
    assert sha(ROOT/'scripts/local_experiment_utils.py')==plan['source_serializer_sha256']
    assert sha(ROOT/'scripts/run_open_llm_verifier_local.py')==plan['source_prompt_renderer_sha256']
    qman=ROOT/'runs/qwen3_4b_instruct_verifier/manifest.json';qtp=ROOT/'runs/qwen3_4b_instruct_verifier/validation_thresholds.csv'
    assert sha(qman)==plan['qwen_original_manifest_sha256'] and sha(qtp)==plan['qwen_original_threshold_file_sha256']
    qm=json.loads(qman.read_text());qt=pd.read_csv(qtp)
    assert qm['base_model']==plan['qwen_model']=='Qwen/Qwen3-4B-Instruct-2507'
    assert float(qt.loc[qt.policy.eq('f1_opt'),'threshold'].iloc[0])==plan['qwen_threshold']==12.75
    cp=Path(qm['base_model_load_path']);assert cp==Path(plan['qwen_model_load_path'])
    for name,h in plan['qwen_model_weight_sha256'].items():assert sha(cp/name)==h
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported() and not a.output.exists()
    a.output.mkdir(parents=True)
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    manifest={'status':'running','input_manifest_sha256':sha(a.input/'input_manifest.json'),'script_sha256':sha(__file__),
              'model':plan['qwen_model'],'model_revision':plan['qwen_revision'],'model_weight_sha256_verified':plan['qwen_model_weight_sha256'],
              'qwen_threshold':12.75,'threshold_file_sha256':sha(qtp),'serializer_sha256':plan['source_serializer_sha256'],
              'prompt_renderer_sha256':plan['source_prompt_renderer_sha256'],'new_bge_inference':False,'labels_read':False,
              'new_training':False,'thresholds_retuned':False,'gpu':torch.cuda.get_device_name(0),'dtype':'CUDA BF16',
              'batch_size':24,'max_length':256,'repeats':3,'timing_scope':plan['timing_scope'],'completed_conditions':[]}
    dump(a.output/'execution_manifest.json',manifest)
    tok=AutoTokenizer.from_pretrained(cp,padding_side='left',local_files_only=True);tok.pad_token=tok.pad_token or tok.eos_token
    model=AutoModelForCausalLM.from_pretrained(cp,dtype=torch.bfloat16,attn_implementation='sdpa',local_files_only=True).to('cuda').eval()
    yes,no=answer_token_id(tok,'yes'),answer_token_id(tok,'no')
    times=[];cache={}
    @torch.inference_mode()
    def execute(sub):
        torch.cuda.synchronize();start=time.perf_counter()
        qs=item_text(sub,'query','full');cs=item_text(sub,'candidate','full');prompts=[render_prompt(tok,x,y) for x,y in zip(qs,cs)]
        vals=[];tokens=0
        for lo in range(0,len(sub),24):
            enc=tok(prompts[lo:lo+24],padding=True,truncation=True,max_length=256,pad_to_multiple_of=8,return_tensors='pt')
            tokens+=int(enc['attention_mask'].sum());enc={k:v.to('cuda') for k,v in enc.items()}
            with torch.autocast('cuda',dtype=torch.bfloat16):logit=model(**enc).logits[:,-1,:]
            vals.extend((logit[:,yes]-logit[:,no]).float().cpu().numpy().tolist())
        torch.cuda.synchronize();seconds=time.perf_counter()-start
        return np.asarray(vals,float),tokens,seconds
    for condition in plan['conditions']:
        key=condition['model_input_file']
        if key not in cache:
            cache[key]=pd.read_csv(a.input/key,dtype=str,keep_default_na=False)
            assert set(FIELDS)<=set(cache[key]) and not set(cache[key])&{'label','final_label','difficulty','provisional_label','final_relevance','query_item_code','candidate_item_code'}
        features=cache[key]
        if condition['source_year'] is not None:features=features[features.source_year.eq(str(condition['source_year']))].copy()
        else:features=features.copy()
        bge=pd.read_csv(a.input/condition['bge_prediction_file'],usecols=['pair_id','score','threshold','prediction'],float_precision='round_trip')
        frame=features.merge(bge,on='pair_id',validate='one_to_one',sort=False)
        assert len(frame)==condition['pair_n'] and frame.pair_id.is_unique and frame.threshold.eq(condition['bge_threshold']).all()
        assert frame.prediction.eq(frame.score.ge(condition['bge_threshold']).astype(int)).all()
        frame['exact_match']=exact(frame).astype(int);selected=frame.prediction.eq(1)&frame.exact_match.eq(0)
        assert int(selected.sum())==condition['qwen_selected_pair_n'] and int(frame.exact_match.sum())==condition['exact_pair_n']
        sub=frame[selected].copy();torch.manual_seed(int(condition['seed']))
        execute(sub.head(24)) # resident warm-up, excluded from repetitions
        reference_score=None;reference_pass=None
        for repeat in range(3):
            score,tokens,seconds=execute(sub)
            passed=score>=12.75
            assert np.isfinite(score).all() and len(score)==len(sub)
            if reference_pass is None:reference_score,reference_pass=score.copy(),passed.copy()
            else:assert np.array_equal(reference_pass,passed),'Repeat acceptance changed'
            times.append({'condition_id':condition['condition_id'],'dataset':condition['dataset'],'source_year':condition['source_year'],
                          'seed':condition['seed'],'repeat':repeat,'source_pair_n':len(frame),'qwen_pair_n':len(sub),
                          'qwen_prompt_tokens':tokens,'seconds':seconds,'qwen_passed_pairs':int(passed.sum()),'qwen_review_pending_pairs':int((~passed).sum())})
            print('FINISH',condition['condition_id'],repeat,'calls',len(sub),'pass',int(passed.sum()),'seconds',round(seconds,5),flush=True)
        identities=[c for c in ('pair_id','evaluation_split','query_id','source_year','candidate_id') if c in frame]
        out=frame[identities].copy();out['dataset']=condition['dataset'];out['seed']=condition['seed'];out['source_variant']='full' if condition['dataset']=='challenge600' else 'scope_core'
        out['bge_score']=frame.score;out['bge_threshold']=frame.threshold;out['source_bge_prediction']=frame.prediction;out['exact_match']=frame.exact_match
        out['qwen_called']=selected.astype(int);out['qwen_score']=np.nan;out.loc[selected,'qwen_score']=reference_score
        out['qwen_threshold']=12.75;out['accepted']=(frame.exact_match.eq(1)|out.qwen_score.ge(12.75)).astype(int)
        out['review_pending']=(selected&out.qwen_score.lt(12.75)).astype(int)
        out['bge_candidate_accepted']=(frame.exact_match.eq(1)|selected).astype(int)
        out['status']=np.select([frame.exact_match.eq(1),selected&out.qwen_score.ge(12.75),selected&out.qwen_score.lt(12.75)],
                               ['exact_accepted','verifier_accepted','review_pending'],default='not_proposed')
        path=a.output/(condition['condition_id']+'.csv');out.to_csv(path,index=False)
        manifest['completed_conditions'].append({**condition,'output':path.name,'output_sha256':sha(path),
              'accepted_pair_n':int(out.accepted.sum()),'review_pending_pair_n':int(out.review_pending.sum()),
              'three_repeat_acceptance_identical':True,'prediction_repeat_retained':0})
        pd.DataFrame(times).to_csv(a.output/'timing.csv',index=False);dump(a.output/'execution_manifest.json',manifest)
    assert len(times)==27 and len(manifest['completed_conditions'])==9
    manifest['status']='complete';manifest['timing_sha256']=sha(a.output/'timing.csv');dump(a.output/'execution_manifest.json',manifest)
    print('ALL_COMPLETE',flush=True)


if __name__=='__main__':main()
