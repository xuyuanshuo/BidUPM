#!/usr/bin/env python3
"""Frozen hard strata, actual final lists, and diagnostic failure paths only."""
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE.parent / 'rule_first_system_20261004/results/server'
OLD = BASE.parent / 'rule_first_system_validation_20261005'
OUT = BASE / 'results/hard_sample_evaluation'
SEEDS = (20260904, 20260905, 20260906)
GROUPS = {'locked': ['locked'], 'internal_primary': ['locked', 'no_reference'],
          'primary_heldout': ['locked', 'no_reference', 'external'], 'external': ['external'],
          'all_formal': ['locked', 'no_reference', 'external', 'no_reference_reclassified']}
HASHES, CHECKS = {}, []


def sha(path):
    path = Path(path)
    h = hashlib.sha256(path.read_bytes()).hexdigest()
    HASHES.setdefault(str(path.resolve()), h)
    return h


def load(path):
    sha(path)
    return json.loads(Path(path).read_text())


def read(path, **kwargs):
    sha(path)
    return pd.read_csv(path, **kwargs)


def check(name, v, details=None):
    CHECKS.append({'check': name, 'passed': bool(v), 'details': details})
    if not v:
        raise ValueError(name)


def canonical(s):
    return ' '.join(re.sub(r'[^a-z0-9]+', ' ', s.lower().replace('&', ' and ')).split())


def safe(v):
    if isinstance(v, dict):
        return {str(k): safe(x) for k, x in v.items()}
    if isinstance(v, (tuple, list)):
        return [safe(x) for x in v]
    if isinstance(v, (np.integer, np.bool_)):
        return v.item()
    if isinstance(v, (float, np.floating)):
        return float(v) if np.isfinite(v) else None
    return v


def evaluate():
    OUT.mkdir(parents=True, exist_ok=True)
    source = load(SOURCE / 'source_manifest.json')
    check('authoritative frozen source and labels SHA', sha(SOURCE / 'inputs.csv') == source['inputs_sha256'] and sha(SOURCE / 'labels.csv') == source['labels_sha256'])
    inputs = read(SOURCE / 'inputs.csv', dtype=str, keep_default_na=False)
    inputs = inputs[inputs.evaluation_split.ne('validation')]
    labels = read(SOURCE / 'labels.csv', dtype={'pair_id': str}, keep_default_na=False)
    check('labels unique binary frozen difficulty', labels.pair_id.is_unique and labels.final_label.isin([0, 1]).all() and labels.difficulty.isin(['easy', 'hard']).all())
    data = inputs.merge(labels, on='pair_id', validate='one_to_one')
    data['exact'] = [int(bool(canonical(qd) and qu.strip() and canonical(qd) == canonical(cd) and ' '.join(qu.lower().split()) == ' '.join(cu.lower().split())))
                     for qd, cd, qu, cu in data[['query_normalized_description', 'candidate_normalized_description', 'query_normalized_unit', 'candidate_normalized_unit']].itertuples(index=False, name=None)]
    data['exact_count'] = data.groupby(['evaluation_split', 'query_id']).exact.transform('sum')
    rows = data.set_index('pair_id').to_dict('index')
    pools = {k: g for k, g in data.groupby(['evaluation_split', 'query_id'])}
    check('original 220 x30 pool closure', len(rows) == 6600 and len(pools) == 220 and all(len(g) == 30 for g in pools.values()))
    strata = []
    for split, g in data.groupby('evaluation_split'):
        h = g[g.difficulty.eq('hard')]
        hp = h[h.final_label.eq(1)]
        strata.append({'evaluation_split': split, 'query_n': g.query_id.nunique(), 'hard_pair_n': len(h), 'hard_positive_n': len(hp), 'hard_negative_n': len(h)-len(hp),
                       'hard_positive_query_n': hp.query_id.nunique(), 'hard_positive_exact_n': int(hp.exact.sum()), 'hard_positive_blocked_by_E_ge3_n': int(hp.exact_count.ge(3).sum())})
    locked = next(r for r in strata if r['evaluation_split'] == 'locked')
    check('original Table4 hard stratum 2411/23', locked['hard_pair_n'] == 2411 and locked['hard_positive_n'] == 23 and locked['hard_positive_query_n'] == 10)
    check('all locked hard positives nonexact;19 structurally blocked', locked['hard_positive_exact_n'] == 0 and locked['hard_positive_blocked_by_E_ge3_n'] == 19)
    frames, lookup = [], {}
    actualroot = BASE / 'results/local_verifier_system'
    manifest = load(actualroot / 'execution_manifest.json')
    for run in manifest['completed_runs']:
        seed = int(run['seed'])
        path = actualroot / run['output']
        check('actual prediction SHA ' + str(seed), sha(path) == run['sha256'])
        f = read(path, float_precision='round_trip')
        check('actual 4x6600 IDs ' + str(seed), len(f) == 26400 and not f.duplicated(['policy', 'pair_id']).any())
        for name, g in f.groupby('policy'):
            frames.append(g[['seed', 'policy', 'pair_id', 'prediction', 'returned_rank']])
            lookup[seed, name] = g.set_index('pair_id').to_dict('index')
    expqa = load(BASE / 'results/expanded_system_evaluation/qa.json')
    exppath = BASE / 'results/expanded_system_evaluation/reconstructed_predictions_before_gold.csv'
    check('frozen expanded decisions integrity', sha(exppath) == expqa['prediction_sha256_before_gold'])
    exp = read(exppath)
    expanded = exp[exp.policy.eq('expanded_verified_k10')].copy()
    frames.append(expanded[['seed', 'policy', 'pair_id', 'prediction', 'returned_rank']])
    for seed, g in expanded.groupby('seed'):
        lookup[int(seed), 'expanded_verified_k10'] = g.set_index('pair_id').to_dict('index')
    # Full GPT is reconstructed from one original saved judgment, not three runs.
    gptqa = load(OLD / 'results/gpt6_sol_blind/evaluation/qa.json')
    gp = OLD / 'blind_gpt6_sol/outputs/predictions.jsonl'
    check('old blind GPT judgment integrity', sha(gp) == gptqa['blind_integrity']['prediction_sha256'])
    mapping = read(OLD / 'results/gpt6_sol_blind/private_mapping.csv', dtype=str, keep_default_na=False)
    decode = {(r.query_key, r.candidate_key): r.pair_id for r in mapping.itertuples()}
    accepted, ranks = set(), {}
    for j in [json.loads(line) for line in gp.read_text().splitlines() if line.strip()]:
        accepted.update(decode[j['query_key'], c] for c in j['accepted_candidates'])
        ranks.update({decode[j['query_key'], c]: i for i, c in enumerate(j['top3'], 1)})
    full = pd.DataFrame([{'seed': 0, 'policy': 'gpt6_sol_fullpool', 'pair_id': pid, 'prediction': int(pid in accepted), 'returned_rank': ranks.get(pid, 0)} for pid in rows])
    frames.append(full)
    lookup[0, 'gpt6_sol_fullpool'] = full.set_index('pair_id').to_dict('index')
    eranks = {}
    for pool in pools.values():
        ex = pool[pool.exact.eq(1)].sort_values('candidate_id').head(3)
        eranks.update({pid: i for i, pid in enumerate(ex.pair_id, 1)})
    rule = pd.DataFrame([{'seed': 0, 'policy': 'rule_only', 'pair_id': pid, 'prediction': r['exact'], 'returned_rank': eranks.get(pid, 0)} for pid, r in rows.items()])
    frames.append(rule)
    lookup[0, 'rule_only'] = rule.set_index('pair_id').to_dict('index')
    predictions = pd.concat(frames, ignore_index=True)
    check('17 defined list conditions', len(predictions) == 17*6600 and not predictions.duplicated(['seed', 'policy', 'pair_id']).any())
    predictions = predictions.merge(data, on='pair_id', validate='many_to_one')
    eligibility = read(BASE / 'results/expanded_candidate_design/private_eligibility.csv').set_index('pair_id')
    judgments = read(BASE / 'results/expanded_system_evaluation/all_verifier_decisions.csv', usecols=['pair_id', 'verifier_accept']).set_index('pair_id').verifier_accept.to_dict()
    result, perquery, failures, negatives, oracles = [], [], [], [], []
    for group, splits in GROUPS.items():
        gd = data[data.evaluation_split.isin(splits)]
        hp = gd[gd.difficulty.eq('hard') & gd.final_label.eq(1)]
        unrestricted, exactpriority = 0, 0
        hardquery_n, blocked_query_n = 0, 0
        for key, pool in gd.groupby(['evaluation_split', 'query_id']):
            positives = pool[pool.difficulty.eq('hard') & pool.final_label.eq(1)]
            if len(positives):
                hardquery_n += 1
                blocked_query_n += int(int(pool.exact.sum()) >= 3)
            unrestricted += min(3, len(positives))
            exactpriority += min(3, int(positives.exact.sum())) + min(max(0, 3-int(pool.exact.sum())), int(positives.exact.eq(0).sum()))
        oracles.append({'evaluation_group': group, 'query_n': gd.query_id.nunique(), 'hard_positive_n': len(hp), 'hard_positive_query_n': hardquery_n,
                        'hard_positive_blocked_E_ge3_n': int(hp.exact_count.ge(3).sum()), 'hard_positive_queries_blocked_E_ge3_n': blocked_query_n,
                        'unrestricted_cap3_hard_oracle_n': unrestricted, 'exact_priority_cap3_hard_oracle_n': exactpriority,
                        'exact_priority_cap3_hard_oracle_recall_pct': 100*exactpriority/len(hp) if len(hp) else np.nan,
                        'interpretation': 'Evaluation-only structural upper bound using frozen gold; no actual candidate order is changed.'})
        for (seed, policy), frame in predictions[predictions.evaluation_split.isin(splits)].groupby(['seed', 'policy']):
            hard = frame[frame.difficulty.eq('hard')]
            ret = hard.returned_rank.gt(0)
            pos = hard.final_label.eq(1)
            tp, fp, npos = int((ret & pos).sum()), int((ret & ~pos).sum()), int(pos.sum())
            qr, hit = [], []
            for key, q in frame.groupby(['evaluation_split', 'query_id']):
                hpos = q[q.difficulty.eq('hard') & q.final_label.eq(1)]
                if not len(hpos):
                    continue
                htp = int(hpos.returned_rank.gt(0).sum())
                qr.append(htp/len(hpos)); hit.append(int(htp > 0))
                perquery.append({'evaluation_group': group, 'seed': int(seed), 'policy': policy, 'evaluation_split': key[0], 'query_id': key[1],
                                 'hard_positive_n': len(hpos), 'returned_hard_tp_n': htp, 'hard_recall_at3': htp/len(hpos), 'hard_hit_at3': int(htp>0)})
            result.append({'evaluation_group': group, 'seed': int(seed), 'policy': policy, 'query_n': frame.query_id.nunique(),
                           'hard_pair_n': len(hard), 'hard_positive_n': npos, 'hard_positive_query_n': len(qr),
                           'returned_hard_n': tp+fp, 'returned_hard_tp_n': tp, 'returned_hard_fp_n': fp, 'unreturned_hard_positive_n': npos-tp,
                           'hard_returned_precision_pct': 100*tp/(tp+fp) if tp+fp else np.nan,
                           'hard_micro_recall_at3_pct': 100*tp/npos if npos else np.nan,
                           'hard_macro_recall_at3_pct': 100*np.mean(qr) if qr else np.nan,
                           'hard_hit_at3_pct': 100*np.mean(hit) if hit else np.nan,
                           'judgment_repetition_n': 1 if 'gpt' in policy or policy == 'expanded_verified_k10' else 0,
                           'metric_scope': 'Hard pairs inside actual final capped list; not complete-pair classification F1'})
            # A second vectorized count closes the loop against the hard-positive query table.
            check('hard TP query closure ' + str((group, int(seed), policy)), sum(r['returned_hard_tp_n'] for r in perquery if r['evaluation_group']==group and r['seed']==int(seed) and r['policy']==policy) == tp)
    # Failure paths are one record per condition and hard positive, with saved source evidence.
    for (seed, policy), stored in lookup.items():
        for pid, r in rows.items():
            if r['difficulty'] != 'hard':
                continue
            d = stored[pid]
            if int(r['final_label']) == 0:
                if int(d['returned_rank']) > 0:
                    negatives.append({'seed': seed, 'policy': policy, 'pair_id': pid, 'evaluation_split': r['evaluation_split'], 'query_id': r['query_id'],
                                      'returned_rank': int(d['returned_rank']), 'query_description': r['query_description'], 'candidate_description': r['candidate_description'],
                                      'query_unit': r['query_normalized_unit'], 'candidate_unit': r['candidate_normalized_unit']})
                continue
            found = int(d['returned_rank']) > 0
            if found:
                stage = 'returned_hard_positive'
            elif policy == 'rule_only':
                stage = 'nonexact_not_accepted_by_rule'
            elif policy.startswith('rule_bge') or policy == 'expanded_verified_k10':
                if int(r['exact_count']) >= 3:
                    stage = 'blocked_by_three_exact_references'
                elif policy == 'expanded_verified_k10':
                    stage = 'outside_bge_top10' if int(eligibility.loc[pid, f'eligible_k10_seed_{seed}']) == 0 else 'gpt_rejected' if judgments.get(pid, 0) == 0 else 'accepted_not_returned_after_cap3'
                elif policy == 'rule_bge_qwen_top10':
                    stage = 'outside_bge_top10' if int(d['qwen_called']) == 0 else 'qwen_threshold_rejected' if float(d['qwen_score']) < 12.75 else 'accepted_not_returned_after_cap3'
                elif float(d['score']) < float(d['threshold']):
                    stage = 'bge_threshold_rejected'
                elif policy == 'rule_bge_qwen_threshold' and float(d['qwen_score']) < 12.75:
                    stage = 'qwen_threshold_rejected'
                else:
                    stage = 'accepted_not_returned_after_cap3'
            elif policy == 'all_bge':
                stage = 'bge_threshold_rejected' if int(d['prediction']) == 0 else 'accepted_not_returned_after_score_top3'
            else:
                stage = 'gpt_rejected' if int(d['prediction']) == 0 else 'gpt_accepted_not_returned_in_top3'
            failures.append({'seed': seed, 'policy': policy, 'pair_id': pid, 'evaluation_split': r['evaluation_split'], 'query_id': r['query_id'],
                             'candidate_id': r['candidate_id'], 'hard_positive': True, 'exact_count': r['exact_count'], 'exact_match': r['exact'],
                             'accepted_prediction': int(d['prediction']), 'returned_rank': int(d['returned_rank']), 'failure_or_success_path': stage,
                             'bge_score': d.get('score', np.nan), 'bge_threshold': d.get('threshold', np.nan), 'qwen_score': d.get('qwen_score', np.nan),
                             'query_description': r['query_description'], 'candidate_description': r['candidate_description'],
                             'query_unit': r['query_normalized_unit'], 'candidate_unit': r['candidate_normalized_unit']})
    rdf = pd.DataFrame(result)
    aggregated = []
    for (group, policy), g in rdf.groupby(['evaluation_group', 'policy']):
        metrics = ['returned_hard_tp_n', 'returned_hard_fp_n', 'unreturned_hard_positive_n', 'hard_returned_precision_pct', 'hard_micro_recall_at3_pct', 'hard_macro_recall_at3_pct', 'hard_hit_at3_pct']
        aggregated.append({'evaluation_group': group, 'policy': policy, 'condition_n': len(g), 'shared_gpt_judgment_n': 1 if 'gpt' in policy or policy == 'expanded_verified_k10' else 0,
                           'query_n': int(g.query_n.iloc[0]), 'hard_pair_n': int(g.hard_pair_n.iloc[0]), 'hard_positive_n': int(g.hard_positive_n.iloc[0]), 'hard_positive_query_n': int(g.hard_positive_query_n.iloc[0]),
                           **{m+'_mean': float(g[m].mean()) for m in metrics}, **{m+'_sample_sd': float(g[m].std(ddof=1)) if len(g)>1 else np.nan for m in metrics}})
    check('actual threshold hard TP1/FP0 perseed locked', rdf[rdf.evaluation_group.eq('locked') & rdf.policy.eq('rule_bge_qwen_threshold')].returned_hard_tp_n.eq(1).all() and rdf[rdf.evaluation_group.eq('locked') & rdf.policy.eq('rule_bge_qwen_threshold')].returned_hard_fp_n.eq(0).all())
    check('rule hard precision left undefined', rdf[rdf.policy.eq('rule_only')].hard_returned_precision_pct.isna().all())
    pd.DataFrame(strata).to_csv(OUT/'hard_stratum_denominators.csv', index=False)
    rdf.to_csv(OUT/'hard_returned_lists.csv', index=False)
    pd.DataFrame(aggregated).to_csv(OUT/'hard_returned_lists_aggregate.csv', index=False)
    pd.DataFrame(perquery).to_csv(OUT/'hard_positive_query_metrics.csv', index=False)
    pd.DataFrame(oracles).to_csv(OUT/'hard_structural_oracles.csv', index=False)
    fd = pd.DataFrame(failures)
    fd.to_csv(OUT/'transparent_failurepaths.csv', index=False)
    fd.groupby(['policy', 'seed', 'evaluation_split', 'failure_or_success_path']).size().reset_index(name='hard_positive_n').to_csv(OUT/'failurepath_counts.csv', index=False)
    pd.DataFrame(negatives).to_csv(OUT/'returned_hard_false_positives.csv', index=False)
    check('hard-positive failure paths complete', len(fd) == 17*29 and not fd.duplicated(['seed', 'policy', 'pair_id']).any())
    check('all read source bytes unchanged', all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in HASHES.items()))
    qa = {'status': 'passed', 'created_utc': datetime.now(timezone.utc).isoformat(), 'checks': CHECKS, 'source_hashes': HASHES,
          'source_files_unchanged': True, 'evaluation_script_sha256': sha(__file__), 'no_predictions_or_labels_changed': True,
          'new_model_calls': 0, 'construction600_labels_scored': False, 'difficulty_source': 'original authoritative frozen labels.csv difficulty field',
          'full_gpt_list_condition_n': 1, 'expanded_gpt_shared_judgment_n': 1,
          'limitations': ['Hard-return precision and recall evaluate frozen hard pairs appearing in the final max3 lists; they are not complete-pair P/R/F1.',
                          'The full GPT judgment is one saved run; expanded three-seed lists share one expanded judgment.',
                          'Structural oracle is an evaluation-only upper bound; it neither retunes thresholds nor changes actual rankings.',
                          'Constructed600 is excluded because saved human annotation fields are empty.']}
    (OUT/'hard_returned_qa.json').write_text(json.dumps(safe(qa),ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(safe({'status':'passed','aggregate_locked':[r for r in aggregated if r['evaluation_group']=='locked'], 'oracles':oracles}),ensure_ascii=False))


if __name__ == '__main__':
    evaluate()
