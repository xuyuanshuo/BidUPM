#!/usr/bin/env python3
"""Finish frozen 600-pair inference, without consulting any labels."""
import argparse,gc,hashlib,json,os,sys,time
from pathlib import Path
os.environ.setdefault('HF_HUB_OFFLINE','1');os.environ.setdefault('TRANSFORMERS_OFFLINE','1');os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer,AutoModelForSequenceClassification
from peft import PeftModel
ROOT=Path('experiment_runtime')
sys.path.insert(0,str(ROOT/'scripts'))
from local_experiment_utils import item_text
from run_qwen_reranker import QwenPairCollator,load_base_model,label_token_ids

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v): Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,required=True);ap.add_argument('--plan',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    plan=json.loads(a.plan.read_text());frozen=json.loads((a.data/'freeze_manifest.json').read_text())
    assert sha(a.data/'model_inputs_only.csv')==frozen['model_input_csv_sha256']
    frame=pd.read_csv(a.data/'model_inputs_only.csv',dtype=str,keep_default_na=False)
    assert len(frame)==600 and frame.pair_id.nunique()==600
    assert not set(frame)&{'label','final_label','provisional_label','difficulty','annotator_a_label','annotator_b_label'}
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    assert not a.output.exists();a.output.mkdir(parents=True)
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    manifest={'status':'running','pair_n':600,'gpu':torch.cuda.get_device_name(0),'labels_accessed':False,'new_training':False,'new_threshold_selection':False,'input_sha256':sha(a.data/'model_inputs_only.csv'),'plan_sha256':sha(a.plan),'script_sha256':sha(__file__),'repeats':3,'scope':'constructed controlled challenge predictions, not human-gold accuracy','completed_runs':[]}
    dump(a.output/'execution_manifest.json',manifest);times=[]
    for run in plan['runs']:
        cp=Path(run['checkpoint']);threshold=float(run['threshold']);bs=int(run['batch_size']);variant=run['input_variant'];kind=run['kind'];rid=run['run_id']
        threshold_path=ROOT/Path(run['threshold_file']).relative_to('output/remote_experiments_20260923')
        assert sha(threshold_path)==run['threshold_file_sha256'],rid+' threshold hash'
        assert sha(threshold_path.parent/'manifest.json')==run['original_manifest_sha256'],rid+' manifest hash'
        weights={p.name:sha(p) for p in cp.glob('*.safetensors')};assert weights
        torch.manual_seed(int(run['seed'] or 20260904));torch.cuda.synchronize();start=time.perf_counter()
        if kind=='bge':
            tok=AutoTokenizer.from_pretrained(cp,local_files_only=True);model=AutoModelForSequenceClassification.from_pretrained(cp,local_files_only=True).to('cuda').eval()
        else:
            tok=AutoTokenizer.from_pretrained(run['base_model_path'],local_files_only=True,padding_side='left');tok.pad_token=tok.pad_token or tok.eos_token
            model=PeftModel.from_pretrained(load_base_model(run['base_model_path'],torch.device('cuda')),cp).eval()
            collator=QwenPairCollator(tok,int(run['max_length']),run['instruction']);no_id,yes_id=label_token_ids(tok)
        torch.cuda.synchronize();loading=time.perf_counter()-start
        @torch.inference_mode()
        def score(data):
            torch.cuda.synchronize();started=time.perf_counter();q=item_text(data,'query',variant);c=item_text(data,'candidate',variant);ans=[]
            for lo in range(0,len(data),bs):
                if kind=='bge':enc=tok(q[lo:lo+bs],c[lo:lo+bs],padding=True,truncation=True,max_length=int(run['max_length']),return_tensors='pt')
                else:
                    enc=collator([(x,y,0,0.0) for x,y in zip(q[lo:lo+bs],c[lo:lo+bs])]);enc.pop('labels_local');enc.pop('hard_local')
                enc={k:v.to('cuda') for k,v in enc.items()}
                with torch.autocast('cuda',dtype=torch.bfloat16):
                    out=model(**enc).logits;logit=out.reshape(-1) if kind=='bge' else out[:,-1,yes_id]-out[:,-1,no_id]
                ans.extend(logit.float().cpu().numpy().tolist())
            torch.cuda.synchronize();return np.array(ans),time.perf_counter()-started
        score(frame.head(bs));reference=None
        for repeat in range(3):
            scores,secs=score(frame);assert np.isfinite(scores).all();prediction=(scores>=threshold).astype(int)
            if reference is not None:assert np.array_equal(reference,prediction),'Repeat decision changed'
            reference=prediction
            times.append({'run_id':rid,'kind':kind,'seed':run['seed'],'repeat':repeat,'pair_n':600,'seconds':secs,'model_load_seconds':loading,'batch_size':bs})
        out=frame[['pair_id']].copy();out['score']=scores;out['threshold']=threshold;out['prediction']=prediction
        path=a.output/(rid+'.csv');out.to_csv(path,index=False)
        manifest['completed_runs'].append({'run_id':rid,'seed':run['seed'],'variant':variant,'threshold':threshold,'checkpoint':str(cp),'checkpoint_weight_sha256':weights,'threshold_sha256':sha(threshold_path),'output_sha256':sha(path),'output':path.name,'positive_predictions':int(prediction.sum()),'repeat_decisions_identical':True})
        dump(a.output/'execution_manifest.json',manifest);pd.DataFrame(times).to_csv(a.output/'timing.csv',index=False)
        print('FINISH',rid,round(secs,3),int(prediction.sum()),flush=True)
        del model,tok;gc.collect();torch.cuda.empty_cache()
    assert len(manifest['completed_runs'])==len(plan['runs'])==16
    manifest['status']='complete';manifest['timing_sha256']=sha(a.output/'timing.csv');dump(a.output/'execution_manifest.json',manifest)
    print('ALL_COMPLETE',flush=True)
if __name__=='__main__':main()
