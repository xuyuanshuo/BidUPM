#!/usr/bin/env python3
"""Post-freeze transparent diagnostics; never feeds proposal or ranking."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'results/exact_pair_route_before_cap'
SOURCE = BASE.parent / 'rule_first_system_20261004/results/server'
GROUPS = {'locked100': ['locked'], 'internal138': ['locked', 'no_reference'],
          'WSDOT80': ['external'], 'primary218': ['locked', 'no_reference', 'external'],
          'supplementary220': ['locked', 'no_reference', 'external', 'no_reference_reclassified']}


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    freeze = json.loads((OUT / 'frozen_manifest.json').read_text())
    assert all(sha(BASE / p) == h for p, h in freeze['frozen_file_sha256'].items())
    labels = pd.read_csv(SOURCE / 'labels.csv', usecols=['pair_id', 'final_label', 'difficulty'])
    f = pd.read_csv(SOURCE / 'inputs.csv', dtype=str, keep_default_na=False)
    pred = pd.read_csv(OUT / 'predictions_before_gold.csv')
    data = pred.merge(labels, on='pair_id', validate='many_to_one').merge(
        f[['pair_id', 'query_description', 'candidate_description', 'query_normalized_unit', 'candidate_normalized_unit']],
        on='pair_id', validate='many_to_one')
    hard_positive = data[(data.difficulty.eq('hard')) & data.final_label.eq(1)].copy()
    hard_positive['path'] = ['returned' if rank > 0 else 'bge_threshold_rejected' if accept == 0 else 'accepted_but_omitted_by_cap3'
                            for rank, accept in hard_positive[['returned_rank', 'prediction']].itertuples(index=False, name=None)]
    hard_positive.to_csv(OUT / 'hard_positive_failurepaths.csv', index=False)
    transitions, counts = [], []
    for seed in (20260904, 20260905, 20260906):
        e = data[(data.seed.eq(seed)) & data.policy.eq('exact_pair_bge_exact_priority')].set_index('pair_id')
        n = data[(data.seed.eq(seed)) & data.policy.eq('exact_pair_bge_nonexact_first')].set_index('pair_id')
        assert e.prediction.equals(n.prediction)
        for pid in e.index:
            if bool(e.loc[pid, 'returned_rank']) == bool(n.loc[pid, 'returned_rank']):
                continue
            r = e.loc[pid]
            transitions.append({'seed': seed, 'pair_id': pid, 'evaluation_split': r.evaluation_split, 'query_id': r.query_id,
                                'candidate_id': r.candidate_id, 'exact_match': int(r.exact_match), 'gold': int(r.final_label),
                                'difficulty': r.difficulty, 'transition': 'added_by_nonexact_first' if n.loc[pid, 'returned_rank'] > 0 else 'removed_by_nonexact_first',
                                'exact_priority_rank': int(e.loc[pid, 'returned_rank']), 'nonexact_first_rank': int(n.loc[pid, 'returned_rank']),
                                'bge_score': r.score, 'query_description': r.query_description, 'candidate_description': r.candidate_description})
        for group, splits in GROUPS.items():
            part = [r for r in transitions if r['seed'] == seed and r['evaluation_split'] in splits]
            count = {'seed': seed, 'evaluation_group': group}
            for action in ('added_by_nonexact_first', 'removed_by_nonexact_first'):
                pp = [r for r in part if r['transition'] == action]
                count[action + '_n'] = len(pp)
                count[action + '_tp_n'] = sum(r['gold'] for r in pp)
                count[action + '_fp_n'] = sum(1-r['gold'] for r in pp)
                count[action + '_exact_tp_n'] = sum(r['gold'] and r['exact_match'] for r in pp)
                count[action + '_hard_tp_n'] = sum(r['gold'] and r['difficulty'] == 'hard' for r in pp)
            counts.append(count)
    pd.DataFrame(transitions).to_csv(OUT / 'ranking_membership_transitions.csv', index=False)
    c = pd.DataFrame(counts)
    c.to_csv(OUT / 'ranking_tradeoff_counts.csv', index=False)
    c.groupby('evaluation_group').mean(numeric_only=True).drop(columns='seed').reset_index().to_csv(OUT / 'ranking_tradeoff_counts_aggregate.csv', index=False)
    full = pd.read_csv(OUT / 'full_pair_metrics_aggregate.csv')
    hard = pd.read_csv(OUT / 'hard_pair_metrics_aggregate.csv')
    lists = pd.read_csv(OUT / 'list_metrics_aggregate.csv')
    report = ['逐对 exact 路由与三条列表排序：探索性结果', '',
              '策略先冻结，再重建与接入金标。完整逐对模式只跳过405个exact对，对全部6195个非exact对使用原checkpoint实测分数和原验证阈值。无查询提前停止，无未知-1预测。',
              '这使BGE调用数量减少405/6600=6.1364%；不能沿用原提前停止系统53.5909%的调用节省或其耗时。逐对模式真实GPU复测耗时须另报。',
              '19查询/54对新的匿名盲判输入来自三种子阈值接受的非exact候选并集，保持原匿名ID、五字段与顺序；候选选择不读gold、困难标签或旧GPT判断。', '',
              '宏Recall@3：每个有正例的查询先算“最终列表正确参考数/固定30候选池全部正例数”，再等权平均。主测试有161个正例查询；57个无正例查询单独计算拒绝率。例：找回2/3和1/1时，宏召回为83.33%，微召回为75%。它不是全数据库召回，也不是每条建议正确的概率。',
              '完整配对P/R/F1评价全部二元决定，最终列表P与Recall@3只评价至多三条。hard完整分类和hard列表召回分别保留；rule没有hard输出时precision未定义，不能写成0%。', '',
              '下列指标为三BGE种子算术平均；rule与GPT仅各一份确定输出/旧盲判。两个逐对排序组件的完整分类决定完全相同，只改变列表顺序，不按测试成绩选赢家。']
    for group in GROUPS:
        report += ['', group]
        for _, r in full[full.evaluation_group.eq(group)].iterrows():
            if r.policy == 'exact_pair_bge_nonexact_first':
                continue
            report.append(f"完整配对 {r.policy}: P={r.precision_pct:.4f}%, R={r.recall_pct:.4f}%, F1={r.f1_pct:.4f}%; TP={r.tp:.3f}, FP={r.fp:.3f}, FN={r.fn:.3f}.")
        for _, r in hard[hard.evaluation_group.eq(group)].iterrows():
            if r.policy == 'exact_pair_bge_nonexact_first':
                continue
            p = '未定义' if pd.isna(r.precision_pct) else f'{r.precision_pct:.4f}%'
            report.append(f"困难完整配对 {r.policy}: P={p}, R={r.recall_pct:.4f}%, F1={r.f1_pct:.4f}%; TP={r.tp:.3f}, FP={r.fp:.3f}, FN={r.fn:.3f}.")
        for _, r in lists[lists.evaluation_group.eq(group)].iterrows():
            hp = '未定义' if pd.isna(r.hard_returned_precision_pct) else f'{r.hard_returned_precision_pct:.4f}%'
            report.append(f"最终列表 {r.policy}: P={r.returned_precision_pct:.4f}%, 宏R@3={r.macro_recall_at3_pct:.4f}%, Hit@3={r.hit_at3_pct:.4f}%; hard P={hp}, hard微R@3={r.hard_micro_recall_at3_pct:.4f}%, hard宏R@3={r.hard_macro_recall_at3_pct:.4f}%, hardHit@3={r.hard_hit_at3_pct:.4f}%.")
    report += ['', '解释与限制',
               'locked100完整困难分类找回14/23，恢复原Table4的三种子平均F1=69.8635%。加入全部非exact分数解决提前停止造成的“未知”，但exact优先的三条上限仍只返回1/23困难正例。',
               'nonexact-first在locked100平均返回13.6667/23困难正例，hard微R@3=59.4203%；代价是一些exact正确参考被挤出，误报增多。primary218总体列表宏召回从exact-priority的96.7081%降至94.5549%，precision从98.5464%降至96.6889%。这是一项排序取舍，不能声称全面优于。',
               'primary218的实际local all_bge困难F1=52.0421%，与旧离线conflict_refined的53.5164%不同；本评估保留真实来源，不以旧分数替换实测结果。',
               '原测试已多次被研究；此次冻结与盲判不使它成为新独立确认集。600构造意图/AI标签没有人审gold，不用于质量评价。未推断GPT API费用或完整混合系统总延迟。']
    (OUT / 'report.txt').write_text('\n'.join(report) + '\n')
    print(c[c.evaluation_group.eq('primary218')].to_string(index=False))


if __name__ == '__main__':
    main()
