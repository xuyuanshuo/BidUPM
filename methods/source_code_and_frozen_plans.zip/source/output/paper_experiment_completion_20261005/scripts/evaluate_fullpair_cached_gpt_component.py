#!/usr/bin/env python3
"""Post-hoc replay of OLD fullpool GPT membership, never new selective inference."""
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import importlib.util
import json
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
DESIGN = BASE / 'results/exact_pair_route_before_cap'
OLD = BASE.parent / 'rule_first_system_validation_20261005'
SOURCE = BASE.parent / 'rule_first_system_20261004/results/server'
OUT = BASE / 'results/exact_pair_route_cached_fullpool_gpt'
spec = importlib.util.spec_from_file_location('frozen_pair_route', BASE / 'scripts/evaluate_exact_pair_route_before_cap.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def dump(p, value):
    Path(p).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def main():
    assert not OUT.exists(), 'Refuse to overwrite cached replay freeze'
    OUT.mkdir(parents=True)
    op = OLD / 'blind_gpt6_sol/outputs/predictions.jsonl'
    ip = OLD / 'blind_gpt6_sol/inputs/query_pools.jsonl'
    mp = OLD / 'results/gpt6_sol_blind/private_mapping.csv'
    qap = OLD / 'results/gpt6_sol_blind/evaluation/qa.json'
    sourcepaths = [op, ip, mp, qap, DESIGN / 'frozen_manifest.json', DESIGN / 'private_eligibility.csv',
                   SOURCE / 'inputs.csv', SOURCE / 'source_manifest.json']
    frozen = {'status':'offline_component_policy_fixed_before_replay_and_current_gold_join', 'utc':datetime.now(timezone.utc).isoformat(),
              'source_sha256':{str(p.resolve()):sha(p) for p in sourcepaths}, 'script_sha256':sha(__file__),
              'classification':'Exact accepted unconditionally; nonexact accepted iff original seed BGE threshold passes AND OLD original fullpool GPT accepted membership includes that same pair. Other pairs explicitly reject.',
              'rankings':'Report both previously frozen exact-priority and nonexact-first cap3 orderings; descending BGE score/candidate-ID ties unchanged. OLD GPT top3 is not used to rerank either component.',
              'judgment_source':'One previously completed original 220x30 fullpool GPT blind screening, in its original fullpool context. NOT a new19query/54pair selective judgment.',
              'retrospective_status':'Post-hoc same-context offline component replay on a previously studied test. No test-result winner selection or confirmatory superiority claim.',
              'new_gpt_inference_performed':False,'new_selective_54pair_judgments_available':False,'shared_old_gpt_judgment_n':1,
              'no_threshold_retuning':True,'no_600_construction_gold':True}
    dump(OUT / 'frozen_plan.json', frozen)
    freeze = json.loads((DESIGN / 'frozen_manifest.json').read_text())
    assert all(sha(BASE/p)==h for p,h in freeze['frozen_file_sha256'].items())
    qaold = json.loads(qap.read_text())['blind_integrity']
    assert sha(op) == qaold['prediction_sha256'] and sha(ip) == qaold['input_sha256'] and sha(mp) == qaold['mapping_sha256']
    original = [json.loads(l) for l in ip.read_text().splitlines() if l.strip()]
    judgments = [json.loads(l) for l in op.read_text().splitlines() if l.strip()]
    pidx, jidx = {p['query_key']:p for p in original}, {j['query_key']:j for j in judgments}
    assert len(pidx) == len(jidx) == 220 and set(pidx) == set(jidx)
    yes, allpairs = set(), set()
    for q, p in pidx.items():
        candidate_ids = {c['candidate_key'] for c in p['candidates']}
        j = jidx[q]
        accepted = j['accepted_candidates']
        assert j['adjudication_complete'] is True and len(candidate_ids)==30 and len(accepted)==len(set(accepted)) and set(accepted)<=candidate_ids
        assert len(j['top3']) <= 3 and set(j['top3']) <= set(accepted)
        yes |= {(q,c) for c in accepted}
        allpairs |= {(q,c) for c in candidate_ids}
    mapping = pd.read_csv(mp,usecols=['query_key','candidate_key','pair_id'])
    assert len(mapping)==6600 and mapping.pair_id.is_unique and set(zip(mapping.query_key,mapping.candidate_key))==allpairs
    yesids = {r.pair_id for r in mapping.itertuples() if (r.query_key,r.candidate_key) in yes}
    eligibility = pd.read_csv(DESIGN/'private_eligibility.csv')
    eligibility['cached_fullpool_gpt_accepted'] = eligibility.pair_id.isin(yesids).astype(int)
    eligibility.to_csv(OUT/'cached_replay_eligibility.csv',index=False)
    selected = eligibility[eligibility.verifier_submitted.eq(1)][['query_key','candidate_key','pair_id','cached_fullpool_gpt_accepted']]
    assert len(selected)==54
    selected.to_csv(OUT/'proposed54_oldcontext_membership.csv',index=False)
    f=m.inputs()
    rows=f.to_dict('records')
    pools=defaultdict(list)
    for r in rows: pools[r['evaluation_split'],r['query_id']].append(r)
    predrows, counts = [], []
    for seed in m.SEEDS:
        scores=eligibility.set_index('pair_id')[f'score_seed_{seed}'].to_dict()
        allowed=set(eligibility[eligibility[f'eligible_seed_{seed}'].eq(1)].pair_id)
        keep=allowed&yesids
        counts.append({'seed':seed,'BGE_threshold_accepted_nonexact_pairs':len(allowed),'old_fullpool_GPT_and_BGE_accepted_nonexact_pairs':len(keep),
                       'new_GPT_call_n':0,'shared_old_GPT_judgment_n':1})
        for name,order in [('exact_pair_bge_cached_fullpool_gpt_exact_priority','exact_first'),('exact_pair_bge_cached_fullpool_gpt_nonexact_first','nonexact_first')]:
            ranks={}
            for pool in pools.values(): ranks.update(m.ranked(pool,scores,keep,order))
            for r in rows:
                predrows.append({'seed':seed,'policy':name,'pair_id':r['pair_id'],'evaluation_split':r['evaluation_split'],'query_id':r['query_id'],
                                'candidate_id':r['candidate_id'],'exact_match':r['exact_match'],'score':scores[r['pair_id']] if not r['exact_match'] else np.nan,
                                'threshold':m.THRESHOLDS[seed],'prediction':int(r['exact_match'] or r['pair_id'] in keep),'returned_rank':ranks.get(r['pair_id'],0),
                                'shared_old_fullpool_gpt_judgment_n':1,'new_selective_judgment_n':0})
    pred=pd.DataFrame(predrows)
    assert len(pred)==39600 and pred.prediction.isin([0,1]).all() and not pred.duplicated(['seed','policy','pair_id']).any()
    pred.to_csv(OUT/'predictions_before_gold.csv',index=False)
    predhash,predutc=sha(OUT/'predictions_before_gold.csv'),datetime.now(timezone.utc).isoformat()
    sm=json.loads((SOURCE/'source_manifest.json').read_text())
    assert sha(SOURCE/'labels.csv')==sm['labels_sha256']
    gold=pd.read_csv(SOURCE/'labels.csv',usecols=['pair_id','final_label','difficulty'])
    goldutc=datetime.now(timezone.utc).isoformat()
    data=pred.merge(gold,on='pair_id',validate='many_to_one')
    full,hard,lists=[],[],[]
    for (seed,name),d in data.groupby(['seed','policy']):
        for group,splits in m.GROUPS.items():
            z=d[d.evaluation_split.isin(splits)].copy()
            meta={'seed':int(seed),'policy':name,'evaluation_group':group,'query_n':len(z[['evaluation_split','query_id']].drop_duplicates()),'pair_n':len(z),
                  'shared_old_gpt_judgment_n':1,'new_selective_judgment_n':0}
            for hardonly,result in [(False,full),(True,hard)]:
                v=z[z.difficulty.eq('hard')] if hardonly else z
                tp=int((v.prediction.eq(1)&v.final_label.eq(1)).sum());fp=int((v.prediction.eq(1)&v.final_label.eq(0)).sum())
                fn=int((v.prediction.eq(0)&v.final_label.eq(1)).sum());tn=int((v.prediction.eq(0)&v.final_label.eq(0)).sum())
                result.append({**meta,'evaluated_pair_n':len(v),'positive_n':int(v.final_label.sum()),'tp':tp,'fp':fp,'fn':fn,'tn':tn,
                               'precision_pct':100*tp/(tp+fp) if tp+fp else np.nan,'recall_pct':100*tp/(tp+fn) if tp+fn else np.nan,
                               'f1_pct':200*tp/(2*tp+fp+fn) if 2*tp+fp+fn else np.nan})
            z['returned']=z.returned_rank.gt(0).astype(int)
            z['tp']=z.returned.eq(1)&z.final_label.eq(1);z['fp']=z.returned.eq(1)&z.final_label.eq(0)
            z['hard_positive']=z.difficulty.eq('hard')&z.final_label.eq(1)
            z['hard_tp']=z.tp&z.difficulty.eq('hard');z['hard_fp']=z.fp&z.difficulty.eq('hard')
            q=z.groupby(['evaluation_split','query_id']).agg(positive=('final_label','sum'),returned=('returned','sum'),tp=('tp','sum'),
                   hard_positive=('hard_positive','sum'),hard_tp=('hard_tp','sum'))
            assert q.returned.le(3).all()
            pos,no,hq=q[q.positive.gt(0)],q[q.positive.eq(0)],q[q.hard_positive.gt(0)]
            tp,fp,htp,hfp=int(z.tp.sum()),int(z.fp.sum()),int(z.hard_tp.sum()),int(z.hard_fp.sum())
            lists.append({**meta,'returned_tp_n':tp,'returned_fp_n':fp,'returned_fn_n':int(z.final_label.sum())-tp,
                          'returned_precision_pct':100*tp/(tp+fp) if tp+fp else np.nan,
                          'macro_recall_at3_pct':100*(pos.tp/pos.positive).mean(),'hit_at3_pct':100*pos.tp.gt(0).mean(),
                          'no_reference_pool_rejection_pct':100*no.returned.eq(0).mean() if len(no) else np.nan,
                          'hard_positive_n':int(z.hard_positive.sum()),'returned_hard_tp_n':htp,'returned_hard_fp_n':hfp,
                          'hard_returned_precision_pct':100*htp/(htp+hfp) if htp+hfp else np.nan,
                          'hard_micro_recall_at3_pct':100*htp/z.hard_positive.sum() if z.hard_positive.sum() else np.nan,
                          'hard_macro_recall_at3_pct':100*(hq.hard_tp/hq.hard_positive).mean() if len(hq) else np.nan,
                          'hard_hit_at3_pct':100*hq.hard_tp.gt(0).mean() if len(hq) else np.nan})
    for name,records in [('full_pair_metrics',full),('hard_pair_metrics',hard),('list_metrics',lists)]:
        table=pd.DataFrame(records);table.to_csv(OUT/f'{name}.csv',index=False)
        numeric=[c for c in table if c not in ['seed','policy','evaluation_group','shared_old_gpt_judgment_n','new_selective_judgment_n'] and pd.api.types.is_numeric_dtype(table[c])]
        agg=table.groupby(['evaluation_group','policy'])[numeric].mean().reset_index()
        agg['condition_n']=3;agg['shared_old_gpt_judgment_n']=1;agg['new_selective_judgment_n']=0
        agg.to_csv(OUT/f'{name}_aggregate.csv',index=False)
    pd.DataFrame(counts).to_csv(OUT/'component_counts.csv',index=False)
    assert all(sha(p)==h for p,h in frozen['source_sha256'].items())
    qa={'status':'passed','script_sha256':sha(__file__),'frozen_plan_sha256':sha(OUT/'frozen_plan.json'),
        'prediction_sha256_before_gold':predhash,'prediction_completed_utc':predutc,'first_gold_join_utc':goldutc,'gold_sha256':sha(SOURCE/'labels.csv'),
        'new_gpt_inference_performed':False,'shared_old_fullpool_judgment_n':1,'new_selective_54pair_judgment_n':0,
        'old_fullpool_accepted_pairs':len(yesids),'proposed54_cached_accepted_pairs':int(selected.cached_fullpool_gpt_accepted.sum()),
        'prediction_n':len(pred),'source_files_unchanged':True,'no_threshold_retuning':True,'no_gold_selection_or_ranking':True,
        'interpretation':'Post-hoc fullpool-context AND component; not actual new selective GPT inference. Do not infer selective prompt quality, latency, API cost, or hybrid total from replay.',
        'both_rankings_reported_not_test_winner_selected':True,'no_600_construction_gold':True}
    dump(OUT/'qa.json',qa)
    # Execution status is separate from previously frozen 54-pair proposal/plan.
    dump(BASE/'blind_fullpair_selective_gpt6_sol/unexecuted_status.json',{'status':'NOT_EXECUTED','frozen_input_query_n':19,'frozen_input_pair_n':54,
         'fresh_blind_output_exists':False,'new_gpt_inference_performed':False,
         'reason':'Fresh isolated judge could not be created because the agent thread limit was reached; a gold-reading QA worker was not reused as a blind judge.',
         'replacement_analysis':'Separate offline old-fullpool-context component only; original 54-pair frozen pool retained as unexecuted record.',
         'input_sha256':sha(BASE/'blind_fullpair_selective_gpt6_sol/inputs/query_pools.jsonl')})
    report=['旧全池GPT判断的逐对AND组件：仅离线回放',
            '本结果复用原220×30全池盲判的accepted membership；没有执行19query/54pair新盲判，不能称新增选择性GPT推理。',
            '非exact必须同时通过原BGE阈值和旧GPT判断；exact直接接受。保留两种已冻结排序并完整报告，不按测试成绩选赢家。',
            '三BGE种子共享同一旧GPT判断；所有分类决定明确为0/1，至多三条列表另报。原测试已研究，结果仅探索，不是SOTA确认。',
            '未测GPT API成本/延迟或完整混合延迟；600构造标签未作gold。','']
    for name in ['full_pair_metrics_aggregate.csv','hard_pair_metrics_aggregate.csv','list_metrics_aggregate.csv']:
        table=pd.read_csv(OUT/name)
        report+=[name,table[table.evaluation_group.isin(['locked100','primary218'])].to_csv(index=False),'']
    (OUT/'report.txt').write_text('\n'.join(report)+'\n')
    print(json.dumps(qa,ensure_ascii=False,indent=2))
    print(pd.read_csv(OUT/'full_pair_metrics_aggregate.csv').query("evaluation_group in ['locked100','primary218']").to_string(index=False))
    print(pd.read_csv(OUT/'list_metrics_aggregate.csv').query("evaluation_group in ['locked100','primary218']").to_string(index=False))


if __name__=='__main__': main()
