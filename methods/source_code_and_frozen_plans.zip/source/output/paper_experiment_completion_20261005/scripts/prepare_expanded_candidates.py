#!/usr/bin/env python3
"""Freeze expanded rule-first verifier candidates without opening quality data.

Allowed source fields are explicitly allowlisted. No annotations, difficulty,
prior GPT judgments, acceptance thresholds, or evaluation statistics are loaded.
Writes exclusively beneath this new completion experiment directory.
"""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
OLD = WORKSPACE / 'output/rule_first_system_validation_20261005'
SOURCE = WORKSPACE / 'output/rule_first_system_20261004/results/server/inputs.csv'
ORIGINAL = OLD / 'blind_gpt6_sol/inputs/query_pools.jsonl'
MAPPING = OLD / 'results/gpt6_sol_blind/private_mapping.csv'
POLICY_MODULE = OLD / 'scripts/system_policy.py'
PROMPT_SOURCE = OLD / 'scripts/run_gpt6_sol_api_benchmark.py'
DEST = ROOT / 'blind_expanded_gpt6_sol'
PRIVATE = ROOT / 'results/expanded_candidate_design'
SEEDS = (20260904, 20260905, 20260906)
WIDTHS = (3, 5, 10)
FIELDS = ('description', 'normalized_description', 'normalized_unit', 'category', 'spec_tokens')
SOURCE_FIELDS = ('pair_id', 'evaluation_split', 'query_id', 'candidate_id') + tuple(
    f'{side}_{field}' for side in ('query', 'candidate') for field in FIELDS)
SCORE_FIELDS = ('pair_id', 'seed', 'policy', 'batch_size', 'score', 'model_called')


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def load_system_prompt():
    tree = ast.parse(PROMPT_SOURCE.read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'SYSTEM_PROMPT' for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError('Missing baseline domain prompt')


def main():
    assert not DEST.exists(), 'Refusing to overwrite frozen verifier input'
    assert not PRIVATE.exists(), 'Refusing to overwrite frozen private design'
    original = [json.loads(line) for line in ORIGINAL.read_text().splitlines() if line.strip()]
    assert len({p['query_key'] for p in original}) == len(original)
    key_to_item = {}
    query_order = []
    candidate_order = {}
    for pool in original:
        assert set(pool) == {'query_key', 'query', 'candidates'}
        assert set(pool['query']) == set(FIELDS)
        assert all(isinstance(x, str) for x in pool['query'].values())
        qkey = pool['query_key']
        query_order.append(qkey)
        candidate_order[qkey] = []
        for candidate in pool['candidates']:
            assert set(candidate) == set(FIELDS) | {'candidate_key'}
            assert all(isinstance(x, str) for x in candidate.values())
            ckey = candidate['candidate_key']
            assert (qkey, ckey) not in key_to_item
            key_to_item[qkey, ckey] = candidate
            candidate_order[qkey].append(ckey)
    mp = pd.read_csv(MAPPING, usecols=['query_key', 'candidate_key', 'pair_id'], dtype=str, keep_default_na=False)
    assert not mp.pair_id.duplicated().any()
    assert not mp[['query_key', 'candidate_key']].duplicated().any()
    assert set(zip(mp.query_key, mp.candidate_key)) == set(key_to_item)
    source = pd.read_csv(SOURCE, usecols=SOURCE_FIELDS, dtype=str, keep_default_na=False)
    assert not source.pair_id.duplicated().any()
    assert set(mp.pair_id) <= set(source.pair_id)
    # The source also contains separate validation inputs. Restrict to the
    # existing formal-pool identity mapping before any routing or proposal.
    source = source[source.pair_id.isin(set(mp.pair_id))].copy()
    assert set(source.pair_id) == set(mp.pair_id)
    # The original pools define the fixed anonymous order. The mapping gives
    # identity only and contains no gold decisions or difficulty indicators.
    mp['original_order'] = np.arange(len(mp))
    source = mp.merge(source, on='pair_id', how='left', validate='one_to_one', sort=False)
    spec = importlib.util.spec_from_file_location('frozen_input_only_system_policy', POLICY_MODULE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    routing = module.route(source)
    source['rule_exact'] = routing['exact_match'].astype(int)
    source['needs_verifier'] = routing['model_called'].astype(int)
    qkeys = source.groupby('query_key', sort=False)
    query_metadata = qkeys.agg(evaluation_split=('evaluation_split', 'first'),
                              query_id=('query_id', 'first'),
                              exact_count=('rule_exact', 'sum'),
                              pool_count=('pair_id', 'size')).reset_index()
    assert qkeys.evaluation_split.nunique().eq(1).all()
    assert qkeys.query_id.nunique().eq(1).all()
    assert not query_metadata[['evaluation_split', 'query_id']].duplicated().any()
    source = source.merge(query_metadata[['query_key', 'exact_count']], on='query_key', how='left', validate='many_to_one', sort=False)
    source['verifier_submitted'] = 0
    source_hashes = {str(path): sha(path) for path in (SOURCE, ORIGINAL, MAPPING, POLICY_MODULE, PROMPT_SOURCE)}
    seed_eligible_pair_ids = {}
    for seed in SEEDS:
        path = OLD / f'results/runtime/predictions_seed_{seed}.csv'
        scores = pd.read_csv(path, usecols=SCORE_FIELDS, dtype={'pair_id': str})
        scores = scores[(scores.policy == 'system_top3') & (scores.batch_size == 64)].copy()
        assert len(scores) == len(source) and not scores.pair_id.duplicated().any()
        assert set(scores.pair_id) == set(source.pair_id)
        assert scores.seed.eq(seed).all()
        aligned = source[['pair_id', 'query_key', 'candidate_id', 'rule_exact', 'exact_count']].merge(
            scores[['pair_id', 'score', 'model_called']], on='pair_id', how='left', validate='one_to_one', sort=False)
        expected_called = (aligned.exact_count < 3) & (aligned.rule_exact == 0)
        assert np.array_equal(aligned.model_called.to_numpy(dtype=int), expected_called.to_numpy(dtype=int))
        assert np.isfinite(aligned.loc[expected_called, 'score']).all()
        source[f'score_seed_{seed}'] = aligned.score.where(expected_called)
        ranks = pd.Series(0, index=source.index, dtype=int)
        for _, positions in aligned.groupby('query_key', sort=False).indices.items():
            part = aligned.iloc[positions]
            eligible = part[(part.exact_count < 3) & (part.rule_exact == 0)].sort_values(
                ['score', 'candidate_id'], ascending=[False, True], kind='stable')
            ranks.loc[eligible.index] = np.arange(1, len(eligible) + 1)
        source[f'nonexact_rank_seed_{seed}'] = ranks
        seed_eligible_pair_ids[str(seed)] = {}
        for width in WIDTHS:
            flag = (ranks > 0) & (ranks <= width)
            source[f'eligible_k{width}_seed_{seed}'] = flag.astype(int)
            seed_eligible_pair_ids[str(seed)][f'k{width}'] = source.loc[flag, 'pair_id'].tolist()
    submitted = np.zeros(len(source), dtype=bool)
    for seed in SEEDS:
        submitted |= source[f'eligible_k10_seed_{seed}'].to_numpy(dtype=bool)
    source['verifier_submitted'] = submitted.astype(int)
    offered = {q: set(group.candidate_key) for q, group in source[submitted].groupby('query_key', sort=False)}
    payload = []
    for pool in original:
        qkey = pool['query_key']
        if qkey not in offered:
            continue
        candidates = [c for c in pool['candidates'] if c['candidate_key'] in offered[qkey]]
        assert candidates and len(candidates) == len(offered[qkey])
        payload.append({'query_key': qkey, 'query': pool['query'], 'candidates': candidates})
    e_lt3 = set(query_metadata.loc[query_metadata.exact_count < 3, 'query_key'])
    assert set(offered) == e_lt3, 'Every residual query must receive new judgment'
    assert sum(len(p['candidates']) for p in payload) == int(submitted.sum())
    assert not source.loc[submitted, 'rule_exact'].any()
    assert (source.loc[submitted, 'exact_count'] < 3).all()
    # Keep exactly the baseline domain instructions, to isolate candidate pool
    # widening from a simultaneous verifier prompt change.
    system_prompt = load_system_prompt()
    policy = {
        'name': 'rule_first_cap3_expanded_selective_verifier',
        'seeds': list(SEEDS), 'candidate_widths': list(WIDTHS),
        'primary_prespecified_width': 10,
        'residual_proposal': 'For E<3, rank all scored nonexact candidates by descending BGE logit, then ascending candidate_id, separately per seed; ignore original acceptance threshold; include top K.',
        'verifier_input': 'One union of per-seed top10 nonexact proposals for every E<3 query, with original anonymous query/candidate order and exactly the original five sanitized fields.',
        'verifier_output': 'One compatible/rejected judgment per submitted pair via accepted list; verifier top3 is preserved for diagnostics but not used in the primary BGE-ordered policy.',
        'composition': 'If E>=3, return first three exact candidates by ascending candidate_id and skip BGE/verifier. If E<3, retain exact candidates by ascending candidate_id, then fill remaining slots with verifier-accepted nonexact candidates in the seed-specific topK, ordered by descending BGE logit then ascending candidate_id. Never return more than three; never force fill.',
        'nested_width_interpretation': 'K3/K5/K10 reuse judgments from the uniontop10 context. They are contextual width diagnostics, not independent K-specific prompts, and must not be described as separately judged experiments.',
        'selection_inputs_allowed': list(SOURCE_FIELDS) + list(SCORE_FIELDS) + ['anonymous query/candidate identity mapping', 'original five-field anonymous pools'],
        'forbidden_selection_inputs': ['gold labels', 'difficulty', 'prior GPT predictions', 'evaluation quality metrics', 'original BGE acceptance threshold'],
        'raw_item_codes': 'Retain existing source identity in private metadata only. Raw pay-item codes are absent from the verifier payload and are not used as verifier evidence.',
        'model': 'gpt-6-sol', 'reasoning_effort': 'medium',
        'validation_status': 'Post-hoc experiment on the already used formal test; requires untouched independent validation before confirmatory superiority claims.',
    }
    DEST.joinpath('inputs').mkdir(parents=True)
    DEST.joinpath('outputs').mkdir()
    PRIVATE.mkdir(parents=True)
    out = DEST / 'inputs/query_pools.jsonl'
    out.write_text(''.join(json.dumps(p, ensure_ascii=False) + '\n' for p in payload))
    (DEST / 'inputs/system_prompt.txt').write_text(system_prompt)
    private_fields = ['query_key', 'candidate_key', 'pair_id', 'evaluation_split', 'query_id', 'candidate_id',
                      'original_order', 'rule_exact', 'exact_count', 'needs_verifier', 'verifier_submitted']
    private_fields += [name for seed in SEEDS for name in
                      [f'score_seed_{seed}', f'nonexact_rank_seed_{seed}'] + [f'eligible_k{k}_seed_{seed}' for k in WIDTHS]]
    source[private_fields].to_csv(PRIVATE / 'private_eligibility.csv', index=False)
    source.loc[submitted, ['query_key', 'candidate_key', 'pair_id', 'evaluation_split', 'query_id', 'candidate_id']].to_csv(
        PRIVATE / 'private_mapping.csv', index=False)
    query_metadata['verifier_called'] = query_metadata.query_key.isin(offered).astype(int)
    query_metadata.to_csv(PRIVATE / 'query_routes.csv', index=False)
    write_json(PRIVATE / 'policy.json', policy)
    write_json(PRIVATE / 'seed_eligibility.json', seed_eligible_pair_ids)
    order = [{'query_key': p['query_key'], 'candidate_keys': [c['candidate_key'] for c in p['candidates']]} for p in payload]
    write_json(PRIVATE / 'frozen_order.json', order)
    frozen_paths = [out, DEST / 'inputs/system_prompt.txt', PRIVATE / 'private_eligibility.csv',
                    PRIVATE / 'private_mapping.csv', PRIVATE / 'query_routes.csv', PRIVATE / 'policy.json',
                    PRIVATE / 'seed_eligibility.json', PRIVATE / 'frozen_order.json']
    frozen = {
        'status': 'frozen_before_any_new_verifier_judgment_or_quality_evaluation',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'input_sha256': sha(out), 'policy_sha256': sha(PRIVATE / 'policy.json'),
        'prompt_sha256': sha(DEST / 'inputs/system_prompt.txt'),
        'order_sha256': sha(PRIVATE / 'frozen_order.json'),
        'source_sha256': source_hashes,
        'frozen_file_sha256': {str(path.relative_to(ROOT)): sha(path) for path in frozen_paths},
        'preparation_script_sha256': sha(Path(__file__)),
        'gold_labels_read': False, 'difficulty_read': False,
        'prior_gpt_predictions_read': False, 'quality_metrics_read': False,
        'original_acceptance_threshold_read': False,
        'no_inference_performed': True,
    }
    frozen['freeze_commitment_sha256'] = hashlib.sha256(canonical(frozen).encode()).hexdigest()
    write_json(PRIVATE / 'frozen_manifest.json', frozen)
    # Counts are published only after the input/order/policy commitment exists.
    counts = {
        'query_count': len(original), 'candidate_pair_count': len(source),
        'source_partition_query_counts': query_metadata.evaluation_split.value_counts().to_dict(),
        'rules_only_queries_e_ge3': int((query_metadata.exact_count >= 3).sum()),
        'verifier_queries_e_lt3': len(payload),
        'unique_verifier_candidate_pairs_uniontop10': int(submitted.sum()),
        'exact_count_distribution': {str(k): int(v) for k, v in query_metadata.exact_count.value_counts().sort_index().items()},
        'submitted_pool_size_min': min(len(p['candidates']) for p in payload),
        'submitted_pool_size_max': max(len(p['candidates']) for p in payload),
        'by_seed_and_width': {
            str(seed): {str(k): int(source[f'eligible_k{k}_seed_{seed}'].sum()) for k in WIDTHS} for seed in SEEDS},
        'freeze_commitment_sha256': frozen['freeze_commitment_sha256'],
    }
    write_json(PRIVATE / 'counts_after_freeze.json', counts)
    print(json.dumps(counts, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
