#!/usr/bin/env python3
"""Actual frozen local system GPU comparisons, label-blind and repeated."""
import argparse,gc,hashlib,json,os,sys,time
from pathlib import Path
os.environ.setdefault('HF_HUB_OFFLINE','1');os.environ.setdefault('TRANSFORMERS_OFFLINE','1');os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer,AutoModelForSequenceClassification,AutoModelForCausalLM
ROOT=Path('experiment_runtime')
sys.path.insert(0,str(ROOT/'scripts'))
sys.path.insert(0,str(ROOT/'system_validation_20261005/scripts'))
from local_experiment_utils import item_text
from run_open_llm_verifier_local import render_prompt,answer_token_id
from system_policy import route,serialize,rank_returned
POLICIES=('all_bge','rule_bge','rule_bge_qwen_threshold','rule_bge_qwen_top10')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v): Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    sm=json.loads((a.source/'source_manifest.json').read_text());assert sha(a.source/'inputs.csv')==sm['inputs_sha256']
    f=pd.read_csv(a.source/'inputs.csv',dtype=str,keep_default_na=False);f=f[f.evaluation_split.ne('validation')].reset_index(drop=True)
    assert len(f)==6600 and not set(f)&{'final_label','difficulty','label','provisional_label'}
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported();assert not a.output.exists();a.output.mkdir(parents=True)
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    qt=pd.read_csv(ROOT/'runs/qwen3_4b_instruct_verifier/validation_thresholds.csv');qthreshold=float(qt.loc[qt.policy.eq('f1_opt'),'threshold'].iloc[0]);assert qthreshold==12.75
    qmanifest=json.loads((ROOT/'runs/qwen3_4b_instruct_verifier/manifest.json').read_text());qcp=Path(qmanifest['base_model_load_path'])
    for name,h in qmanifest['base_model_weight_sha256'].items():assert sha(qcp/name)==h
    plan={'status':'running','policies':POLICIES,'pair_n':6600,'query_n':220,'primary_query_n':218,'labels_accessed':False,'thresholds_retuned':False,'new_training':False,'qwen_threshold':qthreshold,'qwen_threshold_sha256':sha(ROOT/'runs/qwen3_4b_instruct_verifier/validation_thresholds.csv'),'source_sha256':sha(a.source/'inputs.csv'),'script_sha256':sha(__file__),'batch_bge':64,'batch_qwen':24,'max_length':256,'repeats':3,'gpu':torch.cuda.get_device_name(0),'timing':'Synchronized resident models; gate, serialize, tokenize, actual BGE, proposal/threshold, actual selected Qwen, merge/rank. Excludes model loading, CSV import and candidate retrieval. No GPT/API calls.','completed_runs':[]}
    dump(a.output/'execution_manifest.json',plan)
    qtok=AutoTokenizer.from_pretrained(qcp,padding_side='left',local_files_only=True);qtok.pad_token=qtok.pad_token or qtok.eos_token
    qmodel=AutoModelForCausalLM.from_pretrained(qcp,dtype=torch.bfloat16,attn_implementation='sdpa',local_files_only=True).to('cuda').eval()
    yes,no=answer_token_id(qtok,'yes'),answer_token_id(qtok,'no');times=[]
    @torch.inference_mode()
    def execute(model,tok,threshold,policy,frame):
        torch.cuda.synchronize();start=time.perf_counter();n=len(frame)
        r=route(frame) if policy!='all_bge' else {'rule_accept':np.zeros(n,bool),'model_called':np.ones(n,bool)}
        exact=r['rule_accept'];ix=np.flatnonzero(r['model_called']);sub=frame.iloc[ix];scores=np.full(n,np.nan)
        qs,cs=serialize(sub,'query'),serialize(sub,'candidate')
        for lo in range(0,len(ix),64):
            enc=tok(qs[lo:lo+64],cs[lo:lo+64],padding=True,truncation=True,max_length=256,return_tensors='pt');enc={k:v.to('cuda') for k,v in enc.items()}
            with torch.autocast('cuda',dtype=torch.bfloat16):logit=model(**enc).logits.reshape(-1)
            scores[ix[lo:lo+64]]=logit.float().cpu().numpy()
        bgeaccepted=np.isfinite(scores)&(scores>=threshold);selected=np.zeros(n,bool);qscore=np.full(n,np.nan);tokens=0
        if policy=='rule_bge_qwen_threshold':selected=bgeaccepted&~exact
        elif policy=='rule_bge_qwen_top10':
            temp=frame.assign(_score=scores,_order=np.arange(n))
            for _,group in temp.groupby(['evaluation_split','query_id'],sort=False):
                nonexact=group[np.isfinite(group._score)]
                ranked=nonexact.sort_values(['_score','candidate_id'],ascending=[False,True],kind='stable').head(10)
                selected[ranked._order.to_numpy(int)]=True
        if policy.startswith('rule_bge_qwen'):
            qi=np.flatnonzero(selected);sub=frame.iloc[qi];qs=item_text(sub,'query','full');cs=item_text(sub,'candidate','full');prompts=[render_prompt(qtok,x,y) for x,y in zip(qs,cs)]
            for lo in range(0,len(qi),24):
                enc=qtok(prompts[lo:lo+24],padding=True,truncation=True,max_length=256,pad_to_multiple_of=8,return_tensors='pt');tokens+=int(enc['attention_mask'].sum());enc={k:v.to('cuda') for k,v in enc.items()}
                with torch.autocast('cuda',dtype=torch.bfloat16):logit=qmodel(**enc).logits[:,-1,:]
                qscore[qi[lo:lo+24]]=(logit[:,yes]-logit[:,no]).float().cpu().numpy()
            keep=selected&(qscore>=qthreshold)
        else:keep=bgeaccepted
        rank=rank_returned(frame,exact,np.where(keep,scores,np.nan),float('-inf'))
        prediction=exact.astype(int);prediction[keep]=1
        torch.cuda.synchronize();elapsed=time.perf_counter()-start
        return {'score':scores,'qwen_score':qscore,'prediction':prediction,'returned_rank':rank,'exact_match':exact.astype(int),'bge_called':r['model_called'].astype(int),'qwen_called':selected.astype(int)}, {'seconds':elapsed,'bge_pairs':int(len(ix)),'qwen_pairs':int(selected.sum()),'qwen_prompt_tokens':tokens}
    for run in sm['runs']:
        seed=int(run['seed']);threshold=float(run['threshold']);cp=Path(run['checkpoint'])
        for name,h in run['checkpoint_files'].items():assert sha(cp/name)==h
        torch.manual_seed(seed);tok=AutoTokenizer.from_pretrained(cp,local_files_only=True);model=AutoModelForSequenceClassification.from_pretrained(cp,local_files_only=True).to('cuda').eval()
        warm=f.groupby(['evaluation_split','query_id'],sort=False).head(30).head(120).reset_index(drop=True)
        for policy in POLICIES:execute(model,tok,threshold,policy,warm)
        reference={};rows=[]
        for repeat in range(3):
            for policy in np.random.default_rng(seed+repeat).permutation(POLICIES):
                result,timing=execute(model,tok,threshold,str(policy),f);times.append({'seed':seed,'policy':str(policy),'repeat':repeat,'pairs':6600,'queries':220,**timing})
                if policy in reference:assert np.array_equal(reference[policy],result['returned_rank']),'Repeat rank changed'
                else:
                    reference[policy]=result['returned_rank'].copy();out=f[['pair_id','evaluation_split','query_id','candidate_id']].copy();out['seed']=seed;out['policy']=str(policy);out['threshold']=threshold
                    for k,v in result.items():out[k]=v
                    rows.append(out)
                print('FINISH',seed,policy,repeat,round(timing['seconds'],3),timing['qwen_pairs'],flush=True)
        path=a.output/f'predictions_seed_{seed}.csv';pd.concat(rows).to_csv(path,index=False)
        plan['completed_runs'].append({'seed':seed,'threshold':threshold,'output':path.name,'sha256':sha(path),'repeat_ranks_identical':True});pd.DataFrame(times).to_csv(a.output/'timing.csv',index=False);dump(a.output/'execution_manifest.json',plan)
        del model,tok;gc.collect();torch.cuda.empty_cache()
    assert len(times)==36;plan['status']='complete';plan['timing_sha256']=sha(a.output/'timing.csv');dump(a.output/'execution_manifest.json',plan);print('ALL_COMPLETE',flush=True)
if __name__=='__main__':main()
