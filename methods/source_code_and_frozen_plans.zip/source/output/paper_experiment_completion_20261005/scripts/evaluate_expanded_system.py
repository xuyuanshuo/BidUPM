#!/usr/bin/env python3
"""Frozen, retrospective component evaluation; never rejudge or optimize gold."""
from pathlib import Path
import importlib.util, json, hashlib, sys
from datetime import datetime, timezone
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
OLD = BASE.parent / 'rule_first_system_validation_20261005'
SOURCE = BASE.parent / 'rule_first_system_20261004/results/server'
OUT = BASE / 'results/expanded_system_evaluation'
DESIGN = BASE / 'results/expanded_candidate_design'
SEEDS = (20260904, 20260905, 20260906)
spec = importlib.util.spec_from_file_location('reference_metrics', OLD/'scripts/evaluate_selective_gpt6.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
m.GROUPS.update(primary_heldout=['locked','no_reference','external'], internal_primary=['locked','no_reference'])

def require(v, msg):
    if not bool(v): raise ValueError(msg)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def jread(p): return json.loads(Path(p).read_text())
def lines(p): return [json.loads(l) for l in Path(p).read_text().splitlines() if l.strip()]
def dump(p,v): Path(p).write_text(json.dumps(m.safe(v),ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    freeze=jread(DESIGN/'frozen_manifest.json')
    for rel,h in freeze['frozen_file_sha256'].items(): require(sha(BASE/rel)==h,'Freeze changed: '+rel)
    for path,h in freeze['source_sha256'].items(): require(sha(path)==h,'Source changed: '+path)
    require(not freeze['gold_labels_read'] and not freeze['prior_gpt_predictions_read'],'Selection unblinded')
    poolpath=BASE/'blind_expanded_gpt6_sol/inputs/query_pools.jsonl'
    predpath=BASE/'blind_expanded_gpt6_sol/outputs/predictions.jsonl'
    manifest=jread(predpath.parent/'output_manifest.json')
    require(manifest['model']=='gpt-6-sol' and not manifest['settings']['api_calls'],'Model/source mismatch')
    require(manifest['input_sha256']==sha(poolpath)==freeze['input_sha256'],'Blind input mismatch')
    require(manifest['system_prompt_sha256']==freeze['prompt_sha256'],'Prompt mismatch')
    pools=lines(poolpath); judgments=lines(predpath)
    pidx={p['query_key']:p for p in pools}; oidx={p['query_id']:p for p in judgments}
    require(len(pidx)==len(oidx)==104 and set(pidx)==set(oidx),'Blind query coverage')
    accepted=set(); offered=set(); judged=[]
    for q,p in pidx.items():
        cids={c['candidate_key'] for c in p['candidates']}; o=oidx[q]
        require(len(cids)==len(p['candidates']),'Input duplicate')
        notes={c['candidate_id']:c for c in o['judgments']}
        require(len(notes)==len(o['judgments']) and set(notes)==cids,'Judgment coverage')
        yes={c for c,n in notes.items() if n['compatible'] is True}
        require(yes==set(o['compatible_candidate_ids']) and len(yes)==len(o['compatible_candidate_ids']),'Accept mismatch')
        require(len(o['top3_candidate_ids'])<=3 and len(set(o['top3_candidate_ids']))==len(o['top3_candidate_ids']) and set(o['top3_candidate_ids']).issubset(yes),'Verifier rank malformed')
        for c,n in notes.items():
            require(isinstance(n['compatible'],bool) and bool(n['reason']),'Invalid judgment')
            offered.add((q,c)); judged.append({'query_key':q,'candidate_key':c,'verifier_accept':int(n['compatible']),'reason':n['reason']})
        accepted.update((q,c) for c in yes)
    require(len(offered)==len(judged)==1650 and len(accepted)==110,'Blind count mismatch')
    mapping=pd.read_csv(DESIGN/'private_mapping.csv',dtype=str,keep_default_na=False)
    require(set(map(tuple,mapping[['query_key','candidate_key']].to_numpy()))==offered and mapping.pair_id.nunique()==1650,'Mapping not bijective')
    decisions=mapping.merge(pd.DataFrame(judged),on=['query_key','candidate_key'],validate='one_to_one')
    decisions.to_csv(OUT/'all_verifier_decisions.csv',index=False)
    acceptids=set(decisions.loc[decisions.verifier_accept.eq(1),'pair_id'])
    eligibility=pd.read_csv(DESIGN/'private_eligibility.csv')
    source_manifest=jread(SOURCE/'source_manifest.json')
    inputs=pd.read_csv(SOURCE/'inputs.csv',dtype=str,keep_default_na=False)
    inputs=inputs[inputs.evaluation_split.ne('validation')].copy()
    require(len(inputs)==6600 and inputs.pair_id.nunique()==6600,'Input scope')
    inputs['exact_match']=m.exact_series(inputs).astype(int)
    require(set(eligibility.pair_id)==set(inputs.pair_id) and len(eligibility)==6600,'Eligibility coverage')
    fullgpt=pd.read_csv(OLD/'results/gpt6_sol_blind/evaluation/blind_pair_predictions.csv',usecols=['pair_id','prediction','returned_rank'])
    narrow=pd.read_csv(OLD/'results/selective_gpt6_sol/evaluation/reconstructed_predictions_before_gold.csv')
    frames=[]; rankchecks=[]
    for seed in SEEDS:
        raw=pd.read_csv(OLD/f'results/runtime/predictions_seed_{seed}.csv',float_precision='round_trip')
        for oldpol,newpol in [('rule_only','rule_only'),('all_bge','all_bge'),('system_top3','thresholded_system')]:
            f=raw[raw.policy.eq(oldpol)&raw.batch_size.eq(64)].merge(inputs.drop(columns=['evaluation_split','query_id','exact_match']),on='pair_id',validate='one_to_one')
            require(len(f)==6600,'Runtime coverage')
            f['source']='real_gpu_frozen';f['policy']=newpol;frames.append(f)
        core=frames[-1].copy()
        for k in (3,5,10):
            f=core.copy(); f['source']='expanded_blind_agent';f['policy']=f'expanded_verified_k{k}'
            allowed=set(eligibility.loc[eligibility[f'eligible_k{k}_seed_{seed}'].eq(1),'pair_id'])
            keep=f.pair_id.isin(allowed&acceptids)&f.exact_match.eq(0)
            f['prediction']=f.exact_match.copy();f.loc[keep,'prediction']=1
            f['returned_rank']=m.rank_pandas(f,keep)
            pure=m.rank_python(f.to_dict('records'),allowed&acceptids)
            require(f.pair_id.map(pure).eq(f.returned_rank).all(),'Independent ranking mismatch')
            frames.append(f); rankchecks.append({'seed':seed,'k':k,'independent_ranking_passed':True})
        f=core.copy();allowed=set(eligibility.loc[eligibility[f'eligible_k10_seed_{seed}'].eq(1),'pair_id'])
        keep=f.pair_id.isin(allowed)&f.exact_match.eq(0)
        f['source']='component_cached_scores';f['policy']='expanded_k10_no_verifier'
        f['prediction']=f.exact_match.copy();f.loc[keep,'prediction']=1;f['returned_rank']=m.rank_pandas(f,keep);frames.append(f)
        f=inputs.merge(fullgpt,on='pair_id',validate='one_to_one'); f['seed']=seed;f['batch_size']=64;f['source']='one_previous_fullpool_agent';f['policy']='gpt6_sol_fullpool';frames.append(f)
        n=narrow[narrow.policy.eq('selective_gpt_top3')&narrow.seed.eq(seed)].copy()
        n=n.merge(inputs.drop(columns=['evaluation_split','query_id','candidate_id','exact_match']),on='pair_id',validate='one_to_one');n['policy']='narrow_verified_system';frames.append(n)
    cols=m.META+['pair_id','evaluation_split','query_id','candidate_id','exact_match','prediction','returned_rank']
    predictions=pd.concat([f[cols] for f in frames],ignore_index=True)
    require(len(predictions)==3*9*6600 and not predictions.duplicated(m.META+['pair_id']).any(),'Prediction count/uniqueness')
    require(predictions.groupby(m.META+m.QKEYS).returned_rank.apply(lambda s:sorted(s[s.gt(0)].tolist())==list(range(1,int(s.gt(0).sum())+1)) and s.gt(0).sum()<=3).all(),'Cap/order')
    predictions.to_csv(OUT/'reconstructed_predictions_before_gold.csv',index=False)
    qa={'status':'running','study_type':'retrospective exploration on previously studied test, not confirmatory SOTA','primary_queries':218,'supplementary_queries':220,'new_blind_queries':104,'new_blind_pairs':1650,'source_and_blind_integrity_passed':True,'one_shared_gpt_judgment_not_three_runs':True,'no_api_calls':True,'no_labels_used_for_proposal_or_ranking':True,'input_sha256':sha(poolpath),'output_sha256':sha(predpath),'prediction_sha256_before_gold':sha(OUT/'reconstructed_predictions_before_gold.csv'),'rank_checks':rankchecks,'reconstruction_completed_utc':datetime.now(timezone.utc).isoformat()}
    require(sha(SOURCE/'labels.csv')==source_manifest['labels_sha256'],'Labels hash mismatch')
    labels=pd.read_csv(SOURCE/'labels.csv');qa['first_gold_join_utc']=datetime.now(timezone.utc).isoformat()
    predictions=predictions.merge(labels,on='pair_id',validate='many_to_one')
    queries=m.query_frame(predictions); summary=m.summary_frame(predictions,queries)
    independent=m.independent_count_crosscheck(predictions,summary)
    independent.to_csv(OUT/'independent_count_crosscheck.csv',index=False)
    summary.to_csv(OUT/'summary_per_seed.csv',index=False); queries.to_csv(OUT/'per_query.csv',index=False)
    met=['returned_precision_pct','macro_recall_at3_pct','hit_at3_pct','no_reference_pool_rejection_pct','returned_tp_n','returned_fp_n','returned_nonexact_tp_n']
    agg=summary.groupby(['evaluation_group','policy'])[met].agg(['mean','std']);agg.columns=['_'.join(c) for c in agg.columns];agg.reset_index().to_csv(OUT/'summary_aggregate.csv',index=False)
    # Same sampled queries and same seed weights for each method. Seed judgments are shared.
    primary=queries[queries.evaluation_split.isin(m.GROUPS['primary_heldout'])]
    keys=primary[['evaluation_split','query_id']].drop_duplicates().sort_values(['evaluation_split','query_id'])
    ordered_keys=list(map(tuple,keys.to_numpy()));rng=np.random.default_rng(20261005);boot=[]
    def arrays(policy):
        a=primary[primary.policy.eq(policy)].set_index(['seed','evaluation_split','query_id'])
        return np.array([[[float(a.loc[(s,*q),c]) for c in ['positive_n','returned_tp_n','returned_fp_n','hit']] for q in ordered_keys] for s in SEEDS])
    target=arrays('expanded_verified_k10')
    for comparator in ['rule_only','all_bge','gpt6_sol_fullpool']:
        other=arrays(comparator); values=[]
        for start in range(0,10000,500):
            ix=rng.integers(0,len(keys),size=(min(500,10000-start),len(keys)))
            def calc(arr):
                a=arr[:,ix,:];pos=a[:,:,:,0];tp=a[:,:,:,1];fp=a[:,:,:,2];hit=a[:,:,:,3];valid=pos>0
                rec=np.divide(tp,pos,out=np.zeros_like(tp),where=valid).sum(axis=2)/valid.sum(axis=2)
                hr=(hit*valid).sum(axis=2)/valid.sum(axis=2)
                p=tp.sum(axis=2)/(tp+fp).sum(axis=2)
                return np.stack([p.mean(axis=0),rec.mean(axis=0),hr.mean(axis=0)],axis=1)*100
            values.append(calc(target)-calc(other))
        delta=np.concatenate(values)
        for i,name in enumerate(['return_precision','macro_recall_at3','hit_at3']):
            lo,hi=np.percentile(delta[:,i],[2.5,97.5]);boot.append({'comparison':'expanded_k10 minus '+comparator,'metric':name,'ci95_lower_pp':lo,'ci95_upper_pp':hi,'bootstrap_queries':218,'resamples':10000,'seed_judgments_shared':True})
    pd.DataFrame(boot).to_csv(OUT/'paired_query_bootstrap.csv',index=False)
    # Query-level outcomes for transparent differences; no subsequent rejudgment.
    compare=primary[primary.policy.isin(['expanded_verified_k10','rule_only','gpt6_sol_fullpool'])]
    compare.to_csv(OUT/'primary_query_outcomes.csv',index=False)
    qa.update(status='passed',independent_metric_checks=len(independent),threshold_retuning=False,output_labels_changed=False,script_sha256=sha(__file__))
    dump(OUT/'qa.json',qa)
    display=agg.reset_index();display=display[display.evaluation_group.eq('primary_heldout')]
    report=['扩展候选系统完整评估（已使用测试集上的探索）','主测试为218query/6540pairs，另2query/60pairs仅补充审计。最终列表至多3条。','K10在推理前指定；K3/K5共享uniontop10核验上下文，不能称三次独立GPT运行。','所有候选/核验输入与组合策略在新盲测前冻结；重建预测保存后才接入金标。','宏Recall@3和Hit@3仅在有正例查询上平均；返回精确率是实际列表TP/(TP+FP)。','下列数值为三BGE种子均值；GPT全池为同一份旧盲测重复作为对照，并非三次调用。','']
    for row in display.to_dict('records'):
        report.append(f"{row['policy']}: P={row['returned_precision_pct_mean']:.4f}%; 宏R@3={row['macro_recall_at3_pct_mean']:.4f}%; Hit@3={row['hit_at3_pct_mean']:.4f}%; TP={row['returned_tp_n_mean']:.3f}; FP={row['returned_fp_n_mean']:.3f}")
    report += ['','质量优劣必须同时看召回和错误参考；没有保证胜过所有基线。','未计量API费用/服务延迟；Codex代理工作时长不可作为API延迟。','新方法看过旧测试结果后设计；上述盲判防止答案直接泄漏，但不使旧测试变成新的独立确认集。']
    (OUT/'实验结果与适用范围.txt').write_text('\n'.join(report)+'\n')
    print('\n'.join(report))

if __name__=='__main__': main()
