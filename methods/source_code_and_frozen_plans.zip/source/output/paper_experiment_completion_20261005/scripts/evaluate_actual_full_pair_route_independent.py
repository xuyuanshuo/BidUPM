#!/usr/bin/env python3
"""Independent integrity, metrics, and resident GPU cost for actual full-pair run."""
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE.parent / 'rule_first_system_20261004/results/server'
spec = importlib.util.spec_from_file_location('frozen_pair_route', BASE / 'scripts/evaluate_exact_pair_route_before_cap.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
POLICIES = ('all_bge', 'exact_pair_bge', 'exact_pair_bge_qwen_threshold')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main(run):
    out = run / 'analysis'
    out.mkdir(exist_ok=True)
    checks, hashes = [], {}
    def check(name, cond, details=None):
        checks.append({'name': name, 'passed': bool(cond), 'details': details})
        assert cond, name
    def record(p):
        hashes[str(p.resolve())] = sha(p)
        return hashes[str(p.resolve())]
    manifest = json.loads((run / 'execution_manifest.json').read_text())
    record(run / 'execution_manifest.json')
    sm = json.loads((SOURCE / 'source_manifest.json').read_text())
    record(SOURCE / 'source_manifest.json')
    check('completed 27-condition label-blind execution', manifest['status'] == 'complete' and tuple(manifest['policies']) == POLICIES and manifest['repeats'] == 3 and manifest['pair_n'] == 6600 and manifest['query_n'] == 220 and not manifest['labels_accessed'] and not manifest['thresholds_retuned'])
    check('frozen runner bytes', record(BASE / 'scripts/run_full_pair_route.py') == manifest['script_sha256'])
    check('authoritative input hash', record(SOURCE / 'inputs.csv') == manifest['source_sha256'] == sm['inputs_sha256'])
    check('original BGE validation thresholds', {int(r['seed']): float(r['threshold']) for r in sm['runs']} == m.THRESHOLDS)
    qpath = BASE.parent / 'remote_experiments_20260923/runs/qwen3_4b_instruct_verifier/validation_thresholds.csv'
    check('frozen Qwen validation threshold file', record(qpath) == manifest['qwen_threshold_sha256'])
    qt = pd.read_csv(qpath)
    check('frozen Qwen validation threshold 12.75', float(qt.loc[qt.policy.eq('f1_opt'), 'threshold'].iloc[0]) == manifest['qwen_threshold'] == 12.75)
    f = m.inputs()
    rows = f.set_index('pair_id').to_dict('index')
    q = defaultdict(list)
    for r in f.to_dict('records'):
        q[r['evaluation_split'], r['query_id']].append(r)
    check('independently derived exact405/nonexact6195', f.exact_match.sum() == 405 and len(q) == 220)
    assert len(manifest['completed_runs']) == 3
    frames, differences, calls = [], [], []
    prior = pd.read_csv(BASE / 'results/exact_pair_route_before_cap/predictions_before_gold.csv', float_precision='round_trip')
    for r in manifest['completed_runs']:
        seed = int(r['seed'])
        path = run / r['output']
        check('actual prediction SHA ' + str(seed), record(path) == r['sha256'])
        raw = pd.read_csv(path, float_precision='round_trip')
        check('complete 3x6600 per seed ' + str(seed), len(raw) == 19800 and set(raw.policy) == set(POLICIES) and raw.seed.eq(seed).all() and not raw.duplicated(['policy', 'pair_id']).any() and raw.threshold.eq(m.THRESHOLDS[seed]).all())
        for policy, p in raw.groupby('policy'):
            p = p.set_index('pair_id')
            check('identity join ' + str((seed, policy)), set(p.index) == set(rows) and all(p.loc[pid, c] == rows[pid][c] for pid in rows for c in ['evaluation_split', 'query_id', 'candidate_id']))
            called = set(rows) if policy == 'all_bge' else {pid for pid, rr in rows.items() if not rr['exact_match']}
            scores, qscores = p.score.to_dict(), p.qwen_score.to_dict()
            bgeaccepted = {pid for pid in called if scores[pid] >= m.THRESHOLDS[seed]}
            qselected = bgeaccepted if policy == 'exact_pair_bge_qwen_threshold' else set()
            keep = {pid for pid in qselected if qscores[pid] >= 12.75} if qselected else bgeaccepted
            # For a Qwen policy with zero proposals, keep remains empty.
            if policy == 'exact_pair_bge_qwen_threshold':
                keep = {pid for pid in qselected if qscores[pid] >= 12.75}
            ranks = {}
            for pool in q.values():
                ranks.update(m.ranked(pool, scores, keep, 'score' if policy == 'all_bge' else 'exact_first'))
            for pid, rr in rows.items():
                ex = rr['exact_match'] if policy != 'all_bge' else 0
                check_values = (int(p.loc[pid, 'exact_match']) == ex, int(p.loc[pid, 'bge_called']) == int(pid in called),
                                int(p.loc[pid, 'qwen_called']) == int(pid in qselected), np.isfinite(scores[pid]) == (pid in called),
                                np.isfinite(qscores[pid]) == (pid in qselected), int(p.loc[pid, 'prediction']) == int(ex or pid in keep),
                                int(p.loc[pid, 'returned_rank']) == ranks.get(pid, 0))
                assert all(check_values), (seed, policy, pid)
            check('independent all decisions/calls/ranks ' + str((seed, policy)), True)
            calls.append({'seed': seed, 'policy': policy, 'bge_pairs': len(called), 'qwen_pairs': len(qselected), 'qwen_passed_pairs': len(keep) if qselected else 0})
            for ordering in ['exact_first', 'nonexact_first'] if policy != 'all_bge' else ['score']:
                rank2 = {}
                for pool in q.values():
                    rank2.update(m.ranked(pool, scores, keep, ordering))
                name = policy + ('_nonexact_first' if ordering == 'nonexact_first' else '')
                ff = p.reset_index().copy()
                ff['policy'] = name
                ff['returned_rank'] = ff.pair_id.map(rank2).fillna(0).astype(int)
                # Actual all-BGE saved exactmask is zero; use source exact for diagnostics.
                ff['source_exact_match'] = ff.pair_id.map({pid: rr['exact_match'] for pid, rr in rows.items()})
                frames.append(ff)
            if policy in ['all_bge', 'exact_pair_bge']:
                oldname = 'all_bge' if policy == 'all_bge' else 'exact_pair_bge_exact_priority'
                old = prior[(prior.seed.eq(seed)) & prior.policy.eq(oldname)].set_index('pair_id')
                scoreids = list(called)
                difference = np.array([scores[pid]-old.loc[pid, 'score'] for pid in scoreids])
                differences.append({'seed': seed, 'policy': policy, 'actual_vs_reconstruction_prediction_difference_n': int(p.prediction.ne(old.prediction.reindex(p.index)).sum()),
                                    'actual_vs_reconstruction_rank_difference_n': int(p.returned_rank.ne(old.returned_rank.reindex(p.index)).sum()),
                                    'score_difference_n': int((difference != 0).sum()), 'max_abs_score_difference': float(abs(difference).max()) if len(difference) else 0})
    predictions = pd.concat(frames, ignore_index=True)
    check('five policy/ranking components x3seedsx6600', len(predictions) == 99000 and predictions.prediction.isin([0, 1]).all() and not predictions.duplicated(['seed', 'policy', 'pair_id']).any())
    predictions.to_csv(out / 'actual_predictions_before_gold.csv', index=False)
    predictionhash, predictionutc = sha(out / 'actual_predictions_before_gold.csv'), datetime.now(timezone.utc).isoformat()
    check('timing file hash', record(run / 'timing.csv') == manifest['timing_sha256'])
    timing = pd.read_csv(run / 'timing.csv')
    check('27 actual unique timing records', len(timing) == 27 and set(zip(timing.seed, timing.policy, timing['repeat'])) == {(s, p, r) for s in m.SEEDS for p in POLICIES for r in range(3)} and np.isfinite(timing.seconds).all() and timing.seconds.gt(0).all())
    check('220 scope and pair/call counts per timing record', timing.queries.eq(220).all() and timing.pairs.eq(6600).all() and all(int(t.bge_pairs) == next(r['bge_pairs'] for r in calls if (r['seed'], r['policy']) == (t.seed, t.policy)) and int(t.qwen_pairs) == next(r['qwen_pairs'] for r in calls if (r['seed'], r['policy']) == (t.seed, t.policy)) for t in timing.itertuples()))
    median = timing.groupby(['seed', 'policy']).seconds.median().unstack('policy')
    costs = []
    for policy in POLICIES:
        sec = float(median[policy].mean())
        costs.append({'policy': policy, 'timing_query_n': 220, 'seeds': 3, 'repeats_per_seed': 3,
                      'seconds_mean_of_perseed_3repeat_medians': sec, 'ms_per_query': sec*1000/220,
                      'gpu_hourly_CNY': 2.88, 'amortized_CNY_per_1000_queries': sec/220*1000*2.88/3600,
                      'percent_of_within_experiment_all_bge_time': sec/float(median.all_bge.mean())*100,
                      'bge_pair_n': 6600 if policy == 'all_bge' else 6195,
                      'bge_call_saving_pct': 0 if policy == 'all_bge' else 405/6600*100,
                      'qwen_pair_n_mean': float(timing[timing.policy.eq(policy)].groupby('seed').qwen_pairs.first().mean()),
                      'qwen_prompt_token_n_mean': float(timing[timing.policy.eq(policy)].groupby('seed').qwen_prompt_tokens.first().mean())})
    pd.DataFrame(costs).to_csv(out / 'actual_timing_cost.csv', index=False)
    pd.DataFrame(calls).to_csv(out / 'actual_model_call_counts.csv', index=False)
    pd.DataFrame(differences).to_csv(out / 'actual_vs_frozen_reconstruction.csv', index=False)
    check('authoritative frozen labels hash after prediction saving', record(SOURCE / 'labels.csv') == sm['labels_sha256'])
    labels = pd.read_csv(SOURCE / 'labels.csv', usecols=['pair_id', 'final_label', 'difficulty']).set_index('pair_id')
    goldutc = datetime.now(timezone.utc).isoformat()
    gold, hard = labels.final_label.astype(int).to_dict(), labels.difficulty.eq('hard').to_dict()
    full, hp, listed = [], [], []
    for (seed, policy), g in predictions.groupby(['seed', 'policy']):
        pp, ranks = g.set_index('pair_id').prediction.to_dict(), g.set_index('pair_id').returned_rank.to_dict()
        for group, splits in m.GROUPS.items():
            ids = [pid for pid, r in rows.items() if r['evaluation_split'] in splits]
            hids = [pid for pid in ids if hard[pid]]
            qp = defaultdict(list)
            for pid in ids:
                qp[rows[pid]['evaluation_split'], rows[pid]['query_id']].append(pid)
            meta = {'seed': int(seed), 'policy': policy, 'evaluation_group': group, 'query_n': len(qp), 'pair_n': len(ids)}
            full.append({**meta, **m.confusion(ids, pp, gold)})
            hp.append({**meta, 'hard_pair_n': len(hids), 'hard_positive_n': sum(gold[p] for p in hids), **m.confusion(hids, pp, gold)})
            ret = [p for p in ids if ranks[p] > 0]
            tp, fp = sum(gold[p] for p in ret), sum(1-gold[p] for p in ret)
            htp, hfp = sum(gold[p] for p in ret if hard[p]), sum(1-gold[p] for p in ret if hard[p])
            posq, noq, hardq = [], [], []
            for pool in qp.values():
                rp = [p for p in pool if ranks[p] > 0]
                assert len(rp) <= 3 and sorted(ranks[p] for p in rp) == list(range(1, len(rp)+1))
                positive, hpos = sum(gold[p] for p in pool), sum(gold[p] for p in pool if hard[p])
                rt, ht = sum(gold[p] for p in rp), sum(gold[p] for p in rp if hard[p])
                if positive: posq.append((rt/positive, int(rt>0)))
                else: noq.append(int(not rp))
                if hpos: hardq.append((ht/hpos, int(ht>0)))
            hpositive = sum(gold[p] for p in hids)
            listed.append({**meta, 'returned_tp_n': tp, 'returned_fp_n': fp, 'returned_fn_n': sum(gold[p] for p in ids)-tp,
                           'returned_precision_pct': 100*tp/(tp+fp) if tp+fp else np.nan,
                           'macro_recall_at3_pct': 100*np.mean([x[0] for x in posq]), 'hit_at3_pct': 100*np.mean([x[1] for x in posq]),
                           'no_reference_pool_rejection_pct': 100*np.mean(noq) if noq else np.nan,
                           'hard_positive_n': hpositive, 'returned_hard_tp_n': htp, 'returned_hard_fp_n': hfp,
                           'hard_returned_precision_pct': 100*htp/(htp+hfp) if htp+hfp else np.nan,
                           'hard_micro_recall_at3_pct': 100*htp/hpositive if hpositive else np.nan,
                           'hard_macro_recall_at3_pct': 100*np.mean([x[0] for x in hardq]) if hardq else np.nan,
                           'hard_hit_at3_pct': 100*np.mean([x[1] for x in hardq]) if hardq else np.nan})
            sub = g[g.evaluation_split.isin(splits)]
            for hardonly, target in [(False, full[-1]), (True, hp[-1])]:
                z = sub[sub.pair_id.map(hard)] if hardonly else sub
                y = z.pair_id.map(gold)
                cc = {'tp': int((z.prediction.eq(1)&y.eq(1)).sum()), 'fp': int((z.prediction.eq(1)&y.eq(0)).sum()),
                      'fn': int((z.prediction.eq(0)&y.eq(1)).sum()), 'tn': int((z.prediction.eq(0)&y.eq(0)).sum())}
                check('independent vector confusion ' + str((seed, policy, group, hardonly)), all(target[k] == v for k,v in cc.items()))
    for name, vals in [('full_pair_metrics', full), ('hard_pair_metrics', hp), ('list_metrics', listed)]:
        table = pd.DataFrame(vals)
        table.to_csv(out / f'{name}.csv', index=False)
        num = [c for c in table if c not in ['seed','policy','evaluation_group'] and pd.api.types.is_numeric_dtype(table[c])]
        aggregate = table.groupby(['evaluation_group','policy'])[num].mean().reset_index()
        aggregate['condition_n'] = 3
        aggregate.to_csv(out / f'{name}_aggregate.csv', index=False)
    check('read source/output bytes unchanged', all(sha(p)==h for p,h in hashes.items()))
    qa = {'status':'passed', 'checks':checks, 'source_sha256':hashes, 'prediction_sha256_before_gold':predictionhash,
          'prediction_completed_before_gold_utc':predictionutc, 'first_gold_join_utc':goldutc,
          'repeat_rank_stability_limitation':'Runner asserts three repeats rank-identical, but only one prediction CSV per seed retained; cannot recompute repeat agreement.',
          'weight_verification_limitation':'Remote checkpoint bytes not locally present; runner checks each source-manifest file hash before model load. Identity verification remains execution-attested.',
          'cost_scope':'220-query resident GPU batch inference, synchronized gate/tokenize/BGE/selected-Qwen/merge; excludes loading/retrieval/file IO. Perseed median3 thenmean3. 2.88CNY/hour amortized, not invoice. No primary218 isolated timing, GPT API cost or full hybrid latency inference.',
          'metric_scope':'Full pair and hard pair classification use ALL explicit binary decisions; list metrics use capped3 final lists. Both ranking components are prespecified retrospective exploration, never select a test-result winner.',
          'no_labels_used_for_selection_or_ranking':True,'no_threshold_retuning':True,'no_600_provisional_gold':True,
          'frozen_reconstruction_comparison':differences,'script_sha256':sha(__file__)}
    (out/'qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(pd.DataFrame(costs).to_string(index=False))
    print(pd.read_csv(out/'hard_pair_metrics_aggregate.csv').query("evaluation_group in ['locked100','primary218']").to_string(index=False))


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--run',type=Path,required=True)
    a=p.parse_args()
    main(a.run.resolve())
