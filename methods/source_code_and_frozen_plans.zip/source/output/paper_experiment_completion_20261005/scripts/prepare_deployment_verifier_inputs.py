#!/usr/bin/env python3
"""Freeze Qwen-only deployment inputs from completed BGE runs; never gold."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import shutil
import pandas as pd
import numpy as np

BASE=Path(__file__).resolve().parents[1]
DEPLOY=BASE/'deployment_verifier_600_alberta'
OLD=BASE.parent/'rule_first_system_validation_20261005'
REMOTE=BASE.parent/'remote_experiments_20260923'
SEEDS=(20260904,20260905,20260906)
THRESHOLDS={20260904:9.1875,20260905:-1.453125,20260906:8.4375}
FIELDS=tuple(f'{side}_{field}' for side in ('query','candidate') for field in ('description','normalized_description','normalized_unit','category','spec_tokens'))


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def canonical(v):return ' '.join(re.sub(r'[^a-z0-9]+',' ',str(v).lower().replace('&',' and ')).split())
def unit(v):return ' '.join(str(v).lower().split())
def exact(f):
    qd=f.query_normalized_description.map(canonical);cd=f.candidate_normalized_description.map(canonical)
    qu=f.query_normalized_unit.map(unit);cu=f.candidate_normalized_unit.map(unit)
    return qd.ne('')&qu.ne('')&qd.eq(cd)&qu.eq(cu)


def main():
    assert not DEPLOY.exists(),'Refuse to overwrite frozen deployment input'
    inp=DEPLOY/'inputs';(inp/'source_bge').mkdir(parents=True)
    csource=BASE.parent/'internal_hard_challenge_20260928/constructed_600/model_inputs_only.csv'
    asource=OLD/'results/raw_alberta_model/inference_pairs_cleaned.csv'
    hashes={str(p.resolve()):sha(p) for p in [csource,asource,BASE/'results/challenge600_real_gpu/execution_manifest.json',
              OLD/'results/raw_alberta_scope_core/execution_manifest.json',REMOTE/'runs/qwen3_4b_instruct_verifier/manifest.json',
              REMOTE/'runs/qwen3_4b_instruct_verifier/validation_thresholds.csv',REMOTE/'scripts/local_experiment_utils.py',
              REMOTE/'scripts/run_open_llm_verifier_local.py',BASE/'scripts/run_deployment_qwen_verifier.py']}
    # Explicit field allowlists exclude item codes, provisional construction labels,
    # human labels, difficulty, model judgments, and all other source metadata.
    c=pd.read_csv(csource,usecols=['pair_id',*FIELDS],dtype=str,keep_default_na=False)
    a=pd.read_csv(asource,usecols=['pair_id','evaluation_split','query_id','source_year','candidate_id',*FIELDS],dtype=str,keep_default_na=False)
    assert len(c)==600 and c.pair_id.is_unique and len(a)==67635 and a.pair_id.is_unique
    c=c[['pair_id',*FIELDS]]
    for side in ('query','candidate'):a[f'{side}_description']=a[f'{side}_normalized_description']
    a=a[['pair_id','evaluation_split','query_id','source_year','candidate_id',*FIELDS]]
    c.to_csv(inp/'model_inputs_challenge600.csv',index=False)
    a.to_csv(inp/'model_inputs_alberta_scope_core.csv',index=False)
    cmanifest=json.loads((BASE/'results/challenge600_real_gpu/execution_manifest.json').read_text())
    amanifest=json.loads((OLD/'results/raw_alberta_scope_core/execution_manifest.json').read_text())
    # The existing BGE manifests were independently audited earlier. Freeze their
    # actual score bytes again and verify threshold application without labels.
    conditions=[]
    for dataset,source,modelinput,yearvalues in [('challenge600',c,'model_inputs_challenge600.csv',[None]),
               ('alberta_scope_core',a,'model_inputs_alberta_scope_core.csv',[2024,2026])]:
        for seed in SEEDS:
            p=BASE/f'results/challenge600_real_gpu/bge_hard_seed_{seed}.csv' if dataset=='challenge600' else OLD/f'results/raw_alberta_scope_core/predictions_scope_core_seed_{seed}.csv'
            hashes[str(p.resolve())]=sha(p)
            target=inp/'source_bge'/f'{dataset}_seed_{seed}.csv';shutil.copyfile(p,target)
            bge=pd.read_csv(p,float_precision='round_trip')
            assert bge.pair_id.is_unique and bge.pair_id.tolist()==source.pair_id.tolist() and np.isfinite(bge.score).all()
            assert bge.threshold.eq(THRESHOLDS[seed]).all() and bge.prediction.eq(bge.score.ge(THRESHOLDS[seed]).astype(int)).all()
            if dataset=='alberta_scope_core':assert bge.seed.eq(seed).all() and bge.variant.eq('scope_core').all()
            full=source.merge(bge[['pair_id','score','prediction']],on='pair_id',validate='one_to_one',sort=False)
            full['exact_match']=exact(full).astype(int)
            for year in yearvalues:
                part=full if year is None else full[full.source_year.eq(str(year))]
                conditions.append({'condition_id':dataset+(f'_{year}' if year else '')+f'_seed_{seed}',
                     'dataset':dataset,'source_year':year,'seed':seed,'model_input_file':modelinput,
                     'bge_prediction_file':str(target.relative_to(inp)),'bge_threshold':THRESHOLDS[seed],
                     'pair_n':len(part),'query_pool_n':None if dataset=='challenge600' else int(part.query_id.nunique()),
                     'exact_pair_n':int(part.exact_match.sum()),'bge_positive_pair_n':int(part.prediction.sum()),
                     'qwen_selected_pair_n':int((part.prediction.eq(1)&part.exact_match.eq(0)).sum())})
    qman=REMOTE/'runs/qwen3_4b_instruct_verifier/manifest.json'
    qthreshold=REMOTE/'runs/qwen3_4b_instruct_verifier/validation_thresholds.csv'
    qm=json.loads(qman.read_text());qt=pd.read_csv(qthreshold)
    assert qm['base_model']=='Qwen/Qwen3-4B-Instruct-2507' and float(qt.loc[qt.policy.eq('f1_opt'),'threshold'].iloc[0])==12.75
    frozenpaths=sorted(p for p in inp.rglob('*') if p.is_file())
    plan={'status':'FROZEN_BEFORE_QWEN_ONLY_INFERENCE','created_utc':datetime.now(timezone.utc).isoformat(),
          'selection':'All BGE-positive nonexact pairs, using actual completed full BGE predictions and each original seed threshold; no query early-stop or topK selection.',
          'exact':'Nonempty canonical normalized description plus normalized unit equality; exact pairs accepted directly and never Qwen-called.',
          'source_transformation':'Challenge600: allowlisted five fields only. Alberta scope_core: cleaned descriptions replaced by their normalized description, exactly reproducing the prior real BGE core representation.',
          'output':'Retain source BGE scores/predictions and all pair identities. accepted=exact OR (selected AND Qwen score>=12.75); review_pending=selected AND Qwen score<12.75; BGE-positive nonexact candidates remain in the record even if not verifier-accepted. No forced top3.',
          'qwen_model':qm['base_model'],'qwen_revision':qm['base_model_revision'],'qwen_threshold':12.75,
          'qwen_original_manifest_sha256':sha(qman),'qwen_original_threshold_file_sha256':sha(qthreshold),
          'qwen_model_weight_sha256':qm['base_model_weight_sha256'],'qwen_model_load_path':qm['base_model_load_path'],
          'source_serializer_sha256':sha(REMOTE/'scripts/local_experiment_utils.py'),
          'source_prompt_renderer_sha256':sha(REMOTE/'scripts/run_open_llm_verifier_local.py'),
          'batch_size':24,'max_length':256,'repeats':3,'new_bge_inference':False,'new_training':False,'threshold_retuning':False,
          'human_gold_read':False,'construction_labels_read':False,'quality_metrics_computed':False,
          'timing_scope':'Qwen-only resident synchronized selected-pair serialization, chat rendering, tokenization, inference, score transfer. Excludes prior BGE, model loading, file IO, retrieval, and merge/export. Not full system latency.',
          'conditions':conditions,'source_sha256':hashes,'input_file_sha256':{str(p.relative_to(inp)):sha(p) for p in frozenpaths},
          'builder_sha256':sha(__file__),'runner_sha256':sha(BASE/'scripts/run_deployment_qwen_verifier.py'),
          'no_gold_limitation':'Both supplemental collections lack adjudicated independent human gold. Call/pass/disagreement/coverage counts are not accuracy.'}
    dump(inp/'input_manifest.json',plan)
    pd.DataFrame(conditions).to_csv(DEPLOY/'frozen_condition_counts.csv',index=False)
    print(pd.DataFrame(conditions).to_string(index=False))
    print('TOTAL_SELECTED_QWEN_CALLS_PER_REPEAT',sum(r['qwen_selected_pair_n'] for r in conditions))


if __name__=='__main__':main()
